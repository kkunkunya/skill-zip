# Results-Driven RL 经验积累

> 本文档由技能执行过程中动态更新，记录有效模式和失败教训。
> 更新原则：精炼而非堆砌，同类经验只保留最有效的 3-5 条，过时经验直接替换。

## 有效模式

- **超参数快速收敛组合**：PPO 默认起点 lr=3e-4, clip=0.2, gamma=0.99, gae_lambda=0.95, batch_size=64, n_epochs=10；不收敛先砍 lr 到 1e-4
- **奖励函数设计**：各分量量级对齐是第一优先级；用 `reward = w1*norm(cost) + w2*norm(satisfaction) - w3*norm(penalty)` 归一化后再加权，避免某项主导
- **reward hacking 防御**：售电/放电等可产生负成本的动作必须加价差约束（售电价 = 买电价 * 0.3）；满意度等指标必须与动作连续相关，不能只在终态计算
- **训练日志必备项**：每 10 ep 输出 reward_mean / cost_mean / viol_rate / lr / best_mark，用 flush=True 确保实时可见
- **评估可靠性**：环境/奖励任何改动后必须删旧模型重训；torch.load 加 weights_only=False（PyTorch 2.6+）

## 失败教训

- **约束阈值用绝对值**：用 1e-2 这种绝对阈值导致 viol=1.0 恒定，动态裁剪完全失效。必须用相对值如 `load_peak * 0.02~0.05`
- **w_penalty 过大**：w_penalty=10.0 导致奖励深度负值永远不收敛，应从 0.5-2.0 开始
- **grid_cost 允许负值**：Agent 发现售电可获利后疯狂套利，必须加买卖价差

## 待验证假设

（初始为空，使用过程中积累）

---
*最近更新：2026-02-17*
