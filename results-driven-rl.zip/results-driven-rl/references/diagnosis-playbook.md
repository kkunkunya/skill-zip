# RL 训练诊断手册

## 诊断流程

```
训练日志 → 检查3指标（reward趋势 / viol值 / 算法排序）→ 定位根因 → 修复 → 重跑100ep验证
```

---

## 奖励函数审查清单（训练前必做）

在写训练代码前，逐条检查奖励函数设计：

### 检查1: 有没有可被利用的漏洞？

```python
# ❌ 错误：grid_cost = price * grid_power
#    当 grid_power < 0（售电），grid_cost 为负
#    reward = -w_cost * grid_cost → 售电变成正奖励
#    Agent 会疯狂售电套利，不管功率平衡

# ✅ 正确：买卖价差，售电收益远低于购电成本
if grid_power >= 0:
    grid_cost = price * grid_power          # 购电原价
else:
    grid_cost = price * 0.3 * grid_power    # 售电按上网电价 30%
```

### 检查2: 每个指标是否与动作相关？

```python
# ❌ 错误：满意度只在 EV 离站时计算
#    一天中大部分时段没有 EV 离站 → satisfaction = 1.0
#    所有算法的 24 步平均满意度几乎相同
if not leaving:
    satisfaction = 1.0  # 没人离站就给满分

# ✅ 正确：用在站 EV 的充电进度（与充电动作直接相关）
if n_present > 0:
    satisfaction = mean(min(ev.soc / ev.target_soc, 1.0) for ev in present)
```

### 检查3: 惩罚权重量级是否合理？

```python
# 逐项估算每步各奖励分量典型值
for key in ['grid_cost', 'imbalance_penalty', 'clip_penalty', 'satisfaction']:
    vals = [info[key] for info in episode_infos]
    print(f"  {key}: mean={np.mean(vals):.2f}")

# 确保没有单项 >10x 其他项
# 典型合理范围：各分量在 1~50 之间
```

### 检查4: 约束阈值是否与系统量级匹配？

```python
# ❌ 错误：用绝对值阈值
violation = 1.0 if (imbalance > 1e-2) else 0.0  # 0.01 kW 太严

# ✅ 正确：用系统量级的百分比
violation = 1.0 if (imbalance > load_peak * 0.02) else 0.0  # 负荷的 2%
# load_peak=300 kW → 阈值 = 6 kW，合理
```

---

## 症状1: violation 恒定 1.0

**表现**: `viol=1.000` 从头到尾不变

**根因**: 约束判定阈值过严

```python
# 错误：0.01 kW 不平衡就算违反
violation = 1.0 if (imbalance > 1e-2) else 0.0

# 正确：容忍负荷 2-5% 的不平衡
violation = 1.0 if (imbalance > load_peak * 0.02) else 0.0
```

**连锁影响**: 动态裁剪 clip_eps 始终在上限 → PPO 学不精细

## 症状2: 奖励全程深度负值

**表现**: reward 在 -5000 ~ -20000，无上升趋势

**修复**:
| 参数 | 错误值 | 推荐值 |
|------|--------|--------|
| w_penalty | 10.0 | 0.5-2.0 |
| w_satisfaction | 0.5 | 1.0-3.0 |
| clip_penalty_coef | 0.1 | 0.01-0.05 |

## 症状3: 日成本为负值（评估时）

**表现**: 评估输出 `cost=-4598.5`，RL 算法成本全为负

**根因**: Reward hacking — Agent 学会大量向电网售电获利

```python
# grid_cost = price * grid_power，grid_power 可为负
# reward = -w_cost * grid_cost → 售电越多奖励越高
# Agent 策略：疯狂售电，不管功率平衡（因为售电利润 >> 不平衡惩罚）
```

**修复**: 加买卖价差
```python
if grid_power >= 0:
    grid_cost = price * grid_power
else:
    grid_cost = price * 0.3 * grid_power  # 售电只给 30% 价格
```

**重要**: 改完奖励函数后**必须删旧模型+重训**，旧模型在新环境下表现无意义。

## 症状4: 所有算法某指标完全相同

**表现**: 5 个算法的满意度都是 0.792

**根因**: 该指标不依赖算法动作

**诊断方法**:
1. 检查指标计算公式，确认是否用到了 action
2. 用随机策略跑 10 个 seed，看指标是否都相同
3. 如果相同 → 指标是环境固有属性，不是策略质量度量

**典型案例**: 满意度只在 EV 离站时刻计算，其余时段固定为 1.0 → 所有算法平均值几乎相同

**修复**: 改为连续、与动作相关的指标

## 症状5: PPO 不如 baseline

**排查**: update_epochs(推荐5-15)、lr_actor(1e-4~5e-4)、网络([128,128])、entropy_coef(0.005-0.02)

## 症状6: 训练速度极慢

**排查**: CPU/GPU设备、环境step复杂度、SAC天然2-3x慢于PPO属正常

---

## 评估阶段踩坑

### 坑1: PyTorch 2.6 torch.load 报错

```
_pickle.UnpicklingError: Weights only load failed...
```

**原因**: PyTorch 2.6 将 `torch.load` 默认值从 `weights_only=False` 改为 `True`

**修复**: 所有 `torch.load` 加参数
```python
ckpt = torch.load(path, map_location=self.device, weights_only=False)
```

### 坑2: 模型保存目录不存在

```
RuntimeError: Parent directory results/ch4/models does not exist
```

**修复**: save 方法内加 makedirs
```python
def save(self, path: str):
    import os; os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save({"actor": ..., "critic": ...}, path)
```

### 坑3: 改环境后用旧模型评估

**表现**: 评估结果异常（成本/违约率/满意度与预期不符）

**根因**: 模型在旧环境训练，新环境的奖励/约束已改变

**铁律**: 环境改了 → 删模型 → 重训 → 再评估
```bash
rm -rf results/ch4/models/* results/ch4/logs/*
# 重新训练所有算法
```

### 坑4: unzip 部署不干净

**表现**: 新代码上传后行为异常，旧逻辑仍在生效

**根因**: `unzip -o` 只覆盖同名文件，不删除旧文件中新包里没有的文件

**修复**:
```bash
rm -rf src/ configs/ pyproject.toml   # 先删旧代码
unzip -o new_package.zip              # 再解压新代码
```

---

## 快速验证脚本

```python
env = build_env(cfg)
for ep in range(100):
    obs, _ = env.reset(seed=ep)
    done, ep_r, ep_v = False, 0, 0
    while not done:
        action = env.action_space.sample()
        obs, r, term, trunc, info = env.step(action)
        done = term or trunc
        ep_r += r
        ep_v += info.get("violation", 0)
    if ep < 5:
        print(f"EP{ep}: reward={ep_r:.1f}, viol={ep_v:.0f}/{24}")
# 随机策略 reward 应在合理负值范围（-100 ~ -500）
# 如果 reward = -50000 → 惩罚太重
# 如果 reward = +5000 → 有 reward hacking（售电套利？）
# 如果 viol = 24/24 → 阈值太严
# 如果所有 seed 满意度相同 → 指标不依赖动作
```
