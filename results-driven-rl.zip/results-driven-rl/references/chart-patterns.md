# 论文图表模式（Matplotlib/Seaborn 模板）

## 通用设置

```python
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams.update({
    "font.family": "SimHei",        # 中文黑体
    "axes.unicode_minus": False,    # 负号显示
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox_inches": "tight",
})

# 统一配色（5算法）
COLORS = {
    "PPO": "#E63946",   # 红（主角突出）
    "SAC": "#457B9D",   # 蓝
    "DDPG": "#2A9D8F",  # 青
    "DQN": "#E9C46A",   # 黄
    "Rule": "#A8A8A8",  # 灰
}
ALGO_ORDER = ["PPO", "SAC", "DDPG", "DQN", "Rule"]
```

## 图表1: 收敛曲线

```python
def plot_convergence(csv_dir, out_path, window=50):
    fig, ax = plt.subplots(figsize=(8, 5))
    for algo in ALGO_ORDER:
        path = csv_dir / f"train_{algo.lower()}.csv"
        if not path.exists():
            continue
        df = pd.read_csv(path)
        rewards = df["reward"].rolling(window, min_periods=1).mean()
        ax.plot(rewards, label=algo, color=COLORS[algo], linewidth=1.5)
    ax.set_xlabel("训练轮次")
    ax.set_ylabel("累计奖励（滑动平均）")
    ax.legend(loc="lower right", framealpha=0.9)
    ax.grid(alpha=0.3)
    fig.savefig(out_path)
    plt.close(fig)
    print(f"  收敛曲线 → {out_path}", flush=True)
```

## 图表2: 算法对比表（LaTeX）

```python
def make_comparison_table(metrics_csv, out_path):
    df = pd.read_csv(metrics_csv)
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{算法性能对比}",
        r"\begin{tabular}{lcccc}",
        r"\toprule",
        r"算法 & 日成本(元) & 违约率(\%) & 满意度 & 收敛轮次 \\",
        r"\midrule",
    ]
    for _, row in df.iterrows():
        name = row["algorithm"].upper()
        conv = int(row["converge_episode"]) if pd.notna(row.get("converge_episode")) else "-"
        bold = r"\textbf{" if name == "PPO" else ""
        end = "}" if name == "PPO" else ""
        lines.append(
            f"  {bold}{name}{end} & {row['daily_cost']:.1f} & "
            f"{row['violation_rate']*100:.1f} & {row['satisfaction']:.3f} & {conv} \\\\"
        )
    lines += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")
    print(f"  对比表 → {out_path}", flush=True)
```

## 图表3: 调度堆叠图

```python
def plot_schedule(schedule_csv, out_path):
    df = pd.read_csv(schedule_csv)
    fig, ax1 = plt.subplots(figsize=(10, 5))

    hours = df["hour"]
    ax1.fill_between(hours, 0, df["pv_power"], alpha=0.4, label="光伏", color="#F4A261")
    ax1.fill_between(hours, 0, -df["ess_power"], alpha=0.4, label="储能", color="#2A9D8F")
    ax1.bar(hours, df["ev_power"], width=0.6, alpha=0.6, label="EV充电", color="#457B9D")
    ax1.plot(hours, df["load_power"], "k--", linewidth=1.5, label="负荷")
    ax1.plot(hours, df["grid_power"], "r-", linewidth=1.5, label="电网交互")

    ax1.set_xlabel("时刻 (h)")
    ax1.set_ylabel("功率 (kW)")
    ax1.legend(loc="upper left", ncol=3, fontsize=8)
    ax1.set_xticks(range(0, 25, 2))
    ax1.grid(alpha=0.3)

    # 叠加电价（右轴）
    ax2 = ax1.twinx()
    ax2.step(hours, df["price"], where="mid", color="#E63946", alpha=0.5, linewidth=1)
    ax2.set_ylabel("电价 (元/kWh)", color="#E63946")
    ax2.tick_params(axis="y", labelcolor="#E63946")

    fig.savefig(out_path)
    plt.close(fig)
    print(f"  调度图 → {out_path}", flush=True)
```

## 图表4: 消融对比柱状图

```python
def plot_ablation(ablation_csv, out_path):
    df = pd.read_csv(ablation_csv)
    fig, ax = plt.subplots(figsize=(6, 4))

    labels = {"full": "完整模型", "no_clip": "去除动态裁剪",
              "no_per": "去除PER", "standard": "标准PPO"}
    colors = ["#E63946", "#457B9D", "#2A9D8F", "#A8A8A8"]

    names = [labels.get(v, v) for v in df["variant"]]
    vals = df["avg_reward"]
    bars = ax.bar(names, vals, color=colors, edgecolor="white", linewidth=0.5)

    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5,
                f"{val:.0f}", ha="center", va="bottom", fontsize=9)

    ax.set_ylabel("平均奖励")
    ax.set_title("消融实验对比")
    ax.grid(axis="y", alpha=0.3)
    fig.savefig(out_path)
    plt.close(fig)
    print(f"  消融图 → {out_path}", flush=True)
```

## 图表5: EV 满意度曲线

```python
def plot_ev_satisfaction(ev_csv, out_path):
    df = pd.read_csv(ev_csv)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(df["hour"], df["satisfaction"], "o-", color="#E63946", linewidth=1.5)
    ax.fill_between(df["hour"], df["satisfaction"], alpha=0.2, color="#E63946")
    ax.set_xlabel("时刻 (h)")
    ax.set_ylabel("EV 用户满意度")
    ax.set_ylim(0, 1.05)
    ax.set_xticks(range(0, 25, 2))
    ax.grid(alpha=0.3)
    fig.savefig(out_path)
    plt.close(fig)
    print(f"  满意度曲线 → {out_path}", flush=True)
```

## 完整出图脚本调用模式

```python
# 在 plot_single.py 中的 main() 里依次调用：
fig_dir = Path(cfg["training"]["figure_dir"])
fig_dir.mkdir(parents=True, exist_ok=True)
log_dir = Path(cfg["training"]["log_dir"])

plot_convergence(log_dir, fig_dir / "convergence.png")
make_comparison_table(log_dir / "eval_metrics.csv", fig_dir / "comparison.tex")
plot_schedule(log_dir / "schedule_ppo.csv", fig_dir / "schedule.png")
plot_ablation(log_dir / "ablation_metrics.csv", fig_dir / "ablation.png")
plot_ev_satisfaction(log_dir / "ev_soc_ppo.csv", fig_dir / "ev_satisfaction.png")
```
