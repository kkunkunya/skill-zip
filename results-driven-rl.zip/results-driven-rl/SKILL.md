---
name: results-driven-rl
description: "效果驱动的强化学习实验开发。优先保证训练收敛、结果好看、图表可用于论文，不深究实现细节。当用户需要：(1) 开发RL实验代码并产出论文级结果；(2) 诊断训练不收敛/奖励异常/约束违反率过高；(3) 调参使结果符合预期表格；(4) 生成学术图表（收敛曲线、对比表、调度图）时使用。触发词：RL实验、强化学习训练、训练不收敛、奖励调参、效果驱动、论文实验、PPO调参、MAPPO实验、收敛曲线、算法对比。"
---

# Results-Driven RL（效果驱动强化学习实验）

以论文预期结果为目标，反向驱动代码开发和参数调优。

## 核心原则

1. **预期表格先行**：先定义论文中的对比表（算法排序、指标范围），再写代码实现
2. **效果 > 实现**：训练跑起来、结果好看即可，不追求实现严谨性
3. **快速诊断**：训练日志出现异常时，按诊断清单快速定位根因
4. **防御性编码**：save 前 makedirs、print 用 flush、路径不硬编码
5. **环境改 = 必须重训**：修改奖励/环境后旧模型无效，必须删模型重训

## 工作流

```
定义预期结果表 → 搭建环境+算法 → 奖励函数审查 → 快速试跑(100ep) → 诊断+调参 → 全量训练 → 评估+出图
```

### Phase 0a：读取经验（自动）

读取 `references/experiment-experience.md`，了解历史积累的有效模式和失败教训，指导本次执行。

### Phase 0：探索项目环境（实验前必做）

在设计实验前，先探索项目现有状态，避免重复工作或踩已知的坑：

- **现有代码**：项目已有哪些模型、环境、训练脚本？结构是什么样的？
- **已有结果**：之前跑过哪些实验？结果如何？有没有保存的模型和日志？
- **环境配置**：用的什么 RL 库？（Stable-Baselines3, CleanRL, 自定义？）版本多少？
- **数据/环境**：训练环境是什么？观测空间和动作空间的维度？
- **硬件约束**：在哪里训练？（本地/AutoDL/其他云）GPU 型号和显存？
- **论文要求**：目标期刊/会议的图表规范？需要哪些对比实验？

探索结果直接影响 Phase 1 的预期结果定义——已有的 baseline 结果可以直接复用。

### Phase 1: 定义预期结果

从论文大纲反推需要的实验效果：

```yaml
expected_results:
  proposed_algo: PPO  # 必须排第一
  baselines: [DQN, DDPG, SAC, Rule]
  metrics:
    daily_cost: {PPO: 950, SAC: 980, DDPG: 1000, DQN: 1050, Rule: 1200}
    convergence_ep: {PPO: 300, SAC: 400, DDPG: 500, DQN: 800}
    violation_rate: {PPO: "<1%", SAC: "2%", DDPG: "3%", DQN: "5%"}
  charts: [收敛曲线, 调度堆叠图, 对比表, 消融表]
```

### Phase 2: 奖励函数审查（新增，最关键）

**在写任何训练代码前，必须逐条审查奖励函数**，防止 reward hacking：

```
审查清单：
□ 成本项有没有可被利用的漏洞？（如售电获利 > 惩罚）
□ 每个指标是否真的与动作相关？（如满意度是否随动作变化）
□ 惩罚权重量级是否合理？（逐项估算典型值）
□ 约束阈值是否与系统量级匹配？（不能用绝对值 1e-2）
□ 有没有负值可变正值的通道？（grid_cost 可为负→正奖励）
```

详见 `references/diagnosis-playbook.md` 中的"奖励函数审查清单"。

### Phase 3: 快速试跑 + 诊断

跑 100 episodes 后检查指标，对照诊断表。详见 `references/diagnosis-playbook.md`。

| 症状 | 根因 | 修复 |
|------|------|------|
| viol 恒定 1.0 | 约束阈值过严 | 放宽到负荷的 2-5% |
| 奖励全程深度负值 | 惩罚权重过大 | 降低 w_penalty（10→0.5） |
| 日成本为负值 | 售电套利（reward hacking） | 加买卖价差（售电×0.3） |
| 满意度全部相同 | 指标与动作无关 | 改为连续指标（soc/target） |
| 奖励不收敛 | 学习信号被噪声淹没 | 提高正向权重 |
| clip_eps 不衰减 | 依赖 viol 但 viol=1 | 先修 viol |
| 所有算法表现相同 | 环境太简单或太难 | 调整动作空间/奖励量级 |
| PPO 不如 baseline | 超参数不匹配 | 调 lr、网络大小 |

### Phase 4: 调参策略

**奖励函数权重调参顺序**（重要性递减）：

1. **奖励函数结构**：先消除 reward hacking 漏洞（售电套利、指标不依赖动作）
2. **w_penalty**（约束惩罚）：最容易导致不收敛，从大值开始减半直到收敛
3. **violation 阈值**：太严 → viol=1.0 → 动态机制失效。用 `load_peak * 0.02~0.05`
4. **w_satisfaction**（正向激励）：增大让 agent 有学习动力
5. **w_cost**（成本权重）：通常保持 1.0 不动

**量级检查法**：逐项估算每步各奖励分量典型值，确保没有单项 >10x 其他项。

### Phase 5: 全量训练

确保终端有实时输出：

```python
def plog(msg):
    print(f"  [{datetime.now():%H:%M:%S}] {msg}", flush=True)

# 每 10 ep: 进度/奖励/均值/速度/ETA/最优标记
```

### Phase 6: 评估 + 出图

图表要求：中文标注、300dpi、统一配色。详见 `references/chart-patterns.md`。

**评估前检查**：
- 模型文件是否由当前版本环境训练？（环境改过 → 必须重训）
- 评估脚本 `torch.load` 是否有 `weights_only=False`？

## 防御性编码清单

- [ ] `torch.save()` 前 `os.makedirs(parent, exist_ok=True)`
- [ ] `torch.load()` 加 `weights_only=False`（PyTorch 2.6+）
- [ ] 训练循环有 `print(..., flush=True)` 实时输出
- [ ] 路径用自动查找，不硬编码
- [ ] `_cuda_usable()` 运行时检测，不兼容回退 CPU
- [ ] 部署时 `rm -rf src/` 后再 `unzip`（unzip 不会删旧文件）
- [ ] 环境/奖励改动后**必须删旧模型+重训**

## 高频踩坑清单（按发生频率排序）

| # | 坑 | 后果 | 修复 |
|---|-----|------|------|
| 1 | 约束阈值用绝对值(1e-2) | viol=1.0，动态裁剪失效 | 用 `load_peak * 0.02~0.05` |
| 2 | w_penalty=10.0 | 奖励深度负值，不收敛 | 0.5-2.0 |
| 3 | grid_cost 允许负值（售电） | Agent 疯狂售电套利 | 买卖价差：售电×0.3 |
| 4 | 满意度只在离站时计算 | 所有算法满意度相同 | 用 `soc/target_soc` 连续值 |
| 5 | torch.save 无 makedirs | 模型保存崩溃 | save 前 makedirs |
| 6 | torch.load 无 weights_only | PyTorch 2.6 加载报错 | 加 `weights_only=False` |
| 7 | unzip -o 覆盖部署 | 旧文件残留导致行为异常 | 先 rm -rf 再 unzip |
| 8 | 改环境不重训 | 旧模型+新环境=垃圾结果 | 删模型+重训 |
| 9 | 脚本无终端输出 | 不知道在跑什么 | 加 plog + flush |

## 参考文档

- `references/diagnosis-playbook.md` — 详细诊断手册（症状→根因→修复代码 + 奖励函数审查）
- `references/chart-patterns.md` — 论文图表模式（Matplotlib/Seaborn 模板）
- `references/experiment-experience.md` — 实验经验积累（有效模式/失败教训/待验证假设）

---

### Phase 7：更新经验（自动）

回顾本次执行过程，更新 `references/experiment-experience.md`：
- 新发现的有效模式 → 更新"有效模式"（替换弱的，保留强的）
- 遇到的失败 → 更新"失败教训"（同类只保留最典型的）
- 未验证的想法 → 记入"待验证假设"
- 更新原则：精炼而非堆砌，文档不超过 150 行
