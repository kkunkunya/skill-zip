#!/bin/bash
# init_repo.sh - 按最佳实践初始化 GitHub 仓库
# Input: 项目路径, 仓库名, 可见性, 描述, 项目类型
# Output: 初始化完成的仓库（含 .github/ 模板）
# Pos: github-project-manager skill 的仓库初始化入口
#
# Usage:
#   init_repo.sh [options]
#   init_repo.sh --path . --name my-project --type python --visibility public
#   init_repo.sh --path . --setup-only   # 仅设置 .github/ 目录，不创建远程仓库

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"

# 默认值
PROJECT_PATH="."
REPO_NAME=""
VISIBILITY="private"
DESCRIPTION=""
PROJECT_TYPE="python"
SETUP_ONLY=false

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -p|--path)        PROJECT_PATH="$2"; shift 2 ;;
        -n|--name)        REPO_NAME="$2"; shift 2 ;;
        -v|--visibility)  VISIBILITY="$2"; shift 2 ;;
        -d|--description) DESCRIPTION="$2"; shift 2 ;;
        -t|--type)        PROJECT_TYPE="$2"; shift 2 ;;
        --setup-only)     SETUP_ONLY=true; shift ;;
        *)                echo "未知参数: $1"; exit 1 ;;
    esac
done

cd "$PROJECT_PATH"

# 自动检测仓库名
if [ -z "$REPO_NAME" ]; then
    REPO_NAME=$(basename "$(pwd)")
fi

echo "=== GitHub 项目初始化 ==="
echo "路径: $(pwd)"
echo "仓库: ${REPO_NAME}"
echo "类型: ${PROJECT_TYPE}"
echo "可见: ${VISIBILITY}"

# ─── 1. Git 初始化 ───
if [ ! -d ".git" ]; then
    git init --quiet
    echo "[1/6] Git 初始化 OK"
else
    echo "[1/6] Git 已存在，跳过"
fi

# ─── 2. .gitignore ───
if [ ! -f ".gitignore" ]; then
    case "$PROJECT_TYPE" in
        python)
            cat > .gitignore << 'GITIGNORE'
__pycache__/
*.py[cod]
*.egg-info/
dist/
build/
.venv/
venv/
*.env
.env.*
.pytest_cache/
.mypy_cache/
*.log
.DS_Store
.doc-cache/
.agent-locks/
GITIGNORE
            ;;
        node|javascript|typescript)
            cat > .gitignore << 'GITIGNORE'
node_modules/
dist/
build/
.env
.env.*
*.log
.DS_Store
.doc-cache/
.agent-locks/
GITIGNORE
            ;;
        *)
            cat > .gitignore << 'GITIGNORE'
*.env
.env.*
*.log
.DS_Store
.doc-cache/
.agent-locks/
GITIGNORE
            ;;
    esac
    echo "[2/6] .gitignore 创建 OK"
else
    echo "[2/6] .gitignore 已存在，跳过"
fi

# ─── 3. .github/ 目录结构 ───
mkdir -p .github/workflows .github/ISSUE_TEMPLATE

# Bug Report 模板
if [ ! -f ".github/ISSUE_TEMPLATE/bug_report.md" ]; then
    cat > .github/ISSUE_TEMPLATE/bug_report.md << 'TEMPLATE'
---
name: Bug Report
about: Report a bug to help us improve
title: '[BUG] '
labels: bug
---

## Description
A clear description of the bug.

## Steps to Reproduce
1. ...
2. ...

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened.

## Environment
- OS:
- Version:
TEMPLATE
fi

# Feature Request 模板
if [ ! -f ".github/ISSUE_TEMPLATE/feature_request.md" ]; then
    cat > .github/ISSUE_TEMPLATE/feature_request.md << 'TEMPLATE'
---
name: Feature Request
about: Suggest an idea for this project
title: '[FEAT] '
labels: enhancement
---

## Problem
What problem does this solve?

## Proposed Solution
Describe the solution you'd like.

## Alternatives
Any alternatives you've considered.
TEMPLATE
fi

# PR 模板
if [ ! -f ".github/PULL_REQUEST_TEMPLATE.md" ]; then
    cat > .github/PULL_REQUEST_TEMPLATE.md << 'TEMPLATE'
## Summary
Brief description of changes.

## Changes
- ...

## Test Plan
- [ ] Tests pass locally
- [ ] New tests added (if applicable)

## Related Issues
Closes #
TEMPLATE
fi

echo "[3/6] .github/ 模板 OK"

# ─── 4. CI 工作流 ───
if [ ! -f ".github/workflows/ci.yml" ]; then
    case "$PROJECT_TYPE" in
        python)
            cat > .github/workflows/ci.yml << 'WORKFLOW'
name: CI
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync
      - run: uv run pytest --fast -q
WORKFLOW
            ;;
        node|javascript|typescript)
            cat > .github/workflows/ci.yml << 'WORKFLOW'
name: CI
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm test
WORKFLOW
            ;;
    esac
    echo "[4/6] CI 工作流 OK"
else
    echo "[4/6] CI 已存在，跳过"
fi

# ─── 5. Agent 协调目录 ───
mkdir -p .agent-locks
if [ ! -f ".agent-locks/.gitkeep" ]; then
    touch .agent-locks/.gitkeep
    echo "[5/6] Agent 协调目录 OK"
else
    echo "[5/6] Agent 协调目录已存在，跳过"
fi

# ─── 6. 创建远程仓库并推送 ───
if [ "$SETUP_ONLY" = true ]; then
    echo "[6/6] --setup-only 模式，跳过远程仓库创建"
    echo ""
    echo "=== 完成 ==="
    echo "已设置: .gitignore, .github/, .agent-locks/"
    exit 0
fi

# 检查 gh CLI
if ! command -v gh &>/dev/null; then
    echo "ERROR 需要 gh CLI (brew install gh)"
    exit 1
fi

# 提交所有变更
git add -A
git commit -m "init: project setup with best practices" --quiet 2>/dev/null || true

# 创建远程仓库
if ! git remote get-url origin &>/dev/null; then
    local gh_args="--${VISIBILITY} --source=."
    if [ -n "$DESCRIPTION" ]; then
        gh_args="${gh_args} --description \"${DESCRIPTION}\""
    fi
    eval "gh repo create \"${REPO_NAME}\" ${gh_args} --push"
    echo "[6/6] GitHub 仓库创建 OK"
else
    git push --quiet
    echo "[6/6] 已推送到现有远程仓库"
fi

echo ""
echo "=== 完成 ==="
echo "仓库: https://github.com/$(gh api user -q .login)/${REPO_NAME}"
