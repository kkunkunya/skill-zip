#!/bin/bash
set -euo pipefail

# setup_protection.sh - 分支保护规则自动配置
# 通过 gh api 设置分支保护、CODEOWNERS 等安全策略

REPO=""
BRANCH="main"
REQUIRE_REVIEWS=1
REQUIRE_CI=true
NO_FORCE_PUSH=true
NO_DELETE=true

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --repo) REPO="$2"; shift 2 ;;
        --branch) BRANCH="$2"; shift 2 ;;
        --reviews) REQUIRE_REVIEWS="$2"; shift 2 ;;
        --no-ci) REQUIRE_CI=false; shift ;;
        --allow-force-push) NO_FORCE_PUSH=false; shift ;;
        --allow-delete) NO_DELETE=false; shift ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

# 自动检测仓库
if [ -z "$REPO" ]; then
    REPO=$(gh repo view --json nameWithOwner --jq '.nameWithOwner' 2>/dev/null || echo "")
    if [ -z "$REPO" ]; then
        echo "❌ 无法检测仓库，请使用 --repo owner/name 指定"
        exit 1
    fi
fi

echo "🛡️  配置分支保护规则..."
echo "   仓库: $REPO"
echo "   分支: $BRANCH"
echo "   审查人数: $REQUIRE_REVIEWS"
echo "   要求 CI: $REQUIRE_CI"
echo ""

# 构建保护规则 JSON
PROTECTION_JSON=$(cat << ENDJSON
{
  "required_pull_request_reviews": {
    "required_approving_review_count": ${REQUIRE_REVIEWS},
    "dismiss_stale_reviews": true
  },
  "enforce_admins": false,
  "required_status_checks": null,
  "restrictions": null,
  "allow_force_pushes": $([ "$NO_FORCE_PUSH" = true ] && echo "false" || echo "true"),
  "allow_deletions": $([ "$NO_DELETE" = true ] && echo "false" || echo "true")
}
ENDJSON
)

# 如果要求 CI 检查，添加状态检查
if [ "$REQUIRE_CI" = true ]; then
    PROTECTION_JSON=$(cat << ENDJSON
{
  "required_pull_request_reviews": {
    "required_approving_review_count": ${REQUIRE_REVIEWS},
    "dismiss_stale_reviews": true
  },
  "enforce_admins": false,
  "required_status_checks": {
    "strict": true,
    "contexts": ["test"]
  },
  "restrictions": null,
  "allow_force_pushes": $([ "$NO_FORCE_PUSH" = true ] && echo "false" || echo "true"),
  "allow_deletions": $([ "$NO_DELETE" = true ] && echo "false" || echo "true")
}
ENDJSON
)
fi

# 应用分支保护规则
echo "📋 应用保护规则到 $BRANCH 分支..."
if echo "$PROTECTION_JSON" | gh api \
    "repos/${REPO}/branches/${BRANCH}/protection" \
    --method PUT \
    --input - \
    > /dev/null 2>&1; then
    echo "✅ 分支保护规则已设置"
else
    echo "⚠️  分支保护设置失败（可能需要 Pro/Team 计划，或分支尚不存在）"
    echo "   免费计划仅支持公开仓库的分支保护"
fi

# 显示当前保护状态
echo ""
echo "📊 当前保护状态:"
gh api "repos/${REPO}/branches/${BRANCH}/protection" --jq '{
  enforce_admins: .enforce_admins.enabled,
  required_reviews: .required_pull_request_reviews.required_approving_review_count,
  dismiss_stale: .required_pull_request_reviews.dismiss_stale_reviews,
  force_push: .allow_force_pushes.enabled,
  deletions: .allow_deletions.enabled
}' 2>/dev/null || echo "   (无法获取，分支可能尚未创建)"

echo ""
echo "✅ 分支保护配置完成"
