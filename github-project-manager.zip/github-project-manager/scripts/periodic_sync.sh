#!/bin/bash
# periodic_sync.sh - 定时同步本地变更到 GitHub
# Input: interval(秒), max_iter(次数)
# Output: 同步状态日志
# Pos: Agent 并行工作期间的后台同步守护
#
# Usage:
#   periodic_sync.sh [interval-seconds] [max-iterations]
#   periodic_sync.sh 300        # 每5分钟同步，无限循环
#   periodic_sync.sh 300 10     # 每5分钟同步，最多10次
#   periodic_sync.sh once       # 只同步一次

set -euo pipefail

INTERVAL="${1:-300}"
MAX_ITER="${2:-0}"
ITER=0
LOG_PREFIX="[sync]"

# ─── 单次同步 ───
sync_once() {
    local ts
    ts=$(date +%H:%M:%S)

    # 检查是否有变更
    if [ -z "$(git status --porcelain 2>/dev/null)" ]; then
        echo "${LOG_PREFIX} [${ts}] 无变更"
        return 0
    fi

    # 暂存（排除敏感文件）
    git add -A
    git reset -- '*.env' '.env' '.env.*' '*.key' '*.pem' '*credentials*' '*secret*' 2>/dev/null || true

    # 检查暂存区是否有内容
    if [ -z "$(git diff --cached --name-only 2>/dev/null)" ]; then
        echo "${LOG_PREFIX} [${ts}] 暂存区为空（可能都是敏感文件）"
        return 0
    fi

    # 统计实际暂存的变更（reset 之后再统计才准确）
    local file_count
    file_count=$(git diff --cached --name-only | wc -l | tr -d ' ')

    # 生成提交信息
    local msg="auto-sync: ${file_count} files (${ts})"

    git commit -m "${msg}" --quiet

    # 推送（带冲突处理）
    if git push --quiet 2>/dev/null; then
        echo "${LOG_PREFIX} [${ts}] OK ${file_count} files"
    else
        echo "${LOG_PREFIX} [${ts}] 冲突，尝试 rebase..."
        if git pull --rebase --quiet 2>/dev/null && git push --quiet 2>/dev/null; then
            echo "${LOG_PREFIX} [${ts}] OK (rebase 后推送成功)"
        else
            echo "${LOG_PREFIX} [${ts}] WARN 推送失败，下次重试"
        fi
    fi
}

# ─── 单次模式 ───
if [ "$INTERVAL" = "once" ]; then
    sync_once
    exit 0
fi

# ─── 循环模式 ───
echo "${LOG_PREFIX} 启动定时同步 (间隔: ${INTERVAL}s, 上限: ${MAX_ITER:-无限})"
while true; do
    sync_once
    ITER=$((ITER + 1))

    if [ "$MAX_ITER" -gt 0 ] && [ "$ITER" -ge "$MAX_ITER" ]; then
        echo "${LOG_PREFIX} 达到上限 (${MAX_ITER}次)，停止"
        break
    fi

    sleep "$INTERVAL"
done
