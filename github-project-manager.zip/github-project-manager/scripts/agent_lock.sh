#!/bin/bash
# agent_lock.sh - 并行 Agent 任务锁定协议
# Input: 子命令 + 参数
# Output: 锁定/释放/查询结果
# Pos: github-project-manager skill 的核心协调脚本
#
# Usage:
#   agent_lock.sh claim <task-name> <agent-id> [file1 file2 ...]
#   agent_lock.sh release <task-name>
#   agent_lock.sh check <task-name>
#   agent_lock.sh list
#   agent_lock.sh stale-check [timeout-minutes]
#   agent_lock.sh force-release <task-name>

set -euo pipefail

LOCK_DIR=".agent-locks"

# ─── claim: 认领任务 ───
claim() {
    local task="${1:?用法: claim <task-name> <agent-id> [files...]}"
    local agent="${2:?缺少 agent-id}"
    shift 2
    local files=("$@")

    # 拉取最新状态
    git pull --rebase --quiet 2>/dev/null || true

    # 检查是否已被锁定
    if [ -f "$LOCK_DIR/${task}.lock" ]; then
        local owner
        owner=$(python3 -c "import json; print(json.load(open('$LOCK_DIR/${task}.lock'))['agent'])" 2>/dev/null || echo "unknown")
        echo "ERROR $LOCK_DIR/${task}.lock 已被 ${owner} 认领"
        return 1
    fi

    # 创建锁目录
    mkdir -p "$LOCK_DIR"

    # 构建 files JSON 数组
    local files_json="[]"
    if [ ${#files[@]} -gt 0 ]; then
        files_json=$(printf '%s\n' "${files[@]}" | python3 -c "import sys,json; print(json.dumps([l.strip() for l in sys.stdin if l.strip()]))")
    fi

    # 写入锁文件
    python3 -c "
import json
from datetime import datetime, timezone
lock = {
    'agent': '${agent}',
    'claimed': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
    'files': ${files_json}
}
with open('${LOCK_DIR}/${task}.lock', 'w') as f:
    json.dump(lock, f, indent=2)
"

    # 提交并推送（原子性操作）
    git add "$LOCK_DIR/${task}.lock"
    git commit -m "lock: ${task} claimed by ${agent}" --quiet

    if ! git push --quiet 2>/dev/null; then
        # 推送失败 = 冲突（其他 Agent 也在操作）
        git pull --rebase --quiet 2>/dev/null || true

        # 检查是否被抢
        if [ -f "$LOCK_DIR/${task}.lock" ]; then
            local current_owner
            current_owner=$(python3 -c "import json; print(json.load(open('$LOCK_DIR/${task}.lock'))['agent'])" 2>/dev/null || echo "unknown")
            if [ "$current_owner" != "$agent" ]; then
                echo "ERROR 竞争条件: ${task} 已被 ${current_owner} 抢先认领"
                return 1
            fi
        fi
        # 重试推送
        git push --quiet 2>/dev/null || true
    fi

    echo "OK ${task} <- ${agent}"
    return 0
}

# ─── release: 释放任务 ───
release() {
    local task="${1:?用法: release <task-name>}"

    if [ ! -f "$LOCK_DIR/${task}.lock" ]; then
        echo "WARN ${task} 未被锁定"
        return 0
    fi

    git rm "$LOCK_DIR/${task}.lock" --quiet
    git commit -m "unlock: ${task} released" --quiet
    git push --quiet 2>/dev/null || true

    echo "OK ${task} released"
}

# ─── check: 查询任务状态 ───
check() {
    local task="${1:?用法: check <task-name>}"

    git pull --rebase --quiet 2>/dev/null || true

    if [ -f "$LOCK_DIR/${task}.lock" ]; then
        echo "LOCKED"
        cat "$LOCK_DIR/${task}.lock"
        return 0
    else
        echo "AVAILABLE ${task}"
        return 1
    fi
}

# ─── list: 列出所有锁 ───
list() {
    git pull --rebase --quiet 2>/dev/null || true

    if [ ! -d "$LOCK_DIR" ] || [ -z "$(ls -A "$LOCK_DIR" 2>/dev/null | grep '\.lock$')" ]; then
        echo "无活跃锁"
        return 0
    fi

    echo "活跃锁列表:"
    for lock in "$LOCK_DIR"/*.lock; do
        [ -f "$lock" ] || continue
        local task
        task=$(basename "$lock" .lock)
        python3 -c "
import json
with open('${lock}') as f:
    d = json.load(f)
print(f'  ${task} -> {d[\"agent\"]} (since {d[\"claimed\"]})')
if d.get('files'):
    for fp in d['files']:
        print(f'    - {fp}')
"
    done
}

# ─── stale-check: 检测死锁 ───
stale_check() {
    local timeout_min="${1:-30}"
    local now
    now=$(date +%s)

    git pull --rebase --quiet 2>/dev/null || true

    if [ ! -d "$LOCK_DIR" ]; then
        echo "无锁目录"
        return 0
    fi

    local found_stale=0
    for lock in "$LOCK_DIR"/*.lock; do
        [ -f "$lock" ] || continue
        local task
        task=$(basename "$lock" .lock)

        python3 -c "
import json
from datetime import datetime, timezone
with open('${lock}') as f:
    d = json.load(f)
claimed = datetime.strptime(d['claimed'], '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
now = datetime.now(timezone.utc)
age_min = int((now - claimed).total_seconds() / 60)
if age_min > ${timeout_min}:
    print(f'STALE ${task} ({d[\"agent\"]}, {age_min}min, timeout=${timeout_min}min)')
"
    done
}

# ─── force-release: 强制释放（用于死锁恢复）───
force_release() {
    local task="${1:?用法: force-release <task-name>}"

    if [ ! -f "$LOCK_DIR/${task}.lock" ]; then
        echo "WARN ${task} 未被锁定"
        return 0
    fi

    local owner
    owner=$(python3 -c "import json; print(json.load(open('$LOCK_DIR/${task}.lock'))['agent'])" 2>/dev/null || echo "unknown")

    git rm "$LOCK_DIR/${task}.lock" --quiet
    git commit -m "force-unlock: ${task} (was: ${owner})" --quiet
    git push --quiet 2>/dev/null || true

    echo "OK ${task} force-released (was: ${owner})"
}

# ─── 主入口 ───
case "${1:-help}" in
    claim)          shift; claim "$@" ;;
    release)        shift; release "$@" ;;
    check)          shift; check "$@" ;;
    list)           list ;;
    stale-check)    shift; stale_check "$@" ;;
    force-release)  shift; force_release "$@" ;;
    *)
        echo "用法: $(basename "$0") {claim|release|check|list|stale-check|force-release} [args...]"
        echo ""
        echo "命令:"
        echo "  claim <task> <agent> [files...]  认领任务"
        echo "  release <task>                   释放任务"
        echo "  check <task>                     查询任务状态"
        echo "  list                             列出所有锁"
        echo "  stale-check [minutes]            检测死锁(默认30min)"
        echo "  force-release <task>             强制释放死锁"
        exit 1
        ;;
esac
