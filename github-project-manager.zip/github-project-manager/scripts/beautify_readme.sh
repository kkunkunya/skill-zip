#!/bin/bash
set -euo pipefail

# beautify_readme.sh - Bilingual README Generator
# Generates professional README.md with bilingual support (EN/ZH)

# Defaults
PROJECT_PATH="."
PROJECT_NAME=""
DESCRIPTION=""
DESCRIPTION_ZH=""
PROJECT_TYPE="python"
LICENSE_TYPE="MIT"
GITHUB_USER=""
REPO_NAME=""
FEATURES=""
FEATURES_ZH=""
NO_BADGES=false
NO_TOC=false
LANG="bilingual"  # en | zh-CN | bilingual (default: bilingual)

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --path) PROJECT_PATH="$2"; shift 2 ;;
        --name) PROJECT_NAME="$2"; shift 2 ;;
        --description) DESCRIPTION="$2"; shift 2 ;;
        --description-zh) DESCRIPTION_ZH="$2"; shift 2 ;;
        --type) PROJECT_TYPE="$2"; shift 2 ;;
        --license) LICENSE_TYPE="$2"; shift 2 ;;
        --github-user) GITHUB_USER="$2"; shift 2 ;;
        --repo-name) REPO_NAME="$2"; shift 2 ;;
        --features) FEATURES="$2"; shift 2 ;;
        --features-zh) FEATURES_ZH="$2"; shift 2 ;;
        --no-badges) NO_BADGES=true; shift ;;
        --no-toc) NO_TOC=true; shift ;;
        --lang) LANG="$2"; shift 2 ;;
        --bilingual) LANG="bilingual"; shift ;;
        *) echo "Unknown argument: $1"; exit 1 ;;
    esac
done

# Auto-detect
if [ -z "$PROJECT_NAME" ]; then
    PROJECT_NAME=$(basename "$(cd "$PROJECT_PATH" && pwd)")
fi

if [ -z "$REPO_NAME" ]; then
    REPO_NAME="$PROJECT_NAME"
fi

if [ -z "$GITHUB_USER" ]; then
    GITHUB_USER=$(gh api user --jq '.login' 2>/dev/null || echo "your-username")
fi

# Generate directory tree
generate_tree() {
    if command -v tree &>/dev/null; then
        (cd "$PROJECT_PATH" && tree -L 2 -d --charset ascii -I '__pycache__|node_modules|.git|.venv|venv|*.egg-info|dist|build|log|.agent-locks|.doc-cache' 2>/dev/null || echo "$PROJECT_NAME/")
    else
        echo "$PROJECT_NAME/"
        for dir in src tests docs scripts examples assets; do
            if [ -d "$PROJECT_PATH/$dir" ]; then
                echo "├── $dir/"
            fi
        done
    fi
}

# Generate badges (shared between EN/ZH)
generate_badges() {
    if [ "$NO_BADGES" = true ]; then return; fi

    echo "<!-- Badges -->"
    echo "[![License: ${LICENSE_TYPE}](https://img.shields.io/badge/License-${LICENSE_TYPE}-blue.svg)](LICENSE)"
    echo "[![CI](https://github.com/${GITHUB_USER}/${REPO_NAME}/actions/workflows/ci.yml/badge.svg)](https://github.com/${GITHUB_USER}/${REPO_NAME}/actions/workflows/ci.yml)"

    if [ "$PROJECT_TYPE" = "python" ]; then
        echo "[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white)](https://python.org)"
        if [ -f "$PROJECT_PATH/pyproject.toml" ] && grep -q "torch" "$PROJECT_PATH/pyproject.toml" 2>/dev/null; then
            echo "[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-EE4C2C?logo=pytorch&logoColor=white)](https://pytorch.org)"
        fi
        if [ -f "$PROJECT_PATH/pyproject.toml" ] && grep -q "gymnasium" "$PROJECT_PATH/pyproject.toml" 2>/dev/null; then
            echo "[![Gymnasium](https://img.shields.io/badge/Gymnasium-0.29+-00ADD8?logo=openaigym&logoColor=white)](https://gymnasium.farama.org)"
        fi
    elif [ "$PROJECT_TYPE" = "node" ]; then
        echo "[![Node.js](https://img.shields.io/badge/Node.js-18+-339933?logo=node.js&logoColor=white)](https://nodejs.org)"
    fi
    echo ""
}

# ─── English README Generator ───
generate_en_readme() {
    local OUTPUT_PATH="$PROJECT_PATH/README.md"
    local IS_BILINGUAL="$1"

    if [ -f "$OUTPUT_PATH" ]; then
        cp "$OUTPUT_PATH" "${OUTPUT_PATH}.bak"
    fi

    {
        echo '<div align="center">'
        echo ""

        # Language switcher (only in bilingual mode)
        if [ "$IS_BILINGUAL" = true ]; then
            echo "**English** | [中文](README.zh-CN.md)"
            echo ""
        fi

        echo "# $PROJECT_NAME"
        echo ""

        if [ -n "$DESCRIPTION" ]; then
            echo "**$DESCRIPTION**"
            echo ""
        fi

        generate_badges

        echo "</div>"
        echo ""
        echo "<!-- Screenshot/GIF area -->"
        echo "<!-- ![Demo](assets/demo.gif) -->"
        echo ""

        # TOC
        if [ "$NO_TOC" = false ]; then
            cat << 'TOC'
## 📋 Table of Contents

- [Features](#-features)
- [Quick Start](#-quick-start)
- [Installation](#-installation)
- [Usage](#-usage)
- [Project Structure](#-project-structure)
- [Contributing](#-contributing)
- [License](#-license)

TOC
        fi

        # Features
        echo "## ✨ Features"
        echo ""
        if [ -n "$FEATURES" ]; then
            IFS=',' read -ra FEAT_ARRAY <<< "$FEATURES"
            for feat in "${FEAT_ARRAY[@]}"; do
                echo "- $feat"
            done
        else
            echo "- Feature 1"
            echo "- Feature 2"
            echo "- Feature 3"
        fi
        echo ""

        # Quick Start
        echo "## 🚀 Quick Start"
        echo ""
        echo '```bash'
        echo "git clone https://github.com/GITHUB_USER/REPO_NAME.git"
        echo "cd REPO_NAME"
        if [ "$PROJECT_TYPE" = "python" ]; then
            echo "uv sync && uv run python -m src.main"
        elif [ "$PROJECT_TYPE" = "node" ]; then
            echo "npm install && npm start"
        fi
        echo '```'
        echo ""

        # Installation
        echo "## 📦 Installation"
        echo ""
        if [ "$PROJECT_TYPE" = "python" ]; then
            cat << 'INSTALL'
```bash
# Clone the repository
git clone https://github.com/GITHUB_USER/REPO_NAME.git
cd REPO_NAME

# Install with uv (recommended)
uv sync

# Or with pip
pip install -e .
```
INSTALL
        elif [ "$PROJECT_TYPE" = "node" ]; then
            cat << 'INSTALL'
```bash
git clone https://github.com/GITHUB_USER/REPO_NAME.git
cd REPO_NAME
npm install
```
INSTALL
        fi
        echo ""

        # Usage
        echo "## 📖 Usage"
        echo ""
        echo '```bash'
        if [ "$PROJECT_TYPE" = "python" ]; then
            echo "uv run python -m ${REPO_NAME}"
        elif [ "$PROJECT_TYPE" = "node" ]; then
            echo "npm start"
        fi
        echo '```'
        echo ""

        # Project Structure
        echo "## 📁 Project Structure"
        echo ""
        echo '```'
        generate_tree
        echo '```'
        echo ""

        # Contributing
        echo "## 🤝 Contributing"
        echo ""
        echo "Contributions are welcome! Please see [Contributing Guide](CONTRIBUTING.md) for details."
        echo ""

        # License
        echo "## 📄 License"
        echo ""
        echo "This project is licensed under the [${LICENSE_TYPE} License](LICENSE)."

    } > "$OUTPUT_PATH"

    # Replace placeholders
    if command -v sed &>/dev/null; then
        sed -i.tmp "s|GITHUB_USER|${GITHUB_USER}|g" "$OUTPUT_PATH"
        sed -i.tmp "s|REPO_NAME|${REPO_NAME}|g" "$OUTPUT_PATH"
        rm -f "${OUTPUT_PATH}.tmp"
    fi

    echo "✅ README.md (English) generated: $OUTPUT_PATH"
}

# ─── Chinese README Generator ───
generate_zh_readme() {
    local OUTPUT_PATH="$PROJECT_PATH/README.zh-CN.md"
    local IS_BILINGUAL="$1"

    {
        echo '<div align="center">'
        echo ""

        # Language switcher
        if [ "$IS_BILINGUAL" = true ]; then
            echo "[English](README.md) | **中文**"
            echo ""
        fi

        echo "# $PROJECT_NAME"
        echo ""

        local DESC_TO_USE="${DESCRIPTION_ZH:-$DESCRIPTION}"
        if [ -n "$DESC_TO_USE" ]; then
            echo "**$DESC_TO_USE**"
            echo ""
        fi

        generate_badges

        echo "</div>"
        echo ""
        echo "<!-- 截图/GIF 展示区域 -->"
        echo "<!-- ![Demo](assets/demo.gif) -->"
        echo ""

        # TOC
        if [ "$NO_TOC" = false ]; then
            cat << 'TOC'
## 📋 目录

- [功能特性](#-功能特性)
- [快速开始](#-快速开始)
- [安装](#-安装)
- [使用方法](#-使用方法)
- [项目结构](#-项目结构)
- [贡献](#-贡献)
- [许可证](#-许可证)

TOC
        fi

        # Features
        echo "## ✨ 功能特性"
        echo ""
        local FEAT_TO_USE="${FEATURES_ZH:-$FEATURES}"
        if [ -n "$FEAT_TO_USE" ]; then
            IFS=',' read -ra FEAT_ARRAY <<< "$FEAT_TO_USE"
            for feat in "${FEAT_ARRAY[@]}"; do
                echo "- $feat"
            done
        else
            echo "- 功能 1"
            echo "- 功能 2"
            echo "- 功能 3"
        fi
        echo ""

        # Quick Start
        echo "## 🚀 快速开始"
        echo ""
        echo '```bash'
        echo "git clone https://github.com/GITHUB_USER/REPO_NAME.git"
        echo "cd REPO_NAME"
        if [ "$PROJECT_TYPE" = "python" ]; then
            echo "uv sync && uv run python -m src.main"
        elif [ "$PROJECT_TYPE" = "node" ]; then
            echo "npm install && npm start"
        fi
        echo '```'
        echo ""

        # Installation
        echo "## 📦 安装"
        echo ""
        if [ "$PROJECT_TYPE" = "python" ]; then
            cat << 'INSTALL'
```bash
# 克隆仓库
git clone https://github.com/GITHUB_USER/REPO_NAME.git
cd REPO_NAME

# 使用 uv 安装依赖（推荐）
uv sync

# 或使用 pip
pip install -e .
```
INSTALL
        elif [ "$PROJECT_TYPE" = "node" ]; then
            cat << 'INSTALL'
```bash
git clone https://github.com/GITHUB_USER/REPO_NAME.git
cd REPO_NAME
npm install
```
INSTALL
        fi
        echo ""

        # Usage
        echo "## 📖 使用方法"
        echo ""
        echo '```bash'
        if [ "$PROJECT_TYPE" = "python" ]; then
            echo "uv run python -m ${REPO_NAME}"
        elif [ "$PROJECT_TYPE" = "node" ]; then
            echo "npm start"
        fi
        echo '```'
        echo ""

        # Project Structure
        echo "## 📁 项目结构"
        echo ""
        echo '```'
        generate_tree
        echo '```'
        echo ""

        # Contributing
        echo "## 🤝 贡献"
        echo ""
        echo "欢迎贡献！请查看 [贡献指南](CONTRIBUTING.md) 了解详情。"
        echo ""

        # License
        echo "## 📄 许可证"
        echo ""
        echo "本项目采用 [${LICENSE_TYPE} 许可证](LICENSE)。"

    } > "$OUTPUT_PATH"

    # Replace placeholders
    if command -v sed &>/dev/null; then
        sed -i.tmp "s|GITHUB_USER|${GITHUB_USER}|g" "$OUTPUT_PATH"
        sed -i.tmp "s|REPO_NAME|${REPO_NAME}|g" "$OUTPUT_PATH"
        rm -f "${OUTPUT_PATH}.tmp"
    fi

    echo "✅ README.zh-CN.md (中文) generated: $OUTPUT_PATH"
}

# ─── Main Logic ───
echo "📝 Generating README..."
echo "   Project: $PROJECT_NAME"
echo "   Type: $PROJECT_TYPE"
echo "   User: $GITHUB_USER"
echo "   Repo: $REPO_NAME"
echo "   Lang: $LANG"

case "$LANG" in
    en)
        generate_en_readme false
        ;;
    zh-CN|zh)
        generate_zh_readme false
        ;;
    bilingual|both)
        generate_en_readme true
        generate_zh_readme true
        echo ""
        echo "🌐 Bilingual READMEs generated with language switcher!"
        ;;
    *)
        echo "❌ Unknown language: $LANG (use: en, zh-CN, bilingual)"
        exit 1
        ;;
esac

echo ""
echo "📌 Next steps:"
echo "   1. Replace the Logo placeholder with your project logo"
echo "   2. Add screenshots or GIF demos"
echo "   3. Customize the features list"
echo "   4. Add detailed usage examples"
