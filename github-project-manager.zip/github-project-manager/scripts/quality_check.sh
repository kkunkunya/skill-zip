#!/bin/bash
set -euo pipefail

# quality_check.sh - 仓库质量评分脚本
# Input: --path <项目路径> --verbose (可选)
# Output: 0-100 分质量评分 + 改进建议
# Pos: github-project-manager/scripts/ 仓库质量检查工具

PROJECT_PATH="."
VERBOSE=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --path) PROJECT_PATH="$2"; shift 2 ;;
        --verbose) VERBOSE=true; shift ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

SCORE=0
MAX_SCORE=0
PASS_ITEMS=()
FAIL_ITEMS=()
WARN_ITEMS=()

# 检查函数
check() {
    local category="$1"
    local item="$2"
    local points="$3"
    local condition="$4"
    local suggestion="$5"

    MAX_SCORE=$((MAX_SCORE + points))

    if eval "$condition"; then
        SCORE=$((SCORE + points))
        PASS_ITEMS+=("✅ [$category] $item (+${points}分)")
    else
        FAIL_ITEMS+=("❌ [$category] $item (${points}分) → $suggestion")
    fi
}

# 警告检查（不计分）
warn_check() {
    local category="$1"
    local item="$2"
    local condition="$3"
    local suggestion="$4"

    if ! eval "$condition"; then
        WARN_ITEMS+=("⚠️  [$category] $item → $suggestion")
    fi
}

echo "📊 GitHub 仓库质量评估"
echo "   路径: $(cd "$PROJECT_PATH" && pwd)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# ===== 基础结构 (30分) =====
check "基础" "Git 仓库已初始化" 5 \
    "[ -d '$PROJECT_PATH/.git' ]" \
    "运行 git init"

check "基础" "README.md 存在" 8 \
    "[ -f '$PROJECT_PATH/README.md' ]" \
    "创建 README.md（使用 beautify_readme.sh）"

check "基础" "LICENSE 文件存在" 5 \
    "[ -f '$PROJECT_PATH/LICENSE' ] || [ -f '$PROJECT_PATH/LICENSE.md' ]" \
    "添加 LICENSE 文件（推荐 MIT）"

check "基础" ".gitignore 存在" 5 \
    "[ -f '$PROJECT_PATH/.gitignore' ]" \
    "创建 .gitignore（使用 init_repo.sh）"

check "基础" "源代码目录存在" 4 \
    "[ -d '$PROJECT_PATH/src' ] || [ -d '$PROJECT_PATH/lib' ] || [ -d '$PROJECT_PATH/app' ]" \
    "创建 src/ 目录组织源代码"

check "基础" "文档目录存在" 3 \
    "[ -d '$PROJECT_PATH/docs' ]" \
    "创建 docs/ 目录"

# ===== GitHub 配置 (25分) =====
check "GitHub" "CI 工作流存在" 8 \
    "[ -d '$PROJECT_PATH/.github/workflows' ] && ls '$PROJECT_PATH/.github/workflows'/*.yml >/dev/null 2>&1" \
    "创建 .github/workflows/ci.yml"

check "GitHub" "Issue 模板存在" 5 \
    "[ -d '$PROJECT_PATH/.github/ISSUE_TEMPLATE' ]" \
    "创建 .github/ISSUE_TEMPLATE/ 目录和模板"

check "GitHub" "PR 模板存在" 5 \
    "[ -f '$PROJECT_PATH/.github/PULL_REQUEST_TEMPLATE.md' ]" \
    "创建 PR 模板"

check "GitHub" "Dependabot 配置" 4 \
    "[ -f '$PROJECT_PATH/.github/dependabot.yml' ]" \
    "创建 .github/dependabot.yml"

check "GitHub" "CODEOWNERS 存在" 3 \
    "[ -f '$PROJECT_PATH/.github/CODEOWNERS' ] || [ -f '$PROJECT_PATH/CODEOWNERS' ]" \
    "创建 CODEOWNERS 文件"

# ===== 社区文件 (20分) =====
check "社区" "CONTRIBUTING.md 存在" 8 \
    "[ -f '$PROJECT_PATH/CONTRIBUTING.md' ]" \
    "创建贡献指南"

check "社区" "CODE_OF_CONDUCT.md 存在" 4 \
    "[ -f '$PROJECT_PATH/CODE_OF_CONDUCT.md' ]" \
    "创建行为准则"

check "社区" "SECURITY.md 存在" 4 \
    "[ -f '$PROJECT_PATH/SECURITY.md' ]" \
    "创建安全策略"

check "社区" ".editorconfig 存在" 4 \
    "[ -f '$PROJECT_PATH/.editorconfig' ]" \
    "创建 .editorconfig 统一编辑器配置"

# ===== README 质量 (15分) =====
if [ -f "$PROJECT_PATH/README.md" ]; then
    README_CONTENT=$(cat "$PROJECT_PATH/README.md" 2>/dev/null || echo "")

    check "README" "包含徽章 (badges)" 4 \
        "echo '$README_CONTENT' | grep -q 'img.shields.io\|badge' 2>/dev/null" \
        "添加 shields.io 徽章"

    check "README" "包含安装说明" 4 \
        "echo '$README_CONTENT' | grep -qi 'install\|安装\|setup\|快速开始' 2>/dev/null" \
        "添加安装说明章节"

    check "README" "包含许可证信息" 3 \
        "echo '$README_CONTENT' | grep -qi 'license\|许可证\|MIT\|Apache\|GPL' 2>/dev/null" \
        "添加许可证信息"

    check "README" "长度充足 (>50行)" 4 \
        "[ \$(wc -l < '$PROJECT_PATH/README.md' | tr -d ' ') -gt 50 ]" \
        "丰富 README 内容（建议 >50 行）"
else
    MAX_SCORE=$((MAX_SCORE + 15))
    FAIL_ITEMS+=("❌ [README] 所有 README 质量检查 (15分) → 先创建 README.md")
fi

# ===== 代码质量 (10分) =====
check "代码" "测试目录存在" 5 \
    "[ -d '$PROJECT_PATH/tests' ] || [ -d '$PROJECT_PATH/test' ]" \
    "创建 tests/ 目录和测试文件"

check "代码" "包管理配置存在" 5 \
    "[ -f '$PROJECT_PATH/pyproject.toml' ] || [ -f '$PROJECT_PATH/package.json' ] || [ -f '$PROJECT_PATH/Cargo.toml' ]" \
    "创建项目配置文件"

# ===== 警告项（不计分）=====
warn_check "推荐" "examples/ 目录" \
    "[ -d '$PROJECT_PATH/examples' ]" \
    "创建 examples/ 目录提供使用示例"

warn_check "推荐" "CHANGELOG.md" \
    "[ -f '$PROJECT_PATH/CHANGELOG.md' ]" \
    "创建 CHANGELOG.md 记录版本变更"

# ===== 输出结果 =====
echo ""

# 计算百分比
if [ "$MAX_SCORE" -gt 0 ]; then
    PERCENTAGE=$((SCORE * 100 / MAX_SCORE))
else
    PERCENTAGE=0
fi

# 评级
if [ "$PERCENTAGE" -ge 90 ]; then
    GRADE="🏆 A+ (优秀)"
elif [ "$PERCENTAGE" -ge 80 ]; then
    GRADE="🥇 A (良好)"
elif [ "$PERCENTAGE" -ge 70 ]; then
    GRADE="🥈 B (合格)"
elif [ "$PERCENTAGE" -ge 60 ]; then
    GRADE="🥉 C (及格)"
else
    GRADE="⚠️  D (需改进)"
fi

# 进度条
BAR_LENGTH=30
FILLED=$((PERCENTAGE * BAR_LENGTH / 100))
EMPTY=$((BAR_LENGTH - FILLED))
BAR=$(printf '█%.0s' $(seq 1 $FILLED 2>/dev/null) 2>/dev/null || echo "")
BAR_EMPTY=$(printf '░%.0s' $(seq 1 $EMPTY 2>/dev/null) 2>/dev/null || echo "")

echo "┌─────────────────────────────────────────┐"
echo "│  质量评分: ${SCORE}/${MAX_SCORE} (${PERCENTAGE}%)  ${GRADE}"
echo "│  ${BAR}${BAR_EMPTY}"
echo "└─────────────────────────────────────────┘"
echo ""

# 通过项
if [ ${#PASS_ITEMS[@]} -gt 0 ]; then
    echo "通过项 (${#PASS_ITEMS[@]}):"
    for item in "${PASS_ITEMS[@]}"; do
        echo "  $item"
    done
    echo ""
fi

# 失败项
if [ ${#FAIL_ITEMS[@]} -gt 0 ]; then
    echo "待改进 (${#FAIL_ITEMS[@]}):"
    for item in "${FAIL_ITEMS[@]}"; do
        echo "  $item"
    done
    echo ""
fi

# 警告项
if [ ${#WARN_ITEMS[@]} -gt 0 ]; then
    echo "建议项:"
    for item in "${WARN_ITEMS[@]}"; do
        echo "  $item"
    done
    echo ""
fi

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "评估完成 · $(date '+%Y-%m-%d %H:%M:%S')"
