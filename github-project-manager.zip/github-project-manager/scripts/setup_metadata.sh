#!/bin/bash
set -euo pipefail

# setup_metadata.sh - 仓库元数据设置
# 设置 Description、Topics、Homepage、社交预览图

REPO=""
DESCRIPTION=""
TOPICS=""
HOMEPAGE=""
PREVIEW_IMAGE=""

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --repo) REPO="$2"; shift 2 ;;
        --description) DESCRIPTION="$2"; shift 2 ;;
        --topics) TOPICS="$2"; shift 2 ;;
        --homepage) HOMEPAGE="$2"; shift 2 ;;
        --preview) PREVIEW_IMAGE="$2"; shift 2 ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

# 自动检测仓库
if [ -z "$REPO" ]; then
    REPO=$(gh repo view --json nameWithOwner --jq '.nameWithOwner' 2>/dev/null || echo "")
    if [ -z "$REPO" ]; then
        echo "❌ 无法检测仓库，请使用 --repo owner/name 指定"
        exit 1
    fi
fi

echo "📋 设置仓库元数据..."
echo "   仓库: $REPO"

CHANGES=0

# 设置 Description
if [ -n "$DESCRIPTION" ]; then
    echo ""
    echo "📝 设置 Description..."
    gh repo edit "$REPO" --description "$DESCRIPTION" 2>/dev/null && {
        echo "   ✅ Description 已更新"
        CHANGES=$((CHANGES + 1))
    } || echo "   ⚠️  Description 设置失败"
fi

# 设置 Homepage
if [ -n "$HOMEPAGE" ]; then
    echo ""
    echo "🌐 设置 Homepage..."
    gh repo edit "$REPO" --homepage "$HOMEPAGE" 2>/dev/null && {
        echo "   ✅ Homepage 已更新"
        CHANGES=$((CHANGES + 1))
    } || echo "   ⚠️  Homepage 设置失败"
fi

# 设置 Topics
if [ -n "$TOPICS" ]; then
    echo ""
    echo "🏷️  设置 Topics..."
    # 将逗号分隔的 topics 转换为 JSON 数组
    TOPICS_JSON=$(echo "$TOPICS" | tr ',' '\n' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | python3 -c "
import sys, json
topics = [line.strip().lower().replace(' ', '-') for line in sys.stdin if line.strip()]
print(json.dumps({'names': topics}))
")

    echo "$TOPICS_JSON" | gh api \
        "repos/${REPO}/topics" \
        --method PUT \
        --input - \
        > /dev/null 2>&1 && {
        echo "   ✅ Topics 已更新: $TOPICS"
        CHANGES=$((CHANGES + 1))
    } || echo "   ⚠️  Topics 设置失败"
fi

# 设置社交预览图
if [ -n "$PREVIEW_IMAGE" ]; then
    echo ""
    echo "🖼️  设置社交预览图..."
    if [ -f "$PREVIEW_IMAGE" ]; then
        # 检查文件大小 (< 1MB)
        FILE_SIZE=$(wc -c < "$PREVIEW_IMAGE" | tr -d ' ')
        if [ "$FILE_SIZE" -gt 1048576 ]; then
            echo "   ⚠️  图片大小超过 1MB ($FILE_SIZE bytes)，建议压缩后重试"
        else
            # 使用 gh api 上传社交预览图
            # 注意：GitHub API 不直接支持上传社交预览图
            # 需要通过 Settings 页面手动上传，或使用 GraphQL API
            echo "   ℹ️  社交预览图需要手动上传:"
            echo "   → https://github.com/${REPO}/settings"
            echo "   → Social preview → Edit → Upload an image"
            echo "   推荐尺寸: 1280×640 像素"
        fi
    else
        echo "   ❌ 图片文件不存在: $PREVIEW_IMAGE"
    fi
fi

# 显示当前仓库信息
echo ""
echo "📊 当前仓库信息:"
gh repo view "$REPO" --json description,homepageUrl,repositoryTopics --jq '{
  description: .description,
  homepage: .homepageUrl,
  topics: [.repositoryTopics[].name]
}' 2>/dev/null || echo "   (无法获取仓库信息)"

echo ""
if [ "$CHANGES" -gt 0 ]; then
    echo "✅ 共更新 $CHANGES 项元数据"
else
    echo "ℹ️  未做任何更改"
fi
