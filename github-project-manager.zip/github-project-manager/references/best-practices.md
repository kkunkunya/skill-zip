# GitHub 最佳实践精要

> 精简自 github_best_practices_study_pack，仅保留 AI Agent 执行时需要的检查清单。

## 仓库结构检查清单

| 目录/文件 | 必需 | 说明 |
|----------|------|------|
| `src/` | ✓ | 核心源代码 |
| `tests/` | ✓ | 测试文件 |
| `docs/` | 推荐 | 项目文档 |
| `examples/` | 推荐 | 使用示例 |
| `.github/` | ✓ | GitHub 配置 |
| `.github/workflows/ci.yml` | ✓ | CI 工作流 |
| `.github/ISSUE_TEMPLATE/` | ✓ | Issue 模板 |
| `.github/PULL_REQUEST_TEMPLATE.md` | ✓ | PR 模板 |
| `README.md` | ✓ | 项目说明 |
| `LICENSE` | ✓ | 许可证 |
| `CONTRIBUTING.md` | 推荐 | 贡献指南 |
| `.gitignore` | ✓ | 忽略规则 |

## README 质量标准

**必须包含**：
- [ ] 项目名称和简介（1-2句话说清是什么）
- [ ] 安装/使用指南（可复制的命令）
- [ ] 许可证声明

**推荐包含**：
- [ ] 徽章（CI 状态、版本号、许可证）
- [ ] 截图或 GIF 演示
- [ ] 核心特性列表
- [ ] 贡献指南链接
- [ ] API 文档链接

**高 Star 项目额外要素**：
- [ ] Logo
- [ ] 多语言支持（README.zh-CN.md）
- [ ] 完整的目录（Table of Contents）
- [ ] 致谢和联系方式

## 多语言 README

两种方式：

1. **文件名后缀**（简单项目）：`README.zh-CN.md`, `README.es.md`
2. **i18n 目录**（复杂项目）：`i18n/zh-CN/README.md`

在主 README 顶部添加语言切换器：
```markdown
[English](README.md) | [简体中文](README.zh-CN.md)
```

## CI/CD 工作流

### Python 项目（uv）
```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v5
      - run: uv sync
      - run: uv run pytest --fast -q
```

### Node.js 项目
```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: {node-version: 20, cache: npm}
      - run: npm ci && npm test
```

## 许可证选择

| 场景 | 推荐 |
|------|------|
| 最大自由度 | MIT |
| 要求衍生开源 | GPL-3.0 |
| 企业友好 | Apache-2.0 |
| 不确定 | MIT（最简单） |

## 推广时机

项目具备以下条件即可推广：
1. 核心功能可工作
2. README 完整（至少包含必须项）
3. 有安装和使用指南
4. CI 通过

## 来源

- GitHub 官方仓库最佳实践
- othneildrew/Best-README-Template
- anuraghazra/github-readme-stats
- Shields.io 徽章服务
- github_best_practices_study_pack (本地)
