# Agent 并行协调协议

## 架构总览

```
┌─────────────────────────────────────────────────┐
│              项目仓库 (共享 main 分支)             │
│                                                  │
│  .agent-locks/          ← git 追踪的协调目录      │
│  ├── task-XXX.lock      ← JSON 锁文件            │
│  └── .gitkeep                                    │
└──────┬──────────────────────┬────────────────────┘
       │ git pull/push        │ git pull/push
 ┌─────┴──────┐         ┌────┴───────┐
 │  Agent A   │         │  Agent B   │
 │  终端 1    │         │  终端 2    │
 └────────────┘         └────────────┘
```

## 核心原则

**git push 的原子性 = 分布式锁**

两个 Agent 同时 claim 同一任务时：
1. A: 创建 lock → commit → push ✓（先到先得）
2. B: 创建 lock → commit → push ✗（冲突）
3. B: git pull → 发现 A 已锁 → 选其他任务

无需 Redis、无需数据库、无需额外进程。

## 锁文件格式

```json
{
  "agent": "agent-1",
  "claimed": "2026-02-07T10:00:00Z",
  "files": ["src/parser.py", "tests/test_parser.py"]
}
```

## 协议流程

### 1. 认领任务

```bash
bash scripts/agent_lock.sh claim <task-name> <agent-id> [files...]
```

内部流程：
1. `git pull --rebase` 获取最新状态
2. 检查 `.agent-locks/<task>.lock` 是否存在
3. 不存在 → 创建锁文件 → `git add + commit + push`
4. push 成功 → 认领完成
5. push 失败 → `git pull` → 检查是否被抢 → 被抢则返回错误

### 2. 释放任务

```bash
bash scripts/agent_lock.sh release <task-name>
```

完成工作后删除锁文件并推送。

### 3. 查看状态

```bash
bash scripts/agent_lock.sh list         # 所有活跃锁
bash scripts/agent_lock.sh check <task> # 单个任务
```

### 4. 死锁检测

```bash
bash scripts/agent_lock.sh stale-check 30  # 超过30分钟的锁
bash scripts/agent_lock.sh force-release <task>  # 强制释放
```

## 与现有体系集成

| 现有机制 | 锁协议 | 关系 |
|---------|-------|------|
| parallel-agents.md 阶段划分 | .agent-locks/ | 阶段内细粒度协调 |
| agent-task.md 文件范围 | lock 的 files 字段 | 运行时互斥 |
| Gate 同步点 | 所有 lock 释放 | Gate 前提条件 |
| TaskCreate owner | lock 文件 | 逻辑层 vs 物理层 |

## Agent 提示词模板

在 Agent 的 AGENT_PROMPT.md 中加入：

```
## 任务协调规则
1. 开始任务前：bash scripts/agent_lock.sh claim <task> <my-id> <files...>
2. claim 失败：选择其他未锁定任务
3. 完成任务后：bash scripts/agent_lock.sh release <task>
4. 定期同步：后台运行 bash scripts/periodic_sync.sh 300
5. 冲突处理：git pull --rebase → 解决冲突 → git push
```

## 定时同步

```bash
# 后台运行，每5分钟同步一次
nohup bash scripts/periodic_sync.sh 300 > sync.log 2>&1 &

# 单次同步
bash scripts/periodic_sync.sh once
```

同步策略：
- 自动排除敏感文件（.env, *.key, *credentials*）
- 冲突时自动 rebase
- 提交信息包含变更统计（+N ~N -N）
