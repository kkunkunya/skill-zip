# GitHub Project Manager 经验积累

> 本文档由技能执行过程中动态更新，记录有效模式和失败教训。
> 更新原则：精炼而非堆砌，同类经验只保留最有效的 3-5 条，过时经验直接替换。

## 有效模式

- README 中"Quick Start"部分是用户最先看的，应包含可直接运行的命令（不超过 5 步）
- 仓库结构：`src/` + `tests/` + `docs/` 三目录是最受欢迎的基础结构
- CI 配置：GitHub Actions 优先用官方 action（如 `actions/setup-python@v5`），避免第三方 action 的维护风险
- 徽章顺序：CI状态 → 版本 → License → 语言/框架，从左到右重要性递减
- 分支保护：个人项目 1 reviewer 足够，团队项目至少 2 reviewer + require CI pass

## 失败教训

（初始为空，使用过程中积累）

## 待验证假设

（初始为空，使用过程中积累）

---
*最近更新：2026-02-17*
