---
name: github-project-manager
description: "GitHub 项目全生命周期管理：仓库初始化（最佳实践结构）、并行 Agent 任务锁定协调、定时同步到 GitHub、PR/Issue 管理。触发词：GitHub管理、初始化仓库、同步到GitHub、任务锁定、agent协调、创建PR、GitHub最佳实践、仓库结构、agent-lock、periodic-sync。使用场景：(1) 新项目初始化（含 .github/ 模板、CI/CD、.gitignore）；(2) 多 Agent 并行开发时的任务锁定和 GitHub 同步；(3) 检查仓库是否符合最佳实践；(4) 创建 PR/Issue。"
context: fork
---

# GitHub Project Manager

GitHub 项目全生命周期管理，从初始化到多 Agent 协同再到发布。

## 功能路由

根据用户意图选择对应操作：

| 用户意图 | 操作 | 命令 |
|---------|------|------|
| 初始化新仓库 | [仓库初始化](#1-仓库初始化) | `bash scripts/init_repo.sh` |
| 并行 Agent 任务锁定 | [Agent 协调](#2-agent-协调) | `bash scripts/agent_lock.sh` |
| 定时同步到 GitHub | [定时同步](#3-定时同步) | `bash scripts/periodic_sync.sh` |
| 检查仓库质量 | [最佳实践检查](#4-最佳实践检查) | 手动对照检查清单 |
| 创建 PR/Issue | [PR/Issue 管理](#5-prissue-管理) | `gh` CLI |

## 1. 仓库初始化

按最佳实践一键初始化项目仓库。

```bash
# 完整初始化（含远程仓库创建）
bash "<skill-path>/scripts/init_repo.sh" --path . --type python --visibility private

# 仅设置 .github/ 目录（不创建远程仓库）
bash "<skill-path>/scripts/init_repo.sh" --path . --type python --setup-only
```

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--path` | `.` | 项目路径 |
| `--name` | 目录名 | GitHub 仓库名 |
| `--type` | `python` | 项目类型（python/node） |
| `--visibility` | `private` | public 或 private |
| `--description` | 空 | 仓库描述 |
| `--setup-only` | false | 仅设置本地结构 |

自动创建：`.gitignore`、`.github/workflows/ci.yml`、Issue 模板、PR 模板、`.agent-locks/`。

## 2. Agent 协调

多终端并行 Agent 的任务锁定协议。利用 git push 原子性实现分布式锁。

```bash
SCRIPT="<skill-path>/scripts/agent_lock.sh"

# 认领任务（含要修改的文件列表）
bash "$SCRIPT" claim parse-csv agent-1 src/parser.py tests/test_parser.py

# 释放任务
bash "$SCRIPT" release parse-csv

# 查看所有活跃锁
bash "$SCRIPT" list

# 检测死锁（超过30分钟未释放）
bash "$SCRIPT" stale-check 30

# 强制释放死锁
bash "$SCRIPT" force-release parse-csv
```

**Agent 并行工作流**：
1. Agent 启动 → `claim` 认领任务
2. claim 失败（被抢）→ 选其他任务
3. 工作中 → 后台运行 `periodic_sync.sh`
4. 完成 → `release` 释放任务 → 选下一个

详细协议：见 `references/agent-coordination.md`。

## 3. 定时同步

后台运行，定期将变更推送到 GitHub。

```bash
# 后台启动，每5分钟同步
nohup bash "<skill-path>/scripts/periodic_sync.sh" 300 > sync.log 2>&1 &

# 单次同步
bash "<skill-path>/scripts/periodic_sync.sh" once

# 同步10次后停止
bash "<skill-path>/scripts/periodic_sync.sh" 300 10
```

特性：
- 自动排除敏感文件（.env, *.key, *credentials*）
- 冲突时自动 rebase
- 提交信息含变更统计

## 4. 最佳实践检查

对照检查清单评估仓库质量。详细清单见 `references/best-practices.md`。

**快速检查**（必须项）：
1. README.md 是否包含：名称 + 简介 + 安装指南 + 许可证？
2. .github/workflows/ci.yml 是否存在？
3. LICENSE 文件是否存在？
4. .gitignore 是否完整？
5. Issue/PR 模板是否存在？

**高质量检查**（推荐项）：
6. README 是否有徽章、截图/GIF？
7. 是否有 CONTRIBUTING.md？
8. 是否支持多语言（README.zh-CN.md）？
9. CI 是否通过？

## 5. PR/Issue 管理

使用 `gh` CLI 进行 PR 和 Issue 管理。

```bash
# 创建 PR
gh pr create --title "feat: add parser" --body "## Summary\n- Added CSV parser\n\n## Test Plan\n- [x] Unit tests pass"

# 创建 Issue
gh issue create --title "[BUG] Parser fails" --label bug --body "..."

# 查看 PR 状态
gh pr status

# 合并 PR
gh pr merge <number> --squash
```

## 前提条件

- `gh` CLI 已安装：`brew install gh`
- `gh` 已认证：`gh auth login`
- `python3` 可用（agent_lock.sh 依赖）

## 与现有 Skill 的关系

| Skill | 关系 |
|-------|------|
| `github-uploader` | 本 skill 的仓库初始化是其超集（含 .github/ 模板和 CI） |
| `parallel-agents.md` | 本 skill 的 Agent 协调是其运行时补充（阶段内细粒度锁定） |
| `skill-zip-sync` | 互不冲突，skill-zip-sync 专注 skill 打包同步 |
