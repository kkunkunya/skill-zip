---
name: github-project-manager
description: "GitHub 项目全生命周期管理 v2：仓库初始化、README 美化、分支保护、元数据设置、质量评分、Agent 协调、定时同步、PR/Issue 管理。触发词：GitHub管理、初始化仓库、美化仓库、README美化、分支保护、仓库质量、同步到GitHub、任务锁定、agent协调、创建PR、GitHub最佳实践、仓库结构。使用场景：(1) 新项目初始化（含 .github/ 模板、CI/CD、社区文件）；(2) README 美化（徽章、目录、结构化布局）；(3) 分支保护规则配置；(4) 仓库元数据设置（Topics/Description）；(5) 仓库质量评分；(6) 多 Agent 并行开发协调；(7) 创建 PR/Issue。"
context: fork
---

# GitHub Project Manager v2

GitHub 项目全生命周期管理：初始化 → 美化 → 保护 → 自动化 → 协调 → 质量评估。

## 功能路由

根据用户意图选择对应操作：

| 用户意图 | 模块 | 命令 | 优先级 |
|---------|------|------|--------|
| 初始化新仓库 | [init 初始化](#1-init-初始化) | `bash scripts/init_repo.sh` | P0 |
| 美化 README / 徽章 | [beautify 美化](#2-beautify-美化) | LLM 驱动（分析代码库 → 生成内容） | P0 |
| 设置分支保护 | [protect 保护](#3-protect-保护) | `bash scripts/setup_protection.sh` | P0 |
| 设置 Topics/Description | [metadata 元数据](#4-metadata-元数据) | `bash scripts/setup_metadata.sh` | P1 |
| 检查仓库质量评分 | [quality 质量](#5-quality-质量评估) | `bash scripts/quality_check.sh` | P1 |
| Agent 任务锁定 | [coordinate 协调](#6-coordinate-协调) | `bash scripts/agent_lock.sh` | 按需 |
| 定时同步到 GitHub | [sync 同步](#7-sync-同步) | `bash scripts/periodic_sync.sh` | 按需 |
| 创建 PR/Issue | [manage 管理](#8-manage-管理) | `gh` CLI | 按需 |

### 新项目完整工作流

对于全新项目，按以下顺序执行：

```
① init → ② beautify → ③ protect → ④ metadata → ⑤ quality（验证）
```

## 1. init 初始化

按最佳实践一键初始化项目仓库（增强版：含社区文件）。

```bash
# 完整初始化（含远程仓库创建）
bash "<skill-path>/scripts/init_repo.sh" --path . --type python --visibility private

# 仅设置本地结构（不创建远程仓库）
bash "<skill-path>/scripts/init_repo.sh" --path . --type python --setup-only
```

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--path` | `.` | 项目路径 |
| `--name` | 目录名 | GitHub 仓库名 |
| `--type` | `python` | 项目类型（python/node） |
| `--visibility` | `private` | public 或 private |
| `--description` | 空 | 仓库描述 |
| `--setup-only` | false | 仅设置本地结构 |

自动创建：`.gitignore`、`.github/workflows/ci.yml`、Issue/PR 模板、`.agent-locks/`、`CONTRIBUTING.md`、`CODE_OF_CONDUCT.md`、`SECURITY.md`、`.editorconfig`、`CODEOWNERS`、`.github/dependabot.yml`。

社区文件模板位于 `templates/community/`，可自定义。

## 2. beautify 美化

生成专业的 README.md，包含徽章、目录、结构化布局。**LLM 驱动**——通过分析代码库生成有意义的内容，而非填充模板。

### 工作流程（LLM 驱动）

1. **分析代码库**：
   - 读取项目入口文件（`main.py`/`index.ts`/`pyproject.toml`/`package.json`）
   - 用 Grep 搜索关键功能模块和 API 端点
   - 用 `tree` 命令获取项目结构（排除 `__pycache__`、`node_modules`、`.git`、`.venv`）
   - 检测项目类型、依赖框架、License 类型

2. **生成内容**（LLM 推理，非模板填充）：
   - **项目描述**：基于代码理解生成中英文描述
   - **功能列表**：从实际代码中提取核心功能，而非用户手动输入
   - **安装说明**：根据 `pyproject.toml`/`package.json` 生成准确的安装步骤
   - **使用示例**：基于实际入口点和 CLI 参数生成可运行的示例
   - **徽章选择**：检测实际使用的框架（PyTorch/React/FastAPI 等）生成对应徽章

3. **组装 README**：
   - 按标准结构写入：Header → Badges → Description → TOC → Features → Quick Start → Install → Usage → Structure → Contributing → License
   - 使用 shields.io 徽章 URL 格式
   - 双语支持：可生成 `README.md`（英文）+ `README_zh-CN.md`（中文）并互相链接

4. **用户确认**：生成后展示给用户审阅，根据反馈调整

### 参考模板

脚本 `scripts/beautify_readme.sh` 保留作为**结构参考**（标准 README 布局、徽章 URL 格式、项目树过滤规则），但不再作为主要工作方式。

```bash
# 仅在需要快速生成骨架时使用脚本（不推荐，内容为模板占位符）
bash "<skill-path>/scripts/beautify_readme.sh" --path . --name "My Project" \
    --description "项目描述" --type python --license MIT
```

### 关键原则

- **分析优先于参数**：不要求用户手动输入 features/description，而是从代码中推断
- **具体优先于通用**：生成的使用示例应该能直接运行，而非 `python -m project_name`
- **双语自然**：中英文内容应各自自然，而非机械翻译

## 3. protect 保护

通过 gh api 自动配置分支保护规则。

```bash
# 默认保护 main 分支
bash "<skill-path>/scripts/setup_protection.sh"

# 自定义保护
bash "<skill-path>/scripts/setup_protection.sh" --branch main --reviews 2

# 指定仓库
bash "<skill-path>/scripts/setup_protection.sh" --repo owner/repo --branch develop
```

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--repo` | 自动检测 | 仓库（owner/name） |
| `--branch` | `main` | 要保护的分支 |
| `--reviews` | `1` | 要求的审查人数 |
| `--no-ci` | false | 不要求 CI 通过 |
| `--allow-force-push` | false | 允许强制推送 |

注意：免费计划仅支持公开仓库的分支保护。

## 4. metadata 元数据

设置仓库的 Description、Topics、Homepage、社交预览图。

```bash
bash "<skill-path>/scripts/setup_metadata.sh" \
    --description "Otter USV Ship Berthing with PER-SAC" \
    --topics "reinforcement-learning,robotics,usv,pytorch,gymnasium" \
    --homepage "https://example.com"
```

| 参数 | 说明 |
|------|------|
| `--repo` | 仓库（自动检测） |
| `--description` | 仓库描述 |
| `--topics` | 标签（逗号分隔，自动转小写+连字符） |
| `--homepage` | 主页 URL |
| `--preview` | 社交预览图路径（1280×640px） |

## 5. quality 质量评估

自动扫描仓库，逐项检查最佳实践，生成 0-100 分评分。

```bash
# 评估当前目录
bash "<skill-path>/scripts/quality_check.sh"

# 评估指定项目
bash "<skill-path>/scripts/quality_check.sh" --path /path/to/project

# 详细模式
bash "<skill-path>/scripts/quality_check.sh" --path . --verbose
```

评分维度（满分 100）：
- 基础结构 (30分)：git、README、LICENSE、.gitignore、src/、docs/
- GitHub 配置 (25分)：CI、Issue/PR 模板、Dependabot、CODEOWNERS
- 社区文件 (20分)：CONTRIBUTING、CODE_OF_CONDUCT、SECURITY、.editorconfig
- README 质量 (15分)：徽章、安装说明、许可证、长度
- 代码质量 (10分)：测试目录、包管理配置

## 6. coordinate 协调

多终端并行 Agent 的任务锁定协议。利用 git push 原子性实现分布式锁。

```bash
SCRIPT="<skill-path>/scripts/agent_lock.sh"

bash "$SCRIPT" claim parse-csv agent-1 src/parser.py tests/test_parser.py
bash "$SCRIPT" release parse-csv
bash "$SCRIPT" list
bash "$SCRIPT" stale-check 30
bash "$SCRIPT" force-release parse-csv
```

详细协议：见 `references/agent-coordination.md`。

## 7. sync 同步

后台运行，定期将变更推送到 GitHub。

```bash
# 后台启动，每5分钟同步
nohup bash "<skill-path>/scripts/periodic_sync.sh" 300 > sync.log 2>&1 &

# 单次同步
bash "<skill-path>/scripts/periodic_sync.sh" once
```

特性：自动排除敏感文件、冲突时自动 rebase、提交信息含变更统计。

## 8. manage 管理

使用 `gh` CLI 进行 PR 和 Issue 管理。

```bash
gh pr create --title "feat: add parser" --body "..."
gh issue create --title "[BUG] Parser fails" --label bug
gh pr status
gh pr merge <number> --squash
```

## 前提条件

- `gh` CLI 已安装：`brew install gh`
- `gh` 已认证：`gh auth login`（需要 `repo` scope）
- `python3` 可用（agent_lock.sh 和 setup_metadata.sh 依赖）

## 文件结构

```
github-project-manager/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── init_repo.sh                  # 仓库初始化
│   ├── beautify_readme.sh            # README 美化生成器
│   ├── setup_protection.sh           # 分支保护配置
│   ├── setup_metadata.sh             # 仓库元数据设置
│   ├── quality_check.sh              # 质量评分
│   ├── agent_lock.sh                 # Agent 任务锁定
│   └── periodic_sync.sh              # 定时同步
├── templates/
│   ├── community/                    # 社区文件模板
│   │   ├── CONTRIBUTING.md
│   │   ├── CODE_OF_CONDUCT.md
│   │   ├── SECURITY.md
│   │   └── CODEOWNERS
│   └── workflows/                    # 工作流模板
│       ├── auto-release.yml
│       ├── issue-management.yml
│       └── stale-cleanup.yml
└── references/
    ├── agent-coordination.md
    └── best-practices.md
```

## 与现有 Skill 的关系

| Skill | 关系 |
|-------|------|
| `github-uploader` | 本 skill 的仓库初始化是其超集（含 .github/ 模板和 CI） |
| `image-generator` | 可联动生成 Logo 和社交预览图 |
| `parallel-agents.md` | 本 skill 的 Agent 协调是其运行时补充 |
| `skill-zip-sync` | 互不冲突，skill-zip-sync 专注 skill 打包同步 |
