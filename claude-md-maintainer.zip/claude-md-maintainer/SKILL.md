---
name: claude-md-maintainer
description: CLAUDE.md 维护规范（添加工具/技能、修改规则、精简审计）
---

# Claude MD Maintainer

维护 `~/.claude/` 配置系统的规范和操作手册。

## 管辖范围

| 文件/目录 | 职责 | 维护频率 |
|-----------|------|---------|
| `CLAUDE.md` | 系统总纲（铁律摘要、工具体系、工作模式、偏好） | 规则/工具变更时 |
| `templates/` | 蓝图库（project-spec、progress、parallel-agents） | 流程变更时 |
| `docs/` | 运行时文档（iron-rules、task-system、findings、progress） | 见各文件说明 |
| `skills/registry.json` | 技能注册表（SessionStart Hook 自动同步） | 自动 |
| `agents/` | Agent 角色定义（codex-proxy.md） | 角色变更时 |
| `hooks/` | 事件钩子脚本 | 流程变更时 |

## 核心原则

**只存 LLM 推导不出的约束，其余让 LLM 现场生成。**

判断标准：
- ✅ 需要预写：每次都用且格式固定的（project-spec 模板）、必须严格遵守的约束（通信协议、升级规则）
- ❌ 不需要预写：LLM 能从约束现场生成的（Agent 详细指令、Review 清单、Mermaid 图）

## 操作手册

### 1. 添加新 Skill

```
1. 创建 skills/{name}/SKILL.md
2. registry.json 由 SessionStart Hook 自动同步（无需手动）
3. 如果 skill 影响铁律 → 更新 docs/iron-rules.md
4. 如果 skill 影响工作模式 → 更新 CLAUDE.md §3
5. 不需要更新 templates/（skill 通过 task metadata.skills 绑定）
```

### 2. 修改铁律

```
1. 修改 docs/iron-rules.md（完整版，Single Source）
2. 同步更新 CLAUDE.md §1 铁律摘要表
3. 检查：是否有 skill 引用了被改的铁律？（grep "§N" skills/*/SKILL.md）
```

### 3. 修改 Team 模式

```
1. 修改 templates/parallel-agents.md（角色/协议/Gate 的 Single Source）
2. 同步更新 CLAUDE.md §3 Team 模式部分
3. 如涉及 AI Proxy → 同步更新 agents/codex-proxy.md
```

### 4. 精简审计（定期）

当系统感觉臃肿时，执行以下检查：

```
审计清单：
□ CLAUDE.md 是否超过 200 行？→ 找冗余段落精简
□ templates/ 中每个文件是否都在近 30 天内被实际使用？→ 未使用则考虑删除
□ docs/ 中是否有内容和 CLAUDE.md 重复？→ CLAUDE.md 只保留摘要，详情留 docs/
□ registry.json 中是否有 skill 目录已不存在？→ 清理孤儿条目
□ hooks/ 中是否有脚本未在 settings.json 中注册？→ 清理孤儿脚本
□ agents/ 中的角色定义是否和 parallel-agents.md 矛盾？→ 以 parallel-agents.md 为准
```

### 5. 一致性检查命令

快速检查配置系统的健康状态：

```bash
# 检查 CLAUDE.md 引用的文件是否都存在
grep -oE '`[^`]*\.(md|json|sh)`' ~/.claude/CLAUDE.md | tr -d '`' | while read f; do
  resolved=$(echo "$f" | sed "s|^docs/|$HOME/.claude/docs/|;s|^templates/|$HOME/.claude/templates/|;s|^agents/|$HOME/.claude/agents/|;s|^skills/|$HOME/.claude/skills/|")
  [ ! -f "$resolved" ] && echo "❌ 引用不存在: $f"
done

# 检查 registry.json 中的 skill 目录是否都存在
python3 -c "
import json, os
reg = json.load(open(os.path.expanduser('~/.claude/skills/registry.json')))
for s in reg['skills']:
    path = os.path.expanduser(f'~/.claude/skills/{s[\"name\"]}')
    if not os.path.isdir(path): print(f'❌ 孤儿 skill: {s[\"name\"]}')
"
```

## 文件间引用关系（维护时参考）

```
CLAUDE.md
├── §1 铁律摘要 ← docs/iron-rules.md（完整版）
├── §2 工具体系 ← skills/registry.json
├── §3 Team 模式 ← templates/parallel-agents.md
└── §3 Subagent ← 内置 agent 类型

templates/parallel-agents.md
├── AI Proxy → agents/codex-proxy.md
├── 文件锁 → skills/github-project-manager/scripts/agent_lock.sh
└── 技能绑定 → docs/task-system.md 的 WAL 约定

docs/task-system.md
├── 期望映射 → templates/project-spec.md 的 E/D 编号
└── 进度记录 → templates/progress.md 的格式
```
