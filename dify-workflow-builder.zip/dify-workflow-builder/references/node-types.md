# Dify 完整节点类型参考

## 节点分类总览

| 分类 | 节点类型 | 用途 |
|-----|---------|------|
| **入口** | start, trigger | 工作流起点 |
| **出口** | end, answer | 工作流终点/流式输出 |
| **AI** | llm, question-classifier, parameter-extractor | 大模型调用 |
| **数据** | code, template-transform, variable-aggregator, variable-assigner | 数据处理 |
| **控制** | if-else, iteration, iteration-start | 流程控制 |
| **外部** | http-request, tool, knowledge-retrieval | 外部集成 |
| **辅助** | list-operator, doc-extractor, assigner | 辅助操作 |

## 详细配置

### Start 节点

**输入变量类型**：
- `text-input` - 单行文本
- `paragraph` - 多行文本
- `select` - 下拉选择
- `number` - 数字输入
- `file` - 文件上传
- `file-list` - 多文件上传

### LLM 节点

**支持的模型提供商**：
- `openai` - GPT-4, GPT-3.5
- `anthropic` - Claude 系列
- `deepseek` - DeepSeek Chat
- `zhipu` - 智谱 GLM
- `qwen` - 通义千问
- `moonshot` - Kimi
- `minimax` - MiniMax
- `baichuan` - 百川

**completion_params 参数**：
- `temperature` - 0-2，控制随机性
- `max_tokens` - 最大输出 token
- `top_p` - 核采样参数
- `presence_penalty` - 存在惩罚
- `frequency_penalty` - 频率惩罚

### Code 节点

**支持语言**：
- `python3` - Python 3.x（推荐）
- `javascript` - Node.js

**Python 可用标准库**：
json, re, math, datetime, random, hashlib, base64, urllib, collections, itertools

**函数签名要求**：
```python
def main(param1: str, param2: int) -> dict:
    return {"output1": value1, "output2": value2}
```

### HTTP Request 节点

**支持方法**：GET, POST, PUT, DELETE, PATCH, HEAD

**Body 类型**：
- `none` - 无请求体
- `form-data` - 表单数据
- `x-www-form-urlencoded` - URL 编码
- `json` - JSON 格式
- `raw-text` - 原始文本

### If-Else 节点

**比较运算符**：
- `contains` / `not contains` - 包含/不包含
- `start with` / `end with` - 开头/结尾
- `is` / `is not` - 等于/不等于
- `empty` / `not empty` - 空/非空
- `=` / `≠` / `>` / `<` / `≥` / `≤` - 数值比较

**逻辑运算符**：`and`, `or`

### Knowledge Retrieval 节点

**检索模式**：
- `single` - 单知识库检索
- `multiple` - 多知识库检索

**重排序模型**：
- Cohere Rerank
- Jina Reranker
- BGE Reranker
