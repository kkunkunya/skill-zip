---
name: dify-workflow-builder
description: |
  Dify 智能体工作流创建与优化专家。用于：(1) 创建新的 Dify Workflow/Chatflow 应用 YAML 配置；(2) 优化现有 Dify 工作流的节点设计、Prompt 模板、变量传递；(3) 分析和调试 Dify DSL 文件；(4) 设计多节点 RAG、意图识别、多维度分析等复杂工作流。
  触发场景：用户提到 Dify、工作流设计、智能体创建、DSL/YAML 配置、节点编排、Prompt 优化等关键词时使用。
---

# Dify Workflow Builder

## 概述

Dify 是一个开源的 LLM 应用开发平台，支持通过可视化画布构建 AI 工作流。本技能提供：
- **工作流设计**：从需求到完整 YAML 配置
- **节点编排**：40+ 节点类型的最佳实践
- **Prompt 优化**：高效的提示词模板设计
- **调试诊断**：DSL 文件分析与问题定位

## 工作流决策树

```
用户需求
├── 单轮对话 → Workflow 模式
│   ├── 简单问答 → Start → LLM → End
│   ├── 数据处理 → Start → Code → LLM → End
│   └── 多维分析 → Start → 意图识别 → 并行分析 → 汇总 → End
│
├── 多轮对话 → Chatflow 模式
│   ├── 知识问答 → Start → Knowledge Retrieval → LLM → End
│   └── 复杂交互 → Start → Question Classifier → 分支处理 → End
│
└── 自动化任务 → Trigger 模式
    ├── 定时执行 → Trigger (Schedule) → 处理流程 → End
    └── 事件驱动 → Trigger (Webhook) → 处理流程 → End
```

## Dify DSL 结构 (v0.6+)

### 顶层结构

```yaml
app:
  name: 应用名称
  description: 应用描述
  icon: 🤖                    # emoji 或图标路径
  icon_background: '#1E88E5'  # 图标背景色
  mode: workflow              # workflow | chatflow
  use_icon_as_answer_icon: false

kind: app
version: 0.1.5               # DSL 版本

workflow:
  conversation_variables: [] # 会话变量（chatflow 专用）
  environment_variables: []  # 环境变量
  features: {...}            # 功能配置
  graph:
    edges: [...]             # 节点连接
    nodes: [...]             # 节点定义
    viewport: {x, y, zoom}   # 画布视图
```

### 节点通用结构

```yaml
- id: '1736000000001'        # 唯一 ID（推荐时间戳格式）
  type: custom               # 固定值
  data:
    type: start|llm|code|end|...  # 节点类型
    title: 节点标题
    desc: 节点描述
    selected: false
    # ... 节点特定配置
  position: {x: 80, y: 300}
  width: 244
  height: 90
  sourcePosition: right
  targetPosition: left
```

### 边（连接）结构

```yaml
- id: 'source-id-source-target-id-target'
  source: '1736000000001'    # 源节点 ID
  target: '1736000000002'    # 目标节点 ID
  sourceHandle: source       # 输出句柄
  targetHandle: target       # 输入句柄
  type: custom
  data:
    sourceType: start        # 源节点类型
    targetType: llm          # 目标节点类型
    isInIteration: false
```

## 核心节点类型

### 1. Start 节点（开始）

```yaml
data:
  type: start
  title: 开始
  desc: 接收用户输入
  variables:
    - variable: user_input   # 变量名
      label: 请输入问题       # 显示标签
      type: paragraph        # text-input | paragraph | select | number
      required: true
      max_length: 2000
      options: []            # select 类型的选项
```

### 2. LLM 节点（大模型）

```yaml
data:
  type: llm
  title: 意图识别
  desc: 分析用户意图
  model:
    provider: deepseek       # openai | anthropic | deepseek | ...
    name: deepseek-chat      # 模型名称
    mode: chat
    completion_params:
      temperature: 0.3       # 0-1，越低越确定
      max_tokens: 2000
  prompt_template:
    - id: uuid-1
      role: system
      text: |
        你是一个意图识别专家。
        请分析用户问题并以 JSON 格式输出。
    - id: uuid-2
      role: user
      text: '{{#1736000000001.user_input#}}'  # 变量引用
  context:
    enabled: false           # 是否启用知识库上下文
    variable_selector: []
  vision:
    enabled: false           # 是否启用视觉能力
  variables: []
```

### 3. Code 节点（代码）

```yaml
data:
  type: code
  title: 数据处理
  desc: 解析 JSON 并提取参数
  code_language: python3     # python3 | javascript
  code: |
    import json

    def main(input_text: str) -> dict:
        try:
            result = json.loads(input_text)
        except:
            result = {"error": "解析失败"}
        return {
            "parsed_data": json.dumps(result, ensure_ascii=False),
            "status": "success"
        }
  variables:
    - variable: input_text
      value_selector:
        - '1736000000002'    # 源节点 ID
        - text               # 源变量名
  outputs:
    parsed_data:
      type: string
      children: null
    status:
      type: string
      children: null
```

### 4. End 节点（结束）

```yaml
data:
  type: end
  title: 结束
  desc: 输出最终结果
  outputs:
    - variable: result
      value_selector:
        - '1736000000010'
        - final_output
```

### 5. If-Else 节点（条件分支）

```yaml
data:
  type: if-else
  title: 条件判断
  conditions:
    - id: condition-1
      logical_operator: and
      conditions:
        - variable_selector:
            - '1736000000003'
            - intent
          comparison_operator: contains
          value: 分析
  cases:
    - id: case-true
      logical_operator: and
      conditions: [...]
    - id: case-false
      logical_operator: and
      conditions: []
```

### 6. Knowledge Retrieval 节点（知识检索）

```yaml
data:
  type: knowledge-retrieval
  title: 知识库检索
  dataset_ids:
    - dataset-uuid-1
    - dataset-uuid-2
  retrieval_mode: multiple   # single | multiple
  query_variable_selector:
    - '1736000000001'
    - user_input
  single_retrieval_config:
    model:
      provider: openai
      name: gpt-4
    score_threshold: 0.5
  multiple_retrieval_config:
    top_k: 5
    score_threshold: 0.3
    reranking_model:
      provider: cohere
      name: rerank-english-v2.0
```

### 7. HTTP Request 节点

```yaml
data:
  type: http-request
  title: API 调用
  method: POST
  url: https://api.example.com/data
  headers:
    - key: Content-Type
      value: application/json
    - key: Authorization
      value: 'Bearer {{#env.API_KEY#}}'
  body:
    type: json
    data: '{"query": "{{#1736000000001.user_input#}}"}'
  timeout: 30
```

### 8. Template Transform 节点（Jinja2 模板）

```yaml
data:
  type: template-transform
  title: 模板渲染
  template: |
    # 分析报告

    **分析对象**: {{ company_name }}
    **分析时间**: {{ timestamp }}

    ## 结果
    {{ analysis_result }}
  variables:
    - variable: company_name
      value_selector: ['node-id', 'company']
    - variable: timestamp
      value_selector: ['node-id', 'time']
    - variable: analysis_result
      value_selector: ['node-id', 'result']
```

### 9. Iteration 节点（循环）

```yaml
data:
  type: iteration
  title: 批量处理
  iterator_selector:
    - '1736000000003'
    - items_array
  output_selector:
    - '1736000000005'
    - processed_item
  # 内部包含子图（iteration_start → 处理节点 → iteration_end）
```

### 10. Question Classifier 节点（问题分类）

```yaml
data:
  type: question-classifier
  title: 问题分类
  query_variable_selector:
    - '1736000000001'
    - user_input
  model:
    provider: openai
    name: gpt-4
  classes:
    - id: class-1
      name: 财务分析
    - id: class-2
      name: 风险评估
    - id: class-3
      name: 其他问题
```

## 变量引用语法

### Prompt 模板中引用变量

```
{{#node_id.variable_name#}}
```

**示例**：
- `{{#1736000000001.user_input#}}` - 引用 Start 节点的 user_input
- `{{#1736000000005.text#}}` - 引用 LLM 节点的输出文本
- `{{#env.API_KEY#}}` - 引用环境变量

### Code 节点中的 value_selector

```yaml
variables:
  - variable: local_var_name
    value_selector:
      - 'source_node_id'
      - 'source_variable_name'
```

## 最佳实践

### 1. 节点 ID 命名规范

```
推荐：时间戳格式 '1736000000001', '1736000000002'...
优点：唯一性强，便于排序和追踪
```

### 2. Prompt 设计原则

| 原则 | 说明 |
|-----|------|
| **角色明确** | System prompt 明确定义 AI 角色和能力边界 |
| **输出格式** | 要求 JSON 输出时，提供示例格式 |
| **字数控制** | 明确输出长度限制（如"150字内"） |
| **温度设置** | 分析任务用低温度(0.1-0.3)，创意任务用高温度(0.7-0.9) |

### 3. 工作流设计模式

**模式 A：意图识别 + 分支处理**
```
Start → 意图识别(LLM) → 参数提取(Code) → If-Else → 分支处理 → 汇总 → End
```

**模式 B：多维度并行分析**
```
Start → 数据获取(Code) → [盈利分析, 偿债分析, 现金流分析](并行LLM) → 综合评估 → End
```

**模式 C：RAG 增强问答**
```
Start → Knowledge Retrieval → LLM(带上下文) → End
```

**模式 D：迭代处理**
```
Start → 数据拆分(Code) → Iteration[处理单项] → 结果汇总(Code) → End
```

### 4. 错误处理

```yaml
# Code 节点中的防御性编程
def main(input_text: str) -> dict:
    try:
        result = json.loads(input_text)
    except json.JSONDecodeError:
        result = {"error": "JSON 解析失败", "raw": input_text[:100]}
    except Exception as e:
        result = {"error": str(e)}
    return {"output": json.dumps(result, ensure_ascii=False)}
```

### 5. 性能优化

| 优化点 | 建议 |
|-------|------|
| **减少 LLM 调用** | 合并可以一次完成的分析任务 |
| **并行执行** | 无依赖的节点可以并行（Dify 自动处理） |
| **缓存数据** | 静态数据用 Code 节点内嵌，避免重复获取 |
| **精简 Prompt** | 删除冗余指令，保留核心要求 |

## 常见问题排查

| 问题 | 可能原因 | 解决方案 |
|-----|---------|---------|
| 变量引用失败 | 节点 ID 或变量名错误 | 检查 `{{#node_id.var#}}` 格式 |
| Code 节点报错 | 语法错误或依赖缺失 | 只能用标准库，检查 return 格式 |
| LLM 输出不稳定 | 温度过高或 Prompt 模糊 | 降低 temperature，明确输出格式 |
| 工作流超时 | 节点过多或 LLM 响应慢 | 精简流程，使用更快的模型 |
| 导入失败 | DSL 版本不兼容 | 检查 version 字段，升级 Dify |

## 资源

### references/

- `node-types.md` - 完整节点类型参考（40+ 节点详细配置）
- `prompt-templates.md` - 常用 Prompt 模板库
- `workflow-patterns.md` - 工作流设计模式详解

### assets/

- `templates/` - 常用工作流 YAML 模板
  - `simple-qa.yml` - 简单问答模板
  - `rag-chatbot.yml` - RAG 知识问答模板
  - `multi-analysis.yml` - 多维度分析模板

