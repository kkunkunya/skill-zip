# Changelog

## [Unreleased] - 2026-02-08

### Added - Math Equation Support

#### Documentation
- **docx.md**: Added comprehensive "Working with Math Equations" section
  - Method 1: Using Pandoc (recommended)
  - Method 2: Using docxlatex library (with compatibility notes)
  - Method 3: Raw XML extraction for advanced use cases
  - Creating documents with equations (Pandoc and Python methods)
  - Editing equations (round-trip and direct XML editing)
  - Common equation formats and important notes

- **docx-math.md**: New detailed reference document for OMML equations
  - OMML structure and elements
  - Format comparison (OMML, LaTeX, MathML)
  - Reading, creating, and editing equations
  - MathML to OMML conversion
  - LaTeX to OMML conversion
  - Common equation patterns
  - Important constraints and troubleshooting
  - Best practices

- **SKILL.md**: Updated quick reference tables
  - Added "With Equations" column to reading content table
  - Added equation support to creating documents table
  - Added new scripts: `insert_equation.py`, `extract_equations.py`
  - Added "Equation Processing Patterns" section with examples

#### Scripts
- **extract_equations.py**: Extract mathematical equations from Word documents
  - Supports text, JSON, and Markdown output formats
  - Uses docxlatex library for extraction
  - Command-line interface with help documentation

- **insert_equation.py**: Insert mathematical equations into Word documents
  - Supports LaTeX input with automatic conversion to OMML
  - Auto-detects MML2OMML.XSL stylesheet location
  - Can create new documents or append to existing ones
  - Supports batch insertion from file

#### Dependencies
- Updated dependency list in docx.md:
  - **docxlatex**: For extracting equations (optional)
  - **lxml**: For XML/XSLT processing (optional)
  - **latex2mathml**: For LaTeX → MathML conversion (optional)
  - **sympy**: For generating equations from Python expressions (optional)

### Testing
- Comprehensive test suite created and passed:
  - ✅ Pandoc: Markdown → Word with equations
  - ✅ Pandoc: Word → Markdown equation extraction
  - ✅ XML direct extraction of OMML equations
  - ✅ Equation rendering verification (all types)
  - ✅ Round-trip conversion (Markdown ↔ Word)

### Known Issues
- docxlatex library may have compatibility issues with some Word documents
  - Workaround: Use Pandoc (Method 1) or XML extraction (Method 3)
  - Added warning note in documentation

### Recommendations
- **Primary method**: Use Pandoc for equation processing (simple and reliable)
- **Advanced use**: Use XML parsing with lxml for programmatic control
- **Fallback**: docxlatex for equation-only extraction (check compatibility first)

---

## Summary

This update adds complete mathematical equation support to the document-suite skill, addressing the issue of "equations always having rendering problems." The implementation is based on:

1. **OMML (Office Math Markup Language)**: Word's native equation format
2. **Pandoc**: Primary tool for LaTeX ↔ OMML conversion
3. **XML manipulation**: For advanced programmatic control

All core functionality has been tested and verified to work correctly.
