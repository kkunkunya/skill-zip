---
name: document-suite
description: "Unified document processing for DOCX, XLSX, PDF, PPTX. Create, read, edit documents with full support for text, images, tables, and formatting. Supports: (1) Word documents - create with docx-js, edit with OOXML, extract with pandoc; (2) Excel - create/edit with openpyxl, analyze with pandas; (3) PDF - extract with pdfplumber, create with reportlab, convert to images; (4) PowerPoint - create with html2pptx, edit OOXML, generate thumbnails. Use when working with Office files or PDFs."
---

# Document Suite

Unified skill for processing Office documents and PDFs.

## File Type Detection

| Extension | Type | Reference |
|-----------|------|-----------|
| `.docx` | Word document | [docx.md](references/docx.md) |
| `.xlsx`, `.xlsm` | Excel spreadsheet | [xlsx.md](references/xlsx.md) |
| `.pdf` | PDF document | [pdf.md](references/pdf.md) |
| `.pptx` | PowerPoint presentation | [pptx.md](references/pptx.md) |

## Quick Reference

### Reading Content

| Format | Text Only | With Images | Raw Access |
|--------|-----------|-------------|------------|
| **DOCX** | `pandoc file.docx -o out.md` | Unpack → `word/media/` | `unpack.py` |
| **XLSX** | `pandas.read_excel()` | N/A | `openpyxl` |
| **PDF** | `pdfplumber` | `pdftoppm -jpeg` | `pdfimages -all` |
| **PPTX** | `python -m markitdown` | `thumbnail.py` | `unpack.py` |

### Creating Documents

| Format | Library | Language |
|--------|---------|----------|
| **DOCX** | docx-js | JavaScript |
| **XLSX** | openpyxl | Python |
| **PDF** | reportlab | Python |
| **PPTX** | html2pptx | JavaScript |

### Editing Documents

| Format | Method |
|--------|--------|
| **DOCX** | Unpack → Edit XML → Pack |
| **XLSX** | openpyxl (preserves formulas) |
| **PDF** | Limited (pypdf for merge/split) |
| **PPTX** | Unpack → Edit XML → Pack |

## Workflow Selection

1. **Identify file type** by extension
2. **Read the corresponding reference file** for detailed instructions
3. **Follow the workflow** for your task (read/create/edit)

## Common Scripts

Located in `scripts/` directory:

| Script | Purpose |
|--------|---------|
| `unpack.py` | Extract OOXML archives (docx/pptx) |
| `pack.py` | Repackage OOXML archives |
| `validate.py` | Validate OOXML structure |
| `recalc.py` | Recalculate Excel formulas |
| `thumbnail.py` | Generate PPTX thumbnail grids |
| `html2pptx.js` | Convert HTML to PPTX slides |
| `convert_pdf_to_images.py` | PDF → PNG images |

## Image Extraction Patterns

For documents with important images (papers, presentations):

```bash
# PDF: Extract all embedded images
pdfimages -all document.pdf images/img

# PDF: Convert pages to images (for visual analysis)
pdftoppm -jpeg -r 150 document.pdf page

# PPTX: Generate thumbnail grid
python scripts/thumbnail.py presentation.pptx

# DOCX/PPTX: Access embedded media
python scripts/unpack.py document.docx unpacked/
ls unpacked/word/media/   # or ppt/media/ for PPTX
```
