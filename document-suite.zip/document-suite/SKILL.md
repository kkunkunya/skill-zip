---
name: document-suite
description: "Unified document processing for DOCX, XLSX, PDF, PPTX. Create, read, edit documents with full support for text, images, tables, and formatting. Supports: (1) Word documents - create with docx-js, edit with OOXML, extract with pandoc; (2) Excel - create/edit with openpyxl, analyze with pandas; (3) PDF - extract with pdfplumber, create with reportlab, convert to images; (4) PowerPoint - create with html2pptx, edit OOXML, generate thumbnails. Use when working with Office files or PDFs."
---

# Document Suite

Unified skill for processing Office documents and PDFs.

## File Type Detection

| Extension | Type | Reference |
|-----------|------|-----------|
| `.docx` | Word document | [docx.md](references/docx.md) |
| `.xlsx`, `.xlsm` | Excel spreadsheet | [xlsx.md](references/xlsx.md) |
| `.pdf` | PDF document | [pdf.md](references/pdf.md) |
| `.pptx` | PowerPoint presentation | [pptx.md](references/pptx.md) |

## Quick Reference

### Reading Content

| Format | Text Only | With Equations | With Images | Raw Access |
|--------|-----------|----------------|-------------|------------|
| **DOCX** | `pandoc file.docx -o out.md` | Same (auto converts to LaTeX) | Unpack → `word/media/` | `unpack.py` |
| **XLSX** | `pandas.read_excel()` | N/A | `openpyxl` |
| **PDF** | `pdfplumber` | `pdftoppm -jpeg` | `pdfimages -all` |
| **PPTX** | `python -m markitdown` | `thumbnail.py` | `unpack.py` |

### Creating Documents

| Format | Library | Language | With Equations |
|--------|---------|----------|----------------|
| **DOCX** | docx-js | JavaScript | `pandoc md→docx` (LaTeX in Markdown) |
| **XLSX** | openpyxl | Python |
| **PDF** | reportlab | Python |
| **PPTX** | html2pptx | JavaScript |

### Editing Documents

| Format | Method |
|--------|--------|
| **DOCX** | Unpack → Edit XML → Pack |
| **XLSX** | openpyxl (preserves formulas) |
| **PDF** | Limited (pypdf for merge/split) |
| **PPTX** | Unpack → Edit XML → Pack |

## Workflow Selection

1. **Identify file type** by extension
2. **Read the corresponding reference file** for detailed instructions
3. **Follow the workflow** for your task (read/create/edit)

## Common Scripts

Located in `scripts/` directory:

| Script | Purpose |
|--------|---------|
| `unpack.py` | Extract OOXML archives (docx/pptx) |
| `pack.py` | Repackage OOXML archives |
| `validate.py` | Validate OOXML structure |
| `recalc.py` | Recalculate Excel formulas |
| `thumbnail.py` | Generate PPTX thumbnail grids |
| `html2pptx.js` | Convert HTML to PPTX slides |
| `convert_pdf_to_images.py` | PDF → PNG images |
| `insert_equation.py` | Insert equations into Word (MathML → OMML) |
| `extract_equations.py` | Extract equations from Word (OMML → LaTeX) |

## Equation Processing Patterns

For documents with mathematical equations:

```bash
# DOCX: Extract equations to LaTeX (recommended)
pandoc document.docx -o output.md
# Equations appear as $...$ (inline) or $$...$$ (display)

# DOCX: Extract equations only
pip install docxlatex
python -c "from docxlatex import Document; print(Document('file.docx').equations)"

# DOCX: Create document with equations
# Write Markdown with LaTeX equations, then:
pandoc input.md -o output.docx

# DOCX: Insert equation programmatically
python scripts/insert_equation.py output.docx "x^2 + 2x + 1"
```

## Image Extraction Patterns

For documents with important images (papers, presentations):

```bash
# PDF: Extract all embedded images
pdfimages -all document.pdf images/img

# PDF: Convert pages to images (for visual analysis)
pdftoppm -jpeg -r 150 document.pdf page

# PPTX: Generate thumbnail grid
python scripts/thumbnail.py presentation.pptx

# DOCX/PPTX: Access embedded media
python scripts/unpack.py document.docx unpacked/
ls unpacked/word/media/   # or ppt/media/ for PPTX
```
