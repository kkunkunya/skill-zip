# Word Math Equations Reference

Complete guide for working with mathematical equations in Word documents using OMML (Office Math Markup Language).

## Overview

Word documents store mathematical equations in **OMML (Office Math Markup Language)** format, which is part of the Office Open XML (OOXML) standard. This guide covers reading, creating, and manipulating equations.

## Equation Formats

### Format Comparison

| Format | Description | Use Case |
|--------|-------------|----------|
| **OMML** | Office Math Markup Language | Word's native format |
| **LaTeX** | Academic typesetting standard | User input, Markdown |
| **MathML** | W3C web standard | Intermediate conversion format |

### Conversion Chain

```
LaTeX ←→ MathML ←→ OMML
  ↓         ↓         ↓
Pandoc   XSLT    Word
```

## OMML Structure

### Basic Structure

OMML equations are stored in `word/document.xml` with the namespace:
```
http://schemas.openxmlformats.org/officeDocument/2006/math
```

### Inline Equation

```xml
<m:oMath>
  <m:r>
    <m:t>x^2 + 1</m:t>
  </m:r>
</m:oMath>
```

### Display Equation (Standalone Line)

```xml
<m:oMathPara>
  <m:oMath>
    <m:f>
      <m:num><m:r><m:t>1</m:t></m:r></m:num>
      <m:den><m:r><m:t>2</m:t></m:r></m:den>
    </m:f>
  </m:oMath>
</m:oMathPara>
```

### Common OMML Elements

| Element | Description | Example |
|---------|-------------|---------|
| `<m:oMath>` | Math zone container | All equations |
| `<m:oMathPara>` | Display equation wrapper | Standalone equations |
| `<m:f>` | Fraction | 1/2 |
| `<m:num>` | Numerator | Top of fraction |
| `<m:den>` | Denominator | Bottom of fraction |
| `<m:rad>` | Radical (root) | √x |
| `<m:sup>` | Superscript | x² |
| `<m:sub>` | Subscript | x₁ |
| `<m:r>` | Run (text container) | x, y, z |
| `<m:t>` | Text content | Actual characters |

## Reading Equations

### Method 1: Pandoc (Recommended)

**Advantages**: Simple, automatic conversion to LaTeX

```bash
pandoc input.docx -o output.md
```

**Output format**:
- Inline: `$E = mc^2$`
- Display: `$$x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}$$`

### Method 2: docxlatex Library

**Advantages**: Lightweight, equations only

```bash
pip install docxlatex
```

```python
from docxlatex import Document

doc = Document("document.docx")
equations = doc.equations  # List of LaTeX strings

for i, eq in enumerate(equations, 1):
    print(f"Equation {i}: {eq}")
```

### Method 3: Raw XML Extraction

**Advantages**: Full control, access to OMML

```python
from zipfile import ZipFile
from lxml import etree

# Extract XML
with ZipFile('document.docx') as docx:
    xml_content = docx.read('word/document.xml')

# Parse XML
tree = etree.fromstring(xml_content)

# Define namespaces
namespaces = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math'
}

# Find all equations
equations = tree.xpath('//m:oMath', namespaces=namespaces)

for eq in equations:
    omml_xml = etree.tostring(eq, encoding='unicode', pretty_print=True)
    print(omml_xml)
```

## Creating Equations

### Method 1: Pandoc (Recommended)

**Advantages**: Simple, supports full LaTeX syntax

Create a Markdown file with LaTeX equations:

```markdown
# Mathematical Document

Inline equation: The famous equation $E = mc^2$ relates energy and mass.

Display equation:

$$
x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}
$$

This is the quadratic formula.
```

Convert to Word:

```bash
pandoc input.md -o output.docx
```

### Method 2: Python with MathML

**Advantages**: Programmatic control, automation

**Requirements**:
- MML2OMML.XSL stylesheet from Microsoft Office
- Typically located at: `C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL`

```python
from lxml import etree
from docx import Document

def insert_mathml_equation(doc, mathml_string, xsl_path='MML2OMML.XSL'):
    """
    Insert MathML equation into Word document.
    
    Args:
        doc: python-docx Document object
        mathml_string: MathML equation string (must include namespace)
        xsl_path: Path to MML2OMML.XSL stylesheet
    
    Returns:
        Paragraph object containing the equation
    """
    # Parse MathML
    tree = etree.fromstring(mathml_string)
    
    # Load XSLT stylesheet
    xslt = etree.parse(xsl_path)
    transform = etree.XSLT(xslt)
    
    # Convert to OMML
    omml = transform(tree)
    
    # Insert into document
    paragraph = doc.add_paragraph()
    paragraph._element.append(omml.getroot())
    
    return paragraph

# Example usage
doc = Document()

# MathML equation (must include namespace)
mathml = '''<math xmlns="http://www.w3.org/1998/Math/MathML">
  <mfrac>
    <mn>1</mn>
    <mn>2</mn>
  </mfrac>
</math>'''

insert_mathml_equation(doc, mathml)
doc.save('equation.docx')
```

### Method 3: SymPy Integration

**Advantages**: Generate equations from Python expressions

```python
from sympy import *
from sympy.printing.mathml import mathml
from lxml import etree
from docx import Document

def sympy_to_word(doc, expr, xsl_path='MML2OMML.XSL'):
    """
    Convert SymPy expression to Word equation.
    
    Args:
        doc: python-docx Document object
        expr: SymPy expression
        xsl_path: Path to MML2OMML.XSL stylesheet
    
    Returns:
        Paragraph object containing the equation
    """
    # Generate MathML
    math_ml = mathml(expr, printer='presentation')
    mathml_string = f'<math xmlns="http://www.w3.org/1998/Math/MathML">{math_ml}</math>'
    
    # Convert to OMML
    tree = etree.fromstring(mathml_string)
    xslt = etree.parse(xsl_path)
    transform = etree.XSLT(xslt)
    omml = transform(tree)
    
    # Insert into document
    paragraph = doc.add_paragraph()
    paragraph._element.append(omml.getroot())
    
    return paragraph

# Example usage
from sympy.abc import x, a, b, c

doc = Document()

# Quadratic formula
formula = (-b + sqrt(b**2 - 4*a*c)) / (2*a)
sympy_to_word(doc, formula)

doc.save('sympy_equation.docx')
```

## Editing Equations

### Method 1: Pandoc Round-Trip (Recommended)

**Advantages**: Safe, preserves formatting

```bash
# 1. Convert to Markdown
pandoc input.docx -o temp.md

# 2. Edit equations in temp.md
# Change $x^2$ to $x^3$, etc.

# 3. Convert back to Word
pandoc temp.md -o output.docx
```

### Method 2: Direct XML Editing

**Advantages**: Precise control, complex documents

```python
from zipfile import ZipFile
from lxml import etree
import shutil
import os

def edit_equations_in_docx(input_path, output_path, edit_function):
    """
    Edit equations in a Word document by modifying XML.
    
    Args:
        input_path: Path to input .docx file
        output_path: Path to output .docx file
        edit_function: Function that takes and returns an lxml element
    """
    # Create temporary directory
    temp_dir = 'temp_docx'
    os.makedirs(temp_dir, exist_ok=True)
    
    # Extract document
    with ZipFile(input_path, 'r') as zip_ref:
        zip_ref.extractall(temp_dir)
    
    # Read and parse XML
    xml_path = os.path.join(temp_dir, 'word', 'document.xml')
    with open(xml_path, 'rb') as f:
        tree = etree.parse(f)
    
    root = tree.getroot()
    
    # Define namespaces
    namespaces = {
        'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math'
    }
    
    # Find and edit equations
    equations = root.xpath('//m:oMath', namespaces=namespaces)
    for eq in equations:
        edit_function(eq)
    
    # Save modified XML
    with open(xml_path, 'wb') as f:
        tree.write(f, encoding='utf-8', xml_declaration=True)
    
    # Repackage as .docx
    shutil.make_archive('temp_output', 'zip', temp_dir)
    shutil.move('temp_output.zip', output_path)
    
    # Cleanup
    shutil.rmtree(temp_dir)

# Example: Replace all 'x' with 'y' in equations
def replace_x_with_y(equation_element):
    for text_elem in equation_element.xpath('.//m:t', namespaces={'m': 'http://schemas.openxmlformats.org/officeDocument/2006/math'}):
        if text_elem.text:
            text_elem.text = text_elem.text.replace('x', 'y')
    return equation_element

edit_equations_in_docx('input.docx', 'output.docx', replace_x_with_y)
```

## MathML to OMML Conversion

### MML2OMML.XSL Stylesheet

**Purpose**: Convert MathML to OMML (Word's native format)

**Location**: Included with Microsoft Office
- Office 2010: `C:\Program Files (x86)\Microsoft Office\Office14\MML2OMML.XSL`
- Office 2016+: `C:\Program Files\Microsoft Office\root\Office16\MML2OMML.XSL`

**Important Notes**:
- ✅ Must use official Microsoft version
- ✅ Third-party versions may not be compatible
- ✅ Required for reliable MathML → OMML conversion

### Using the Stylesheet

```python
from lxml import etree

# Load stylesheet
xslt = etree.parse('MML2OMML.XSL')
transform = etree.XSLT(xslt)

# Convert MathML to OMML
mathml_tree = etree.fromstring(mathml_string)
omml_tree = transform(mathml_tree)

# Result is ready to insert into Word document
omml_element = omml_tree.getroot()
```

## LaTeX to OMML Conversion

### Two-Step Process

LaTeX → MathML → OMML

**Step 1: LaTeX to MathML**

```python
from latex2mathml.converter import convert

latex = r'\frac{1}{2}'
mathml = convert(latex)
```

**Step 2: MathML to OMML**

```python
from lxml import etree

tree = etree.fromstring(mathml)
xslt = etree.parse('MML2OMML.XSL')
transform = etree.XSLT(xslt)
omml = transform(tree)
```

**Alternative: Use Pandoc**

```bash
# Much simpler for batch conversion
echo '$\frac{1}{2}$' | pandoc -f latex -t docx -o equation.docx
```

## Common Patterns

### Fraction

**LaTeX**: `\frac{1}{2}`

**MathML**:
```xml
<math xmlns="http://www.w3.org/1998/Math/MathML">
  <mfrac>
    <mn>1</mn>
    <mn>2</mn>
  </mfrac>
</math>
```

**OMML**:
```xml
<m:oMath>
  <m:f>
    <m:num><m:r><m:t>1</m:t></m:r></m:num>
    <m:den><m:r><m:t>2</m:t></m:r></m:den>
  </m:f>
</m:oMath>
```

### Square Root

**LaTeX**: `\sqrt{x}`

**MathML**:
```xml
<math xmlns="http://www.w3.org/1998/Math/MathML">
  <msqrt>
    <mi>x</mi>
  </msqrt>
</math>
```

**OMML**:
```xml
<m:oMath>
  <m:rad>
    <m:radPr><m:degHide m:val="1"/></m:radPr>
    <m:deg/>
    <m:e><m:r><m:t>x</m:t></m:r></m:e>
  </m:rad>
</m:oMath>
```

### Superscript

**LaTeX**: `x^2`

**MathML**:
```xml
<math xmlns="http://www.w3.org/1998/Math/MathML">
  <msup>
    <mi>x</mi>
    <mn>2</mn>
  </msup>
</math>
```

**OMML**:
```xml
<m:oMath>
  <m:sSup>
    <m:e><m:r><m:t>x</m:t></m:r></m:e>
    <m:sup><m:r><m:t>2</m:t></m:r></m:sup>
  </m:sSup>
</m:oMath>
```

## Important Constraints

### MathML Requirements

1. **Must include namespace**:
   ```xml
   <!-- ✅ Correct -->
   <math xmlns="http://www.w3.org/1998/Math/MathML">...</math>
   
   <!-- ❌ Wrong -->
   <math>...</math>
   ```

2. **No newlines in string** (causes multiple equation zones):
   ```python
   # ✅ Correct
   mathml = '<math xmlns="..."><mfrac><mn>1</mn><mn>2</mn></mfrac></math>'
   
   # ❌ Wrong
   mathml = '''
   <math xmlns="...">
     <mfrac>
       <mn>1</mn>
       <mn>2</mn>
     </mfrac>
   </math>
   '''
   ```

### python-docx Limitations

**No native equation API** - must use XML manipulation:

```python
# ❌ Does not exist
# doc.add_equation(...)

# ✅ Correct approach
paragraph = doc.add_paragraph()
paragraph._element.append(omml_element)
```

### Namespace Handling

Always define namespaces when working with OOXML:

```python
NAMESPACES = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'm': 'http://schemas.openxmlformats.org/officeDocument/2006/math',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
}

# Use in XPath queries
equations = tree.xpath('//m:oMath', namespaces=NAMESPACES)
```

## Troubleshooting

### Equation Not Displaying

**Possible causes**:
1. Missing namespace in MathML
2. Incorrect XSLT stylesheet version
3. Malformed OMML XML

**Solution**: Use Pandoc for reliable conversion

### Conversion Errors

**Problem**: `new_dom.getroot()` returns `None`

**Cause**: XSLT transformation failed (wrong stylesheet version)

**Solution**: Use official MML2OMML.XSL from Microsoft Office

### Multiple Equation Zones

**Problem**: One equation splits into multiple zones

**Cause**: Newlines in MathML string

**Solution**: Remove all newlines before conversion

## Best Practices

1. **Use Pandoc for most tasks** - simpler and more reliable
2. **Use python-docx + XSLT for programmatic control** - when automation is needed
3. **Always validate MathML** - include namespace, no newlines
4. **Test with simple equations first** - before complex formulas
5. **Keep OMML as intermediate format** - convert to/from LaTeX for editing

## References

- [Office Open XML Math Specification](https://c-rex.net/samples/ooxml/e1/part4/)
- [MathML Specification (W3C)](https://www.w3.org/TR/MathML/)
- [Pandoc User's Guide](https://pandoc.org/MANUAL.html)
- [python-docx Issue #320](https://github.com/python-openxml/python-docx/issues/320)
