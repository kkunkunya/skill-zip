#!/usr/bin/env python3
"""
Insert mathematical equations into Word documents.

This script provides utilities for inserting equations into .docx files.
Supports LaTeX input with automatic conversion to OMML via MathML.

Usage:
    python insert_equation.py output.docx "x^2 + 2x + 1"
    python insert_equation.py output.docx --latex-file equations.txt
    python insert_equation.py existing.docx "E = mc^2" --append

Examples:
    # Create new document with equation
    python insert_equation.py output.docx "\\frac{1}{2}"
    
    # Append to existing document
    python insert_equation.py document.docx "x^2" --append
    
    # Insert multiple equations from file
    python insert_equation.py output.docx --latex-file equations.txt

Requirements:
    - MML2OMML.XSL stylesheet from Microsoft Office
    - Location: C:\\Program Files\\Microsoft Office\\root\\Office16\\MML2OMML.XSL
    
Dependencies:
    pip install python-docx lxml latex2mathml

Note:
    For simple use cases, consider using Pandoc instead:
        echo '$x^2 + 1$' | pandoc -f markdown -t docx -o output.docx
"""

import sys
import argparse
from pathlib import Path

try:
    from docx import Document
    from lxml import etree
except ImportError as e:
    print(f"Error: Required library not found: {e}")
    print("Install with: pip install python-docx lxml")
    sys.exit(1)

try:
    from latex2mathml.converter import convert as latex_to_mathml
except ImportError:
    print("Warning: latex2mathml not found. LaTeX conversion will not work.")
    print("Install with: pip install latex2mathml")
    latex_to_mathml = None


# Default XSL stylesheet paths to try
XSL_PATHS = [
    'MML2OMML.XSL',  # Current directory
    '/usr/share/office/MML2OMML.XSL',  # Linux
    'C:\\Program Files\\Microsoft Office\\root\\Office16\\MML2OMML.XSL',  # Office 2016+
    'C:\\Program Files (x86)\\Microsoft Office\\Office14\\MML2OMML.XSL',  # Office 2010
]


def find_xsl_stylesheet():
    """Find MML2OMML.XSL stylesheet."""
    for path in XSL_PATHS:
        if Path(path).exists():
            return path
    return None


def insert_mathml_equation(doc, mathml_string, xsl_path):
    """
    Insert MathML equation into Word document.
    
    Args:
        doc: python-docx Document object
        mathml_string: MathML equation string (must include namespace)
        xsl_path: Path to MML2OMML.XSL stylesheet
    
    Returns:
        Paragraph object containing the equation
    """
    try:
        # Parse MathML
        tree = etree.fromstring(mathml_string.encode('utf-8'))
        
        # Load XSLT stylesheet
        xslt = etree.parse(xsl_path)
        transform = etree.XSLT(xslt)
        
        # Convert to OMML
        omml = transform(tree)
        
        if omml.getroot() is None:
            raise ValueError("XSLT transformation failed - check stylesheet version")
        
        # Insert into document
        paragraph = doc.add_paragraph()
        paragraph._element.append(omml.getroot())
        
        return paragraph
    
    except Exception as e:
        print(f"Error inserting equation: {e}", file=sys.stderr)
        raise


def latex_to_omml(latex_string, xsl_path):
    """
    Convert LaTeX to OMML via MathML.
    
    Args:
        latex_string: LaTeX equation string
        xsl_path: Path to MML2OMML.XSL stylesheet
    
    Returns:
        MathML string ready for insertion
    """
    if latex_to_mathml is None:
        raise ImportError("latex2mathml library required for LaTeX conversion")
    
    # Convert LaTeX to MathML
    mathml = latex_to_mathml(latex_string)
    
    # Ensure namespace is present
    if 'xmlns=' not in mathml:
        mathml = mathml.replace('<math>', '<math xmlns="http://www.w3.org/1998/Math/MathML">')
    
    return mathml


def insert_latex_equation(doc, latex_string, xsl_path):
    """
    Insert LaTeX equation into Word document.
    
    Args:
        doc: python-docx Document object
        latex_string: LaTeX equation string
        xsl_path: Path to MML2OMML.XSL stylesheet
    
    Returns:
        Paragraph object containing the equation
    """
    mathml = latex_to_omml(latex_string, xsl_path)
    return insert_mathml_equation(doc, mathml, xsl_path)


def main():
    parser = argparse.ArgumentParser(
        description="Insert mathematical equations into Word documents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "output",
        help="Path to output .docx file"
    )
    
    parser.add_argument(
        "equation",
        nargs="?",
        help="LaTeX equation string (e.g., 'x^2 + 1')"
    )
    
    parser.add_argument(
        "--latex-file",
        help="File containing LaTeX equations (one per line)"
    )
    
    parser.add_argument(
        "--append",
        action="store_true",
        help="Append to existing document instead of creating new"
    )
    
    parser.add_argument(
        "--xsl",
        help="Path to MML2OMML.XSL stylesheet (auto-detected if not specified)"
    )
    
    args = parser.parse_args()
    
    # Validate input
    if not args.equation and not args.latex_file:
        parser.error("Either equation or --latex-file must be specified")
    
    # Find XSL stylesheet
    xsl_path = args.xsl or find_xsl_stylesheet()
    if not xsl_path:
        print("Error: MML2OMML.XSL stylesheet not found.", file=sys.stderr)
        print("\nPlease specify the path with --xsl option.", file=sys.stderr)
        print("The stylesheet is typically located at:", file=sys.stderr)
        for path in XSL_PATHS[2:]:
            print(f"  {path}", file=sys.stderr)
        sys.exit(1)
    
    print(f"Using stylesheet: {xsl_path}")
    
    # Load or create document
    if args.append and Path(args.output).exists():
        doc = Document(args.output)
        print(f"Appending to existing document: {args.output}")
    else:
        doc = Document()
        print(f"Creating new document: {args.output}")
    
    # Insert equations
    try:
        if args.equation:
            # Single equation from command line
            insert_latex_equation(doc, args.equation, xsl_path)
            print(f"Inserted equation: {args.equation}")
        
        elif args.latex_file:
            # Multiple equations from file
            latex_file = Path(args.latex_file)
            if not latex_file.exists():
                print(f"Error: File not found: {args.latex_file}", file=sys.stderr)
                sys.exit(1)
            
            equations = latex_file.read_text(encoding='utf-8').strip().split('\n')
            for i, eq in enumerate(equations, 1):
                eq = eq.strip()
                if eq and not eq.startswith('#'):  # Skip empty lines and comments
                    insert_latex_equation(doc, eq, xsl_path)
                    print(f"Inserted equation {i}: {eq}")
        
        # Save document
        doc.save(args.output)
        print(f"\nDocument saved: {args.output}")
    
    except Exception as e:
        print(f"\nError: {e}", file=sys.stderr)
        print("\nTip: For simple use cases, consider using Pandoc:", file=sys.stderr)
        print("  echo '$x^2 + 1$' | pandoc -f markdown -t docx -o output.docx", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
