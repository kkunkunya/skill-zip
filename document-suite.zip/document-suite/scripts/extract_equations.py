#!/usr/bin/env python3
"""
Extract mathematical equations from Word documents.

This script extracts equations from .docx files and outputs them in LaTeX format.
Uses the docxlatex library for simple and reliable extraction.

Usage:
    python extract_equations.py input.docx
    python extract_equations.py input.docx --output equations.txt
    python extract_equations.py input.docx --format json

Examples:
    # Print equations to console
    python extract_equations.py document.docx
    
    # Save to file
    python extract_equations.py document.docx --output equations.txt
    
    # Output as JSON
    python extract_equations.py document.docx --format json

Dependencies:
    pip install docxlatex
"""

import sys
import argparse
import json
from pathlib import Path

try:
    from docxlatex import Document
except ImportError:
    print("Error: docxlatex library not found.")
    print("Install it with: pip install docxlatex")
    sys.exit(1)


def extract_equations(docx_path):
    """
    Extract equations from a Word document.
    
    Args:
        docx_path: Path to .docx file
    
    Returns:
        List of equation strings in LaTeX format
    """
    try:
        doc = Document(docx_path)
        return doc.equations
    except Exception as e:
        print(f"Error reading document: {e}", file=sys.stderr)
        sys.exit(1)


def format_text(equations):
    """Format equations as plain text."""
    if not equations:
        return "No equations found in document."
    
    lines = [f"Found {len(equations)} equation(s):\n"]
    for i, eq in enumerate(equations, 1):
        lines.append(f"{i}. {eq}")
    
    return "\n".join(lines)


def format_json(equations):
    """Format equations as JSON."""
    return json.dumps({
        "count": len(equations),
        "equations": equations
    }, indent=2)


def format_markdown(equations):
    """Format equations as Markdown."""
    if not equations:
        return "No equations found in document."
    
    lines = [f"# Extracted Equations\n", f"Total: {len(equations)} equation(s)\n"]
    for i, eq in enumerate(equations, 1):
        lines.append(f"## Equation {i}\n")
        lines.append(f"```latex\n{eq}\n```\n")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Extract mathematical equations from Word documents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "input",
        help="Path to input .docx file"
    )
    
    parser.add_argument(
        "-o", "--output",
        help="Path to output file (default: print to console)"
    )
    
    parser.add_argument(
        "-f", "--format",
        choices=["text", "json", "markdown"],
        default="text",
        help="Output format (default: text)"
    )
    
    args = parser.parse_args()
    
    # Validate input file
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)
    
    if input_path.suffix.lower() != '.docx':
        print(f"Warning: File does not have .docx extension: {args.input}", file=sys.stderr)
    
    # Extract equations
    equations = extract_equations(str(input_path))
    
    # Format output
    if args.format == "json":
        output = format_json(equations)
    elif args.format == "markdown":
        output = format_markdown(equations)
    else:
        output = format_text(equations)
    
    # Write output
    if args.output:
        output_path = Path(args.output)
        output_path.write_text(output, encoding='utf-8')
        print(f"Equations extracted to: {args.output}")
    else:
        print(output)


if __name__ == "__main__":
    main()
