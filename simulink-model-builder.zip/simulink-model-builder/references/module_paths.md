# Simscape Electrical 模块路径映射表

## 版本对照

| MATLAB 版本 | 主库名 | 状态 |
|------------|--------|------|
| R2016a 及更早 | `powerlib` | 旧结构 |
| R2016b ~ R2023b | `powerlib` | 重构后 |
| R2024a+ | `sps_lib` | 当前推荐 |
| 未来 | `ee_lib` | Simscape 原生 |

---

## R2024b sps_lib 完整路径

### 电源模块 (Sources)

| 模块名 | 路径 |
|--------|------|
| powergui | `sps_lib/powergui` |
| AC Voltage Source | `sps_lib/Sources/AC Voltage Source` |
| DC Voltage Source | `sps_lib/Sources/DC Voltage Source` |
| Three-Phase Source | `sps_lib/Sources/Three-Phase Source` |
| Three-Phase Programmable Voltage Source | `sps_lib/Sources/Three-Phase Programmable Voltage Source` |
| Controlled Voltage Source | `sps_lib/Sources/Controlled Voltage Source` |
| Controlled Current Source | `sps_lib/Sources/Controlled Current Source` |

### 电力电子器件 (Power Electronics)

| 模块名 | 路径 |
|--------|------|
| Universal Bridge | `sps_lib/Power Electronics/Universal Bridge` |
| IGBT/Diode | `sps_lib/Power Electronics/IGBT//Diode` |
| IGBT | `sps_lib/Power Electronics/IGBT` |
| Diode | `sps_lib/Power Electronics/Diode` |
| MOSFET | `sps_lib/Power Electronics/Mosfet` |
| Thyristor | `sps_lib/Power Electronics/Thyristor` |
| GTO | `sps_lib/Power Electronics/GTO` |
| Ideal Switch | `sps_lib/Power Electronics/Ideal Switch` |

### 无源元件 (Passives)

| 模块名 | 路径 |
|--------|------|
| Series RLC Branch | `sps_lib/Passives/Series RLC Branch` |
| Parallel RLC Branch | `sps_lib/Passives/Parallel RLC Branch` |
| Three-Phase Series RLC Branch | `sps_lib/Passives/Three-Phase Series RLC Branch` |
| Three-Phase Parallel RLC Branch | `sps_lib/Passives/Three-Phase Parallel RLC Branch` |
| Mutual Inductance | `sps_lib/Passives/Mutual Inductance` |
| Saturable Transformer | `sps_lib/Passives/Saturable Transformer` |

### 测量模块 (Sensors and Measurements)

| 模块名 | 路径 |
|--------|------|
| Voltage Measurement | `sps_lib/Sensors and Measurements/Voltage Measurement` |
| Current Measurement | `sps_lib/Sensors and Measurements/Current Measurement` |
| Three-Phase V-I Measurement | `sps_lib/Sensors and Measurements/Three-Phase V-I Measurement` |
| Power (Phasor) | `sps_lib/Sensors and Measurements/Power (Phasor)` |
| Impedance Measurement | `sps_lib/Sensors and Measurements/Impedance Measurement` |
| Multimeter | `sps_lib/Sensors and Measurements/Multimeter` |

### 工具模块 (Utilities)

| 模块名 | 路径 |
|--------|------|
| Ground | `sps_lib/Utilities/Ground` |
| Neutral | `sps_lib/Utilities/Neutral` |
| Bus Selector | `sps_lib/Utilities/Bus Selector` |

---

## 参数兼容性

### Universal Bridge

| 版本 | 器件类型参数 | 桥臂数参数 | 可选器件 |
|------|-------------|-----------|---------|
| 旧版 | `Arms` = 'Diodes' | (合并) | Diodes, Thyristors, GTO, IGBT, MOSFET |
| R2024b | `Device` = 'Diodes' | `Arms` = '1'/'2'/'3' | Diodes, Thyristors, GTO/Diodes, Forced-commutated devices, IGBT/Diodes, MOSFET/Diodes |

**正确用法 (R2024b)**:
```matlab
set_param([model, '/Bridge'], 'Device', 'Diodes');
set_param([model, '/Bridge'], 'Arms', '3');
```

### Powergui

不同版本离散仿真模式参数名：

| 版本 | 参数名 |
|------|--------|
| 某些旧版 | `SimulationType` |
| 中期版本 | `SimulationMode` |
| 某些版本 | `SolverType` |

**兼容写法**:
```matlab
param_names = {'SimulationMode', 'SimulationType', 'SolverType'};
for i = 1:length(param_names)
    try
        set_param([model, '/powergui'], param_names{i}, 'Discrete');
        break;
    catch
    end
end
```

### Series RLC Branch

| 参数 | 说明 | 可选值 |
|------|------|--------|
| BranchType | 元件类型 | 'R', 'L', 'C', 'RL', 'RC', 'LC', 'RLC' |
| Resistance | 电阻值 | 数值字符串 |
| Inductance | 电感值 | 数值字符串 |
| Capacitance | 电容值 | 数值字符串 |

---

## 常见错误及解决

### 错误: "没有名为 'powerlib/xxx' 的模块"

**原因**: MATLAB R2024a+ 将 `powerlib` 重命名为 `sps_lib`

**解决**:
```matlab
% 动态检测库
libs = {'sps_lib', 'powerlib'};
for i = 1:length(libs)
    try
        load_system(libs{i});
        active_lib = libs{i};
        break;
    catch
    end
end
```

### 错误: "参数 'xxx' 设置无效"

**原因**: 参数名称或可选值在不同版本有差异

**解决**: 使用 `check_params.m` 脚本查看当前版本的正确参数名和可选值

### 错误: "模块路径不存在"

**原因**: 子目录结构在不同版本有变化

**解决**: 使用 `find_blocks.m` 脚本动态搜索正确路径
