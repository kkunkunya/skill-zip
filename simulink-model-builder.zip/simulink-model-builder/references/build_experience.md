# Simulink 搭建经验文档

> 本文档由 LLM 在每次搭建后更新（更新式，非追加式）。
> 记录对下次搭建有价值的经验，不记流水账。

## Buck Converter (开关电源)

用了: Ideal Switch + Diode + Series RLC Branch + DC Voltage Source + Ground + Voltage/Current Measurement
没用 Universal Bridge: Buck 不是桥式拓扑，Universal Bridge 是给整流/逆变用的

端口关键信息:
- Voltage Measurement 端口是 LConn1(+) / LConn2(-)，没有 RConn！这是最常踩的坑
- Current Measurement 端口是 LConn1 / RConn1，标准命名
- Ideal Switch 有 LConn1(电气入) / RConn1(电气出) / 1(控制信号)
- Diode 是 LConn1(阳极) / RConn1(阴极)，注意方向
- Ground 只有 LConn1

连线模式: DC源→开关→电感→电容/负载，续流二极管阳极接地、阴极接开关输出点
参数注意: powergui 离散模式参数名因版本不同（SimulationType / SimulationMode / SolverType），用 try-catch

## 三相整流

用了: Universal Bridge (Device='Diodes') — 一个模块顶6个二极管
端口: LConn1~3(AC输入) / RConn1(DC+) / RConn2(DC-)
参数陷阱: Device 枚举值有空格 'IGBT / Diodes'（斜杠两边有空格），不是 'IGBT/Diodes'

## 三相电源

Three-Phase Source 端口: 只有 RConn1/RConn2/RConn3（输出端），没有 LConn
参数名(R2025a): Voltage(不是PhaseVoltage) / Frequency / InternalConnection(枚举: Y, Yn, Yg)

## 通用经验

- autorouting 用 'smart' 比 'on' 效果好
- 连线前先确认端口名，用 get_param(blk, 'PortConnectivity') 查
- 参数名不确定时用 get_param(blk, 'DialogParameters') 查
- Simscape 电气端口用 LConn/RConn 命名，Simulink 信号端口用数字 1/2/3
