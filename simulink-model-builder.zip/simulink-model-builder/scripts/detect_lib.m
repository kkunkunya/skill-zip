%% detect_lib.m - 检测当前 MATLAB 版本可用的电力系统库
% 返回: active_lib - 可用库名称 ('sps_lib', 'powerlib', 或 'ee_lib')
%
% 用法:
%   active_lib = detect_lib();
%   fprintf('使用库: %s\n', active_lib);

function active_lib = detect_lib()
    % 按优先级尝试加载库
    libs = {'sps_lib', 'powerlib', 'ee_lib'};
    active_lib = '';

    fprintf('=== 检测电力系统库 ===\n');

    for i = 1:length(libs)
        lib = libs{i};
        try
            load_system(lib);
            fprintf('✓ %s 可用\n', lib);
            if isempty(active_lib)
                active_lib = lib;
            end
        catch
            fprintf('✗ %s 不可用\n', lib);
        end
    end

    if isempty(active_lib)
        error('未找到可用的电力系统库！请检查 Simscape Electrical 是否已安装。');
    end

    fprintf('\n推荐使用: %s\n', active_lib);
end
