%% find_blocks.m - 在指定库中搜索模块
% 输入: lib - 库名称 (如 'sps_lib')
%       block_name - 要搜索的模块名称 (如 'Universal Bridge')
% 返回: path - 完整模块路径
%
% 用法:
%   path = find_blocks('sps_lib', 'Universal Bridge');
%   add_block(path, 'myModel/Bridge');

function path = find_blocks(lib, block_name)
    % 确保库已加载
    if ~bdIsLoaded(lib)
        load_system(lib);
    end

    % 搜索模块
    results = find_system(lib, 'SearchDepth', 15, 'Name', block_name);

    if isempty(results)
        % 尝试模糊搜索
        all_blocks = find_system(lib, 'SearchDepth', 15, 'Type', 'block');
        matches = {};
        for i = 1:length(all_blocks)
            if contains(all_blocks{i}, block_name, 'IgnoreCase', true)
                matches{end+1} = all_blocks{i};
            end
        end

        if ~isempty(matches)
            fprintf('未找到精确匹配，但发现相似模块:\n');
            for i = 1:length(matches)
                fprintf('  %s\n', matches{i});
            end
            path = matches{1};
            fprintf('使用: %s\n', path);
        else
            error('模块未找到: %s (库: %s)', block_name, lib);
        end
    else
        path = results{1};
        if length(results) > 1
            fprintf('找到多个匹配，使用第一个: %s\n', path);
        end
    end
end
