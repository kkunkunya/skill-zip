%% check_params.m - 检查模块的可用参数及其可选值
% 输入: block_path - 模块路径 (如 'myModel/Bridge')
% 输出: 打印所有可设置参数及其可选值
%
% 用法:
%   % 先添加模块到临时模型
%   new_system('temp');
%   add_block('sps_lib/Power Electronics/Universal Bridge', 'temp/Bridge');
%   check_params('temp/Bridge');
%   close_system('temp', 0);

function check_params(block_path)
    fprintf('=== 模块参数检查: %s ===\n\n', block_path);

    % 获取所有对话框参数
    params = get_param(block_path, 'DialogParameters');

    if isempty(params)
        fprintf('此模块没有可配置参数。\n');
        return;
    end

    fields = fieldnames(params);
    fprintf('共 %d 个参数:\n\n', length(fields));

    for i = 1:length(fields)
        name = fields{i};
        p = params.(name);

        fprintf('【%s】\n', name);

        % 获取当前值
        try
            current = get_param(block_path, name);
            fprintf('  当前值: %s\n', current);
        catch
            fprintf('  当前值: (无法获取)\n');
        end

        % 显示可选值（如果是枚举类型）
        if isfield(p, 'Enum') && ~isempty(p.Enum)
            fprintf('  可选值: %s\n', strjoin(p.Enum, ', '));
        end

        % 显示类型
        if isfield(p, 'Type')
            fprintf('  类型: %s\n', p.Type);
        end

        fprintf('\n');
    end
end
