%% beautify_model.m - Simulink 模型一键美化函数
% Input:  model - 模型名称（字符串），必须已打开或可打开
% Output: 无（直接修改并保存模型）
% Pos:    scripts/ 工具函数，供测试脚本和用户直接调用
%
% 功能：
%   1. 设置画布白色背景
%   2. 创建功能区域注释（Area）
%   3. 按功能类别着色
%   4. 自动布局（从内到外）
%   5. 连线优化
%   6. 信号标签命名
%   7. 隐藏默认块名称
%   8. 添加标题注释
%
% 用法:
%   beautify_model('myBuckConverter');
%
% 依赖: 无外部依赖，仅使用 Simulink 标准 API（R2018b+）

function beautify_model(model)
    fprintf('=== 开始美化模型: %s ===\n', model);

    % 确保模型已打开
    try
        open_system(model);
    catch ME
        fprintf('ERROR 无法打开模型 %s: %s\n', model, ME.message);
        return;
    end

    %% Step 1: 设置画布背景
    try
        set_param(model, 'ScreenColor', 'white');
        fprintf('[1/8] 画布背景已设置为白色\n');
    catch ME
        fprintf('[1/8] 画布背景设置失败: %s\n', ME.message);
    end

    %% Step 2: 创建功能区域 Area
    try
        create_functional_areas(model);
        fprintf('[2/8] 功能区域已创建\n');
    catch ME
        fprintf('[2/8] 功能区域创建失败: %s\n', ME.message);
    end

    %% Step 3: 块着色（按功能分组）
    try
        colorize_blocks_by_type(model);
        fprintf('[3/8] 块着色已完成\n');
    catch ME
        fprintf('[3/8] 块着色失败: %s\n', ME.message);
    end

    %% Step 4: 自动布局
    try
        % 先布局子系统（从内到外）
        subsystems = find_system(model, 'BlockType', 'SubSystem');
        for i = 1:length(subsystems)
            try
                Simulink.BlockDiagram.arrangeSystem(subsystems{i});
            catch
                % 某些子系统可能无法布局（如 Mask 子系统），跳过
            end
        end
        % 再布局顶层
        Simulink.BlockDiagram.arrangeSystem(model);
        fprintf('[4/8] 自动布局已完成\n');
    catch ME
        fprintf('[4/8] 自动布局失败: %s\n', ME.message);
    end

    %% Step 5: 优化连线
    try
        lines = find_system(model, 'FindAll', 'on', 'SearchDepth', 1, 'Type', 'line');
        if ~isempty(lines)
            Simulink.BlockDiagram.routeLine(lines);
        end
        fprintf('[5/8] 连线已优化\n');
    catch ME
        fprintf('[5/8] 连线优化失败（可能版本<R2019a）: %s\n', ME.message);
    end

    %% Step 6: 信号标签
    try
        label_key_signals(model);
        fprintf('[6/8] 信号标签已添加\n');
    catch ME
        fprintf('[6/8] 信号标签失败: %s\n', ME.message);
    end

    %% Step 7: 隐藏默认名称
    try
        hide_default_names(model);
        fprintf('[7/8] 默认名称已隐藏\n');
    catch ME
        fprintf('[7/8] 隐藏默认名称失败: %s\n', ME.message);
    end

    %% Step 8: 添加标题注释
    try
        add_title_annotation(model);
        fprintf('[8/8] 标题注释已添加\n');
    catch ME
        fprintf('[8/8] 标题注释失败: %s\n', ME.message);
    end

    %% 保存
    try
        save_system(model);
        fprintf('=== 美化完成并已保存: %s ===\n', model);
    catch ME
        fprintf('=== 保存失败: %s ===\n', ME.message);
    end
end

%% ========== 子函数 ==========

function create_functional_areas(model)
    % 创建功能区域注释（Area）
    % 默认区域定义: {名称, [left, top, width, height], 背景色, 前景色}
    areas = {
        'Power Stage',    [30, 30, 500, 350],   '[0.85 0.92 1.0]',  'blue';
        'Control Loop',   [30, 400, 500, 250],  '[1.0 0.95 0.85]',  '[0.8 0.4 0]';
        'Measurements',   [550, 30, 300, 350],  '[0.85 1.0 0.85]',  'darkGreen';
    };

    for i = 1:size(areas, 1)
        name = areas{i,1};
        pos  = areas{i,2};
        bg   = areas{i,3};
        fg   = areas{i,4};

        area_path = [model, '/', name];

        % 跳过已存在的 Area
        existing = find_system(model, 'SearchDepth', 1, 'Name', name);
        if ~isempty(existing)
            continue;
        end

        try
            add_block('built-in/Area', area_path, 'Position', pos);

            % 查找并设置样式
            handles = find_system(model, 'FindAll', 'on', 'Type', 'annotation', ...
                'AnnotationType', 'area_annotation');
            for j = 1:length(handles)
                try
                    txt = get_param(handles(j), 'PlainText');
                    if strcmp(txt, name)
                        set_param(handles(j), 'BackgroundColor', bg);
                        set_param(handles(j), 'ForegroundColor', fg);
                        set_param(handles(j), 'FontSize', '12');
                    end
                catch
                end
            end
        catch ME
            fprintf('  Area "%s" 创建失败: %s\n', name, ME.message);
        end
    end
end

function colorize_blocks_by_type(model)
    % 按功能类型给块着色
    % 颜色方案：电源=黄色，开关器件=红色/浅红，测量=绿色，控制=蓝色

    blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');

    for i = 1:length(blocks)
        blk = blocks{i};
        try
            bt = get_param(blk, 'BlockType');
            name = get_param(blk, 'Name');

            % 电源类 → 黄色
            if any(strcmpi(bt, {'DCVoltageSource', 'ACVoltageSource'})) || ...
               contains(lower(name), {'source', 'vin', 'vdc'})
                set_param(blk, 'BackgroundColor', 'yellow');

            % 开关器件 → 浅红色
            elseif any(strcmpi(bt, {'SubSystem'})) && ...
                   any(contains(lower(name), {'switch', 'sw', 'igbt', 'mosfet'}))
                set_param(blk, 'BackgroundColor', '[1.0 0.8 0.8]');
            elseif any(strcmpi(bt, {'Switch', 'IdealSwitch'}))
                set_param(blk, 'BackgroundColor', '[1.0 0.8 0.8]');

            % 二极管 → 浅橙色
            elseif strcmpi(bt, 'SubSystem') && contains(lower(name), 'diode')
                set_param(blk, 'BackgroundColor', 'orange');

            % 测量 → 浅绿色
            elseif any(strcmpi(bt, {'VoltageMeasurement', 'CurrentMeasurement'})) || ...
                   contains(lower(name), {'meas', 'sensor'})
                set_param(blk, 'BackgroundColor', '[0.8 1.0 0.8]');

            % 控制相关 → 浅蓝色
            elseif any(strcmpi(bt, {'PIDController', 'DiscreteIntegrator', 'Sum'})) || ...
                   contains(lower(name), {'pi', 'control', 'pwm', 'ref', 'error'})
                set_param(blk, 'BackgroundColor', 'lightBlue');

            % Scope/显示 → 浅灰色
            elseif any(strcmpi(bt, {'Scope', 'Display', 'ToWorkspace'}))
                set_param(blk, 'BackgroundColor', '[0.95 0.95 0.95]');

            % powergui → 白色（不着色）
            elseif contains(lower(name), 'powergui')
                % 保持默认
            end
        catch
            % 某些块可能不支持 BackgroundColor
        end
    end
end

function label_key_signals(model)
    % 给关键信号命名
    % 搜索常见测量块的输出端口并命名

    % 信号名映射: {块名关键词, 端口类型, 端口索引, 标签}
    signal_map = {
        'Vout',     'Outport', 1, 'Vout';
        'Vmeas',    'Outport', 1, 'Vout';
        'Vdc_meas', 'Outport', 1, 'Vdc';
        'Imeas',    'Outport', 1, 'IL';
        'Iload',    'Outport', 1, 'Iload';
        'PWM',      'Outport', 1, 'PWM';
        'Vref',     'Outport', 1, 'Vref';
    };

    blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');

    for i = 1:size(signal_map, 1)
        keyword   = signal_map{i,1};
        port_type = signal_map{i,2};
        port_idx  = signal_map{i,3};
        label     = signal_map{i,4};

        for j = 1:length(blocks)
            name = get_param(blocks{j}, 'Name');
            if strcmpi(name, keyword)
                try
                    ph = get_param(blocks{j}, 'PortHandles');
                    ports = ph.(port_type);
                    if length(ports) >= port_idx
                        line_h = get_param(ports(port_idx), 'Line');
                        if line_h ~= -1
                            set_param(line_h, 'Name', label);
                        end
                    end
                catch
                end
                break;
            end
        end
    end
end

function hide_default_names(model)
    % 隐藏自动生成的默认块名称（如 Gain1, Sum2 等）
    blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');
    default_patterns = {'^Gain\d*$', '^Sum\d*$', '^Product\d*$', ...
                        '^Mux\d*$', '^Demux\d*$', '^Ground\d*$', ...
                        '^GND\d*$', '^Constant\d*$', '^Scope\d*$'};
    for i = 1:length(blocks)
        name = get_param(blocks{i}, 'Name');
        for j = 1:length(default_patterns)
            if ~isempty(regexp(name, default_patterns{j}, 'once'))
                try
                    set_param(blocks{i}, 'HideAutomaticName', 'on');
                catch
                    % 旧版本可能不支持 HideAutomaticName
                    try
                        set_param(blocks{i}, 'ShowName', 'off');
                    catch
                    end
                end
                break;
            end
        end
    end
end

function add_title_annotation(model)
    % 在模型左上角添加标题注释
    model_name = get_param(model, 'Name');
    title_text = sprintf('%s - Auto Generated', model_name);

    % 检查是否已有标题注释（避免重复）
    handles = find_system(model, 'FindAll', 'on', 'Type', 'annotation');
    for i = 1:length(handles)
        try
            txt = get_param(handles(i), 'PlainText');
            if contains(txt, 'Auto Generated')
                return;  % 已存在标题，跳过
            end
        catch
        end
    end

    ann = Simulink.Annotation([model, '/', title_text]);
    ann.Position = [20, -30];
    ann.FontSize = 14;
    ann.FontWeight = 'bold';
    ann.ForegroundColor = '[0.2 0.2 0.6]';
    ann.BackgroundColor = 'white';
end
