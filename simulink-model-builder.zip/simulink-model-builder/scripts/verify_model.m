%% verify_model.m - Simulink 模型闭环验证函数
% Input:  model - 模型名称（字符串），必须已保存为 .slx
%         opts  - 可选结构体：
%                 .stop_time  - 验证仿真时长（默认 '0.01'）
%                 .signals    - 需检查的信号名 cell（默认 {}）
%                 .ranges     - 信号预期范围 cell of [min, max]（默认 {}）
% Output: result - 结构体，包含各项检查结果
% Pos:    scripts/ 工具函数，模型搭建完成后必调用
%
% 用法:
%   result = verify_model('myBuckConverter');
%   result = verify_model('myModel', struct('stop_time','0.05'));
%
% 依赖: 无外部依赖，仅使用 Simulink 标准 API

function result = verify_model(model, opts)
    if nargin < 2, opts = struct(); end
    if ~isfield(opts, 'stop_time'), opts.stop_time = '0.01'; end
    if ~isfield(opts, 'signals'),   opts.signals = {}; end
    if ~isfield(opts, 'ranges'),    opts.ranges = {}; end

    result = struct();
    result.model = model;
    result.pass = true;
    result.checks = {};
    result.errors = {};
    result.warnings = {};

    fprintf('\n========================================\n');
    fprintf('  模型验证: %s\n', model);
    fprintf('========================================\n\n');

    %% Check 1: 模型加载
    fprintf('[1/5] 模型加载...');
    try
        load_system(model);
        fprintf(' ✅ 成功\n');
        result.checks{end+1} = 'load:PASS';
    catch ME
        fprintf(' ❌ 失败: %s\n', ME.message);
        result.checks{end+1} = 'load:FAIL';
        result.errors{end+1} = sprintf('模型加载失败: %s', ME.message);
        result.pass = false;
        print_summary(result);
        return;  % 加载失败，后续检查无意义
    end

    %% Check 2: 未连接端口
    fprintf('[2/5] 端口连接...');
    try
        ports = find_system(model, 'FindAll', 'on', 'Type', 'port');
        unconnected = [];
        for i = 1:length(ports)
            try
                line_h = get_param(ports(i), 'Line');
                if line_h == -1
                    unconnected(end+1) = ports(i); %#ok<AGROW>
                end
            catch
            end
        end
        if isempty(unconnected)
            fprintf(' ✅ 全部连接\n');
            result.checks{end+1} = 'ports:PASS';
        else
            fprintf(' ⚠️ %d 个未连接端口:\n', length(unconnected));
            for i = 1:length(unconnected)
                try
                    blk = get_param(unconnected(i), 'Parent');
                    pt  = get_param(unconnected(i), 'PortType');
                    fprintf('    → %s (%s)\n', blk, pt);
                catch
                end
            end
            result.checks{end+1} = sprintf('ports:WARN(%d)', length(unconnected));
            result.warnings{end+1} = sprintf('%d 个未连接端口', length(unconnected));
        end
    catch ME
        fprintf(' ⚠️ 检查异常: %s\n', ME.message);
        result.checks{end+1} = 'ports:SKIP';
    end

    %% Check 3: 编译（Update Diagram）
    fprintf('[3/5] 模型编译...');
    try
        % 捕获编译警告
        lastwarn('');
        feval(model, [], [], [], 'compile');
        feval(model, [], [], [], 'term');
        [warnMsg, ~] = lastwarn;
        if isempty(warnMsg)
            fprintf(' ✅ 编译通过\n');
            result.checks{end+1} = 'compile:PASS';
        else
            fprintf(' ⚠️ 编译通过（有警告）: %s\n', warnMsg);
            result.checks{end+1} = 'compile:WARN';
            result.warnings{end+1} = sprintf('编译警告: %s', warnMsg);
        end
    catch ME
        fprintf(' ❌ 编译失败: %s\n', ME.message);
        result.checks{end+1} = 'compile:FAIL';
        result.errors{end+1} = sprintf('编译失败: %s', ME.message);
        result.pass = false;
        % 编译失败仍继续检查其他项
    end

    %% Check 4: 短时仿真
    fprintf('[4/5] 仿真测试 (StopTime=%s)...', opts.stop_time);
    try
        simIn = Simulink.SimulationInput(model);
        simIn = simIn.setModelParameter('StopTime', opts.stop_time);
        simOut = sim(simIn);
        fprintf(' ✅ 仿真完成\n');
        result.checks{end+1} = 'sim:PASS';
        result.simOut = simOut;
    catch ME
        fprintf(' ❌ 仿真失败: %s\n', ME.message);
        result.checks{end+1} = 'sim:FAIL';
        result.errors{end+1} = sprintf('仿真失败: %s', ME.message);
        result.pass = false;
    end

    %% Check 5: 输出信号合理性（可选）
    if ~isempty(opts.signals) && isfield(result, 'simOut')
        fprintf('[5/5] 信号检查...\n');
        for i = 1:length(opts.signals)
            sig_name = opts.signals{i};
            try
                sig_data = result.simOut.get(sig_name);
                vals = sig_data.Data;
                has_nan = any(isnan(vals(:)));
                has_inf = any(isinf(vals(:)));
                sig_min = min(vals(:));
                sig_max = max(vals(:));

                if has_nan || has_inf
                    fprintf('    %s: ❌ 含 NaN/Inf\n', sig_name);
                    result.checks{end+1} = sprintf('signal_%s:FAIL(NaN/Inf)', sig_name);
                    result.errors{end+1} = sprintf('信号 %s 含 NaN/Inf', sig_name);
                    result.pass = false;
                elseif ~isempty(opts.ranges) && i <= length(opts.ranges)
                    rng = opts.ranges{i};
                    if sig_min >= rng(1) && sig_max <= rng(2)
                        fprintf('    %s: ✅ [%.2f, %.2f] 在预期范围 [%.2f, %.2f]\n', ...
                            sig_name, sig_min, sig_max, rng(1), rng(2));
                        result.checks{end+1} = sprintf('signal_%s:PASS', sig_name);
                    else
                        fprintf('    %s: ⚠️ [%.2f, %.2f] 超出预期 [%.2f, %.2f]\n', ...
                            sig_name, sig_min, sig_max, rng(1), rng(2));
                        result.checks{end+1} = sprintf('signal_%s:WARN(range)', sig_name);
                        result.warnings{end+1} = sprintf('信号 %s 超出预期范围', sig_name);
                    end
                else
                    fprintf('    %s: ✅ 范围 [%.4g, %.4g]（无NaN/Inf）\n', ...
                        sig_name, sig_min, sig_max);
                    result.checks{end+1} = sprintf('signal_%s:PASS', sig_name);
                end
            catch ME
                fprintf('    %s: ⚠️ 无法读取: %s\n', sig_name, ME.message);
                result.checks{end+1} = sprintf('signal_%s:SKIP', sig_name);
            end
        end
    else
        fprintf('[5/5] 信号检查... ⏭️ 跳过（未指定信号）\n');
        result.checks{end+1} = 'signals:SKIP';
    end

    %% 汇总
    print_summary(result);
end

function print_summary(result)
    fprintf('\n========================================\n');
    if result.pass && isempty(result.warnings)
        fprintf('  ✅ 验证通过: %s\n', result.model);
    elseif result.pass
        fprintf('  ⚠️ 验证通过（有警告）: %s\n', result.model);
    else
        fprintf('  ❌ 验证失败: %s\n', result.model);
    end

    if ~isempty(result.errors)
        fprintf('\n  错误:\n');
        for i = 1:length(result.errors)
            fprintf('    ❌ %s\n', result.errors{i});
        end
    end
    if ~isempty(result.warnings)
        fprintf('\n  警告:\n');
        for i = 1:length(result.warnings)
            fprintf('    ⚠️ %s\n', result.warnings{i});
        end
    end

    fprintf('\n  检查项: %s\n', strjoin(result.checks, ' | '));
    fprintf('========================================\n');
end
