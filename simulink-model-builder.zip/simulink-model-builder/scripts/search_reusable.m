%% search_reusable.m - 模块搜索与复用决策函数
% Input:  circuit_desc - 电路描述字符串（中文或英文）
% Output: strategy - 复用策略 ('subsystem' / 'composite' / 'primitive')
%         block_path - 推荐的模块路径（空字符串表示需手动拼接）
% Pos:    scripts/ 工具函数，供 AI 搭建流程调用
%
% 三级优先级搜索：
%   1. 子系统级（Electric Drives, FACTS 等完整子系统）
%   2. 组合级（Universal Bridge, Three-Phase Source 等高级模块）
%   3. 基础元件级（IGBT, Diode, R/L/C 逐个拼接）
%
% 用法:
%   [strategy, path] = search_reusable('三相整流桥');
%   [strategy, path] = search_reusable('Buck converter');
%   [strategy, path] = search_reusable('PMSM vector control drive');
%
% 依赖: detect_lib.m

function [strategy, block_path] = search_reusable(circuit_desc)
    fprintf('=== 模块复用决策 ===\n');
    fprintf('电路描述: %s\n\n', circuit_desc);

    % 检测可用库
    try
        active_lib = detect_lib();
    catch ME
        fprintf('ERROR 库检测失败: %s\n', ME.message);
        strategy = 'primitive';
        block_path = '';
        return;
    end

    % === 优先级 1: 子系统级模块（一步复用）===
    [found, strategy, block_path] = search_subsystem_level(circuit_desc, active_lib);
    if found
        return;
    end

    % === 优先级 2: 组合级模块（少量组装）===
    [found, strategy, block_path] = search_composite_level(circuit_desc, active_lib);
    if found
        return;
    end

    % === 优先级 3: 基础元件（完全手动）===
    strategy = 'primitive';
    block_path = '';
    fprintf('[优先级3] 无现成模块，需基础元件拼接\n');
    fprintf('建议使用: IGBT/MOSFET + Diode + R/L/C + Ground\n');
    print_summary(strategy, block_path, circuit_desc);
end

%% ========== 子系统级搜索 ==========

function [found, strategy, block_path] = search_subsystem_level(desc, lib)
    found = false;
    strategy = '';
    block_path = '';

    % 子系统级模块映射: {正则模式, 模块关键词, 说明}
    subsys_map = {
        '三相.*整流.*驱动|three.*phase.*rectif.*drive|DC3', 'DC3', 'DC3 三相整流DC驱动';
        'PWM.*逆变.*感应|PWM.*invert.*induc|AC2', 'AC2', 'AC2 PWM感应电机驱动';
        'FOC|磁场定向|field.*orient|AC3', 'AC3', 'AC3 FOC感应电机驱动';
        'DTC|直接转矩|direct.*torque|AC4', 'AC4', 'AC4 DTC感应电机驱动';
        'BLDC|无刷直流|brushless.*dc|AC7', 'AC7', 'AC7 BLDC驱动';
        'PMSM|永磁同步.*矢量|perm.*magnet.*vector|AC6', 'AC6', 'AC6 PMSM矢量控制';
        '六步.*逆变|six.*step|AC1', 'AC1', 'AC1 六步逆变感应电机';
        '无传感器.*FOC|sensorless.*FOC|AC5', 'AC5', 'AC5 无传感器FOC';
        '五相.*永磁|five.*phase|AC8', 'AC8', 'AC8 五相永磁同步';
        '单相.*整流.*DC|single.*phase.*rect.*DC|DC1', 'DC1', 'DC1 单相整流DC驱动';
        '斩波.*DC.*一象限|chopper.*one.*quad|DC5', 'DC5', 'DC5 斩波DC驱动(一象限)';
        '斩波.*DC.*两象限|chopper.*two.*quad|DC6', 'DC6', 'DC6 斩波DC驱动(两象限)';
        '斩波.*DC.*四象限|chopper.*four.*quad|DC7', 'DC7', 'DC7 斩波DC驱动(四象限)';
        'SVC|静止无功', 'SVC', 'SVC 静止无功补偿器';
        'STATCOM', 'STATCOM', 'STATCOM 静止同步补偿器';
        'UPFC|统一潮流', 'UPFC', 'UPFC 统一潮流控制器';
        'H.*Bridge|H.*桥|H桥', 'H-Bridge', 'H桥逆变器';
    };

    for i = 1:size(subsys_map, 1)
        pattern = subsys_map{i, 1};
        keyword = subsys_map{i, 2};
        info    = subsys_map{i, 3};

        if ~isempty(regexpi(desc, pattern))
            % 在库中搜索该模块
            try
                results = find_system(lib, 'SearchDepth', 15, ...
                    'regexp', 'on', 'Name', keyword);
                if ~isempty(results)
                    found = true;
                    strategy = 'subsystem';
                    block_path = results{1};
                    fprintf('[优先级1] 子系统级模块命中: %s\n', info);
                    fprintf('  模块路径: %s\n', block_path);
                    print_summary(strategy, block_path, desc);
                    return;
                end
            catch
            end
        end
    end
end

%% ========== 组合级搜索 ==========

function [found, strategy, block_path] = search_composite_level(desc, lib)
    found = false;
    strategy = '';
    block_path = '';

    % 组合级模块映射: {正则模式, 模块名, 说明}
    composite_map = {
        '整流桥|bridge.*rectif|Universal.*Bridge|三相桥|逆变桥', 'Universal Bridge', '通用桥(含6个器件)';
        '三相电源|three.*phase.*source|三相源', 'Three-Phase Source', '三相电源';
        '变压器|transform|saturable', 'Saturable Transformer', '饱和变压器';
        '三相.*RLC|three.*phase.*rlc', 'Three-Phase Series RLC Branch', '三相串联RLC';
        '三相.*测量|three.*phase.*meas', 'Three-Phase V-I Measurement', '三相电压电流测量';
    };

    for i = 1:size(composite_map, 1)
        pattern    = composite_map{i, 1};
        block_name = composite_map{i, 2};
        info       = composite_map{i, 3};

        if ~isempty(regexpi(desc, pattern))
            try
                results = find_system(lib, 'SearchDepth', 15, 'Name', block_name);
                if ~isempty(results)
                    found = true;
                    strategy = 'composite';
                    block_path = results{1};
                    fprintf('[优先级2] 组合级模块命中: %s\n', info);
                    fprintf('  模块路径: %s\n', block_path);
                    print_summary(strategy, block_path, desc);
                    return;
                end
            catch
            end
        end
    end
end

%% ========== 结果摘要 ==========

function print_summary(strategy, block_path, desc)
    fprintf('\n--- 决策结果 ---\n');
    fprintf('描述:   %s\n', desc);
    fprintf('策略:   %s\n', strategy);
    fprintf('路径:   %s\n', block_path);
    switch strategy
        case 'subsystem'
            fprintf('说明:   一步复用，add_block 即可使用完整子系统\n');
        case 'composite'
            fprintf('说明:   使用高级模块，需少量配置和连线\n');
        case 'primitive'
            fprintf('说明:   需从基础元件(IGBT/Diode/R/L/C)逐个拼接\n');
    end
    fprintf('----------------\n');
end
