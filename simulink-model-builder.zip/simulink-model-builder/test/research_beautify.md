# Simulink 模型美化 - 程序化方法调研报告

> 调研时间：2026-02-07
> 来源：MathWorks 官方文档、MATLAB Central、社区最佳实践

---

## 目录

1. [自动布局 arrangeSystem](#1-自动布局-arrangesystem)
2. [连线优化 routeLine](#2-连线优化-routeline)
3. [块位置控制与对齐](#3-块位置控制与对齐)
4. [块着色与样式](#4-块着色与样式)
5. [注释系统 Annotations](#5-注释系统-annotations)
6. [信号标签 Signal Labels](#6-信号标签-signal-labels)
7. [子系统封装 Subsystem + Mask](#7-子系统封装-subsystem--mask)
8. [块名称与标签控制](#8-块名称与标签控制)
9. [推荐美化工作流](#9-推荐美化工作流)
10. [关键注意事项与常见坑](#10-关键注意事项与常见坑)

---

## 1. 自动布局 arrangeSystem

### API

```matlab
Simulink.BlockDiagram.arrangeSystem(bd)
Simulink.BlockDiagram.arrangeSystem(bd, FullLayout='true')
```

### 参数说明

| 参数 | 类型 | 说明 |
|------|------|------|
| `bd` | char/string/numeric | 模型或子系统路径，如 `'myModel'` 或 `'myModel/Subsystem1'` |
| `FullLayout` | `'true'` / `'false'` | 强制执行布局，即使算法认为不会改善。默认 `'false'` |

### 行为说明

- 重新排列、调整大小、移动 blocks，拉直信号线
- 输入块靠左，输出块靠右，中间按列排列
- **只影响一层**（不递归进入子系统）
- 会改变 line handles（调用后需重新获取）
- 引入版本：R2018b

### 代码示例

```matlab
%% 基本用法 - 自动布局整个模型
model = 'myBuckConverter';
open_system(model);
Simulink.BlockDiagram.arrangeSystem(model);

%% 强制布局（即使算法认为无需改善）
Simulink.BlockDiagram.arrangeSystem(model, FullLayout='true');

%% 布局指定子系统
Simulink.BlockDiagram.arrangeSystem([model, '/Controller']);

%% 递归布局所有子系统
subsystems = find_system(model, 'BlockType', 'SubSystem');
for i = 1:length(subsystems)
    try
        Simulink.BlockDiagram.arrangeSystem(subsystems{i});
    catch ME
        fprintf('跳过 %s: %s\n', subsystems{i}, ME.message);
    end
end
% 最后布局顶层
Simulink.BlockDiagram.arrangeSystem(model);
```

### 保持块大小不变的技巧

`arrangeSystem` 会调整块大小。若需保持原始尺寸：

```matlab
%% 保存块位置 → 布局 → 恢复尺寸（仅移动位置）
blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');
origPos = cell(size(blocks));
for i = 1:length(blocks)
    origPos{i} = get_param(blocks{i}, 'Position');
end

Simulink.BlockDiagram.arrangeSystem(model);

for i = 1:length(blocks)
    newPos = get_param(blocks{i}, 'Position');
    origW = origPos{i}(3) - origPos{i}(1);
    origH = origPos{i}(4) - origPos{i}(2);
    % 保持新位置的左上角，恢复原始宽高
    set_param(blocks{i}, 'Position', ...
        [newPos(1), newPos(2), newPos(1)+origW, newPos(2)+origH]);
end
```

---

## 2. 连线优化 routeLine

### API

```matlab
Simulink.BlockDiagram.routeLine(lines)           % 路由指定线
Simulink.BlockDiagram.routeLine('DeferredLines')  % 路由延迟的线
```

### 参数说明

| 参数 | 类型 | 说明 |
|------|------|------|
| `lines` | numeric array | 线句柄数组，通过 `find_system` 或 `get_param` 获取 |
| `'DeferredLines'` | char | 执行所有被延迟的线路由更新 |

### 行为说明

- 优化线路走向，避免与其他线、块、注释重叠
- 需要画布有足够空白空间
- 大模型可能耗时较长
- 引入版本：R2019a

### 代码示例

```matlab
%% 路由模型中所有线
model = 'myModel';
lines = find_system(model, 'FindAll', 'on', 'SearchDepth', 1, 'Type', 'line');
if ~isempty(lines)
    Simulink.BlockDiagram.routeLine(lines);
end

%% 延迟线路由模式（批量操作时性能更好）
set_param(model, 'LineUpdate', 'deferred');
% ... 执行大量 add_block / set_param / add_line 操作 ...
Simulink.BlockDiagram.routeLine('DeferredLines');
set_param(model, 'LineUpdate', 'on');  % 恢复正常

%% add_line 时使用 smart autorouting
add_line(model, 'Block1/1', 'Block2/1', 'autorouting', 'smart');
% 'smart' 选项：自动避开其他块和线的智能路由
% 'on'    选项：基本自动路由
% 'off'   选项：直线连接（不推荐）
```

### Simulink.connectBlocks（R2021a+）

```matlab
%% 更现代的连线 API，默认使用 smart routing
Simulink.connectBlocks(model, 'Source/1', 'Dest/1');
```

---

## 3. 块位置控制与对齐

### Position 参数格式

```
Position = [left, top, right, bottom]
```

坐标系：原点在左上角，X 轴向右，Y 轴向下。单位为像素。

### 基本操作

```matlab
%% 获取和设置块位置
pos = get_param([model, '/Block1'], 'Position');  % [left top right bottom]
set_param([model, '/Block1'], 'Position', [100, 50, 140, 90]);

%% 获取块尺寸
width  = pos(3) - pos(1);
height = pos(4) - pos(2);
center_x = (pos(1) + pos(3)) / 2;
center_y = (pos(2) + pos(4)) / 2;
```

### 对齐函数工具集

```matlab
%% ============================================================
%% 对齐工具函数
%% ============================================================

function align_blocks_horizontal(model, block_names, y_pos)
    % 将多个块水平对齐到同一 Y 坐标
    % block_names: cell array of block names
    % y_pos: 目标 Y 坐标（块顶部）
    for i = 1:length(block_names)
        path = [model, '/', block_names{i}];
        pos = get_param(path, 'Position');
        h = pos(4) - pos(2);  % 保持原始高度
        set_param(path, 'Position', [pos(1), y_pos, pos(3), y_pos + h]);
    end
end

function align_blocks_vertical(model, block_names, x_pos)
    % 将多个块垂直对齐到同一 X 坐标
    for i = 1:length(block_names)
        path = [model, '/', block_names{i}];
        pos = get_param(path, 'Position');
        w = pos(3) - pos(1);
        set_param(path, 'Position', [x_pos, pos(2), x_pos + w, pos(4)]);
    end
end

function distribute_blocks_horizontal(model, block_names, spacing)
    % 水平等间距分布块
    % spacing: 块之间的间距（像素）
    if nargin < 3, spacing = 80; end
    x = 100;  % 起始 X
    for i = 1:length(block_names)
        path = [model, '/', block_names{i}];
        pos = get_param(path, 'Position');
        w = pos(3) - pos(1);
        h = pos(4) - pos(2);
        set_param(path, 'Position', [x, pos(2), x + w, pos(2) + h]);
        x = x + w + spacing;
    end
end

function distribute_blocks_vertical(model, block_names, spacing)
    % 垂直等间距分布块
    if nargin < 3, spacing = 60; end
    y = 100;  % 起始 Y
    for i = 1:length(block_names)
        path = [model, '/', block_names{i}];
        pos = get_param(path, 'Position');
        w = pos(3) - pos(1);
        h = pos(4) - pos(2);
        set_param(path, 'Position', [pos(1), y, pos(1) + w, y + h]);
        y = y + h + spacing;
    end
end

function center_block(model, block_name, ref_block_name)
    % 将 block 中心对齐到 ref_block 的中心（垂直方向）
    path = [model, '/', block_name];
    ref_path = [model, '/', ref_block_name];
    pos = get_param(path, 'Position');
    ref_pos = get_param(ref_path, 'Position');

    ref_cy = (ref_pos(2) + ref_pos(4)) / 2;
    h = pos(4) - pos(2);
    new_top = ref_cy - h/2;
    set_param(path, 'Position', [pos(1), new_top, pos(3), new_top + h]);
end
```

### 批量操作技巧

```matlab
%% 批量获取所有块的位置（转为矩阵便于计算）
blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');
positions = cell2mat(cellfun(@(b) get_param(b, 'Position'), blocks, ...
    'UniformOutput', false));
% positions 现在是 N×4 矩阵，每行 [left top right bottom]
```

### 块方向控制

```matlab
%% 旋转和翻转
set_param([model, '/Block1'], 'Orientation', 'right');  % 默认：从左到右
set_param([model, '/Block1'], 'Orientation', 'left');   % 从右到左
set_param([model, '/Block1'], 'Orientation', 'up');     % 从下到上
set_param([model, '/Block1'], 'Orientation', 'down');   % 从上到下

%% 块镜像（水平翻转端口）
set_param([model, '/Block1'], 'BlockMirror', 'on');
```

### 网格对齐

Simulink 使用 5 像素不可见网格。GUI 操作会吸附到网格，但 `set_param` 可以绕过这个限制，精确设置任意坐标。

---

## 4. 块着色与样式

### 颜色参数

| 参数 | 作用对象 | 说明 |
|------|---------|------|
| `BackgroundColor` | 块/注释 | 背景填充色 |
| `ForegroundColor` | 块/注释 | 前景色（边框/文字） |
| `ScreenColor` | 模型图 | 画布背景色 |
| `FontName` | 块/线/注释 | 字体名称 |
| `FontSize` | 块/线/注释 | 字体大小 |

### 可用颜色

**预定义颜色名**：`'black'`, `'white'`, `'red'`, `'green'`, `'blue'`, `'cyan'`, `'magenta'`, `'yellow'`, `'gray'`, `'lightBlue'`, `'orange'`, `'darkGreen'`, `'automatic'`

**自定义 RGB**：`'[r, g, b]'`，值范围 0.0~1.0

### 代码示例

```matlab
%% 单个块着色
set_param([model, '/IGBT'], 'BackgroundColor', 'lightBlue');
set_param([model, '/IGBT'], 'ForegroundColor', 'blue');

%% 自定义 RGB 颜色
set_param([model, '/Controller'], 'BackgroundColor', '[0.9 0.95 1.0]');

%% 批量着色 - 按块类型上色
function colorize_by_type(model)
    % 功率器件 → 浅蓝色
    power_types = {'UniversalBridge', 'IGBT', 'Mosfet', 'Diode'};
    for i = 1:length(power_types)
        blocks = find_system(model, 'BlockType', power_types{i});
        for j = 1:length(blocks)
            set_param(blocks{j}, 'BackgroundColor', 'lightBlue');
        end
    end

    % 测量元件 → 浅绿色
    measure_types = {'VoltageMeasurement', 'CurrentMeasurement'};
    for i = 1:length(measure_types)
        blocks = find_system(model, 'BlockType', measure_types{i});
        for j = 1:length(blocks)
            set_param(blocks{j}, 'BackgroundColor', '[0.8 1.0 0.8]');
        end
    end

    % 信号处理 → 浅黄色
    signal_types = {'Scope', 'ToWorkspace', 'Display'};
    for i = 1:length(signal_types)
        blocks = find_system(model, 'BlockType', signal_types{i});
        for j = 1:length(blocks)
            set_param(blocks{j}, 'BackgroundColor', 'yellow');
        end
    end

    % 源 → 浅橙色
    source_blocks = find_system(model, 'BlockType', 'DCVoltageSource');
    for j = 1:length(source_blocks)
        set_param(source_blocks{j}, 'BackgroundColor', 'orange');
    end
end

%% 模型画布背景色
set_param(model, 'ScreenColor', 'white');

%% 字体设置
set_param([model, '/Title'], 'FontSize', '14');
set_param([model, '/Title'], 'FontName', 'Arial');
```

### hilite_system 临时高亮

```matlab
%% 临时高亮（调试用，不保存到模型）
hilite_system([model, '/Block1'], 'find');     % 黄色高亮
hilite_system([model, '/Block1'], 'error');    % 红色高亮
hilite_system([model, '/Block1'], 'none');     % 取消高亮

%% 自定义高亮颜色
hilite_system([model, '/Block1'], 'default', ...
    'BackgroundColor', '[0.5 0.8 1.0]', ...
    'ForegroundColor', 'blue');
```

---

## 5. 注释系统 Annotations

### 注释类型

| 类型 | 创建方式 | 用途 |
|------|---------|------|
| 文字注释 Text | `Simulink.Annotation()` | 说明文字、标题 |
| 区域注释 Area | `add_block('built-in/Area', ...)` | 功能区域分组框 |
| 图片注释 Image | `ann.setImage(path)` | Logo、示意图 |
| 超链接注释 | `Interpreter='rich'` + HTML | 可点击链接 |
| 标记注释 Markup | `ShowMarkup='off'` 可隐藏 | 审查批注 |

### 文字注释

```matlab
%% 创建基本文字注释
ann = Simulink.Annotation([model, '/Buck Converter - Main Circuit']);
ann.Position = [300, 20];          % 注释位置 [x, y]
ann.FontSize = 16;
ann.FontWeight = 'bold';
ann.ForegroundColor = 'blue';
ann.BackgroundColor = 'white';

%% 创建多行注释
ann2 = Simulink.Annotation([model, '/Parameters:' newline ...
    'Vin = 48V' newline ...
    'Vout = 12V' newline ...
    'fsw = 100kHz']);
ann2.Position = [50, 300];
ann2.FontSize = 10;
ann2.BackgroundColor = 'yellow';

%% 创建超链接注释（需 rich interpreter）
ann3 = Simulink.Annotation([model, '/Click for docs']);
ann3.Interpreter = 'rich';
ann3.Text = '<a href="matlab:open(''design_notes.pdf'')">Open Design Notes</a>';
```

### 区域注释 Area

```matlab
%% 创建区域框
% Position = [left, top, width, height]
add_block('built-in/Area', [model, '/Power Stage'], ...
    'Position', [50, 50, 500, 300]);

%% 设置区域样式
area_handle = find_system(model, 'FindAll', 'on', 'Type', 'annotation', ...
    'AnnotationType', 'area_annotation', 'Name', 'Power Stage');
if ~isempty(area_handle)
    set_param(area_handle, 'BackgroundColor', '[0.9 0.95 1.0]');
    set_param(area_handle, 'ForegroundColor', 'blue');
    set_param(area_handle, 'FontSize', '12');
end

%% 批量创建功能区域
function create_functional_areas(model)
    areas = {
        'Power Stage',    [30, 30, 500, 350],  '[0.85 0.92 1.0]',  'blue';
        'Control Logic',  [30, 400, 500, 250], '[1.0 0.95 0.85]',  '[0.8 0.4 0]';
        'Measurements',   [550, 30, 300, 350], '[0.85 1.0 0.85]',  'darkGreen';
        'Output/Display', [550, 400, 300, 250],'[1.0 1.0 0.85]',  '[0.6 0.6 0]';
    };

    for i = 1:size(areas, 1)
        name = areas{i,1};
        pos  = areas{i,2};
        bg   = areas{i,3};
        fg   = areas{i,4};

        add_block('built-in/Area', [model, '/', name], ...
            'Position', pos);

        % 查找刚创建的区域并设置样式
        handles = find_system(model, 'FindAll', 'on', 'Type', 'annotation', ...
            'AnnotationType', 'area_annotation');
        for j = 1:length(handles)
            try
                txt = get_param(handles(j), 'PlainText');
                if strcmp(txt, name)
                    set_param(handles(j), 'BackgroundColor', bg);
                    set_param(handles(j), 'ForegroundColor', fg);
                    set_param(handles(j), 'FontSize', '12');
                end
            catch
            end
        end
    end
end
```

### 查找和修改注释

```matlab
%% 查找所有注释
handles = find_system(model, 'FindAll', 'on', 'Type', 'annotation');
for i = 1:length(handles)
    txt = get_param(handles(i), 'PlainText');
    fprintf('Annotation %d: %s\n', i, txt);
end

%% 删除注释
ann_obj = get_param(handle, 'Object');
delete(ann_obj);
```

---

## 6. 信号标签 Signal Labels

### 给线命名

```matlab
%% 方法 1：通过线句柄设置
line_handle = find_system(model, 'FindAll', 'on', 'Type', 'line');
set_param(line_handle(1), 'Name', 'Vout');

%% 方法 2：通过端口句柄获取线再命名
ph = get_param([model, '/Voltage_Meas'], 'PortHandles');
line_h = get_param(ph.Outport, 'Line');
set_param(line_h, 'Name', 'Vout_measured');

%% 方法 3：add_line 后立即命名
h = add_line(model, 'Vmeas/1', 'Scope/1', 'autorouting', 'smart');
set_param(h, 'Name', 'Vout');

%% 删除信号标签
set_param(line_h, 'Name', '');
```

### 批量命名信号

```matlab
%% 批量给关键信号命名
function label_signals(model)
    signal_map = {
        % {源块, 源端口类型, 源端口索引, 标签名}
        'Vmeas',  'Outport', 1, 'Vout';
        'Imeas',  'Outport', 1, 'IL';
        'PWM',    'Outport', 1, 'PWM_signal';
        'Vref',   'Outport', 1, 'Vref';
    };

    for i = 1:size(signal_map, 1)
        block_name = signal_map{i,1};
        port_type  = signal_map{i,2};
        port_idx   = signal_map{i,3};
        label      = signal_map{i,4};

        try
            path = [model, '/', block_name];
            ph = get_param(path, 'PortHandles');
            ports = ph.(port_type);
            if length(ports) >= port_idx
                line_h = get_param(ports(port_idx), 'Line');
                if line_h ~= -1
                    set_param(line_h, 'Name', label);
                    fprintf('  Labeled: %s/%s(%d) -> "%s"\n', ...
                        block_name, port_type, port_idx, label);
                end
            end
        catch ME
            fprintf('  Skip %s: %s\n', block_name, ME.message);
        end
    end
end
```

### 信号标签传播

```matlab
%% 在子系统端口上显示信号名
set_param([model, '/Subsystem'], 'ShowPortLabels', 'SignalName');
% 选项：'FromPortBlockName' | 'FromPortIcon' | 'SignalName' | 'none'

%% 显示传播的信号名
ph = get_param([model, '/Block'], 'PortHandles');
set_param(ph.Outport(1), 'ShowPropagatedSignals', 'on');
```

---

## 7. 子系统封装 Subsystem + Mask

### 创建子系统

```matlab
%% 方法 1：从现有块创建子系统
block_handles = [];
blocks_to_group = {'IGBT', 'Diode', 'Gate_Driver'};
for i = 1:length(blocks_to_group)
    bh = get_param([model, '/', blocks_to_group{i}], 'Handle');
    block_handles(end+1) = bh;
end
Simulink.BlockDiagram.createSubsystem(block_handles, 'Name', 'Half_Bridge');

%% 方法 2：使用 find_system 查找块
bh = Simulink.findBlocks([model, '/Power_Stage']);
Simulink.BlockDiagram.createSubsystem(bh, 'Name', 'Converter');

%% 方法 3：手动创建空子系统
add_block('simulink/Ports & Subsystems/Subsystem', [model, '/Controller']);
```

### 添加 Mask

```matlab
%% 使用 Simulink.Mask API（推荐）
maskObj = Simulink.Mask.create([model, '/Half_Bridge']);

% 设置描述
maskObj.Display = 'disp(''Half Bridge'')';
maskObj.Description = 'IGBT Half Bridge with Gate Driver';
maskObj.Type = 'Half Bridge';

% 添加参数
maskObj.addParameter('Type', 'edit', ...
    'Name', 'Vdc', ...
    'Prompt', 'DC Bus Voltage (V)', ...
    'Value', '400');

maskObj.addParameter('Type', 'edit', ...
    'Name', 'fsw', ...
    'Prompt', 'Switching Frequency (Hz)', ...
    'Value', '10000');

maskObj.addParameter('Type', 'popup', ...
    'Name', 'device_type', ...
    'Prompt', 'Power Device', ...
    'TypeOptions', {{'IGBT', 'MOSFET', 'GaN'}}, ...
    'Value', 'IGBT');

%% Mask Icon 绘制命令
maskObj.Display = sprintf([...
    'disp(''Half Bridge'');\n' ...
    'port_label(''input'', 1, ''Gate_H'');\n' ...
    'port_label(''input'', 2, ''Gate_L'');\n' ...
    'port_label(''output'', 1, ''Out'');\n' ...
    'color(''blue'');\n' ...
    'plot([0.1 0.9 0.9 0.1 0.1], [0.1 0.1 0.9 0.9 0.1]);\n']);
```

### 使用 set_param 设置 Mask（传统方式）

```matlab
%% set_param 方式（支持更广的 MATLAB 版本）
set_param([model, '/Subsystem'], ...
    'MaskDisplay', 'disp(''My Block'')', ...
    'MaskDescription', 'Description text', ...
    'MaskType', 'CustomBlock', ...
    'MaskPromptString', 'Param1:|Param2:', ...
    'MaskStyleString', 'edit,edit', ...
    'MaskVariables', 'param1=@1;param2=@2;', ...
    'MaskValueString', '100|200');
% @1 表示第1个参数（evaluate 模式）
% &1 表示第1个参数（literal string 模式）
```

### Mask Display 绘图命令

| 命令 | 说明 | 示例 |
|------|------|------|
| `disp('text')` | 显示文字 | `disp('Buck Converter')` |
| `port_label('input',n,'name')` | 输入端口标签 | `port_label('input',1,'Vin')` |
| `port_label('output',n,'name')` | 输出端口标签 | `port_label('output',1,'Vout')` |
| `plot(x, y)` | 绘制线条 | `plot([0 1],[0 1])` |
| `color('name')` | 设置颜色 | `color('blue')` |
| `text(x,y,'str')` | 放置文字 | `text(0.5,0.5,'PWM')` |
| `image(data)` | 显示图片 | `image(imread('icon.png'))` |
| `patch(x,y,[r g b])` | 填充多边形 | `patch([0 1 1 0],[0 0 1 1],[0.9 0.9 1])` |
| `fprintf('text')` | 格式化文字 | `fprintf('Vdc=%g',Vdc)` |

---

## 8. 块名称与标签控制

### 块名称显示

```matlab
%% 获取和设置块名称
name = get_param([model, '/Block1'], 'Name');
set_param([model, '/Block1'], 'Name', 'NewName');

%% 控制名称显示位置
set_param([model, '/Block1'], 'NameLocation', 'bottom');  % top|bottom|left|right

%% 隐藏/显示块名称
set_param([model, '/Block1'], 'ShowName', 'off');  % 隐藏
set_param([model, '/Block1'], 'ShowName', 'on');   % 显示

%% 隐藏自动生成的名称（保留用户定义名称）
set_param([model, '/Block1'], 'HideAutomaticName', 'on');
```

### 批量隐藏默认名称

```matlab
%% 隐藏所有"自动名称"（如 Gain1, Sum2 等）
function hide_default_names(model)
    blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');
    default_patterns = {'^Gain\d*$', '^Sum\d*$', '^Product\d*$', ...
                        '^Mux\d*$', '^Demux\d*$', '^Ground\d*$'};
    for i = 1:length(blocks)
        name = get_param(blocks{i}, 'Name');
        for j = 1:length(default_patterns)
            if ~isempty(regexp(name, default_patterns{j}, 'once'))
                set_param(blocks{i}, 'HideAutomaticName', 'on');
                break;
            end
        end
    end
end
```

### 子系统端口标签

```matlab
%% 设置子系统的端口标签显示方式
set_param([model, '/Subsystem'], 'ShowPortLabels', 'FromPortBlockName');
% 'FromPortBlockName' - 显示内部端口块名（默认）
% 'FromPortIcon'      - 显示端口图标信号名
% 'SignalName'        - 显示连接信号名
% 'none'              - 不显示

%% 重命名子系统内的端口块来自定义标签
set_param([model, '/Subsystem/In1'], 'Name', 'Vin');
set_param([model, '/Subsystem/Out1'], 'Name', 'Vout');
```

---

## 9. 推荐美化工作流

### 完整美化流程（按执行顺序）

```matlab
function beautify_model(model)
    %% beautify_model - Simulink 模型一键美化
    % Input:  model - 模型名称（字符串）
    % Output: 无（直接修改模型）

    fprintf('=== 开始美化模型: %s ===\n', model);
    open_system(model);

    %% Step 1: 设置画布背景
    set_param(model, 'ScreenColor', 'white');
    fprintf('[1/8] 画布背景已设置\n');

    %% Step 2: 创建功能区域 Area
    create_functional_areas(model);
    fprintf('[2/8] 功能区域已创建\n');

    %% Step 3: 块着色（按功能分组）
    colorize_by_type(model);
    fprintf('[3/8] 块着色已完成\n');

    %% Step 4: 自动布局
    % 先布局子系统（从内到外）
    subsystems = find_system(model, 'BlockType', 'SubSystem');
    for i = 1:length(subsystems)
        try
            Simulink.BlockDiagram.arrangeSystem(subsystems{i});
        catch
        end
    end
    % 再布局顶层
    Simulink.BlockDiagram.arrangeSystem(model);
    fprintf('[4/8] 自动布局已完成\n');

    %% Step 5: 优化连线
    lines = find_system(model, 'FindAll', 'on', 'SearchDepth', 1, 'Type', 'line');
    if ~isempty(lines)
        Simulink.BlockDiagram.routeLine(lines);
    end
    fprintf('[5/8] 连线已优化\n');

    %% Step 6: 信号标签
    label_signals(model);
    fprintf('[6/8] 信号标签已添加\n');

    %% Step 7: 隐藏默认名称
    hide_default_names(model);
    fprintf('[7/8] 默认名称已隐藏\n');

    %% Step 8: 添加标题注释
    add_title_annotation(model);
    fprintf('[8/8] 标题注释已添加\n');

    %% 保存
    save_system(model);
    fprintf('=== 美化完成 ===\n');
end

function add_title_annotation(model)
    % 在模型左上角添加标题
    model_name = get_param(model, 'Name');
    title_text = sprintf('%s\nGenerated: %s', model_name, datestr(now));
    ann = Simulink.Annotation([model, '/', title_text]);
    ann.Position = [20, -30];
    ann.FontSize = 14;
    ann.FontWeight = 'bold';
    ann.ForegroundColor = '[0.2 0.2 0.6]';
    ann.BackgroundColor = 'white';
end
```

### 工作流总结

| 步骤 | 操作 | API | 说明 |
|------|------|-----|------|
| 1 | 画布设置 | `set_param(model, 'ScreenColor', ...)` | 白色背景最专业 |
| 2 | 功能区域 | `add_block('built-in/Area', ...)` | 先划区再布局 |
| 3 | 块着色 | `set_param(block, 'BackgroundColor', ...)` | 按功能类型分色 |
| 4 | 自动布局 | `Simulink.BlockDiagram.arrangeSystem()` | 从内到外（子系统先） |
| 5 | 连线优化 | `Simulink.BlockDiagram.routeLine()` | 布局后再优化连线 |
| 6 | 信号标签 | `set_param(line, 'Name', ...)` | 关键信号命名 |
| 7 | 名称清理 | `set_param(block, 'HideAutomaticName', 'on')` | 隐藏无意义名 |
| 8 | 标题注释 | `Simulink.Annotation()` | 模型说明和日期 |

> **关键原则**：先分区 → 再着色 → 再布局 → 再连线 → 最后标注

---

## 10. 关键注意事项与常见坑

### arrangeSystem 相关

| 问题 | 解决方案 |
|------|---------|
| 块被调整大小 | 保存原始 Position → 布局后恢复宽高（见第1节代码） |
| FullLayout='true' 结果更差 | 默认不用 FullLayout，仅在布局明显混乱时使用 |
| 子系统内布局不生效 | 需对每个子系统单独调用，不会递归 |
| line handles 失效 | 布局后必须重新获取 handles |
| R2018b 以下不可用 | 回退方案：手动 set_param Position |

### routeLine 相关

| 问题 | 解决方案 |
|------|---------|
| 连线未改善 | 画布空间不足，先增大块间距 |
| 执行缓慢 | 大模型用延迟模式 `LineUpdate='deferred'` |
| R2019a 以下不可用 | 用 `add_line(..., 'autorouting', 'smart')` 替代 |

### 颜色与注释相关

| 问题 | 解决方案 |
|------|---------|
| RGB 颜色格式错误 | 必须用字符串 `'[r g b]'`，不是数组 |
| Area 背景色不显示 (R2015b) | 已知 bug，R2017b+ 修复 |
| 注释被布局移动 | 布局后重新设置注释位置 |
| 颜色在打印时丢失 | 导出前检查 `PaperPositionMode` 设置 |

### 信号标签相关

| 问题 | 解决方案 |
|------|---------|
| 标签位置无法程序化控制 | `set_param` 不支持标签位置，需手动调整或接受默认 |
| 线句柄为 -1 | 线未连接，先确保 `add_line` 成功 |
| 传播信号名不显示 | 检查 `ShowPropagatedSignals` 属性 |

### Mask 相关

| 问题 | 解决方案 |
|------|---------|
| `set_param` 不支持 Unicode | 使用 `Simulink.Mask` API 替代 |
| Mask 初始化中的 `set_param` | 不要对父级或同级 Mask 块使用 |
| 链接块 Mask 受限 | 检查 `SelfModifiable` 设置 |

### 版本兼容性总结

| 功能 | 最低版本 | 备注 |
|------|---------|------|
| `arrangeSystem` | R2018b | 核心布局功能 |
| `routeLine` | R2019a | 连线优化 |
| `Simulink.Annotation` | R2016a | 注释 API |
| `Simulink.Mask` | R2014b | Mask API（推荐） |
| `add_block('built-in/Area')` | R2017a | Area 注释 |
| `Simulink.connectBlocks` | R2021a | 现代连线 API |
| `Simulink.findBlocks` | R2018a | 现代块查找 |
| `set_param` | 所有版本 | 基础参数设置 |

---

## 完整 API 函数清单

### 布局与排列

| 函数 | 说明 |
|------|------|
| `Simulink.BlockDiagram.arrangeSystem(sys)` | 自动布局 |
| `Simulink.BlockDiagram.routeLine(lines)` | 优化连线路由 |
| `Simulink.BlockDiagram.routeLine('DeferredLines')` | 执行延迟的路由 |
| `Simulink.BlockDiagram.createSubsystem(blocks)` | 创建子系统 |
| `Simulink.BlockDiagram.resizeBlocksToFitContent(sys)` | 按内容调整块大小 |

### 块操作

| 函数/参数 | 说明 |
|-----------|------|
| `set_param(blk, 'Position', [l t r b])` | 设置块位置 |
| `set_param(blk, 'Orientation', dir)` | 块方向：right/left/up/down |
| `set_param(blk, 'BlockMirror', 'on')` | 块镜像 |
| `set_param(blk, 'BackgroundColor', color)` | 块背景色 |
| `set_param(blk, 'ForegroundColor', color)` | 块前景色 |
| `set_param(blk, 'FontName', name)` | 块字体 |
| `set_param(blk, 'FontSize', size)` | 块字号 |
| `set_param(blk, 'ShowName', 'on'/'off')` | 显示/隐藏名称 |
| `set_param(blk, 'HideAutomaticName', 'on')` | 隐藏自动名称 |
| `set_param(blk, 'NameLocation', loc)` | 名称位置：top/bottom/left/right |

### 连线

| 函数/参数 | 说明 |
|-----------|------|
| `add_line(sys, src, dst, 'autorouting', 'smart')` | 智能路由连线 |
| `Simulink.connectBlocks(sys, src, dst)` | 现代连线（R2021a+） |
| `set_param(line, 'Name', name)` | 设置信号标签 |
| `set_param(model, 'LineUpdate', 'deferred')` | 延迟线更新 |

### 注释

| 函数/参数 | 说明 |
|-----------|------|
| `Simulink.Annotation(sys, text)` | 创建文字注释 |
| `ann.Position = [x, y]` | 注释位置 |
| `ann.FontSize = n` | 注释字号 |
| `ann.FontWeight = 'bold'` | 注释加粗 |
| `ann.ForegroundColor = color` | 注释文字颜色 |
| `ann.BackgroundColor = color` | 注释背景色 |
| `ann.Interpreter = 'rich'` | 启用 HTML 解释器 |
| `ann.setImage(path)` | 设置图片注释 |
| `add_block('built-in/Area', path, 'Position', pos)` | 创建区域框 |

### Mask

| 函数/参数 | 说明 |
|-----------|------|
| `Simulink.Mask.create(blk)` | 创建 Mask（推荐） |
| `maskObj.Display = cmd` | 设置图标绘制命令 |
| `maskObj.addParameter(...)` | 添加参数 |
| `maskObj.Description = text` | 设置描述 |
| `set_param(blk, 'MaskDisplay', cmd)` | 传统方式设置图标 |
| `set_param(blk, 'MaskPromptString', ...)` | 传统方式设置参数提示 |

### 模型级设置

| 参数 | 说明 |
|------|------|
| `set_param(model, 'ScreenColor', color)` | 画布背景色 |
| `set_param(model, 'ShowMarkup', 'on'/'off')` | 显示/隐藏标记注释 |

---

## 参考来源

- [Simulink.BlockDiagram.arrangeSystem - MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.blockdiagram.arrangesystem.html)
- [Simulink.BlockDiagram.routeLine - MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.blockdiagram.routeline.html)
- [Configure Model Layout Programmatically - MathWorks](https://www.mathworks.com/help/simulink/ug/configure-model-layout-programmatically.html)
- [Configure Model Style Elements Programmatically - MathWorks](https://www.mathworks.com/help/simulink/ug/configure-model-style-elements-programmatically.html)
- [Create and Edit Annotations Programmatically - MathWorks](https://www.mathworks.com/help/simulink/ug/create-an-annotation-programmatically.html)
- [Configure Model Element Names and Labels - MathWorks](https://www.mathworks.com/help/simulink/ug/configure-model-element-names-and-labels-programmatically.html)
- [Simulink.Annotation - MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.annotation.html)
- [Control Masks Programmatically - MathWorks](https://www.mathworks.com/help/simulink/ug/control-masks-programmatically.html)
- [Simulink.BlockDiagram.createSubsystem - MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.blockdiagram.createsubsystem.html)
- [Visually Organize Models Using Area Annotations - MathWorks](https://www.mathworks.com/help/simulink/ug/visually-organize-models-using-areas.html)
