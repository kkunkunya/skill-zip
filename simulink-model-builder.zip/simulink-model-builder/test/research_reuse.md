# Simulink 可复用模块库调研报告

> 调研时间: 2026-02-07
> 目标: 高效搜索和复用 Simulink/Simscape Electrical 成熟模块，减少从基础运算符拼接的工作量

---

## 一、Simscape Electrical 高级模块分类清单

### 1.1 库体系总览

Simscape Electrical 包含 **两大技术栈**：

| 技术栈 | 库名 | 特点 | 未来 |
|--------|------|------|------|
| **Simscape-based** (新) | `ee_lib` | DAE+ODE 求解器，高保真，多物理域 | 主推方向 |
| **Specialized Power Systems** (旧) | `sps_lib` / `powerlib` | 纯 ODE，三相优化，大系统更快 | **R2026a 移除** |

### 1.2 Simscape-based 库 (ee_lib) — 12 个顶级库

| 库类别 | 子类别 | 典型模块 |
|--------|--------|---------|
| **Connectors & References** | 接地、中性点、相分离器、复用器 | Ground, Neutral, Phase Splitter, Mux |
| **Electromechanical** | 执行器、电机、惯量、测量 | PMSM, Induction Machine, BLDC, Switched Reluctance, Linear Synchronous |
| **Integrated Circuits** | 芯片、逻辑门 | Op-Amp, Comparator, Logic Gates |
| **Passive** | 变压器、RLC、传输线 | Transformer, Mutual Inductance, Transmission Line |
| **Semiconductors & Converters** | **子系统级转换器**、整流器、二极管、晶闸管、晶体管 | (详见 1.3) |
| **Sensors & Transducers** | 模拟/数字传感器 | Voltage Sensor, Current Sensor, Thermistor, Shaft Encoder |
| **Sources** | 电池、太阳能电池、电源轨 | Battery, Solar Cell, DC/AC Voltage Source |
| **Switches & Breakers** | 单相/三相开关、断路器 | Circuit Breaker, Three-Phase Switch, Ideal Switch |
| **Utilities** | 故障、环境参数 | Fault Block, Solver Configuration |
| **Additional Components** | SPICE 兼容元件 | SPICE-compatible R/L/C, Diode, MOSFET |
| **Control** | 信号生成、数学变换、电机控制 | PLL, Clarke/Park Transform, PI Controller |
| **Thermal** | 热端口、散热模型 | Heat Sink, Thermal Port |

### 1.3 子系统级高级模块（超越基础元件）

#### 1.3.1 电力电子转换器 (Semiconductors & Converters)

| 模块名 | 描述 | 复杂度 |
|--------|------|--------|
| **Converter (High Power)** | 高功率转换器子系统 | 子系统级 |
| **Rectifier** | 整流器（多种拓扑） | 子系统级 |
| **H-Bridge** | H 桥逆变器 | 子系统级 |
| **Three-Level Converter** | 三电平变换器（NPC等） | 子系统级 |
| **MMC Arm** | 模块化多电平变换器臂 | 子系统级 |
| **Half Bridge** | 半桥 | 中等 |
| **Gate Multiplexer** | 门信号多路复用 | 辅助 |
| **Solar PV Controller (Three-Phase)** | 三相光伏控制器（含 MPPT） | 子系统级 |

#### 1.3.2 电机驱动 (Electric Drives — Specialized Power Systems)

**AC 驱动 (8 种)：**

| 代号 | 名称 | 电机类型 | 控制方法 |
|------|------|---------|---------|
| AC1 | Six-Step VSI Induction Motor Drive | 感应电机 | 六步逆变 |
| AC2 | PWM VSI Induction Motor Drive | 感应电机 | PWM + 制动斩波 |
| AC3 | FOC Induction Motor Drive | 感应电机 | 磁场定向控制 |
| AC4 | DTC Induction Motor Drive | 感应电机 | 直接转矩控制 |
| AC5 | Sensorless FOC Induction Motor Drive | 感应电机 | 无传感器 FOC |
| AC6 | PMSM Vector Control Drive | 永磁同步电机 | 矢量控制 |
| AC7 | Brushless DC Motor Drive | 无刷直流 | 电子换向 |
| AC8 | Five-Phase PM Synchronous Drive | 五相永磁同步 | 五相控制 |

**DC 驱动 (7 种)：**

| 代号 | 名称 | 拓扑 | 象限 |
|------|------|------|------|
| DC1 | Single-Phase Rectifier DC Drive | 单相整流 | 两象限 |
| DC2 | Single-Phase Rectifier DC Drive (Circ. Current) | 单相整流 | 四象限 |
| DC3 | Three-Phase Rectifier DC Drive | 三相整流 | 两象限 |
| DC4 | Three-Phase Rectifier DC Drive | 三相整流 | 四象限 |
| DC5 | Chopper DC Drive | 斩波 | 一象限 |
| DC6 | Chopper DC Drive | 斩波 | 两象限 |
| DC7 | Chopper DC Drive | 斩波 | 四象限 |

**其他驱动模块：**
- **Motor & Drive (System Level)** — 系统级电机驱动（闭环转矩控制）
- **Shaft** — 机械耦合轴
- **Speed Reducer** — 齿轮减速器

> 每个驱动模块内含三个子系统：Motor + Power Converter + Controller，支持 Detailed 和 Average-Value 两种仿真模式。

#### 1.3.3 FACTS 设备

| 模块 | 描述 | 可用模型 |
|------|------|---------|
| **SVC** | 静止无功补偿器 (TCR+TSC) | Phasor / Detailed |
| **STATCOM** | 静止同步补偿器 (GTO 48脉冲) | Phasor / Detailed / D-STATCOM Average |
| **UPFC** | 统一潮流控制器 | Phasor / Detailed |
| **SSSC** | 静止同步串联补偿器 | Phasor |
| **TCSC** | 可控串联补偿器 | Phasor / Detailed |
| **OLTC** | 有载调压变压器 | Phase Shifting / Regulating |

#### 1.3.4 可再生能源

**太阳能 (PV)：**
| 示例模型 | 规模 | 类型 |
|---------|------|------|
| Single-Phase Grid-Connected PV Array | 3.5 kW | 单相并网 |
| Grid-Connected PV Array | 250 kW | 三相并网 |
| Grid-Connected PV Farm (Average) | 400 kW | 平均值模型 |
| Grid-Connected PV Array (Detailed) | 100 kW | 详细模型 |
| DC Islanded Microgrid + Electrolyzer | — | 离网微电网 |
| GFM BESS + Solar PV | — | 构网型储能 |

**风能 (Wind)：**
| 示例模型 | 类型 |
|---------|------|
| Wind Farm (IG) | 感应发电机 |
| Wind Farm (DFIG Phasor/Detailed/Average) | 双馈感应 |
| Simplified Generator Wind System | 低保真规划 |
| GFM Wind Generator (G-GFM/M-GFM) | 构网型风电 |

#### 1.3.5 HVDC 系统

| 类型 | 模块/示例 | 特点 |
|------|----------|------|
| **LCC-HVDC** | 12-pulse Thyristor Converter | 传统晶闸管换流 |
| **VSC-HVDC** | Voltage-Sourced Converter | 强迫换流，±100kV 200MVA |
| **MMC-HVDC** | Modular Multilevel Converter Arm | 等效模型 (PWM/波形控制) |
| **UHVDC** | ±1100kV, 24GW, 3324km | 超高压直流 |

### 1.4 Specialized Power Systems (sps_lib) 完整模块目录

| 子库 | 模块列表 |
|------|---------|
| **Sources** | powergui, AC Voltage Source, DC Voltage Source, Three-Phase Source, Three-Phase Programmable Voltage Source, Controlled Voltage Source, Controlled Current Source |
| **Power Electronics** | Universal Bridge, IGBT/Diode, IGBT, Diode, MOSFET, Thyristor, GTO, Ideal Switch |
| **Passives** | Series RLC Branch, Parallel RLC Branch, Three-Phase Series RLC Branch, Three-Phase Parallel RLC Branch, Mutual Inductance, Saturable Transformer |
| **Sensors & Measurements** | Voltage Measurement, Current Measurement, Three-Phase V-I Measurement, Power (Phasor), Impedance Measurement, Multimeter |
| **Utilities** | Ground, Neutral, Bus Selector |
| **Electric Drives** | AC1~AC8, DC1~DC7, Motor & Drive, Shaft, Speed Reducer |
| **Machines** | Asynchronous Machine, Synchronous Machine, PM Synchronous Machine, DC Machine |
| **Transformers** | Three-Phase Transformer (2/3 Windings), Saturable Transformer |
| **Control** | PLL, abc_to_dq0/dq0_to_abc, Discrete PI/PID |

---

## 二、find_system 高级搜索模板

### 2.1 基础搜索

```matlab
%% 按名称精确搜索
results = find_system('sps_lib', 'SearchDepth', 15, 'Name', 'Universal Bridge');

%% 按名称模糊搜索（正则）
results = find_system('sps_lib', 'SearchDepth', 15, 'regexp', 'on', 'Name', '.*Bridge.*');

%% 按模块类型搜索
results = find_system('sps_lib', 'SearchDepth', 15, 'BlockType', 'SubSystem');
```

### 2.2 按功能分类搜索

```matlab
%% 搜索所有电力电子器件
function blocks = find_power_electronics(lib)
    keywords = {'IGBT', 'MOSFET', 'Diode', 'Thyristor', 'GTO', 'Switch', 'Bridge'};
    blocks = {};
    for i = 1:length(keywords)
        found = find_system(lib, 'SearchDepth', 15, 'regexp', 'on', 'Name', keywords{i});
        blocks = [blocks; found];
    end
    blocks = unique(blocks);
end

%% 搜索所有电源/源模块
function blocks = find_sources(lib)
    found = find_system(lib, 'SearchDepth', 15, 'regexp', 'on', 'Name', '.*Source.*|.*Battery.*|.*Solar.*');
    blocks = found;
end

%% 搜索所有测量模块
function blocks = find_measurements(lib)
    found = find_system(lib, 'SearchDepth', 15, 'regexp', 'on', 'Name', '.*Measurement.*|.*Sensor.*|.*Multimeter.*');
    blocks = found;
end

%% 搜索所有电机模块
function blocks = find_machines(lib)
    found = find_system(lib, 'SearchDepth', 15, 'regexp', 'on', 'Name', '.*Machine.*|.*Motor.*|.*Generator.*');
    blocks = found;
end
```

### 2.3 按模块属性搜索

```matlab
%% 按 MaskType 搜索（很多 Simscape 模块有 MaskType）
results = find_system('sps_lib', 'SearchDepth', 15, 'MaskType', 'Universal Bridge');

%% 按 BlockDescription 搜索（模块描述包含关键词）
results = find_system('ee_lib', 'SearchDepth', 15, 'regexp', 'on', 'BlockDescription', '.*rectifier.*');

%% 搜索带 Mask 的模块（复杂子系统通常有 Mask）
results = find_system('sps_lib', 'SearchDepth', 15, 'Mask', 'on');

%% 搜索特定 ReferenceBlock（查找模型中使用的库链接）
results = find_system('myModel', 'regexp', 'on', 'ReferenceBlock', 'sps_lib/.*');
```

### 2.4 跨库综合搜索

```matlab
%% 在所有可用电气库中搜索模块
function [path, lib] = find_block_anywhere(block_name)
    libs = {'ee_lib', 'sps_lib', 'powerlib'};
    path = ''; lib = '';
    for i = 1:length(libs)
        try
            load_system(libs{i});
            results = find_system(libs{i}, 'SearchDepth', 15, ...
                'regexp', 'on', 'Name', block_name);
            if ~isempty(results)
                path = results{1};
                lib = libs{i};
                fprintf('Found: %s in %s\n', path, lib);
                return;
            end
        catch
            % 该库不可用
        end
    end
    if isempty(path)
        fprintf('Block "%s" not found in any library\n', block_name);
    end
end
```

### 2.5 Simulink.findBlocks (新 API)

```matlab
%% 使用 Simulink.findBlocks（R2019b+，返回 handles，性能更好）
opts = Simulink.FindOptions('SearchDepth', 15, 'RegExp', 'on');
handles = Simulink.findBlocks('sps_lib', opts, 'Name', '.*Bridge.*');

%% 使用 Simulink.findBlocksOfType
handles = Simulink.findBlocksOfType('myModel', 'SubSystem');
```

### 2.6 Library Link 信息查询

```matlab
%% 查找模型中所有的 Library Link
function links = find_library_links(model)
    % 方法1: 通过 LinkStatus
    links = find_system(model, 'FollowLinks', 'off', 'LookUnderMasks', 'all', ...
        'LinkStatus', 'resolved');

    % 方法2: 通过 libinfo（更详细）
    info = libinfo(model);
    for i = 1:length(info)
        fprintf('Block: %s -> Library: %s\n', info(i).Block, info(i).Library);
    end
end

%% 查找引用特定库的所有链接
results = find_system('myModel', 'regexp', 'on', 'ReferenceBlock', 'sps_lib/Power Electronics/.*');
```

---

## 三、自定义库创建完整代码

### 3.1 创建基本库

```matlab
function create_custom_library(lib_name)
    % 创建自定义库
    % Input: lib_name - 库名称（如 'my_power_lib'）

    % 1. 创建库文件
    new_system(lib_name, 'Library');
    open_system(lib_name);

    % 2. 添加子库（分类组织）
    categories = {'Power_Converters', 'Control_Systems', 'Measurements', 'Common_Circuits'};
    y_offset = 0;
    for i = 1:length(categories)
        add_block('built-in/SubSystem', [lib_name, '/', categories{i}]);
        set_param([lib_name, '/', categories{i}], 'Position', [50, 50+y_offset, 250, 100+y_offset]);
        y_offset = y_offset + 80;
    end

    % 3. 保存
    save_system(lib_name);
    fprintf('Library "%s" created successfully.\n', lib_name);
end
```

### 3.2 向库中添加可复用子系统

```matlab
function add_subsystem_to_library(lib_name, category, subsys_name, builder_func)
    % 向自定义库添加子系统
    % lib_name: 库名  category: 子库名  subsys_name: 子系统名
    % builder_func: 构建函数句柄 @(path) build_xxx(path)

    % 解锁库
    set_param(lib_name, 'Lock', 'off');

    % 创建子系统
    path = [lib_name, '/', category, '/', subsys_name];
    add_block('built-in/SubSystem', path);

    % 调用构建函数填充内容
    builder_func(path);

    % 添加 Mask（提供参数化界面）
    mask = Simulink.Mask.create(path);
    mask.Display = sprintf('disp(''%s'')', subsys_name);

    % 锁定库
    set_param(lib_name, 'Lock', 'on');
    save_system(lib_name);
end
```

### 3.3 注册到 Library Browser (slblocks.m)

```matlab
function blkStruct = slblocks
    % slblocks.m - 将自定义库注册到 Simulink Library Browser
    % 将此文件放在库 .slx 所在目录

    % 浏览器中显示的名称
    Browser.Library = 'my_power_lib';
    Browser.Name    = 'My Power Electronics Library';
    Browser.IsFlat  = 0;  % 0 = 有层级结构

    blkStruct.Browser = Browser;
end
```

### 3.4 完整示例：创建 Buck 变换器库模块

```matlab
function create_buck_converter_library()
    lib = 'PowerElecLib';

    % 创建库
    new_system(lib, 'Library');
    open_system(lib);

    % 添加 Buck 变换器子系统
    buck_path = [lib, '/Buck_Converter'];
    add_block('built-in/SubSystem', buck_path);

    % 检测并加载电气库
    try load_system('sps_lib'); active_lib = 'sps_lib';
    catch
        try load_system('powerlib'); active_lib = 'powerlib';
        catch, error('No power systems library available'); end
    end

    % 添加内部模块
    prefix = buck_path;
    add_block([active_lib, '/Sources/DC Voltage Source'], [prefix, '/Vdc']);
    add_block([active_lib, '/Power Electronics/Ideal Switch'], [prefix, '/SW']);
    add_block([active_lib, '/Power Electronics/Diode'], [prefix, '/D_fw']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [prefix, '/L']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [prefix, '/C']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [prefix, '/R_load']);
    add_block([active_lib, '/Utilities/Ground'], [prefix, '/GND']);
    add_block([active_lib, '/Sensors and Measurements/Voltage Measurement'], [prefix, '/Vout']);

    % 配置参数
    set_param([prefix, '/L'], 'BranchType', 'L', 'Inductance', '1e-3');
    set_param([prefix, '/C'], 'BranchType', 'C', 'Capacitance', '100e-6');
    set_param([prefix, '/R_load'], 'BranchType', 'R', 'Resistance', '10');

    % 添加 Mask 参数化
    mask = Simulink.Mask.create(buck_path);
    mask.addParameter('Name', 'Vin', 'Prompt', 'Input Voltage (V)', 'Value', '24');
    mask.addParameter('Name', 'L_val', 'Prompt', 'Inductance (H)', 'Value', '1e-3');
    mask.addParameter('Name', 'C_val', 'Prompt', 'Capacitance (F)', 'Value', '100e-6');
    mask.addParameter('Name', 'R_val', 'Prompt', 'Load Resistance (Ohm)', 'Value', '10');
    mask.Display = sprintf('disp(''Buck Converter'');\nport_label(''input'', 1, ''PWM'');\nport_label(''output'', 1, ''Vout'');');

    % 锁定库防止误改
    set_param(lib, 'LockLinksToLibrary', 'on');

    save_system(lib);
    fprintf('Buck Converter library created: %s.slx\n', lib);
end
```

---

## 四、「搜索 -> 判断 -> 复用」决策流程

### 4.1 AI 判断是否有现成模块的决策树

```
用户需求: "搭建一个 XXX 电路"
           |
           v
   ┌─────────────────────────┐
   │ Step 1: 关键词分析       │
   │ 提取: 电路类型、拓扑名   │
   │ 例: "三相整流桥"         │
   └───────────┬─────────────┘
               v
   ┌─────────────────────────┐
   │ Step 2: 查找子系统级模块 │
   │ (最高优先级 — 一步复用)   │
   │                         │
   │ 检查清单:                │
   │ - Electric Drives?      │
   │   AC1~AC8, DC1~DC7      │
   │ - FACTS 设备?           │
   │   SVC, STATCOM, UPFC    │
   │ - 高功率转换器?          │
   │   Converter, Rectifier  │
   │ - 电机+驱动?            │
   │   Motor & Drive (Sys)   │
   └───────────┬─────────────┘
               v
        ┌──────┴──────┐
    [找到]          [未找到]
        |               |
        v               v
   ┌──────────┐  ┌─────────────────────────┐
   │ 直接复用  │  │ Step 3: 查找组合级模块    │
   │ add_block │  │ (中等优先级 — 少量组装)   │
   │ + 配参数  │  │                          │
   └──────────┘  │ 检查:                    │
                 │ - Universal Bridge        │
                 │ - Three-Phase Source      │
                 │ - Three-Phase Transformer │
                 │ - Series RLC Branch       │
                 └───────────┬──────────────┘
                             v
                      ┌──────┴──────┐
                  [找到]          [未找到]
                      |               |
                      v               v
                 ┌──────────┐  ┌─────────────────────────┐
                 │ 组合搭建  │  │ Step 4: 基础元件拼接     │
                 │ 复用高级  │  │ (最低优先级 — 完全手动)   │
                 │ 模块+连线 │  │                          │
                 └──────────┘  │ 使用: IGBT, Diode,       │
                               │ MOSFET, R/L/C 等         │
                               │ 逐个添加 + 配参 + 连线    │
                               └──────────────────────────┘
```

### 4.2 搜索优先级策略（MATLAB 代码实现）

```matlab
function [strategy, path] = decide_reuse_strategy(circuit_desc)
    % 决策引擎：根据电路描述决定复用策略
    % Returns: strategy ('subsystem'/'composite'/'primitive'), path (模块路径)

    % 检测可用库
    libs = {'ee_lib', 'sps_lib', 'powerlib'};
    active_lib = '';
    for i = 1:length(libs)
        try load_system(libs{i}); active_lib = libs{i}; break; catch, end
    end

    % === 优先级 1: 子系统级模块 ===
    subsys_map = {
        '.*三相.*整流.*|.*three.*phase.*rectif.*',    'Electric Drives/DC3';
        '.*PWM.*逆变.*|.*PWM.*invert.*',              'Electric Drives/AC2';
        '.*FOC.*|.*磁场定向.*',                        'Electric Drives/AC3';
        '.*DTC.*|.*直接转矩.*',                        'Electric Drives/AC4';
        '.*BLDC.*|.*无刷直流.*',                       'Electric Drives/AC7';
        '.*PMSM.*|.*永磁同步.*',                       'Electric Drives/AC6';
        '.*SVC.*|.*静止无功.*',                        'FACTS/SVC';
        '.*STATCOM.*',                                 'FACTS/STATCOM';
        '.*HVDC.*',                                    'HVDC';
    };

    for i = 1:size(subsys_map, 1)
        if ~isempty(regexpi(circuit_desc, subsys_map{i, 1}))
            strategy = 'subsystem';
            path = subsys_map{i, 2};
            fprintf('Strategy: SUBSYSTEM reuse -> %s\n', path);
            return;
        end
    end

    % === 优先级 2: 组合级模块 ===
    composite_map = {
        '.*整流桥.*|.*bridge.*rectif.*',  'Universal Bridge';
        '.*三相电源.*|.*three.*source.*', 'Three-Phase Source';
        '.*变压器.*|.*transform.*',       'Saturable Transformer';
    };

    for i = 1:size(composite_map, 1)
        if ~isempty(regexpi(circuit_desc, composite_map{i, 1}))
            strategy = 'composite';
            found = find_system(active_lib, 'SearchDepth', 15, ...
                'regexp', 'on', 'Name', composite_map{i, 2});
            if ~isempty(found)
                path = found{1};
                fprintf('Strategy: COMPOSITE with %s\n', path);
                return;
            end
        end
    end

    % === 优先级 3: 基础元件 ===
    strategy = 'primitive';
    path = '';
    fprintf('Strategy: PRIMITIVE assembly required\n');
end
```

### 4.3 常见电路的模块化速查表

| 电路需求 | 最佳复用方案 | 对应模块/路径 |
|---------|-------------|-------------|
| 三相不可控整流 | **Universal Bridge** (Device='Diodes') | `sps_lib/Power Electronics/Universal Bridge` |
| 三相可控整流 | **Universal Bridge** (Device='Thyristors') | 同上，切换 Device 参数 |
| 单相全桥整流 | **Universal Bridge** (Arms='1') | 同上，切换 Arms 参数 |
| 三相 PWM 逆变 | **Universal Bridge** (Device='IGBT/Diodes') | 同上 |
| 感应电机 FOC 驱动 | **AC3** (整套: 电机+变频器+控制器) | `sps_lib/Electric Drives/AC3` |
| BLDC 电机驱动 | **AC7** (整套) | `sps_lib/Electric Drives/AC7` |
| PMSM 矢量控制 | **AC6** (整套) | `sps_lib/Electric Drives/AC6` |
| DC 电机斩波驱动 | **DC5/DC6/DC7** (按象限选) | `sps_lib/Electric Drives/DC5~7` |
| Buck/Boost/Buck-Boost | 无现成子系统，用 **基础元件拼接** | Ideal Switch + Diode + L + C |
| 静止无功补偿 | **SVC** (整套: TCR+TSC+控制) | 示例模型 |
| 并网光伏 | **Solar PV Controller** + 示例模型 | ee_lib + 示例 |
| 风力发电 (DFIG) | **DFIG Wind Farm** 示例模型 | 示例模型 |
| PI 控制器 | **Discrete PI Controller** | Simulink/Discrete |

---

## 五、Library Link vs Reference Subsystem 对比

### 5.1 核心区别

| 特性 | Library Link | Reference Subsystem |
|------|-------------|-------------------|
| **存储位置** | 库文件 (.slx) 中的子系统 | 独立 .slx 文件中的子系统 |
| **引用方式** | 从库拖拽到模型，自动建立链接 | 通过 Subsystem Reference 引用外部文件 |
| **同步更新** | 打开模型时自动同步库更新 | 打开模型时自动加载引用文件 |
| **修改限制** | 链接状态下不可修改（需先 Disable Link） | 直接编辑引用文件即影响所有实例 |
| **参数化** | 通过 Mask 参数 | 通过 Mask 参数或 Model Arguments |
| **版本管理** | 库文件整体版本控制 | 每个子系统独立版本控制 |
| **适用场景** | 小到中型库，团队内部复用 | 大型项目，跨团队复用，独立版本 |
| **代码生成** | 支持可重用函数 | 支持可重用函数 |

### 5.2 Library Link 用法

```matlab
%% 创建链接 (从库到模型)
% 方法1: 编程添加（自动建立 Link）
add_block('my_power_lib/Power_Converters/Buck_Converter', 'myModel/Buck1');

%% 查看 Link 状态
status = get_param('myModel/Buck1', 'LinkStatus');
% 可能值: 'resolved' (正常链接), 'unresolved' (断链), 'none' (无链接)

%% Disable Link（允许局部修改）
set_param('myModel/Buck1', 'LinkStatus', 'inactive');

%% Restore Link（恢复库同步）
set_param('myModel/Buck1', 'LinkStatus', 'restore');

%% 锁定所有 Link（防止误改）
set_param('my_power_lib', 'LockLinksToLibrary', 'on');
```

### 5.3 Reference Subsystem 用法

```matlab
%% 创建 Reference Subsystem
% 1. 先创建独立的子系统文件
new_system('BuckConverter');
% ... 添加内容 ...
save_system('BuckConverter');

% 2. 在模型中引用
add_block('simulink/Ports & Subsystems/Subsystem Reference', 'myModel/Buck1');
set_param('myModel/Buck1', 'ReferencedSubsystem', 'BuckConverter');

%% 查看引用信息
ref = get_param('myModel/Buck1', 'ReferencedSubsystem');
```

### 5.4 选择建议

```
需要复用子系统?
    |
    ├── 同一团队/项目内复用 → Library Link
    │   - 创建 .slx 库文件
    │   - 用 slblocks.m 注册
    │   - 从 Library Browser 拖拽使用
    │
    ├── 跨团队/跨项目复用 → Reference Subsystem
    │   - 每个子系统独立 .slx
    │   - 独立版本控制
    │   - 通过文件路径引用
    │
    └── AI 编程生成模型 → Library Link 更优
        - add_block 一行代码即可复用
        - 参数化通过 set_param 修改 Mask 参数
        - 无需管理多个文件
```

---

## 六、Simscape vs Specialized Power Systems 选择策略

### 6.1 技术对比

| 维度 | Simscape (ee_lib) | Specialized Power Systems (sps_lib) |
|------|-------------------|-------------------------------------|
| **求解器** | DAE + ODE | 仅 ODE |
| **三相建模** | 需手动搭建三相 | 原生三相优化 |
| **电机模型** | PMSM, Induction, BLDC | 完整电机+驱动 (AC1~8, DC1~7) |
| **FACTS** | 有限 | SVC, STATCOM, UPFC, SSSC, TCSC |
| **仿真速度** | 中等 (DAE开销) | 大系统更快 (纯ODE) |
| **多物理域** | 支持 (热、磁、机械) | 仅电气 |
| **代码生成** | 支持 | 支持 |
| **高频电力电子** | 精度更高 | 可能需要很小步长 |
| **未来** | **主推方向** | **R2026a 移除** |

### 6.2 选择决策树

```
你的应用场景?
    |
    ├── 电力电子开关电路 (Buck/Boost/Inverter)
    │   └── 推荐: Simscape (ee_lib) — 高保真开关模型
    │
    ├── 电机驱动系统 (带控制器)
    │   ├── 需要快速验证 → Specialized Power Systems (AC/DC drives)
    │   └── 需要高保真+热分析 → Simscape (ee_lib)
    │
    ├── 电力系统 / 输配电
    │   ├── 大规模 (100+ 节点) → Specialized Power Systems (更快)
    │   └── 小规模+多物理域 → Simscape
    │
    ├── 可再生能源并网
    │   └── 两者都有示例，Simscape 是未来方向
    │
    └── 新项目
        └── **优先 Simscape (ee_lib)**，因为 SPS 将在 R2026a 移除
```

---

## 七、常见电力电子电路模块化搭建模板

### 7.1 三相整流桥 + LC 滤波（一键搭建）

```matlab
function build_three_phase_rectifier(model)
    % 三相不可控整流桥 + LC滤波
    % 使用 Universal Bridge 子系统级模块 — 不需要逐个放二极管

    active_lib = detect_lib();  % 检测 sps_lib/powerlib

    % 添加模块
    add_block([active_lib, '/powergui'], [model, '/powergui']);
    add_block([active_lib, '/Sources/Three-Phase Source'], [model, '/AC_Source']);
    add_block([active_lib, '/Power Electronics/Universal Bridge'], [model, '/Rectifier']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/L_filter']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/C_filter']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/R_load']);
    add_block([active_lib, '/Sensors and Measurements/Voltage Measurement'], [model, '/Vdc_meas']);
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND']);

    % 配置 Universal Bridge — 关键：一个模块 = 6个二极管
    set_param([model, '/Rectifier'], 'Device', 'Diodes', 'Arms', '3');

    % 配置滤波器
    set_param([model, '/L_filter'], 'BranchType', 'L', 'Inductance', '1e-3');
    set_param([model, '/C_filter'], 'BranchType', 'C', 'Capacitance', '2200e-6');
    set_param([model, '/R_load'], 'BranchType', 'R', 'Resistance', '50');

    % 配置 powergui
    try set_param([model, '/powergui'], 'SimulationMode', 'Discrete'); catch, end
    try set_param([model, '/powergui'], 'SampleTime', '5e-6'); catch, end

    % 连线 (省略详细连线代码 — 参考 SKILL.md 连线模板)
    fprintf('Three-phase rectifier with LC filter created in: %s\n', model);
end
```

### 7.2 PWM 控制器模板

```matlab
function build_pwm_controller(model, prefix)
    % 生成 PWM 信号的标准模板
    % prefix: 模块路径前缀

    % 方法1: 使用 Simulink 基础模块搭建
    add_block('simulink/Sources/Repeating Sequence', [prefix, '/Carrier']);
    add_block('simulink/Math Operations/Subtract', [prefix, '/Compare']);
    add_block('simulink/Signal Routing/Switch', [prefix, '/PWM_Switch']);
    add_block('simulink/Sources/Constant', [prefix, '/High']);
    add_block('simulink/Sources/Constant', [prefix, '/Low']);

    set_param([prefix, '/Carrier'], 'rep_seq_t', '[0 1/fsw]', 'rep_seq_y', '[0 1]');
    set_param([prefix, '/High'], 'Value', '1');
    set_param([prefix, '/Low'], 'Value', '0');

    % 方法2: 使用 PWM Generator (如果可用)
    try
        add_block([detect_lib(), '/Control/PWM Generator'], [prefix, '/PWM_Gen']);
        fprintf('Using built-in PWM Generator block\n');
    catch
        fprintf('PWM Generator not available, using manual implementation\n');
    end
end
```

### 7.3 PI 控制器模板

```matlab
function build_pi_controller(model, prefix, Kp, Ki, Ts)
    % 离散 PI 控制器
    % Kp: 比例增益, Ki: 积分增益, Ts: 采样时间

    if nargin < 5, Ts = '1e-4'; end
    if nargin < 4, Ki = '100'; end
    if nargin < 3, Kp = '1'; end

    % 方法1: 使用 Simulink PID Controller
    add_block('simulink/Continuous/PID Controller', [prefix, '/PI']);
    set_param([prefix, '/PI'], ...
        'Controller', 'PI', ...
        'P', Kp, 'I', Ki);

    % 方法2: 离散 PI (更适合电力电子)
    % add_block('simulink/Discrete/Discrete PID Controller', [prefix, '/PI']);
    % set_param([prefix, '/PI'], 'SampleTime', Ts, 'P', Kp, 'I', Ki);
end
```

### 7.4 闭环 Buck 变换器完整模板

```matlab
function build_closed_loop_buck(model)
    % 完整的闭环 Buck 变换器
    % 包含: 主电路 + PWM + PI控制 + 测量

    active_lib = detect_lib();

    %% === 主电路 ===
    add_block([active_lib, '/powergui'], [model, '/powergui']);
    add_block([active_lib, '/Sources/DC Voltage Source'], [model, '/Vin']);
    add_block([active_lib, '/Power Electronics/Ideal Switch'], [model, '/SW']);
    add_block([active_lib, '/Power Electronics/Diode'], [model, '/D_fw']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/L']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/C']);
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/R_load']);
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND1']);
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND2']);

    %% === 测量 ===
    add_block([active_lib, '/Sensors and Measurements/Voltage Measurement'], [model, '/Vout_meas']);

    %% === 控制回路 ===
    add_block('simulink/Sources/Constant', [model, '/Vref']);
    add_block('simulink/Math Operations/Sum', [model, '/Error']);
    add_block('simulink/Continuous/PID Controller', [model, '/PI']);
    add_block('simulink/Sources/Repeating Sequence', [model, '/Carrier']);
    add_block('simulink/Logic and Bit Operations/Compare To Zero', [model, '/Comparator']);

    %% === Scope ===
    add_block('simulink/Sinks/Scope', [model, '/Scope']);

    %% === 参数配置 ===
    set_param([model, '/Vin'], 'Amplitude', '24');
    set_param([model, '/L'], 'BranchType', 'L', 'Inductance', '1e-3');
    set_param([model, '/C'], 'BranchType', 'C', 'Capacitance', '100e-6');
    set_param([model, '/R_load'], 'BranchType', 'R', 'Resistance', '10');
    set_param([model, '/Vref'], 'Value', '12');
    set_param([model, '/PI'], 'Controller', 'PI', 'P', '0.01', 'I', '50');
    set_param([model, '/Carrier'], 'rep_seq_t', '[0 1e-4]', 'rep_seq_y', '[0 1]');

    fprintf('Closed-loop Buck converter created in: %s\n', model);
end
```

---

## 八、GitHub 开源资源

| 项目 | 描述 | 链接 |
|------|------|------|
| **pwrsys-matlab** | 高渗透率转换器接口设备的电力系统设计仿真库 | [github.com/efantnu/pwrsys-matlab](https://github.com/efantnu/pwrsys-matlab) |
| **FastElectricalSimulations** | Simscape 快速电气仿真示例 | [github.com/simscape/FastElectricalSimulations](https://github.com/simscape/FastElectricalSimulations) |
| **Renewable-Energy-Integration-Simscape** | 可再生能源并网集成设计（IEEE 2800 合规测试） | [github.com/simscape/Renewable-Energy-Integration-Simscape](https://github.com/simscape/Renewable-Energy-Integration-Simscape) |

### MATLAB File Exchange 高质量模型

| 模型 | 描述 | 评分 |
|------|------|------|
| Three-Phase AC-DC-AC PWM Converter | 60Hz整流+50Hz逆变，VSC控制 | Hydro-Quebec 官方 |
| Three-Phase Sinusoidal PWM Rectifier | PWM整流器完整实现 | 高 |
| Sinusoidal PWM 3-Phase Inverter | 三相SPWM逆变器 | 高 |
| Electrical Power System Simulation | 电力系统综合仿真 | 高 |

---

## 九、关键发现与建议

### 9.1 关于 AI 编程搭建 Simulink 的策略调整

1. **优先使用子系统级模块** — Electric Drives (AC1~8, DC1~7) 和 Universal Bridge 能极大减少工作量，一个 add_block 替代数十行连线代码。

2. **注意 SPS 即将移除** — R2026a 将移除 Specialized Power Systems，新项目应优先使用 ee_lib (Simscape-based blocks)。但目前 Electric Drives 等高级子系统仅在 SPS 中可用，迁移需要关注。

3. **find_system + regexp 是核心搜索工具** — 结合 MaskType、BlockDescription、Name 三个维度搜索可覆盖 95% 的模块查找需求。

4. **自定义库是积累复用资产的最佳方式** — 将常用电路模板（Buck/Boost/整流桥+滤波/PI控制器）封装为库模块，后续一行 add_block 即可复用。

5. **Detailed vs Average-Value 模式** — Electric Drives 的双模式仿真能力非常适合 AI 工作流：先用 Average-Value 快速验证，再切 Detailed 精确仿真。

### 9.2 推荐更新 SKILL.md 的内容

- 在搭建电路前增加「模块搜索」步骤
- 添加 Universal Bridge 快速搭建整流/逆变的模板
- 添加 Electric Drives 子系统的直接引用方法
- 添加自定义库创建和管理的代码模板
- 更新模块路径映射表，补充 ee_lib 对应路径

---

## 参考来源

- [Simscape Electrical Block Libraries — MathWorks](https://www.mathworks.com/help/sps/ug/simscape-electrical-block-libraries.html)
- [Electrical Block Libraries — MathWorks](https://www.mathworks.com/help/sps/simscape-based-blocks.html)
- [find_system — MathWorks](https://www.mathworks.com/help/simulink/slref/find_system.html)
- [Simulink.findBlocks — MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.findblocks.html)
- [Simulink.FindOptions — MathWorks](https://www.mathworks.com/help/simulink/slref/simulink.findoptions.html)
- [libinfo — MathWorks](https://www.mathworks.com/help/simulink/slref/libinfo.html)
- [Create Custom Library — MathWorks](https://www.mathworks.com/help/simulink/ug/creating-block-libraries.html)
- [Libraries and Blocksets — MathWorks](https://www.mathworks.com/help/simulink/libraries.html)
- [Electric Drives Library — MathWorks](https://www.mathworks.com/help/physmod/sps/electric-drives.html)
- [Upgrade SPS to Simscape — MathWorks](https://www.mathworks.com/help/sps/ug/upgrade-sps-models-to-use-simscape-blocks.html)
- [Simscape Electrical Product — MathWorks](https://www.mathworks.com/products/simscape-electrical.html)
- [Converters (High Power) — MathWorks](https://www.mathworks.com/help/sps/high-power-converters.html)
- [Renewable Energy — MathWorks](https://www.mathworks.com/help/sps/renewable-energy.html)
- [Renewable-Energy-Integration-Simscape — GitHub](https://github.com/simscape/Renewable-Energy-Integration-Simscape)
- [pwrsys-matlab — GitHub](https://github.com/efantnu/pwrsys-matlab)
- [FastElectricalSimulations — GitHub](https://github.com/simscape/FastElectricalSimulations)
