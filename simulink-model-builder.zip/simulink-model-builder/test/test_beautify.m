%% test_beautify.m - 测试 Simulink 模型美化方案
% Input:  无（独立运行）
% Output: 生成美化后的 Buck 变换器模型 test_beautify_buck.slx
% Pos:    test/ 测试脚本，验证 beautify_model 函数和美化 API
%
% 测试内容：
%   1. 创建 Buck 变换器基础模型（使用 detect_lib 兼容）
%   2. 添加所有基本模块和连线
%   3. 调用 arrangeSystem 自动布局
%   4. 添加功能区域注释（Area）标注「主电路」「控制回路」「测量」
%   5. 按功能类别着色（电源=黄色，开关=红色，测量=绿色，控制=蓝色）
%   6. 添加信号标签（Vout, IL 等）
%   7. 隐藏不必要的块名称
%   8. 保存模型
%
% 用法:
%   在 MATLAB 命令窗口运行: test_beautify
%
% 依赖: detect_lib.m（同目录上级 scripts/ 下）

fprintf('\n========================================\n');
fprintf('  测试: Simulink 模型美化方案\n');
fprintf('========================================\n\n');

% 添加 scripts 目录到路径
script_dir = fileparts(mfilename('fullpath'));
addpath(fullfile(script_dir, '..', 'scripts'));

model = 'test_beautify_buck';
pass_count = 0;
fail_count = 0;
total_tests = 8;

%% === 清理旧模型 ===
try close_system(model, 0); catch, end
try delete([model, '.slx']); catch, end

%% === Test 1: 检测库并创建模型 ===
fprintf('[Test 1/8] 检测库并创建模型...\n');
try
    active_lib = detect_lib();
    new_system(model);
    open_system(model);

    % 添加 powergui
    add_block([active_lib, '/powergui'], [model, '/powergui']);
    try set_param([model, '/powergui'], 'SimulationMode', 'Discrete'); catch, end
    try set_param([model, '/powergui'], 'SampleTime', '5e-6'); catch, end

    fprintf('  PASS - 模型创建成功，使用库: %s\n', active_lib);
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
    fprintf('\n=== 测试中断：无法创建模型 ===\n');
    return;
end

%% === Test 2: 添加 Buck 变换器主电路模块 ===
fprintf('[Test 2/8] 添加主电路模块...\n');
try
    % 电源
    add_block([active_lib, '/Sources/DC Voltage Source'], [model, '/Vin']);
    set_param([model, '/Vin'], 'Amplitude', '24');

    % 开关器件
    add_block([active_lib, '/Power Electronics/Ideal Switch'], [model, '/SW']);

    % 续流二极管
    add_block([active_lib, '/Power Electronics/Diode'], [model, '/D_fw']);

    % 无源元件
    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/L']);
    set_param([model, '/L'], 'BranchType', 'L', 'Inductance', '1e-3');

    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/C']);
    set_param([model, '/C'], 'BranchType', 'C', 'Capacitance', '100e-6');

    add_block([active_lib, '/Passives/Series RLC Branch'], [model, '/R_load']);
    set_param([model, '/R_load'], 'BranchType', 'R', 'Resistance', '10');

    % 测量
    add_block([active_lib, '/Sensors and Measurements/Voltage Measurement'], [model, '/Vmeas']);
    add_block([active_lib, '/Sensors and Measurements/Current Measurement'], [model, '/Imeas']);

    % 接地
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND1']);
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND2']);
    add_block([active_lib, '/Utilities/Ground'], [model, '/GND3']);

    % 控制回路
    add_block('simulink/Sources/Constant', [model, '/Vref']);
    set_param([model, '/Vref'], 'Value', '12');

    add_block('simulink/Math Operations/Sum', [model, '/Error']);
    set_param([model, '/Error'], 'Inputs', '+-');

    add_block('simulink/Continuous/PID Controller', [model, '/PI']);
    set_param([model, '/PI'], 'Controller', 'PI', 'P', '0.01', 'I', '50');

    add_block('simulink/Sources/Repeating Sequence', [model, '/Carrier']);
    set_param([model, '/Carrier'], 'rep_seq_t', '[0 1e-4]', 'rep_seq_y', '[0 1]');

    add_block('simulink/Logic and Bit Operations/Compare To Zero', [model, '/Comparator']);

    % 显示
    add_block('simulink/Sinks/Scope', [model, '/Scope']);

    % 验证模块数量
    blocks = find_system(model, 'SearchDepth', 1, 'Type', 'block');
    fprintf('  PASS - 添加了 %d 个模块\n', length(blocks));
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 3: 连线 ===
fprintf('[Test 3/8] 连线...\n');
try
    line_count = 0;

    % 主电路电气连线
    % Vin+ -> SW
    try add_line(model, 'Vin/RConn1', 'SW/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Vin- -> GND1
    try add_line(model, 'Vin/LConn1', 'GND1/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % SW -> Imeas
    try add_line(model, 'SW/RConn1', 'Imeas/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Imeas -> L
    try add_line(model, 'Imeas/RConn1', 'L/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % L -> C
    try add_line(model, 'L/RConn1', 'C/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % L -> R_load
    try add_line(model, 'L/RConn1', 'R_load/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % C -> GND2
    try add_line(model, 'C/RConn1', 'GND2/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % R_load -> GND2
    try add_line(model, 'R_load/RConn1', 'GND2/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % 续流二极管: D阴极 -> SW出, D阳极 -> GND
    try add_line(model, 'D_fw/RConn1', 'Imeas/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    try add_line(model, 'D_fw/LConn1', 'GND3/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end

    % 电压测量（注意: Vmeas 使用 LConn1 和 LConn2）
    try add_line(model, 'L/RConn1', 'Vmeas/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    try add_line(model, 'Vmeas/LConn2', 'GND2/LConn1', 'autorouting', 'on'); line_count = line_count + 1; catch, end

    % 信号连线
    % Vmeas -> Error
    try add_line(model, 'Vmeas/1', 'Error/2', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Vref -> Error
    try add_line(model, 'Vref/1', 'Error/1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Error -> PI
    try add_line(model, 'Error/1', 'PI/1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % PI -> Comparator (PI输出 与 载波 比较)
    try add_line(model, 'PI/1', 'Comparator/1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Comparator -> SW 控制端
    try add_line(model, 'Comparator/1', 'SW/1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Vmeas -> Scope
    try add_line(model, 'Vmeas/1', 'Scope/1', 'autorouting', 'on'); line_count = line_count + 1; catch, end
    % Imeas -> Scope
    try add_line(model, 'Imeas/1', 'Scope/2', 'autorouting', 'on'); line_count = line_count + 1; catch, end

    fprintf('  PASS - 成功连线 %d 条\n', line_count);
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 4: 自动布局 arrangeSystem ===
fprintf('[Test 4/8] 自动布局...\n');
try
    Simulink.BlockDiagram.arrangeSystem(model);
    fprintf('  PASS - arrangeSystem 执行成功\n');
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 5: 功能区域注释 (Area) ===
fprintf('[Test 5/8] 添加功能区域注释...\n');
try
    % 主电路区域
    add_block('built-in/Area', [model, '/Main Circuit'], ...
        'Position', [30, 30, 600, 350]);

    % 控制回路区域
    add_block('built-in/Area', [model, '/Control Loop'], ...
        'Position', [30, 370, 600, 250]);

    % 测量区域
    add_block('built-in/Area', [model, '/Measurement'], ...
        'Position', [650, 30, 300, 350]);

    % 设置 Area 样式
    area_handles = find_system(model, 'FindAll', 'on', 'Type', 'annotation', ...
        'AnnotationType', 'area_annotation');

    for i = 1:length(area_handles)
        try
            txt = get_param(area_handles(i), 'PlainText');
            switch txt
                case 'Main Circuit'
                    set_param(area_handles(i), 'BackgroundColor', '[0.85 0.92 1.0]');
                    set_param(area_handles(i), 'ForegroundColor', 'blue');
                    set_param(area_handles(i), 'FontSize', '12');
                case 'Control Loop'
                    set_param(area_handles(i), 'BackgroundColor', '[1.0 0.95 0.85]');
                    set_param(area_handles(i), 'ForegroundColor', '[0.8 0.4 0]');
                    set_param(area_handles(i), 'FontSize', '12');
                case 'Measurement'
                    set_param(area_handles(i), 'BackgroundColor', '[0.85 1.0 0.85]');
                    set_param(area_handles(i), 'ForegroundColor', 'darkGreen');
                    set_param(area_handles(i), 'FontSize', '12');
            end
        catch
        end
    end

    fprintf('  PASS - 创建了 %d 个功能区域\n', length(area_handles));
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 6: 块着色 ===
fprintf('[Test 6/8] 按功能类别着色...\n');
try
    colored = 0;

    % 电源 → 黄色
    set_param([model, '/Vin'], 'BackgroundColor', 'yellow');
    colored = colored + 1;

    % 开关器件 → 浅红色
    set_param([model, '/SW'], 'BackgroundColor', '[1.0 0.8 0.8]');
    colored = colored + 1;

    % 二极管 → 橙色
    set_param([model, '/D_fw'], 'BackgroundColor', 'orange');
    colored = colored + 1;

    % 测量 → 浅绿色
    set_param([model, '/Vmeas'], 'BackgroundColor', '[0.8 1.0 0.8]');
    set_param([model, '/Imeas'], 'BackgroundColor', '[0.8 1.0 0.8]');
    colored = colored + 2;

    % 控制 → 浅蓝色
    set_param([model, '/Vref'], 'BackgroundColor', 'lightBlue');
    set_param([model, '/Error'], 'BackgroundColor', 'lightBlue');
    set_param([model, '/PI'], 'BackgroundColor', 'lightBlue');
    set_param([model, '/Carrier'], 'BackgroundColor', 'lightBlue');
    set_param([model, '/Comparator'], 'BackgroundColor', 'lightBlue');
    colored = colored + 5;

    % 无源元件 → 默认（不着色）
    % Scope → 浅灰
    set_param([model, '/Scope'], 'BackgroundColor', '[0.95 0.95 0.95]');
    colored = colored + 1;

    fprintf('  PASS - 着色了 %d 个模块\n', colored);
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 7: 信号标签 + 隐藏默认名称 ===
fprintf('[Test 7/8] 信号标签与名称控制...\n');
try
    labeled = 0;

    % 给 Vmeas 输出命名 Vout
    ph = get_param([model, '/Vmeas'], 'PortHandles');
    if ~isempty(ph.Outport)
        line_h = get_param(ph.Outport(1), 'Line');
        if line_h ~= -1
            set_param(line_h, 'Name', 'Vout');
            labeled = labeled + 1;
        end
    end

    % 给 Imeas 输出命名 IL
    ph = get_param([model, '/Imeas'], 'PortHandles');
    if ~isempty(ph.Outport)
        line_h = get_param(ph.Outport(1), 'Line');
        if line_h ~= -1
            set_param(line_h, 'Name', 'IL');
            labeled = labeled + 1;
        end
    end

    % 隐藏默认名称
    hidden = 0;
    default_blocks = {'GND1', 'GND2', 'GND3', 'Scope'};
    for i = 1:length(default_blocks)
        try
            set_param([model, '/', default_blocks{i}], 'HideAutomaticName', 'on');
            hidden = hidden + 1;
        catch
            try
                set_param([model, '/', default_blocks{i}], 'ShowName', 'off');
                hidden = hidden + 1;
            catch
            end
        end
    end

    fprintf('  PASS - 标签 %d 条信号，隐藏 %d 个默认名称\n', labeled, hidden);
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === Test 8: 保存模型 ===
fprintf('[Test 8/8] 保存模型...\n');
try
    % 添加标题注释
    title_text = sprintf('%s - Beautify Test', model);
    ann = Simulink.Annotation([model, '/', title_text]);
    ann.Position = [20, -30];
    ann.FontSize = 14;
    ann.FontWeight = 'bold';
    ann.ForegroundColor = '[0.2 0.2 0.6]';
    ann.BackgroundColor = 'white';

    % 设置白色画布背景
    set_param(model, 'ScreenColor', 'white');

    save_system(model);
    fprintf('  PASS - 模型已保存为 %s.slx\n', model);
    pass_count = pass_count + 1;
catch ME
    fprintf('  FAIL - %s\n', ME.message);
    fail_count = fail_count + 1;
end

%% === 测试结果摘要 ===
fprintf('\n========================================\n');
fprintf('  测试结果摘要 - 模型美化\n');
fprintf('========================================\n');
fprintf('  总测试数: %d\n', total_tests);
fprintf('  通过: %d\n', pass_count);
fprintf('  失败: %d\n', fail_count);
fprintf('  通过率: %.0f%%\n', pass_count/total_tests*100);
if fail_count == 0
    fprintf('  状态: ALL PASSED\n');
else
    fprintf('  状态: SOME FAILED\n');
end
fprintf('========================================\n');

% 清理
try close_system(model, 0); catch, end
