---
name: simulink-model-builder
description: Builds MATLAB Simulink models programmatically with cross-version compatibility (R2016b~R2024b+). Activates when users request Simulink model creation, encounter "no block named 'powerlib/xxx'" errors, need programmatic model generation (add_block/set_param/add_line), work with Simscape Electrical simulations (power electronics/motor drives/switching power supplies), or face port connection errors. Resolves module path compatibility issues across different MATLAB versions.
---

# Simulink Model Builder

## 核心问题

MATLAB 不同版本的 Simscape Electrical 库路径不同：

| 版本 | 库名 | 示例路径 |
|------|------|----------|
| R2016a 及更早 | `powerlib` | `powerlib/Universal Bridge` |
| R2016b ~ R2023b | `powerlib` (重构) | `powerlib/Power Electronics/Universal Bridge` |
| R2024a+ | `sps_lib` | `sps_lib/Power Electronics/Universal Bridge` |
| 未来 | `ee_lib` | Simscape Electrical 原生模块 |

## 工作流

### 1. 检测可用库

```matlab
% 尝试加载可能的库
libs = {'sps_lib', 'powerlib', 'ee_lib'};
for i = 1:length(libs)
    try
        load_system(libs{i});
        active_lib = libs{i};
        break;
    catch
    end
end
```

### 2. 动态搜索模块路径

```matlab
% 使用 find_system 搜索模块
function path = find_block_path(lib, block_name)
    results = find_system(lib, 'SearchDepth', 15, 'Name', block_name);
    if ~isempty(results)
        path = results{1};
    else
        error('模块未找到: %s', block_name);
    end
end
```

### 3. 检查参数名称

不同版本参数名可能不同，需动态检测：

```matlab
% 获取模块可用参数
params = get_param('model/Block', 'DialogParameters');
fields = fieldnames(params);
% 检查 Enum 字段获取可选值
```

### 4. 安全添加模块

```matlab
function add_block_safe(src, dst)
    try
        add_block(src, dst);
    catch
        % 回退：搜索正确路径
        [~, name] = fileparts(src);
        results = find_system('sps_lib', 'SearchDepth', 15, 'Name', name);
        if ~isempty(results)
            add_block(results{1}, dst);
        else
            error('无法添加模块: %s', name);
        end
    end
end
```

## 常见模块路径 (R2024b sps_lib)

| 模块 | 路径 |
|------|------|
| powergui | `sps_lib/powergui` |
| Three-Phase Source | `sps_lib/Sources/Three-Phase Source` |
| AC Voltage Source | `sps_lib/Sources/AC Voltage Source` |
| DC Voltage Source | `sps_lib/Sources/DC Voltage Source` |
| Universal Bridge | `sps_lib/Power Electronics/Universal Bridge` |
| IGBT/Diode | `sps_lib/Power Electronics/IGBT//Diode` |
| IGBT | `sps_lib/Power Electronics/IGBT` |
| Ideal Switch | `sps_lib/Power Electronics/Ideal Switch` |
| Diode | `sps_lib/Power Electronics/Diode` |
| MOSFET | `sps_lib/Power Electronics/Mosfet` |
| Series RLC Branch | `sps_lib/Passives/Series RLC Branch` |
| Voltage Measurement | `sps_lib/Sensors and Measurements/Voltage Measurement` |
| Current Measurement | `sps_lib/Sensors and Measurements/Current Measurement` |
| Ground | `sps_lib/Utilities/Ground` |

## 参数兼容性

### Universal Bridge

| 版本 | 器件类型参数 | 桥臂数参数 |
|------|-------------|-----------|
| 旧版 | `Arms` = 'Diodes' | (无) |
| R2024b | `Device` = 'Diodes' | `Arms` = '3' |

### Powergui

| 版本 | 离散模式参数 |
|------|-------------|
| 旧版 | `SimulationType` = 'Discrete' |
| 中期 | `SimulationMode` = 'Discrete' |
| 某些版本 | `SolverType` = 'Discrete' |

**建议**: 使用 try-catch 尝试多种参数名。

---

<!-- Evolution: 2026-01-15 | source: 100-开关电源 | author: @user -->
## 自动连线 (add_line)

### 端口命名规则

Simscape Electrical 模块使用特殊端口命名，**不同模块端口名不同**：

| 模块类型 | 端口名 | 说明 |
|---------|--------|------|
| **双端口电气元件** | `LConn1`, `RConn1` | 左连接、右连接 |
| **Voltage Measurement** | `LConn1`, `LConn2` | ⚠️ 两个都是 LConn！ |
| **Current Measurement** | `LConn1`, `RConn1` | 标准命名 |
| **Ground** | `LConn1` | 仅一个端口 |
| **开关器件 (IGBT/Ideal Switch)** | `LConn1`, `RConn1`, `1` | 电气端口 + 控制信号 |
| **Diode** | `LConn1` (阳极), `RConn1` (阴极) | 注意方向 |
| **Simulink 信号端口** | `1`, `2`, `3`... | 数字编号 |

### 关键发现

<!-- Correction: 2026-01-15 | was: Vmeas/RConn1 | reason: Voltage Measurement 没有 RConn 端口 -->

**Voltage Measurement 端口特殊**：
- ❌ 错误: `Vmeas/RConn1` (不存在!)
- ✅ 正确: `Vmeas/LConn1` (+端), `Vmeas/LConn2` (-端)

### 安全连线函数

```matlab
% 安全连线：失败时打印错误而非中断
function safe_add_line(model, src, dst)
    try
        add_line(model, src, dst, 'autorouting', 'smart');
        fprintf('  ✓ %s -> %s\n', src, dst);
    catch ME
        fprintf('  ✗ %s -> %s: %s\n', src, dst, ME.message);
    end
end
```

### 批量连线模板

```matlab
%% 电气连线 (try-catch 保护)
try add_line(model, 'Vdc/RConn1', 'SW/LConn1', 'autorouting', 'smart'); catch, end
try add_line(model, 'Vdc/LConn1', 'GND/LConn1', 'autorouting', 'smart'); catch, end
try add_line(model, 'SW/RConn1', 'L/LConn1', 'autorouting', 'smart'); catch, end

%% Voltage Measurement 连线 (注意: 使用 LConn1 和 LConn2)
try add_line(model, 'L/RConn1', 'Vmeas/LConn1', 'autorouting', 'smart'); catch, end  % +端
try add_line(model, 'Vmeas/LConn2', 'GND/LConn1', 'autorouting', 'smart'); catch, end  % -端

%% 信号连线
try add_line(model, 'PWM/1', 'SW/1', 'autorouting', 'smart'); catch, end  % 控制信号
try add_line(model, 'Vmeas/1', 'Scope/1', 'autorouting', 'smart'); catch, end  % 测量信号
```

### 端口诊断脚本

遇到端口名错误时，使用此脚本检查正确的端口名：

```matlab
%% check_ports.m - 检查模块端口名称
function check_ports(model, block_name)
    block_path = [model, '/', block_name];
    ph = get_param(block_path, 'PortHandles');

    fprintf('=== %s 端口信息 ===\n', block_name);
    fields = fieldnames(ph);
    for i = 1:length(fields)
        ports = ph.(fields{i});
        if ~isempty(ports)
            fprintf('%s: %d 个\n', fields{i}, length(ports));
        end
    end

    % 获取连接类型
    pcs = get_param(block_path, 'PortConnectivity');
    fprintf('\n端口连接名 (用于 add_line):\n');
    for i = 1:length(pcs)
        fprintf('  端口 %d: Type = %s\n', i, pcs(i).Type);
    end
end

% 使用示例:
% check_ports('myModel', 'Vmeas')
```

### 常见连线模式

#### Buck 变换器主电路

```matlab
% DC源 -> 开关 -> 电流测量 -> 电感 -> 电容/负载
add_line(model, 'Vdc/RConn1', 'SW/LConn1', 'autorouting', 'smart');
add_line(model, 'SW/RConn1', 'Imeas/LConn1', 'autorouting', 'smart');
add_line(model, 'Imeas/RConn1', 'L/LConn1', 'autorouting', 'smart');
add_line(model, 'L/RConn1', 'C/LConn1', 'autorouting', 'smart');
add_line(model, 'L/RConn1', 'R/LConn1', 'autorouting', 'smart');

% 续流二极管
add_line(model, 'D/RConn1', 'SW/RConn1', 'autorouting', 'smart');  % 阴极->开关出
add_line(model, 'D/LConn1', 'GND/LConn1', 'autorouting', 'smart'); % 阳极->地

% 接地
add_line(model, 'C/RConn1', 'GND2/LConn1', 'autorouting', 'smart');
add_line(model, 'R/RConn1', 'GND2/LConn1', 'autorouting', 'smart');
```

#### 测量与数据记录

```matlab
% Voltage Measurement (特殊端口!)
add_line(model, 'OutputNode/RConn1', 'Vmeas/LConn1', 'autorouting', 'smart');
add_line(model, 'Vmeas/LConn2', 'GND/LConn1', 'autorouting', 'smart');
add_line(model, 'Vmeas/1', 'ToWorkspace/1', 'autorouting', 'smart');  % 信号输出

% Current Measurement (标准端口)
add_line(model, 'Imeas/1', 'Scope/2', 'autorouting', 'smart');  % 信号输出
```

---

## 调试脚本

遇到模块找不到时，运行以下诊断脚本：

```matlab
% 列出库中所有模块
load_system('sps_lib');  % 或 powerlib
blocks = find_system('sps_lib', 'SearchDepth', 15, 'Type', 'block');
for i = 1:length(blocks)
    fprintf('%s\n', blocks{i});
end
```

## 参考文件

- [scripts/detect_lib.m](scripts/detect_lib.m) - 库检测脚本
- [scripts/find_blocks.m](scripts/find_blocks.m) - 模块搜索脚本
- [scripts/check_params.m](scripts/check_params.m) - 参数检查脚本
- [scripts/check_ports.m](scripts/check_ports.m) - 端口诊断脚本
- [references/module_paths.md](references/module_paths.md) - 完整模块路径映射表
