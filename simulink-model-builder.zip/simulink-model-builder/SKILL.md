---
name: simulink-model-builder
description: Builds MATLAB Simulink models programmatically with cross-version compatibility (R2016b~R2025a+). Activates when users request Simulink model creation, encounter "no block named 'powerlib/xxx'" errors, need programmatic model generation (add_block/set_param/add_line), work with Simscape Electrical simulations (power electronics/motor drives/switching power supplies), face port connection errors, need model beautification/layout, or want to reuse mature library modules. Resolves module path compatibility, automates model layout, and provides intelligent module reuse decisions.
---

# Simulink Model Builder

## 架构概览

本技能分为 5 层，覆盖从环境检测到项目管理的完整建模流程：

```
第5层: 项目管理 — Simulink Projects + Data Dictionary + Version Control
第4层: 仿真执行 — SimulationInput + parsim/batchsim 参数扫描
第3层: 大规模架构 — Model Reference + Buses + Subsystem 封装
第2层: 模型构建 — add_block + add_line + set_param + 模块复用
第1层: 环境检测 — detect_lib + find_blocks + check_params + search_reusable
```

## 标准工作流（6步）

```
1. detect_lib()          → 检测可用库 (sps_lib/powerlib/ee_lib)
2. search_reusable(desc) → 判断是否有现成模块可复用
3. add_block + set_param → 添加模块并配参
4. add_line              → 连线（autorouting='on'）
5. beautify_model(sys)   → 一键美化（布局+着色+标注）
6. save_system           → 保存模型
```

⚠️ **重要**: R2026a 将移除 Specialized Power Systems (sps_lib)，新项目优先使用 ee_lib (Simscape-based)。

## 核心问题

MATLAB 不同版本的 Simscape Electrical 库路径不同：

| 版本 | 库名 | 示例路径 | 状态 |
|------|------|----------|------|
| R2016a 及更早 | `powerlib` | `powerlib/Universal Bridge` | 已废弃 |
| R2016b ~ R2023b | `powerlib` (重构) | `powerlib/Power Electronics/Universal Bridge` | 旧版 |
| R2024a+ | `sps_lib` | `sps_lib/Power Electronics/Universal Bridge` | 当前推荐 |
| R2025b+ | `ee_lib` | Simscape Electrical 原生模块 | **未来方向** |

## 工作流

### 1. 检测可用库

```matlab
% 尝试加载可能的库
libs = {'sps_lib', 'powerlib', 'ee_lib'};
for i = 1:length(libs)
    try
        load_system(libs{i});
        active_lib = libs{i};
        break;
    catch
    end
end
```

### 2. 动态搜索模块路径

```matlab
% 使用 find_system 搜索模块
function path = find_block_path(lib, block_name)
    results = find_system(lib, 'SearchDepth', 15, 'Name', block_name);
    if ~isempty(results)
        path = results{1};
    else
        error('模块未找到: %s', block_name);
    end
end
```

### 3. 检查参数名称

不同版本参数名可能不同，需动态检测：

```matlab
% 获取模块可用参数
params = get_param('model/Block', 'DialogParameters');
fields = fieldnames(params);
% 检查 Enum 字段获取可选值
```

### 4. 安全添加模块

```matlab
function add_block_safe(src, dst)
    try
        add_block(src, dst);
    catch
        % 回退：搜索正确路径
        [~, name] = fileparts(src);
        results = find_system('sps_lib', 'SearchDepth', 15, 'Name', name);
        if ~isempty(results)
            add_block(results{1}, dst);
        else
            error('无法添加模块: %s', name);
        end
    end
end
```

## 常见模块路径 (R2024b sps_lib)

| 模块 | 路径 |
|------|------|
| powergui | `sps_lib/powergui` |
| Three-Phase Source | `sps_lib/Sources/Three-Phase Source` |
| AC Voltage Source | `sps_lib/Sources/AC Voltage Source` |
| DC Voltage Source | `sps_lib/Sources/DC Voltage Source` |
| Universal Bridge | `sps_lib/Power Electronics/Universal Bridge` |
| IGBT/Diode | `sps_lib/Power Electronics/IGBT//Diode` |
| IGBT | `sps_lib/Power Electronics/IGBT` |
| Ideal Switch | `sps_lib/Power Electronics/Ideal Switch` |
| Diode | `sps_lib/Power Electronics/Diode` |
| MOSFET | `sps_lib/Power Electronics/Mosfet` |
| Series RLC Branch | `sps_lib/Passives/Series RLC Branch` |
| Voltage Measurement | `sps_lib/Sensors and Measurements/Voltage Measurement` |
| Current Measurement | `sps_lib/Sensors and Measurements/Current Measurement` |
| Ground | `sps_lib/Utilities/Ground` |

## 参数兼容性

### Universal Bridge

| 版本 | 器件类型参数 | 桥臂数参数 |
|------|-------------|-----------|
| 旧版 | `Arms` = 'Diodes' | (无) |
| R2024b+ | `Device` = 'Diodes' | `Arms` = '3' |

⚠️ **Device 枚举值有空格**: `'IGBT / Diodes'`（注意斜杠两边有空格），不是 `'IGBT/Diodes'`

### Three-Phase Source

| 版本 | 电压参数名 | 说明 |
|------|-----------|------|
| R2025a | `Voltage` = '311' | ⚠️ 不是 `PhaseVoltage`！ |
| R2025a | `Frequency` = '50' | 频率 |
| R2025a | `InternalConnection` = 'Yn' | 枚举: Y, Yn, Yg |

### Powergui

| 版本 | 离散模式参数 |
|------|-------------|
| 旧版 | `SimulationType` = 'Discrete' |
| 中期 | `SimulationMode` = 'Discrete' |
| 某些版本 | `SolverType` = 'Discrete' |

**建议**: 使用 try-catch 尝试多种参数名。

---

<!-- Evolution: 2026-01-15 | source: 100-开关电源 | author: @user -->
## 自动连线 (add_line)

### 端口命名规则

Simscape Electrical 模块使用特殊端口命名，**不同模块端口名不同**：

| 模块类型 | 端口名 | 说明 |
|---------|--------|------|
| **双端口电气元件** | `LConn1`, `RConn1` | 左连接、右连接 |
| **Three-Phase Source** | `RConn1`, `RConn2`, `RConn3` | ⚠️ 只有 RConn（输出端），无 LConn！ |
| **Three-Phase V-I Measurement** | `LConn1~3`, `RConn1~3`, `1`, `2` | 左=输入，右=输出，1=Vabc信号，2=Iabc信号 |
| **Universal Bridge (Diodes)** | `LConn1~3`, `RConn1`, `RConn2` | AC输入3端口，DC输出仅2端口（+/-） |
| **Universal Bridge (IGBT/VSC)** | `1`, `LConn1~3`, `RConn1`, `RConn2` | 多一个信号输入端口(脉冲控制) |
| **Voltage Measurement** | `LConn1`, `LConn2` | ⚠️ 两个都是 LConn！(+端/-端) |
| **Current Measurement** | `LConn1`, `RConn1` | 标准命名 |
| **Ground** | `LConn1` | 仅一个端口 |
| **开关器件 (IGBT/Ideal Switch)** | `LConn1`, `RConn1`, `1` | 电气端口 + 控制信号 |
| **Diode** | `LConn1` (阳极), `RConn1` (阴极) | 注意方向 |
| **Simulink 信号端口** | `1`, `2`, `3`... | 数字编号 |

### 关键发现

<!-- Correction: 2026-01-15 | was: Vmeas/RConn1 | reason: Voltage Measurement 没有 RConn 端口 -->

**Voltage Measurement 端口特殊**：
- ❌ 错误: `Vmeas/RConn1` (不存在!)
- ✅ 正确: `Vmeas/LConn1` (+端), `Vmeas/LConn2` (-端)

### 安全连线函数

```matlab
% 安全连线：失败时打印错误而非中断
function safe_add_line(model, src, dst)
    try
        add_line(model, src, dst, 'autorouting', 'smart');
        fprintf('  ✓ %s -> %s\n', src, dst);
    catch ME
        fprintf('  ✗ %s -> %s: %s\n', src, dst, ME.message);
    end
end
```

### 批量连线模板

```matlab
%% 电气连线 (try-catch 保护)
try add_line(model, 'Vdc/RConn1', 'SW/LConn1', 'autorouting', 'smart'); catch, end
try add_line(model, 'Vdc/LConn1', 'GND/LConn1', 'autorouting', 'smart'); catch, end
try add_line(model, 'SW/RConn1', 'L/LConn1', 'autorouting', 'smart'); catch, end

%% Voltage Measurement 连线 (注意: 使用 LConn1 和 LConn2)
try add_line(model, 'L/RConn1', 'Vmeas/LConn1', 'autorouting', 'smart'); catch, end  % +端
try add_line(model, 'Vmeas/LConn2', 'GND/LConn1', 'autorouting', 'smart'); catch, end  % -端

%% 信号连线
try add_line(model, 'PWM/1', 'SW/1', 'autorouting', 'smart'); catch, end  % 控制信号
try add_line(model, 'Vmeas/1', 'Scope/1', 'autorouting', 'smart'); catch, end  % 测量信号
```

### 端口诊断脚本

遇到端口名错误时，使用此脚本检查正确的端口名：

```matlab
%% check_ports.m - 检查模块端口名称
function check_ports(model, block_name)
    block_path = [model, '/', block_name];
    ph = get_param(block_path, 'PortHandles');

    fprintf('=== %s 端口信息 ===\n', block_name);
    fields = fieldnames(ph);
    for i = 1:length(fields)
        ports = ph.(fields{i});
        if ~isempty(ports)
            fprintf('%s: %d 个\n', fields{i}, length(ports));
        end
    end

    % 获取连接类型
    pcs = get_param(block_path, 'PortConnectivity');
    fprintf('\n端口连接名 (用于 add_line):\n');
    for i = 1:length(pcs)
        fprintf('  端口 %d: Type = %s\n', i, pcs(i).Type);
    end
end

% 使用示例:
% check_ports('myModel', 'Vmeas')
```

### 常见连线模式

#### Buck 变换器主电路

```matlab
% DC源 -> 开关 -> 电流测量 -> 电感 -> 电容/负载
add_line(model, 'Vdc/RConn1', 'SW/LConn1', 'autorouting', 'smart');
add_line(model, 'SW/RConn1', 'Imeas/LConn1', 'autorouting', 'smart');
add_line(model, 'Imeas/RConn1', 'L/LConn1', 'autorouting', 'smart');
add_line(model, 'L/RConn1', 'C/LConn1', 'autorouting', 'smart');
add_line(model, 'L/RConn1', 'R/LConn1', 'autorouting', 'smart');

% 续流二极管
add_line(model, 'D/RConn1', 'SW/RConn1', 'autorouting', 'smart');  % 阴极->开关出
add_line(model, 'D/LConn1', 'GND/LConn1', 'autorouting', 'smart'); % 阳极->地

% 接地
add_line(model, 'C/RConn1', 'GND2/LConn1', 'autorouting', 'smart');
add_line(model, 'R/RConn1', 'GND2/LConn1', 'autorouting', 'smart');
```

#### 测量与数据记录

```matlab
% Voltage Measurement (特殊端口!)
add_line(model, 'OutputNode/RConn1', 'Vmeas/LConn1', 'autorouting', 'smart');
add_line(model, 'Vmeas/LConn2', 'GND/LConn1', 'autorouting', 'smart');
add_line(model, 'Vmeas/1', 'ToWorkspace/1', 'autorouting', 'smart');  % 信号输出

% Current Measurement (标准端口)
add_line(model, 'Imeas/1', 'Scope/2', 'autorouting', 'smart');  % 信号输出
```

---

## 调试脚本

遇到模块找不到时，运行以下诊断脚本：

```matlab
% 列出库中所有模块
load_system('sps_lib');  % 或 powerlib
blocks = find_system('sps_lib', 'SearchDepth', 15, 'Type', 'block');
for i = 1:length(blocks)
    fprintf('%s\n', blocks{i});
end
```

## 参考文件

- [scripts/detect_lib.m](scripts/detect_lib.m) - 库检测脚本
- [scripts/find_blocks.m](scripts/find_blocks.m) - 模块搜索脚本
- [scripts/check_params.m](scripts/check_params.m) - 参数检查脚本
- [scripts/check_ports.m](scripts/check_ports.m) - 端口诊断脚本
- [scripts/beautify_model.m](scripts/beautify_model.m) - 一键美化函数
- [scripts/search_reusable.m](scripts/search_reusable.m) - 模块复用决策函数
- [references/module_paths.md](references/module_paths.md) - 完整模块路径映射表

---

## 模块复用策略（搭建前必查）

搭建电路前，**先调用 `search_reusable(desc)` 判断是否有现成模块**，避免用基础元件拼接：

### 三级优先级

| 优先级 | 策略 | 说明 | 代码量节省 |
|--------|------|------|-----------|
| 1 | **子系统级** | Electric Drives (AC1~8, DC1~7), FACTS (SVC/STATCOM/UPFC) | ~90% |
| 2 | **组合级** | Universal Bridge (=6个二极管), Three-Phase Source | ~70% |
| 3 | **基础元件** | IGBT/Diode/MOSFET + R/L/C 逐个拼接 | 0% |

### 速查表

| 电路需求 | 最佳方案 | 一行代码 |
|---------|---------|---------|
| 三相不可控整流 | Universal Bridge (Device='Diodes') | `add_block(lib+'/Power Electronics/Universal Bridge', dst)` |
| 三相 PWM 逆变 | Universal Bridge (Device='IGBT/Diodes') | 同上，切换 Device 参数 |
| 感应电机 FOC | AC3 (整套: 电机+变频器+控制器) | `add_block(lib+'/Electric Drives/AC3', dst)` |
| BLDC 驱动 | AC7 (整套) | `add_block(lib+'/Electric Drives/AC7', dst)` |
| PMSM 矢量控制 | AC6 (整套) | `add_block(lib+'/Electric Drives/AC6', dst)` |
| DC 斩波驱动 | DC5/DC6/DC7 (按象限选) | `add_block(lib+'/Electric Drives/DC5', dst)` |
| Buck/Boost | 无现成子系统 → 基础元件拼接 | Ideal Switch + Diode + L + C |

### 决策函数

```matlab
% 自动判断复用策略
[strategy, path] = search_reusable('三相整流桥');
% → strategy='composite', path='sps_lib/Power Electronics/Universal Bridge'

[strategy, path] = search_reusable('PMSM矢量控制');
% → strategy='subsystem', path='sps_lib/Electric Drives/AC6'

[strategy, path] = search_reusable('Buck converter');
% → strategy='primitive', path='' (需手动拼接)
```

---

## 模型美化（构建后必做）

搭建完成后，**调用 `beautify_model(sys)` 一键美化**，8步自动完成：

### 美化流程

```
1. 画布 → 白色背景
2. 区域 → 创建 Area 注释框（Power Stage / Control Loop / Measurements）
3. 着色 → 电源=黄色，开关=红色，测量=绿色，控制=蓝色
4. 布局 → arrangeSystem（先子系统，再顶层）
5. 连线 → routeLine 优化连线路由
6. 标签 → 给关键信号命名（Vout, IL, PWM 等）
7. 名称 → 隐藏默认块名（Gain1, Sum2 等）
8. 标题 → 左上角添加模型标题注释
```

### 关键 API

| 功能 | API | 最低版本 |
|------|-----|---------|
| 自动布局 | `Simulink.BlockDiagram.arrangeSystem(sys)` | R2018b |
| 连线优化 | `Simulink.BlockDiagram.routeLine(lines)` | R2019a |
| 块着色 | `set_param(blk, 'BackgroundColor', 'yellow')` | R2014b |
| Area 注释 | `add_block('built-in/Area', path, 'Position', pos)` | R2019a |
| 信号标签 | `set_param(line_handle, 'Name', 'Vout')` | 所有版本 |
| 隐藏名称 | `set_param(blk, 'HideAutomaticName', 'on')` | R2021a |
| 文字注释 | `Simulink.Annotation(path)` | R2014b |

### 着色方案

| 功能类别 | 颜色 | 匹配规则 |
|---------|------|---------|
| 电源/Source | 黄色 `yellow` | 名称含 source/vin/vdc |
| 开关器件 | 浅红 `[1.0 0.8 0.8]` | 名称含 switch/sw/igbt/mosfet |
| 二极管 | 橙色 `orange` | 名称含 diode |
| 测量 | 浅绿 `[0.8 1.0 0.8]` | 名称含 meas/sensor |
| 控制 | 浅蓝 `lightBlue` | 名称含 pi/control/pwm/ref |
| 显示 | 浅灰 `[0.95 0.95 0.95]` | Scope/Display/ToWorkspace |

### 注意事项

- **顺序重要**: 先分区 → 再着色 → 再布局 → 再连线 → 最后标注
- `arrangeSystem` 会改变块大小，需要时可保存/恢复原始尺寸
- `routeLine` 需要画布有足够空白区域
- 信号标签位置无法程序化控制（已知限制）

---

## 子系统封装（复用资产积累）

将常用电路封装为子系统，支持参数化和跨模型复用：

### 创建子系统 + Mask

```matlab
% 1. 创建子系统
add_block('built-in/SubSystem', [model, '/BuckConverter']);

% 2. 在子系统内部添加电路
prefix = [model, '/BuckConverter'];
add_block([lib, '/Power Electronics/Ideal Switch'], [prefix, '/SW']);
% ... 添加其他模块和连线 ...

% 3. 添加 Mask 参数化
mask = Simulink.Mask.create([model, '/BuckConverter']);
mask.addParameter('Name', 'Vin_val', 'Prompt', 'Input Voltage (V)', 'Value', '24');
mask.addParameter('Name', 'L_val', 'Prompt', 'Inductance (H)', 'Value', '1e-3');
mask.addParameter('Name', 'C_val', 'Prompt', 'Capacitance (F)', 'Value', '100e-6');
mask.Display = "disp('Buck Converter');\nport_label('input',1,'PWM');\nport_label('output',1,'Vout');";
```

### 创建自定义库

```matlab
% 创建库文件
new_system('my_power_lib', 'Library');
add_block('built-in/SubSystem', 'my_power_lib/Power_Converters');
% 从模型复制子系统到库
add_block([model, '/BuckConverter'], 'my_power_lib/Power_Converters/Buck');
% 锁定库
set_param('my_power_lib', 'Lock', 'on');
save_system('my_power_lib');
```

### Library Link 复用

```matlab
% 从库添加到模型（自动建立 Link）
add_block('my_power_lib/Power_Converters/Buck', 'newModel/Buck1');
% 通过 Mask 参数定制
set_param('newModel/Buck1', 'Vin_val', '48', 'L_val', '2e-3');
```

---

## 大规模架构（第3层）

### Model Reference

独立组件各自一个 .slx 文件，支持并行开发和增量编译：

```matlab
% 在主模型中引用子模型
add_block('simulink/Ports & Subsystems/Model', [model, '/PowerStage']);
set_param([model, '/PowerStage'], 'ModelName', 'PowerStage_design');
```

### Buses

多信号捆绑为单线，降低视觉复杂度：

```matlab
% 创建 Bus 定义
bus = Simulink.Bus;
bus.Elements(1) = Simulink.BusElement; bus.Elements(1).Name = 'Voltage';
bus.Elements(2) = Simulink.BusElement; bus.Elements(2).Name = 'Current';
```

### Data Dictionary

替代 base workspace，支持数据分区和版本追踪：

```matlab
% 创建数据字典
dd = Simulink.data.dictionary.create('myProject.sldd');
sect = getSection(dd, 'Design Data');
addEntry(sect, 'Vin', 24);
% 关联到模型
set_param(model, 'DataDictionary', 'myProject.sldd');
```

---

## 仿真执行（第4层）

### SimulationInput（不污染模型文件）

```matlab
simIn = Simulink.SimulationInput(model);
simIn = simIn.setModelParameter('StopTime', '0.1');
simIn = simIn.setBlockParameter([model, '/Vin'], 'Amplitude', '48');
simOut = sim(simIn);  % 仿真后参数自动回滚
```

⚠️ **注意**: setter 返回新对象，必须 `simIn = simIn.setXxx()`

### 并行参数扫描

```matlab
% 批量仿真不同输入电压
Vin_values = [12, 24, 36, 48];
simIn(1:length(Vin_values)) = Simulink.SimulationInput(model);
for i = 1:length(Vin_values)
    simIn(i) = simIn(i).setBlockParameter([model, '/Vin'], 'Amplitude', num2str(Vin_values(i)));
end
simOut = parsim(simIn, 'ShowProgress', 'on');  % 多核并行仿真
```
