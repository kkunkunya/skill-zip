# 封面素材库

按公式分类存放真人出镜照片，供 `/配图` 命令调用。

## 目录结构

```
portraits/
├── formula-a/    # 公式A：手持设备半身照
├── formula-b/    # 公式B：对比状态照（可选）
├── formula-c/    # 公式C：工位坐姿照
└── README.md
```

## 使用方式

拍照指南见 `../references/cover-photo-guide.md`。

`/配图` 命令会自动扫描此目录，展示候选照片供选择。
效果好的照片会被标记为优质素材，优先复用。
