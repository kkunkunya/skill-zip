---
name: test-driven-development
description: Enforces test-driven development methodology before implementing features or fixing bugs. Mandates RED-GREEN-REFACTOR cycle (write failing test, observe failure, write minimal code to pass, refactor). Activates on requests like "write code", "implement feature", "fix bug", or "develop". Ensures code quality through test-first approach.
context: fork
---

# Test-Driven Development (TDD)

## 核心理念

**先写测试，看它失败，再写代码。**

如果你没看到测试失败，你就不知道测试是否测对了东西。

**违反规则的字面意思就是违反规则的精神。**

## 铁律

```
没有失败测试，就不能写生产代码
```

先写了代码？**删除它，重新开始。**

**没有例外：**
- 不要保留作为"参考"
- 不要边写测试边"调整"它
- 不要看它
- 删除就是删除

## RED-GREEN-REFACTOR 循环

```
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│    RED      │ ──→  │   GREEN     │ ──→  │  REFACTOR   │
│  写失败测试  │      │ 写最小代码   │      │   重构      │
└─────────────┘      └─────────────┘      └─────────────┘
       ↑                                        │
       └────────────────────────────────────────┘
```

### RED - 写失败测试

写一个最小测试，展示期望行为。

```python
# 好例子：清晰、测真实行为、一件事
def test_retry_failed_operations_3_times():
    attempts = 0
    def operation():
        nonlocal attempts
        attempts += 1
        if attempts < 3:
            raise Exception("fail")
        return "success"

    result = retry_operation(operation)

    assert result == "success"
    assert attempts == 3
```

**要求：**
- 只测一个行为
- 名称清晰描述行为
- 用真实代码（除非不得已才用 mock）

### 验证 RED - 看它失败

**必须做，不能跳过。**

```bash
pytest path/to/test.py -v
```

确认：
- 测试失败（不是报错）
- 失败原因是预期的
- 因为功能缺失而失败（不是拼写错误）

### GREEN - 写最小代码

写最简单的代码让测试通过。

```python
# 好例子：刚好够通过
async def retry_operation(fn):
    for i in range(3):
        try:
            return await fn()
        except Exception:
            if i == 2:
                raise
    raise Exception("unreachable")
```

**不要**添加功能、重构其他代码、或"改进"超出测试范围的东西。

### 验证 GREEN - 看它通过

**必须做。**

```bash
pytest path/to/test.py -v
```

确认：
- 测试通过
- 其他测试仍然通过
- 输出干净（无错误、警告）

### REFACTOR - 重构

只在绿色之后：
- 消除重复
- 改善命名
- 提取辅助函数

保持测试绿色。不要添加行为。

## 常见借口 vs 现实

| 借口 | 现实 |
|------|------|
| "太简单不用测" | 简单代码也会出错。测试只需30秒。 |
| "之后再写测试" | 立即通过的测试什么都证明不了。 |
| "我手动测过了" | 临时测试 ≠ 系统测试。没记录，不能重跑。 |
| "删掉X小时的工作太浪费" | 沉没成本谬误。保留未验证代码才是浪费。 |
| "TDD太教条，我在务实" | TDD 就是务实：找bug比调试快。 |
| "测试后写也能达到同样目的" | 后写测试问"这做了什么？" 先写测试问"这应该做什么？" |

## 红旗 - 停下，重新开始

- 先写代码再写测试
- 测试立即通过
- 说不清测试为什么失败
- 想"就这一次"跳过
- "我手动测过了"
- "测试后写也一样"
- "保留作为参考"
- "这次不一样因为..."

**以上都意味着：删除代码，用 TDD 重新开始。**

## Bug 修复示例

**Bug：** 空邮箱被接受

**RED**
```python
def test_rejects_empty_email():
    result = submit_form({"email": ""})
    assert result["error"] == "Email required"
```

**验证 RED**
```bash
$ pytest
FAIL: expected 'Email required', got None
```

**GREEN**
```python
def submit_form(data):
    if not data.get("email", "").strip():
        return {"error": "Email required"}
    # ...
```

**验证 GREEN**
```bash
$ pytest
PASS
```

## 完成前检查清单

- [ ] 每个新函数/方法都有测试
- [ ] 实现前看到每个测试失败
- [ ] 每个测试因预期原因失败（功能缺失，不是拼写错误）
- [ ] 写了最小代码通过每个测试
- [ ] 所有测试通过
- [ ] 输出干净（无错误、警告）
- [ ] 测试用真实代码（mock 只在不得已时用）
- [ ] 边界情况和错误处理都覆盖了

不能全部打勾？你跳过了 TDD。重新开始。

## 与调试集成

发现 bug？写一个能复现它的失败测试。遵循 TDD 循环。测试证明修复有效并防止回归。

**永远不要不写测试就修 bug。**

## 最终规则

```
生产代码 → 必须有测试先失败
否则 → 不是 TDD
```

没有用户许可，没有例外。
