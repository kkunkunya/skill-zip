---
name: delivery-quality-gate
description: "Cross-deliverable customer handoff quality gate. Use before any client demo or delivery to run an expectation-driven PASS/FAIL audit across all deliverables (code, results, charts, docs, media, models, package structure), then execute review-fix-review loops until pass. Triggers: 交付前检查, 质量门控, 客户验收前, 可交付吗, 审查交付物, 图表审查, handoff quality gate. NOT for feature development, training execution, or large refactoring."
---

# 通用交付质量门控（delivery-quality-gate）

目标：在“给客户展示/交付”前，做一次硬门控，防止“看起来完成但细节翻车”。

## 核心原则

- 期望先行：无验收标准不审查，先把客户期望写成可检查条目。
- 证据优先：无新鲜证据不判通过。
- 失败闭环：`PASS=false` 时禁止宣称“可交付”。
- 全交付物覆盖：不仅图表，还要覆盖代码、结果、文档、媒体、模型、打包结构。
- 并行审查：同阶段可并行，降低漏检概率。

## 输入最小集

- 项目根目录路径。
- 本次客户交付范围（必须交付项清单）。
- 验收阈值（至少含 3 条可量化标准）。
- 展示入口（客户将先看哪里：`index.html` / `README` / `PPT` / `figures`）。

## 门控主流程（强制）

### 1) 锁定验收合同（Acceptance Contract）

先形成 `验收矩阵`（可写在会话中，或落盘）：

- 指标名称
- 目标阈值
- 证据来源文件
- 判定规则（`>=`, `<=`, `==`, 集合存在）

若任意指标无法映射到证据文件，直接 `BLOCKED`，不得进入“通过”判定。

### 2) 建立交付物清单（Inventory）

按类型整理为 6 类：

- `RUN`：运行主链（代码、配置、启动命令）
- `RESULT`：结果数据（CSV/JSON/日志摘要）
- `VISUAL`：图表、GIF、截图、视频
- `DOC`：说明文档、交付稿、讲解稿
- `MODEL`：模型权重、checkpoint、配置快照
- `PACKAGE`：客户最终打开路径与目录结构

### 3) 并行三路审查

同一阶段并行执行三路审查，最后汇总共识：

1. `一致性审查`：图/表/文案与源数据是否一致  
2. `完整性审查`：关键文件是否缺失、损坏、不可读、不可运行  
3. `展示质量审查`：客户视角可读性（标签遮挡、裁切、误导坐标、术语混乱）

建议角色：

- 执行审查 Agent ×1
- 独立复核 Agent ×1
- Guardian/汇总 Agent ×1

### 4) 问题分级（固定口径）

- `BLOCKER`：影响正确性或会导致错误承诺（如图表与数据不一致、关键结果缺失）
- `MAJOR`：不影响真值但显著影响客户理解（如标签重叠、关键说明缺失）
- `MINOR`：展示优化项（如配色、排版微调）

判定规则：

- 存在任一 `BLOCKER` => `PASS=false`
- `MAJOR` 数量超过用户容忍阈值 => `PASS=false`
- 仅 `MINOR` 可按是否时间允许决定是否修

### 5) 修复-复审闭环（必须）

循环直到通过：

1. 先修 `BLOCKER`，再修 `MAJOR`
2. 修复后重新跑三路审查
3. 对“改动过的文件 + 受影响文件”做回归复查
4. 仍不通过则继续下一轮

禁止一次性“全量重写”带来新风险；优先最小改动闭环。

### 6) 输出门控结论（固定产物）

建议输出两个文件（可按项目路径调整）：

- `docs/QUALITY_GATE_REPORT.md`
  - 验收矩阵
  - 问题清单（分级）
  - 修复记录
  - 最终结论
- `docs/QUALITY_GATE_DECISION.json`
  - `pass: true|false`
  - `blocker_count`
  - `major_count`
  - `evidence_paths`
  - `timestamp`

若 `pass=false`，禁止输出“可交付”结论。

## 图表专项检查（高频问题防翻车）

每张图至少检查：

- 文件完整（可打开、未损坏）
- 坐标语义合法（例如 episode 不应出现负值）
- 标签/标题/图例不冲突不遮挡
- 图中关键数值可在源 CSV/JSON 回溯
- 图注/文案与口径一致（阈值、样本数、统计定义）

## 文档/讲解稿专项检查

- 结论与数据一致（禁止“口播超结论”）
- 文件路径可点击、可定位
- 术语统一（同一概念不多种叫法）
- 风险与边界有说明（客户问到时可解释）

## 模型与结果专项检查

- 模型文件存在且可定位（路径明确）
- 结果文件与模型版本关联清晰（seed/run_id）
- 关键指标可复算或可追溯

## 与 project-handoff-closedloop 的关系

- 本技能负责“质量门控是否通过”。
- `project-handoff-closedloop` 负责“整理与打包”。
- 推荐顺序：先 `$delivery-quality-gate`，通过后再 `$project-handoff-closedloop`。

## 最终汇报模板（固定）

1. `是否可交付`：PASS/FAIL  
2. `BLOCKER/MAJOR/MINOR 数量`  
3. `本轮修复了什么`  
4. `仍未解决什么（若有）`  
5. `客户查看入口路径`  
6. `下一步建议`

