---
name: hooks-manager
description: Manages Claude Code Hooks for creating, viewing, modifying, and debugging event callbacks. Supports macOS/Linux/Windows environments. Activates when users request hook management, including requests like "hooks", "add hook", "create hook", or "manage hooks". Enables custom script execution on specific Claude Code events.
context: fork
---

# Claude Code Hooks 管理技能

## 核心概念

Hooks 是 Claude Code 的事件回调系统，允许在特定事件发生时执行自定义脚本。

## 支持的 Hook 事件（10种）

| 事件 | 触发时机 | 支持 matcher | 可阻止 |
|------|---------|-------------|--------|
| **PreToolUse** | 工具调用前 | ✅ 工具名 | ✅ 退出码 2 |
| **PostToolUse** | 工具调用后 | ✅ 工具名 | ❌ |
| **PermissionRequest** | 权限请求时 | ✅ 工具名 | ✅ |
| **UserPromptSubmit** | 用户提交提示词 | ❌ | ✅ 退出码 2 |
| **Notification** | 发送通知时 | ✅ 通知类型 | ❌ |
| **Stop** | 主 Agent 停止时 | ❌ | ✅ |
| **SubagentStop** | 子 Agent 停止时 | ❌ | ✅ |
| **PreCompact** | 压缩上下文前 | ✅ manual/auto | ❌ |
| **SessionStart** | 会话开始时 | ✅ startup/resume/clear/compact | ❌ |
| **SessionEnd** | 会话结束时 | ❌ | ❌ |

## Matcher 语法

| 示例 | 含义 |
|-----|------|
| `"Bash"` | 精确匹配 Bash 工具 |
| `"Edit\|Write"` | 匹配 Edit 或 Write |
| `"Notebook.*"` | 匹配 Notebook 开头的工具 |
| `"mcp__server__.*"` | 匹配特定 MCP 服务器的工具 |

## Hook 脚本返回值

### 方式 1：退出码

| 退出码 | 效果 |
|-------|------|
| 0 | 成功，stdout 作为上下文 |
| 2 | **阻止操作**，stderr 作为反馈 |
| 其他 | 非阻止错误 |

### 方式 2：JSON 输出（退出码 0）

**通用格式**（PreToolUse/PostToolUse 等）：
```json
{
  "continue": false,           // 是否继续
  "stopReason": "原因",
  "systemMessage": "系统消息",
  "hookSpecificOutput": {
    "hookEventName": "PreToolUse",
    "permissionDecision": "allow|deny|ask",
    "updatedInput": { }        // 修改工具参数
  }
}
```

**⚠️ Stop hook 专用格式**（使用 `decision` 而非 `continue`）：
```json
{
  "decision": "approve|block",  // approve=允许停止, block=阻止停止
  "reason": "决策原因",
  "systemMessage": "显示给 Claude 的消息"
}
```

> **常见错误**：Stop hook 使用 `continue: true` 会导致 JSON validation failed

## 跨平台要点

1. **使用 Python 脚本**（推荐，跨平台兼容）
2. **路径处理**：使用 `os.path` 或 `pathlib` 处理路径
3. **使用绝对路径**或 `$CLAUDE_PROJECT_DIR` 环境变量

## 配置文件位置

```
# macOS/Linux
用户级别: ~/.claude/settings.json
项目级别: <项目根目录>/.claude/settings.json
本地项目: <项目根目录>/.claude/settings.local.json

# Windows
用户级别: C:\Users\<用户名>\.claude\settings.json
项目级别: <项目根目录>\.claude\settings.json
本地项目: <项目根目录>\.claude\settings.local.json
```

---

## 操作指南

### 查看当前 hooks

1. 读取 `~/.claude/settings.json` 的 `hooks` 字段
2. 或使用 `/hooks` 命令查看

### 创建新 hook

**步骤 1**：创建 Python 脚本

```python
#!/usr/bin/env python3
import json
import sys

def main():
    try:
        data = json.load(sys.stdin)
        # 你的逻辑
        sys.exit(0)  # 成功
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
```

**步骤 2**：添加到 settings.json

```json
{
  "hooks": {
    "EventName": [
      {
        "matcher": "ToolPattern",
        "hooks": [
          {
            "type": "command",
            "command": "python \"路径\\脚本.py\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
```

### 禁用 hook

将 hook 配置注释掉或删除即可。

### 调试 hook

```bash
# 启用调试模式
claude --debug

# 查看详细输出
[DEBUG] Executing hooks for PostToolUse:Bash
[DEBUG] Hook command completed with status 0
```

---

## 已部署的 Hooks

| Hook | 事件 | 功能 |
|------|------|------|
| `file_protector.py` | PreToolUse(Edit\|Write) | 保护敏感文件 |
| `bash_logger.py` | PostToolUse(Bash) | 记录 Bash 命令 |
| `session_init.py` | SessionStart | 注入项目上下文 |
| `prompt_enhancer.py` | UserPromptSubmit | 自动添加上下文 |
| `completion_checker.py` | Stop | 检查未完成任务 |

**脚本位置**: `~/.claude/hooks/`（macOS/Linux）或 `C:\Users\<用户名>\.claude\hooks\`（Windows）

---

## 常用 Hook 模板

### 文件保护（阻止编辑敏感文件）

```python
PROTECTED = [".env", "secrets", ".pem"]
path = data["tool_input"].get("file_path", "")
if any(p in path.lower() for p in PROTECTED):
    sys.exit(2)  # 阻止
```

### 命令审计（记录所有 Bash 命令）

```python
cmd = data["tool_input"].get("command", "")
with open("bash.log", "a") as f:
    f.write(f"[{time}] {cmd}\n")
```

### 上下文注入（SessionStart）

```python
output = {
    "hookSpecificOutput": {
        "hookEventName": "SessionStart",
        "additionalContext": "注入的上下文"
    }
}
print(json.dumps(output))
```

### 智能拦截（LLM 评估）

```json
{
  "hooks": [{
    "type": "prompt",
    "prompt": "分析此操作是否安全: $ARGUMENTS"
  }]
}
```

---

## 触发词

| 用户说 | 动作 |
|-------|------|
| "添加 hook" / "创建钩子" | 引导创建新 hook |
| "查看 hooks" / "显示钩子" | 读取并展示当前配置 |
| "禁用 hook" / "删除钩子" | 修改 settings.json |
| "调试 hook" | 说明调试方法 |

---

## Hookify 轻量级规则模式 ⚡

借鉴官方 Hookify 插件，支持通过 Markdown 文件快速创建规则，无需编写代码。

### 规则文件格式

创建 `.claude/hookify.*.local.md`（例如 `.claude/hookify.block-rm.local.md`）：

```markdown
---
name: block-dangerous-rm
enabled: true
event: bash
pattern: rm\s+-rf
action: block
---

⚠️ **危险操作检测！**

此命令可能删除重要文件。请：
- 确认路径正确
- 考虑使用更安全的方法
- 确保有备份
```

### Frontmatter 字段

| 字段 | 说明 | 示例 |
|------|------|------|
| `name` | 规则名称 | `block-dangerous-rm` |
| `enabled` | 是否启用 | `true` / `false` |
| `event` | 事件类型 | `bash` / `file` / `stop` / `prompt` / `all` |
| `pattern` | 正则匹配 | `rm\s+-rf` |
| `action` | 动作 | `warn`（警告）/ `block`（阻止） |

### 高级：多条件规则

```markdown
---
name: warn-sensitive-files
enabled: true
event: file
action: warn
conditions:
  - field: file_path
    operator: regex_match
    pattern: \.env$|credentials|secrets
  - field: new_text
    operator: contains
    pattern: KEY
---

🔐 **敏感文件编辑检测！**
确保凭证未硬编码且文件在 .gitignore 中。
```

### 操作符参考

| 操作符 | 说明 |
|-------|------|
| `regex_match` | 正则匹配（最常用） |
| `contains` | 包含字符串 |
| `equals` | 精确匹配 |
| `not_contains` | 不包含 |
| `starts_with` | 以...开头 |
| `ends_with` | 以...结尾 |

### 字段参考

**bash 事件**：`command`
**file 事件**：`file_path`, `new_text`, `old_text`, `content`
**prompt 事件**：`user_prompt`

### 快速示例

**阻止危险命令**：
```markdown
---
name: block-destructive
enabled: true
event: bash
pattern: rm\s+-rf|dd\s+if=|mkfs
action: block
---
🛑 破坏性操作已阻止！
```

**警告调试代码**：
```markdown
---
name: warn-debug
enabled: true
event: file
pattern: console\.log\(|debugger;
action: warn
---
🐛 检测到调试代码，提交前请移除。
```

### 管理规则

| 操作 | 方法 |
|------|------|
| 创建规则 | 新建 `.claude/hookify.*.local.md` |
| 禁用规则 | 设置 `enabled: false` |
| 删除规则 | 删除对应的 `.local.md` 文件 |
| 查看规则 | `ls .claude/hookify.*.local.md` |

---

## 演进记录

| 日期 | 更新内容 | 来源 |
|------|---------|------|
| 2026-01-17 | 添加 Hookify 轻量级规则模式 | 学习官方插件 |
| 2026-01-13 | 添加 Stop hook 专用 JSON 格式（decision 字段） | 实际调试发现 |
