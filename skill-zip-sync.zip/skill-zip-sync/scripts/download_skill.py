#!/usr/bin/env python3
"""
Skill 下载工具
从 GitHub 仓库下载指定的 skill ZIP 并解压到 skills 目录
"""

import os
import sys
import json
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import HTTPError

# 配置
SKILLS_DIR = Path.home() / ".claude" / "skills"
REPO_NAME = "kkunkunya/skill-zip"
RAW_BASE_URL = f"https://github.com/{REPO_NAME}/raw/main"


def fetch_index() -> dict:
    """获取远程 index.json"""
    url = f"{RAW_BASE_URL}/index.json"
    try:
        req = Request(url, headers={'User-Agent': 'skill-downloader/1.0'})
        with urlopen(req, timeout=30) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except HTTPError as e:
        if e.code == 404:
            print("错误: 仓库中未找到 index.json，请先运行 sync_skills.py")
        else:
            print(f"HTTP 错误: {e.code}")
        return None
    except Exception as e:
        print(f"获取索引失败: {e}")
        return None


def list_available_skills():
    """列出可用的 skills"""
    index = fetch_index()
    if not index:
        return 1

    skills = index.get('skills', [])
    if not skills:
        print("仓库中没有可用的 skills")
        return 0

    print(f"可用的 Skills ({len(skills)} 个):\n")
    print(f"{'名称':<30} {'大小':>10}  描述")
    print("-" * 80)

    for skill in skills:
        name = skill['name']
        size = f"{skill['size'] / 1024:.1f} KB"
        desc = skill.get('description', '-')[:40]
        if len(skill.get('description', '')) > 40:
            desc += '...'
        print(f"{name:<30} {size:>10}  {desc}")

    print(f"\n最后更新: {index.get('updated_at', 'unknown')}")
    return 0


def download_skill(skill_name: str, force: bool = False) -> int:
    """下载并安装指定的 skill"""
    # 检查本地是否已存在
    local_path = SKILLS_DIR / skill_name
    if local_path.exists() and not force:
        print(f"Skill '{skill_name}' 已存在于本地")
        print(f"使用 --force 覆盖安装")
        return 1

    # 获取索引验证 skill 存在
    index = fetch_index()
    if not index:
        return 1

    skill_info = None
    for s in index.get('skills', []):
        if s['name'] == skill_name:
            skill_info = s
            break

    if not skill_info:
        print(f"错误: 未找到 skill '{skill_name}'")
        print("使用 --list 查看可用的 skills")
        return 1

    # 下载 ZIP
    zip_url = f"{RAW_BASE_URL}/{skill_name}.zip"
    print(f"正在下载: {skill_name}.zip ({skill_info['size'] / 1024:.1f} KB)")

    try:
        req = Request(zip_url, headers={'User-Agent': 'skill-downloader/1.0'})
        with urlopen(req, timeout=60) as resp:
            zip_data = resp.read()
    except HTTPError as e:
        print(f"下载失败: HTTP {e.code}")
        return 1
    except Exception as e:
        print(f"下载失败: {e}")
        return 1

    # 解压到临时目录
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        zip_path = tmp_path / f"{skill_name}.zip"

        # 保存 ZIP
        with open(zip_path, 'wb') as f:
            f.write(zip_data)

        # 解压
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(tmp_path)

        # 移动到目标位置
        extracted_path = tmp_path / skill_name
        if not extracted_path.exists():
            print(f"错误: ZIP 结构异常，未找到 {skill_name} 目录")
            return 1

        # 如果目标存在且 force，先删除
        if local_path.exists():
            shutil.rmtree(local_path)

        # 移动
        shutil.move(str(extracted_path), str(local_path))

    print(f"✅ 成功安装: {skill_name}")
    print(f"   位置: {local_path}")
    return 0


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='Skill 下载工具')
    parser.add_argument('skill_name', nargs='?', help='要下载的 skill 名称')
    parser.add_argument('--list', '-l', action='store_true', help='列出可用的 skills')
    parser.add_argument('--force', '-f', action='store_true', help='强制覆盖已存在的 skill')
    args = parser.parse_args()

    if args.list or not args.skill_name:
        return list_available_skills()

    return download_skill(args.skill_name, args.force)


if __name__ == "__main__":
    sys.exit(main())
