#!/usr/bin/env python3
"""
Skill ZIP 同步工具
将 ~/.claude/skills/ 下的每个 skill 打包成 ZIP 并同步到 GitHub 仓库
"""

import os
import sys
import json
import shutil
import zipfile
import hashlib
import subprocess
from pathlib import Path
from datetime import datetime

# 配置
SKILLS_DIR = Path.home() / ".claude" / "skills"
REPO_NAME = "kkunkunya/skill-zip"
EXCLUDE_PATTERNS = [
    ".DS_Store",
    "__pycache__",
    "*.pyc",
    ".git",
    "node_modules",
    ".skill",  # 排除已打包的 .skill 文件
]


def should_exclude(path: Path) -> bool:
    """检查文件是否应该被排除"""
    name = path.name
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith("*"):
            if name.endswith(pattern[1:]):
                return True
        elif name == pattern:
            return True
    return False


def get_skill_dirs() -> list[Path]:
    """获取所有 skill 目录（包含 SKILL.md 的目录）"""
    skills = []
    if not SKILLS_DIR.exists():
        return skills

    for item in SKILLS_DIR.iterdir():
        if item.is_dir() and (item / "SKILL.md").exists():
            skills.append(item)

    return sorted(skills, key=lambda x: x.name)


def create_skill_zip(skill_dir: Path, output_dir: Path) -> Path:
    """将单个 skill 目录打包成 ZIP"""
    skill_name = skill_dir.name
    zip_path = output_dir / f"{skill_name}.zip"

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(skill_dir):
            # 过滤目录
            dirs[:] = [d for d in dirs if not should_exclude(Path(d))]

            for file in files:
                file_path = Path(root) / file
                if should_exclude(file_path):
                    continue

                # 计算相对路径（保留 skill 目录名）
                arcname = str(file_path.relative_to(skill_dir.parent))
                zf.write(file_path, arcname)

    return zip_path


def get_file_hash(file_path: Path) -> str:
    """计算文件 MD5 哈希"""
    md5 = hashlib.md5()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            md5.update(chunk)
    return md5.hexdigest()


def generate_index(skills_info: list[dict], output_dir: Path) -> Path:
    """生成 index.json 索引文件"""
    index = {
        "updated_at": datetime.now().isoformat(),
        "skills": skills_info
    }

    index_path = output_dir / "index.json"
    with open(index_path, 'w', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, indent=2)

    return index_path


def generate_readme(skills_info: list[dict], output_dir: Path) -> Path:
    """生成 README.md"""
    readme_content = """# Skill ZIP Repository

Claude Code Skills 压缩包仓库，每个 skill 独立打包，按需下载。

## 使用方法

### 方法1：直接下载
点击下方链接下载对应的 ZIP 文件，解压到 `~/.claude/skills/` 目录。

### 方法2：命令行下载
```bash
# 下载指定 skill
curl -L "https://github.com/kkunkunya/skill-zip/raw/main/<skill-name>.zip" -o <skill-name>.zip
unzip <skill-name>.zip -d ~/.claude/skills/
```

## 可用 Skills

| Skill | 描述 | 下载 |
|-------|------|------|
"""

    for skill in skills_info:
        name = skill['name']
        desc = skill.get('description', '-')[:60]
        if len(skill.get('description', '')) > 60:
            desc += '...'
        readme_content += f"| {name} | {desc} | [下载]({name}.zip) |\n"

    readme_content += f"\n---\n\n*最后更新: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n"

    readme_path = output_dir / "README.md"
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)

    return readme_path


def extract_skill_description(skill_dir: Path) -> str:
    """从 SKILL.md 提取 description"""
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return ""

    content = skill_md.read_text(encoding='utf-8')

    # 解析 YAML frontmatter
    if content.startswith('---'):
        parts = content.split('---', 2)
        if len(parts) >= 3:
            frontmatter = parts[1]
            for line in frontmatter.split('\n'):
                if line.strip().startswith('description:'):
                    desc = line.split(':', 1)[1].strip()
                    # 移除引号
                    if desc.startswith('"') and desc.endswith('"'):
                        desc = desc[1:-1]
                    elif desc.startswith("'") and desc.endswith("'"):
                        desc = desc[1:-1]
                    return desc

    return ""


def clone_or_update_repo(work_dir: Path) -> Path:
    """克隆或更新仓库"""
    repo_dir = work_dir / "skill-zip"

    if repo_dir.exists():
        # 重置并更新现有仓库
        subprocess.run(
            ["git", "fetch", "origin"],
            cwd=repo_dir,
            check=True,
            capture_output=True
        )
        subprocess.run(
            ["git", "reset", "--hard", "origin/main"],
            cwd=repo_dir,
            capture_output=True
        )
    else:
        # 克隆仓库
        subprocess.run(
            ["gh", "repo", "clone", REPO_NAME, str(repo_dir)],
            check=True,
            capture_output=True
        )

    return repo_dir


def sync_to_github(repo_dir: Path, message: str = None):
    """同步到 GitHub"""
    if message is None:
        message = f"Sync skills at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

    # 添加所有更改
    subprocess.run(["git", "add", "-A"], cwd=repo_dir, check=True)

    # 检查是否有更改
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=repo_dir,
        capture_output=True,
        text=True
    )

    if not result.stdout.strip():
        print("没有更改需要同步")
        return False

    # 提交
    subprocess.run(
        ["git", "commit", "-m", message],
        cwd=repo_dir,
        check=True
    )

    # 推送（使用 gh 以利用已认证的凭据）
    subprocess.run(
        ["gh", "repo", "sync", "--source", ".", "--force"],
        cwd=repo_dir,
        check=False  # gh repo sync 可能不支持，回退到 git push
    )

    # 尝试使用 git push with gh auth
    result = subprocess.run(
        ["git", "push", "--force", "origin", "main"],
        cwd=repo_dir,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        # 使用 gh 设置远程 URL 并重试
        subprocess.run(
            ["gh", "repo", "set-default", REPO_NAME],
            cwd=repo_dir,
            capture_output=True
        )
        subprocess.run(
            ["git", "remote", "set-url", "origin", f"https://github.com/{REPO_NAME}.git"],
            cwd=repo_dir,
            capture_output=True
        )
        # 使用 gh auth 配置 git
        subprocess.run(
            ["gh", "auth", "setup-git"],
            capture_output=True
        )
        subprocess.run(
            ["git", "push", "--force", "origin", "main"],
            cwd=repo_dir,
            check=True
        )

    return True


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(description='Skill ZIP 同步工具')
    parser.add_argument('--list', action='store_true', help='仅列出 skills，不同步')
    parser.add_argument('--dry-run', action='store_true', help='仅打包，不推送到 GitHub')
    parser.add_argument('--skill', type=str, help='仅同步指定的 skill')
    args = parser.parse_args()

    # 获取所有 skills
    skills = get_skill_dirs()

    if not skills:
        print("未找到任何 skill")
        return 1

    if args.list:
        print(f"找到 {len(skills)} 个 skills:\n")
        for skill in skills:
            desc = extract_skill_description(skill)
            print(f"  - {skill.name}")
            if desc and not desc.startswith('[TODO'):
                print(f"    {desc[:80]}...")
        return 0

    # 过滤指定 skill
    if args.skill:
        skills = [s for s in skills if s.name == args.skill]
        if not skills:
            print(f"未找到 skill: {args.skill}")
            return 1

    # 创建临时工作目录
    work_dir = Path("/tmp/skill-zip-sync")
    work_dir.mkdir(exist_ok=True)

    # 克隆/更新仓库
    print("正在同步仓库...")
    repo_dir = clone_or_update_repo(work_dir)

    # 清理旧的 ZIP 文件（如果是全量同步）
    if not args.skill:
        for old_zip in repo_dir.glob("*.zip"):
            old_zip.unlink()

    # 打包每个 skill
    skills_info = []
    print(f"\n正在打包 {len(skills)} 个 skills...")

    for skill in skills:
        print(f"  打包: {skill.name}")
        zip_path = create_skill_zip(skill, repo_dir)

        skills_info.append({
            "name": skill.name,
            "description": extract_skill_description(skill),
            "file": f"{skill.name}.zip",
            "size": zip_path.stat().st_size,
            "hash": get_file_hash(zip_path)
        })

    # 生成索引和 README
    print("\n生成索引文件...")
    generate_index(skills_info, repo_dir)
    generate_readme(skills_info, repo_dir)

    if args.dry_run:
        print(f"\n[Dry Run] ZIP 文件已生成到: {repo_dir}")
        return 0

    # 同步到 GitHub
    print("\n正在推送到 GitHub...")
    if sync_to_github(repo_dir):
        print(f"\n✅ 成功同步 {len(skills)} 个 skills 到 GitHub!")
        print(f"   仓库地址: https://github.com/{REPO_NAME}")
    else:
        print("\n没有更改需要同步")

    return 0


if __name__ == "__main__":
    sys.exit(main())
