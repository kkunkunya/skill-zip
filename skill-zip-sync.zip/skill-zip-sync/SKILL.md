---
name: skill-zip-sync
description: "将 ~/.claude/skills/ 下的所有 skill 打包成独立 ZIP 并同步到 GitHub 仓库，支持按需下载。触发词：同步 skill、skill 打包、上传 skill、下载 skill、skill-zip、技能同步、技能仓库。"
---

# Skill ZIP 同步

将本地 skills 打包成 ZIP 并同步到 GitHub 仓库 `kkunkunya/skill-zip`，实现 skill 的集中管理和按需下载。

## 快速开始

### 同步所有 skills 到 GitHub

```bash
python3 ~/.claude/skills/skill-zip-sync/scripts/sync_skills.py
```

### 列出可下载的 skills

```bash
python3 ~/.claude/skills/skill-zip-sync/scripts/download_skill.py --list
```

### 下载指定 skill

```bash
python3 ~/.claude/skills/skill-zip-sync/scripts/download_skill.py <skill-name>
```

## 命令详解

### sync_skills.py - 同步工具

| 参数 | 说明 |
|------|------|
| `--list` | 仅列出本地 skills，不同步 |
| `--dry-run` | 仅打包到本地，不推送 GitHub |
| `--skill <name>` | 仅同步指定的 skill |

**示例**：
```bash
# 查看本地有哪些 skills
python3 ~/.claude/skills/skill-zip-sync/scripts/sync_skills.py --list

# 仅同步 document-suite
python3 ~/.claude/skills/skill-zip-sync/scripts/sync_skills.py --skill document-suite

# 测试打包（不推送）
python3 ~/.claude/skills/skill-zip-sync/scripts/sync_skills.py --dry-run
```

### download_skill.py - 下载工具

| 参数 | 说明 |
|------|------|
| `--list, -l` | 列出远程仓库中可用的 skills |
| `--force, -f` | 强制覆盖已存在的 skill |

**示例**：
```bash
# 下载 ui-ux-pro-max
python3 ~/.claude/skills/skill-zip-sync/scripts/download_skill.py ui-ux-pro-max

# 强制更新已有的 skill
python3 ~/.claude/skills/skill-zip-sync/scripts/download_skill.py ui-ux-pro-max --force
```

## 仓库结构

同步后 GitHub 仓库结构：
```
skill-zip/
├── README.md           # 自动生成的说明文档
├── index.json          # skills 索引（名称、描述、大小、哈希）
├── skill-a.zip         # 各 skill 的独立压缩包
├── skill-b.zip
└── ...
```

## 排除规则

打包时自动排除：
- `.DS_Store`
- `__pycache__/`
- `*.pyc`
- `.git/`
- `node_modules/`
- `.skill` 文件
