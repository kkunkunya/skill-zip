# Type: split-compare（公式B）

> 分屏对比展示过程/结果 + 时间标签

## 构图规则

- **左右分屏**：画面垂直分为两半，中间可有分割线或渐变过渡
- **左侧**：起始状态（混乱/旧版/问题/开始时间）
- **右侧**：结束状态（整齐/新版/解决/结束时间）
- **时间标签**：顶部或底部放置时间/状态标签（如 "9:00am → 8:45pm"）

## 必须包含的元素

- **对比画面**：左右两侧内容形成明确反差
- **标签式挂件**：色块背景的文字标签（蓝底白字、黄底黑字），模拟 UI 元素
- **箭头/过渡**：中间用箭头、渐变或分割线连接两侧
- **可选人物**：人物可出现在一侧或两侧（基于 `--ref` 照片）

## 分屏内容类型

| 对比维度 | 左侧 | 右侧 |
|---------|------|------|
| 时间 | 9:00am / Before | 8:45pm / After |
| 质量 | 代码混乱 / 旧 UI | 代码整洁 / 新 UI |
| 效率 | 手动操作 | AI 自动化 |
| 成长 | 新手状态 | 进阶状态 |

## 光影与调性

- **两侧可用不同色调**：左侧偏冷/灰暗（问题感），右侧偏暖/明亮（解决感）
- **或统一暖色调**：两侧同色系，靠内容本身形成对比
- **高饱和度可选**：盘点/测评类内容可用高饱和对比色（黑/黄、蓝/橙）

## Prompt 模板片段

```
COMPOSITION: Vertical split-screen layout.
LEFT HALF: [before state] — [description of starting condition].
RIGHT HALF: [after state] — [description of ending condition].
CENTER: [arrow/gradient/divider line] connecting both sides.

LABELS: Tag-style badges at [top/bottom]:
- Left tag: "[start label]" on [blue/gray] background, white text
- Right tag: "[end label]" on [yellow/green] background, black text

OPTIONAL PERSON: [If ref photo provided] Person appears on [left/right/both] side(s).

COLOR TONE: Left side slightly desaturated/cool, right side warm/vibrant.
OR: Unified warm tone with content-driven contrast.

TEXT: Minimal — labels and tags only, no long sentences.
Bold sans-serif font for tags. High readability on mobile.
```

## 适用场景

| 内容类型 | 示例 |
|---------|------|
| 教程/流程 | "从零到上线的一天" |
| 工具对比 | "手动 vs AI 自动化" |
| 成长记录 | "3个月前 vs 现在" |
| 复盘 | "重构前后的代码" |
