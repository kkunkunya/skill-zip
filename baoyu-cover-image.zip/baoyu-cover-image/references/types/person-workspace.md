# Type: person-workspace（公式C）

> 人坐在电脑前 + 悬浮 AI 工具 Logo + 表情

## 构图规则

- **人物区域**：人物坐在工作台前，占画面 40-50%，偏左或居中
- **屏幕区域**：电脑屏幕可见（代码/工具界面），占 20-30%
- **悬浮元素**：AI 工具/技术 Logo 悬浮在画面中（如气泡/光晕效果），占 20-30%
- **图层堆叠**：前景（人物抠图）→ 中景（大标题文字，可穿插人物身后）→ 背景（工作环境）

## 必须包含的元素

- **真人坐姿照**：基于 `--ref` 提供的照片，人物坐在电脑前
- **悬浮 Logo 阵列**：相关技术/工具的 Logo（如 Claude, OpenAI, Swift, Python）
- **表情**：惊讶/思考/专注，暗示"发现了什么"
- **屏幕内容**：电脑屏幕上显示代码/工具界面（可模糊但要可辨识）

## 悬浮元素设计

- Logo 以圆形气泡或光晕包裹，半透明
- 大小不一，形成层次感（主工具大，辅助工具小）
- 分布在人物周围，不遮挡面部
- 可加微光/发光效果，增加科技感

## 光影与调性

### 暖色 Premium 风格（默认）
- 暖色调，自然光从侧面打入
- 背景真实工作环境微虚化
- 胶片感色调，高级不廉价

### 高饱和网感风格（可选）
- 满版填充，视觉元素填充率 80-90%
- 杂志拼贴手法：人物抠图 + 巨大标题穿插 + 环境背景
- 网感贴纸元素（像素墨镜、表情包、流汗黄豆）消解严肃感
- 高饱和对比色：黑/黄、蓝/橙、红/绿

## Prompt 模板片段

```
COMPOSITION: Person seated at desk with computer, occupying [left/center] 40-50%.
Computer screen visible showing [code/tool interface], slightly angled.
Floating tech logos around person: [Logo1, Logo2, Logo3] in translucent bubble/glow style.
Logos vary in size (main tool larger), distributed around person without covering face.

BACKGROUND: Real workspace — desk, monitor, keyboard, [bookshelf/plants].
Slightly blurred, warm natural lighting from side.

PERSON: Based on reference photo. Expression: [surprised/thinking/focused].
Conveying "I just discovered something interesting" vibe.

FLOATING ELEMENTS: [Tool logos] in circular bubbles with soft glow effect.
Semi-transparent, layered at different depths for parallax feel.
Main tool logo: 1.5x size of others, positioned near person's head level.

TEXT: "[headline]" in bold display font.
[Optional: text layered behind person for depth effect — collage style]

STYLE VARIANT: [warm-premium / high-saturation-collage]
```

## 适用场景

| 内容类型 | 示例 |
|---------|------|
| 工具测评 | "Claude Code 太强了" |
| AI 工作流 | "我的 AI 编程工作流" |
| 技术探索 | "试了6个 Coding Agent" |
| 效率分享 | "这套工具让我效率翻倍" |
