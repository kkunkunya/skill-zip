# Type: person-device（公式A）

> 半身人像 + 手持设备展示成品 + 巨大数字/文案

## 构图规则

- **人物区域**：占画面左侧或右侧 1/3 ~ 1/2，半身（胸部以上）
- **设备区域**：人物手持手机/平板，屏幕朝向观众，展示 App 界面或成果
- **文案区域**：剩余空间放置巨大数字或核心文案（3-5 词）
- **视觉引导**：人物视线或手势指向设备/文案，引导观众注意力

## 必须包含的元素

- **真人半身照**：基于 `--ref` 提供的人像照片生成
- **手持设备**：手机/平板/笔记本，屏幕内容清晰可见
- **大字文案**：数字字号极大（占文案区 60%+），如 `10x`、`$1,500/mo`、`1 Week`
- **高亮强调**：重点词用底色高亮（明黄色或亮绿色"记号笔"风格）

## 光影与调性

- **暖色调为主**：Warm/Cozy，胶片感或电影感
- **背景**：真实 Workspace 微虚化（书架、绿植、键盘），保留生活气息
- **避免**：过度锐化、高饱和度的"廉价感"、纯色/虚拟背景

## 表情管理

- 不需要夸张的"油管脸"（张大嘴）
- 眼神自信、专注，或带一点"展示成果"的小得意
- 人设：实干家，不是说教者

## Prompt 模板片段

```
COMPOSITION: Half-body portrait on [left/right] 1/3 of frame.
Person holding [device] with screen facing viewer, showing [app/result].
Remaining space: giant text "[headline]" with [yellow/green] highlight on key word.
Person's gaze directed toward [device/text] to guide viewer attention.

BACKGROUND: Slightly blurred real workspace — [bookshelf/plants/keyboard/monitor].
Warm, cozy lighting. Film-grain texture. Premium feel, NOT over-sharpened.

PERSON: Based on reference photo. Confident expression, slight pride.
NOT exaggerated YouTube face. Natural, authentic vibe.

TEXT: "[number/headline]" in bold sans-serif, occupying 60%+ of text area.
Key word highlighted with [yellow] marker-style background.
Maximum 3-5 words total.
```

## 适用场景

| 内容类型 | 示例 |
|---------|------|
| 成果展示 | "我的 App 月入 $1,500" |
| 效率提升 | "这个工具让我效率提升 10x" |
| 项目发布 | "一周做完的 App" |
| 工具推荐 | "这个 AI 工具太强了" |
