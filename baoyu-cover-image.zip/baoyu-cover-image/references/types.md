# Type Composition Guidelines

## Type Gallery

| Type | Description | Best For |
|------|-------------|----------|
| `hero` | Large visual impact, title overlay | Product launch, brand promotion, major announcements |
| `conceptual` | Concept visualization, abstract core ideas | Technical articles, methodology, architecture design |
| `typography` | Text-focused layout, prominent title | Opinion pieces, quotes, insights |
| `metaphor` | Visual metaphor, concrete expressing abstract | Philosophy, growth, personal development |
| `scene` | Atmospheric scene, narrative feel | Stories, travel, lifestyle |
| `minimal` | Minimalist composition, generous whitespace | Zen, focus, core concepts |
| `person-device` | Real person holding device showing results + giant numbers | Product launch, income reveal, app showcase |
| `split-compare` | Split-screen before/after comparison + time labels | Tutorials, tool comparison, growth records |
| `person-workspace` | Person at desk + floating tech logos + expression | Tool reviews, AI workflows, tech exploration |

## Type-Specific Composition

| Type | Composition Guidelines |
|------|------------------------|
| `hero` | Large focal visual (60-70% area), title overlay on visual, dramatic composition |
| `conceptual` | Abstract shapes representing core concepts, information hierarchy, clean zones |
| `typography` | Title as primary element (40%+ area), minimal supporting visuals, strong hierarchy |
| `metaphor` | Concrete object/scene representing abstract idea, symbolic elements, emotional resonance |
| `scene` | Atmospheric environment, narrative elements, mood-setting lighting and colors |
| `minimal` | Single focal element, generous whitespace (60%+), essential shapes only |
| `person-device` | Person on left/right 1/3, holding device with screen visible, giant text in remaining space. Warm film-grain lighting, real workspace background. Details: [types/person-device.md](types/person-device.md) |
| `split-compare` | Vertical split layout, left=before right=after, tag-style labels, arrow/divider in center. Optional person on one/both sides. Details: [types/split-compare.md](types/split-compare.md) |
| `person-workspace` | Person at desk 40-50%, computer screen visible, floating tech logos in bubble/glow style around person. Collage layering optional. Details: [types/person-workspace.md](types/person-workspace.md) |
