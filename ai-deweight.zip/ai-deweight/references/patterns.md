# AI 写作模式检测目录

> **使用说明**：诊断阶段按此目录扫描全文，逐条检测并记录命中模式。每条模式包含 ID、严重度、触发词、AI 特征说明、修改示例和学术例外。标记 `[已覆盖]` 表示 prompts.md 中已有对应规则；标记 `[新增]` 表示本次融合补充。

---

## 一、内容模式 (Content Patterns) C1-C6

### C1 夸大象征 (Inflated Significance)
- **严重度**：高
- **触发词**：标志着、象征着、体现了、代表着、彰显了、signifies、symbolizes、represents a milestone、embodies
- **AI 特征**：AI 习惯将普通事件/成果包装为里程碑式的重大意义，缺乏具体证据支撑
- **示例**：
  - ❌ 该系统的部署**标志着**智能交通领域的重大突破
  - ✅ 该系统部署后，路口通行效率提升 18%
- **覆盖状态**：[新增]
- **学术例外**：结论段可适度使用，但须有前文数据支撑

### C2 夸大知名度 (Inflated Notability)
- **严重度**：中
- **触发词**：引起广泛关注、备受瞩目、广受认可、widely recognized、garnered significant attention、acclaimed
- **AI 特征**：无引用地宣称某事物"广受关注"，属于无根据的权威性宣称
- **示例**：
  - ❌ 该方法**引起了学术界的广泛关注**
  - ✅ 该方法被 12 篇后续研究引用（截至 2024 年）
- **覆盖状态**：[新增]
- **学术例外**：有引用数据支撑时可保留

### C3 浅层分析 (Superficial Analysis)
- **严重度**：高
- **触发词**：展示了、突出了、揭示了、凸显了、demonstrates、highlights、reveals、showcases、underscores
- **AI 特征**：用模糊的分析动词代替具体数据或直接陈述，给人"分析了但什么都没说"的感觉
- **示例**：
  - ❌ 实验结果**展示了**该模型的优越性能
  - ✅ 该模型在 BLEU 指标上达到 34.2，超过基线 3.1 个百分点
- **覆盖状态**：[新增]
- **学术例外**：概述性段落可适度使用，但后续需有具体数据

### C4 宣传语言 (Promotional Language)
- **严重度**：高
- **触发词**：革命性的、开创性的、前所未有的、卓越的、revolutionary、groundbreaking、unprecedented、cutting-edge、state-of-the-art
- **AI 特征**：使用营销式形容词夸大学术贡献
- **示例**：
  - ❌ 本文提出了一种**革命性的**算法
  - ✅ 本文提出了一种改进的算法，在 X 任务上提升了 Y%
- **覆盖状态**：[已覆盖] — prompts.md 已禁止修辞性语言
- **学术例外**：无

### C5 模糊归因 (Vague Attribution)
- **严重度**：中
- **触发词**：有研究表明、研究发现、据报道、有学者认为、studies have shown、research suggests、it has been found
- **AI 特征**：用模糊的集体归因代替具体引用，降低可追溯性
- **示例**：
  - ❌ **有研究表明**深度学习在此领域效果显著
  - ✅ Li et al. (2023) 在 ImageNet 上验证了该方法的有效性
- **覆盖状态**：[新增]（部分场景 prompts.md 已处理引用格式）
- **学术例外**：综述段引用多篇文献时可使用，但应附引用编号

### C6 公式化挑战展望 (Formulaic Challenge-Prospect)
- **严重度**：中
- **触发词**：尽管面临挑战但前景光明、虽然存在不足但未来可期、challenges remain yet prospects are promising、despite limitations the future is bright
- **AI 特征**：用"挑战+乐观"的固定公式结尾，回避具体限制和后续步骤
- **示例**：
  - ❌ 尽管面临诸多挑战，但该技术的前景依然光明
  - ✅ 主要限制在于训练数据不足（<1000 样本），后续将探索数据增强策略
- **覆盖状态**：[新增]
- **学术例外**：无

---

## 二、语言模式 (Language Patterns) L1-L6

### L1 AI 词汇 (AI Vocabulary)
- **严重度**：致命
- **触发词**：
  - 中文：此外、至关重要、深入探讨、格局、关键性的、全面的、多维度的、赋能、深度赋能、助力
  - 英文：Furthermore、Delve into、Landscape、Facilitate、Illuminate、Leverage、Robust、Nuanced、Meticulous、Tapestry、Embody、Underscore、Paramount、Foster、Navigate、Comprehensive、Intricate、Pivotal、Showcase、Streamline
- **AI 特征**：AI 过度使用特定"高级"词汇，频率远超人类写作
- **示例**：
  - ❌ This **nuanced** approach **leverages** a **robust** framework to **navigate** the **landscape**
  - ✅ This approach uses a tested framework to address the problem
- **覆盖状态**：[已覆盖] — prompts.md 协议 B 已禁用华丽词汇
- **学术例外**：领域内约定俗成的术语除外（如 robust optimization 是正式术语）

### L2 系词回避 (Copula Avoidance)
- **严重度**：中
- **触发词**：serves as、represents、functions as、acts as、stands as、constitutes
- **AI 特征**：AI 回避简单的 is/are，转而使用冗长的替代表达
- **示例**：
  - ❌ This module **serves as** the core component
  - ✅ This module **is** the core component
- **覆盖状态**：[新增]
- **学术例外**：当语义确实需要区分"作为...的角色"时可保留

### L3 否定并列 (Negation Juxtaposition)
- **严重度**：中
- **触发词**：不仅...而且/还、不但...而且、not only...but also、both...and
- **AI 特征**：AI 过度使用"不仅...而且"这种并列结构，频率远超人类写作
- **示例**：
  - ❌ 该方法**不仅**提高了精度，**而且**降低了计算成本
  - ✅ 该方法提高了精度（+3.2%），同时计算成本下降 15%
- **覆盖状态**：[新增]
- **学术例外**：偶尔使用一次可接受，但全文不应超过 2 处

### L4 三连规则 (Rule of Three)
- **严重度**：高
- **触发词**：三项并列结构（A、B和C / A, B, and C）
- **AI 特征**：AI 极度偏好三项并列列举，形成机械节奏感
- **示例**：
  - ❌ 该系统具有**高效性、可扩展性和可靠性**
  - ✅ 该系统在效率和可扩展性方面表现优异（可靠性测试见第 5 节）
- **覆盖状态**：[新增]
- **学术例外**：确实恰好三项时可保留，但应检查是否人为凑数

### L5 同义词循环 (Synonym Cycling)
- **严重度**：中
- **触发词**：同一概念在相邻段落中使用不同词汇（如：方法→途径→策略→手段）
- **AI 特征**：AI 为避免重复，过度使用同义词替换，反而显得刻意
- **示例**：
  - ❌ 第一段"方法"→第二段"途径"→第三段"策略"→第四段"手段"
  - ✅ 全文统一使用"方法"，仅在语义确需区分时换词
- **覆盖状态**：[已覆盖] — prompts.md 要求系统性词汇替换保持一致
- **学术例外**：领域内有明确区分的近义术语除外

### L6 虚假范围 (False Scope)
- **严重度**：中
- **触发词**：从...到...、ranging from...to...、spanning from...to...
- **AI 特征**：用"从 A 到 B"暗示广泛覆盖，但 A 和 B 之间缺乏真实关联
- **示例**：
  - ❌ 该技术可应用于**从**医疗诊断**到**自动驾驶的广泛场景
  - ✅ 该技术已在医疗诊断（肺部 CT）和自动驾驶（车道检测）中验证
- **覆盖状态**：[新增]
- **学术例外**：有具体证据支撑范围时可保留

---

## 三、风格模式 (Style Patterns) S1-S6

### S1 破折号滥用 (Dash Abuse)
- **严重度**：高
- **触发词**：—、──、--（用于解释性插入、戏剧性停顿）
- **AI 特征**：AI 过度使用破折号进行插入说明或制造节奏变化
- **示例**：
  - ❌ 该框架 —— 经过三年开发 —— 终于发布了
  - ✅ 经过三年开发，该框架终于发布了
- **覆盖状态**：[已覆盖] — prompts.md 已禁止破折号
- **学术例外**：学术写作中极少需要破折号

### S2 加粗滥用 (Bold Abuse)
- **严重度**：中
- **触发词**：**加粗文本** 出现频率 > 每段 1 处
- **AI 特征**：AI 过度加粗关键词，干扰阅读节奏
- **示例**：
  - ❌ 本研究的**主要贡献**在于提出了**创新性**的**深度学习**方法
  - ✅ 本研究的主要贡献在于提出了创新性的深度学习方法
- **覆盖状态**：[新增]
- **学术例外**：术语首次出现可加粗定义

### S3 行内列表 (Inline Lists)
- **严重度**：低
- **触发词**：行内编号列表（1) ... 2) ... 3) ...）出现在段落中间
- **AI 特征**：AI 习惯在段落中嵌入编号列表，破坏段落连贯性
- **示例**：
  - ❌ 该方法有三个优势：1) 速度快 2) 精度高 3) 易部署
  - ✅ 该方法在速度、精度和部署便捷性方面具有优势
- **覆盖状态**：[新增]
- **学术例外**：方法论描述中的步骤编号可保留

### S4 标题大写 (Title Capitalization)
- **严重度**：低
- **触发词**：英文标题全词首字母大写（Title Case）
- **AI 特征**：AI 默认使用 Title Case，而许多期刊要求 Sentence case
- **示例**：
  - ❌ A Novel Approach To Deep Learning Based Image Classification
  - ✅ A novel approach to deep learning based image classification
- **覆盖状态**：[新增]
- **学术例外**：按目标期刊格式要求，部分期刊确实要求 Title Case

### S5 Emoji 使用 (Emoji Usage)
- **严重度**：致命
- **触发词**：任何 emoji 符号（🔍📊✅❌等）
- **AI 特征**：AI 在非聊天场景中插入 emoji，在学术文本中完全不可接受
- **示例**：
  - ❌ 实验结果表明 ✅ 该方法有效
  - ✅ 实验结果表明该方法有效
- **覆盖状态**：[新增]
- **学术例外**：无

### S6 弯引号 (Smart Quotes)
- **严重度**：低
- **触发词**：" " ' '（弯引号/智能引号）
- **AI 特征**：AI 默认输出弯引号，与学术写作和代码环境中的直引号不一致
- **示例**：
  - ❌ 所谓\u201c深度学习\u201d
  - ✅ 所谓"深度学习"
- **覆盖状态**：[新增]
- **学术例外**：按目标期刊格式要求

---

## 四、填充模式 (Filler Patterns) F1-F6

### F1 协作痕迹 (Collaboration Artifacts)
- **严重度**：致命
- **触发词**：当然可以、好的我来、以下是、让我帮你、Sure, here is、I'd be happy to、Certainly、As requested
- **AI 特征**：AI 对话模式的开头语泄漏到输出文本中
- **示例**：
  - ❌ **当然可以。**以下是关于深度学习的综述...
  - ✅ 深度学习近年来在多个领域取得显著进展...
- **覆盖状态**：[新增]
- **学术例外**：无

### F2 知识截止 (Knowledge Cutoff)
- **严重度**：致命
- **触发词**：截至我的训练数据、as of my knowledge cutoff、as of my last update、I don't have access to real-time
- **AI 特征**：AI 暴露自身知识截止限制
- **示例**：
  - ❌ **截至 2024 年**，该领域的最新进展...
  - ✅ 该领域的最新进展包括 X (2023)、Y (2024)
- **覆盖状态**：[新增]
- **学术例外**：无

### F3 卑躬屈膝 (Sycophantic Tone)
- **严重度**：高
- **触发词**：非常好的问题、这是一个很好的观点、Great question、That's an excellent point、What a thoughtful observation
- **AI 特征**：AI 对话模式中的讨好性回复
- **示例**：
  - ❌ **这是一个很好的研究方向。**本文聚焦于...
  - ✅ 本文聚焦于...
- **覆盖状态**：[新增]
- **学术例外**：无

### F4 填充短语 (Filler Phrases)
- **严重度**：中
- **触发词**：值得注意的是、需要指出的是、众所周知、不言而喻、It is worth noting that、It should be pointed out that、It goes without saying、Needless to say
- **AI 特征**：用填充短语凑字数，不提供新信息
- **示例**：
  - ❌ **值得注意的是**，该方法在小样本场景下表现出色
  - ✅ 该方法在小样本场景下表现出色（50-shot 准确率 89%）
- **覆盖状态**：[已覆盖] — prompts.md 已要求删除冗余修饰
- **学术例外**：偶尔用于段落过渡可接受

### F5 过度限定 (Over-Qualification)
- **严重度**：中
- **触发词**：然而需要注意的是、但值得一提的是、不过有趣的是、However it is important to note、It is crucial to understand、One must bear in mind
- **AI 特征**：过度添加限定和警告，显得缺乏自信
- **示例**：
  - ❌ 该方法有效。**然而需要注意的是**，数据集规模可能影响结果
  - ✅ 该方法有效，但受限于数据集规模（详见 4.3 节讨论）
- **覆盖状态**：[新增]
- **学术例外**：方法论局限性讨论中可适度使用

### F6 万能结论 (Universal Conclusion)
- **严重度**：高
- **触发词**：总而言之、综上所述、总的来说、In conclusion、To summarize、In summary、All in all、Overall
- **AI 特征**：AI 机械地添加总结性开头，且结论通常只是重复前文
- **示例**：
  - ❌ **总而言之**，本文提出的方法在效率和精度方面均有提升
  - ✅ 本文方法将推理速度提升 2.3 倍，BLEU 提升 1.8，代码已开源
- **覆盖状态**：[新增]
- **学术例外**：论文结论章可使用一次，但内容须有增量信息

---

## 附录 A：中文 AI 词汇监控清单

以下词汇在 AI 生成文本中出现频率显著高于人类写作。诊断时统计出现次数，超过阈值即标记。

| 类别 | 监控词汇 | 阈值（每千字） |
|------|---------|---------------|
| 连接词 | 此外、而且、另外、与此同时、不仅如此 | ≤1 |
| 程度词 | 至关重要、极其重要、非常关键、尤为突出 | ≤0.5 |
| 分析词 | 深入探讨、全面分析、系统性研究、多维度考量 | ≤0.5 |
| 评价词 | 卓越的、显著的、突出的、优异的 | ≤1 |
| 趋势词 | 格局、赋能、助力、引领、驱动 | ≤0.5 |
| 结构词 | 框架、体系、范式、生态 | ≤1 |
| 动作词 | 探索、践行、赋能、洞察、聚焦 | ≤1 |

## 附录 B：英文 AI 词汇监控清单

| 类别 | 监控词汇 | 阈值（每千词） |
|------|---------|---------------|
| 高频致命 | Delve, Landscape, Tapestry, Embody, Illuminate, Underscore | ≤0 |
| 高频危险 | Furthermore, Leverage, Robust, Nuanced, Meticulous, Paramount | ≤0.5 |
| 中频可疑 | Foster, Navigate, Comprehensive, Intricate, Pivotal, Showcase, Streamline, Facilitate | ≤1 |
| 连接词堆砌 | Moreover, Additionally, Consequently, Nevertheless, Nonetheless | ≤1 |
| 形容词堆砌 | Multifaceted, Noteworthy, Remarkable, Substantial, Innovative | ≤1 |
