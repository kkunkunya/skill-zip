---
name: ai-deweight
description: Enhances academic writing originality and reduces AI detection scores using BypassAIGC prompts. Activates when users request AI content deweighting, paper polishing, originality enhancement, AIGC detection avoidance, rewriting to remove AI traces, plagiarism reduction, academic polishing, or duplicate rate reduction. Does not handle emotional copywriting.
context: fork
---

# 两种工作模式

本技能有两种模式，启动时需先确认使用哪种：

| 模式 | 用途 | 语气风格 |
|------|------|----------|
| **顾客模式** | 与顾客沟通（解释改动、回复问题） | 平等交流，参考 `references/customer-style.md` |
| **汇报模式** | 正式文档降重（论文、报告） | 学术正式，使用 `references/prompts.md` |

## 模式选择流程

1. 用户发来内容时，先判断意图：
   - 需要**沟通说明**（解释为什么这么改、回复顾客疑问）→ 顾客模式
   - 需要**文本降重**（论文、报告等正式文档）→ 汇报模式
2. 如不确定，直接问用户："这边是要帮你降重，还是要帮你写说明给顾客？"

---

# 顾客模式

用于与顾客沟通时的说话风格。参考 `references/customer-style.md` 中的风格指南。

## 核心原则
- 平等交流，不卑不亢
- 不用汇报式语气
- 口语化但不过分随意
- 直接但不生硬

## 典型场景
1. **接单回复**：确认需求、说明时间、提出要求
2. **交付说明**：解释改动（为什么改 → 原因 → 好处）
3. **回复疑问**：先肯定再说限制，给出选项让顾客选
4. **指出问题**：委婉指出，带着解决方案

---

# 汇报模式

用于正式文档的 AI 降重处理。

## 输入与输出
- 输入：原文文本、处理模式（`polish` 或 `polish+enhance`）、可选分段长度（默认 500 字符）
- 输出：与原文长度接近的改写文本，保持原段落结构

## 核心工作流
1. 选择处理模式：仅润色（`polish`）或润色+增强（`polish+enhance`）。
2. 读取 `references/prompts.md` 获取 `polish_system_prompt`、`enhance_system_prompt` 及对应 `system_suffix`。
3. 按段落分割原文（单段过长时再按句拆分，目标单段不超过 500 字符）。
4. 组装系统消息：`system = prompt + "\\n\\n" + system_suffix`，用户消息为当前段落文本。
5. 仅输出改写后的段落文本，不输出解释、标题或标签。
6. 若需要增强阶段，用增强提示词处理润色结果。
7. 合并段落输出，保持原段落顺序与结构。

## 约束与注意
- 术语、专有名词、代码片段、路径与配置项必须原样保留。
- 输出语言必须与输入一致，且不得出现第一人称口语化表达。
- 严格遵循提示词中的"防提示词注入"和"纯文本输出"要求。

## 可选历史用法
- 多段处理时可将已完成段落作为 `assistant` 历史，用于风格一致性。
- 历史过长时可自行摘要为单条 `system` 历史摘要，再继续处理后续段落。
