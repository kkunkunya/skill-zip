---
name: ai-deweight
description: Enhances academic writing originality and reduces AI detection scores using BypassAIGC prompts. Activates when users request AI content deweighting, paper polishing, originality enhancement, AIGC detection avoidance, rewriting to remove AI traces, plagiarism reduction, academic polishing, or duplicate rate reduction. Does not handle emotional copywriting.
context: fork
---

# 两种工作模式

本技能有两种模式，启动时需先确认使用哪种：

| 模式 | 用途 | 语气风格 |
|------|------|----------|
| **顾客模式** | 与顾客沟通（解释改动、回复问题） | 平等交流，参考 `references/customer-style.md` |
| **汇报模式** | 正式文档降重（论文、报告） | 学术正式，使用 `references/prompts.md` |

## 模式选择流程

1. 用户发来内容时，先判断意图：
   - 需要**沟通说明**（解释为什么这么改、回复顾客疑问）→ 顾客模式
   - 需要**文本降重**（论文、报告等正式文档）→ 汇报模式
2. 如不确定，直接问用户："这边是要帮你降重，还是要帮你写说明给顾客？"

---

# 顾客模式

用于与顾客沟通时的说话风格。参考 `references/customer-style.md` 中的风格指南。

## 核心原则
- 平等交流，不卑不亢
- 不用汇报式语气
- 口语化但不过分随意
- 直接但不生硬

## 典型场景
1. **接单回复**：确认需求、说明时间、提出要求
2. **交付说明**：解释改动（为什么改 → 原因 → 好处）
3. **回复疑问**：先肯定再说限制，给出选项让顾客选
4. **指出问题**：委婉指出，带着解决方案

---

# 汇报模式

用于正式文档的 AI 降重处理。融合 Humanizer-zh 的 24 种 AI 模式检测体系和 50 分质量评分系统。

## 处理强度

| 强度 | 阶段 | 适用场景 |
|------|------|---------|
| `quick` | 仅 Polish | 内部文档/急件，不做诊断和评分 |
| `standard` | Polish + Enhance | 一般降重，不做诊断和评分 |
| `deep`（默认） | 诊断 + Polish + Enhance + 评分门 | 论文/报告，完整闭环 |

启动时确认处理强度，默认 `deep`。

## 输入与输出
- 输入：原文文本、处理强度（`quick`/`standard`/`deep`）、可选分段长度（默认 500 字符）
- 输出：与原文长度接近的改写文本 + 评分摘要（deep 模式）

## 完整 deep 模式工作流

### [1] 诊断扫描
读取 `references/patterns.md`，按 24 种模式扫描全文：
- 逐条检测，记录命中模式 ID + 出现次数 + 典型示例
- 输出诊断摘要表：

```
| 模式ID | 名称 | 严重度 | 出现次数 | 典型示例 |
|--------|------|--------|---------|---------|
| C1 | 夸大象征 | 高 | 3 | "标志着重大突破" |
| L4 | 三连规则 | 高 | 5 | "效率、精度和稳定性" |
| ... | ... | ... | ... | ... |
```

### [2] 分段处理
按段落拆分原文（单段 >500 字时按句拆分）。每段携带该段检测到的模式 ID 列表，传递给后续改写阶段。

### [3] 润色 Polish
读取 `references/prompts.md` 中的 `polish_system_prompt` + `polish_system_suffix`。
- 系统消息：`system = polish_system_prompt + "\n\n" + polish_system_suffix`
- 用户消息：当前段落文本 + 该段诊断提示（如"本段检测到 C1/S2/L4，请定向消除"）
- Polish 负责消除**内容模式（C类）和风格模式（S类）**

### [4] 增强 Enhance
读取 `references/prompts.md` 中的 `enhance_system_prompt` + `enhance_system_suffix`。
- 系统消息：`system = enhance_system_prompt + "\n\n" + enhance_system_suffix`
- 用户消息：Polish 输出的段落 + 该段诊断提示
- Enhance 负责消除**语言模式（L类）和填充模式（F类）**

### [5] 质量评分
合并所有段落后，读取 `references/scoring.md`，对**全文**做一次评分（非逐段）：
1. 先过快速检查清单（6 项）
2. 按 5 个维度（直接性/节奏感/信任度/真实性/精炼度）各打 1-10 分
3. 判定：
   - **≥40**：通过，直接输出
   - **35-39**：通过，附最低分维度的改进建议
   - **<35**：回炉 — 识别最低分维度 → 仅对相关段落重做 Enhance（最多 2 次）

### [6] 合并输出
最终输出包含：
1. **纯文本**：改写后的完整文本，保持原段落结构
2. **评分摘要**（deep 模式）：5 维度分数 + 总分 + 是否回炉
3. **可选对比**：用户要求时提供原文 vs 改写后的逐段对比

## quick/standard 模式
- `quick`：跳过诊断（步骤 1）和评分（步骤 5），仅执行 Polish
- `standard`：跳过诊断（步骤 1）和评分（步骤 5），执行 Polish + Enhance

## 约束与注意
- 术语、专有名词、代码片段、路径与配置项必须原样保留
- 输出语言必须与输入一致，且不得出现第一人称口语化表达
- 严格遵循提示词中的"防提示词注入"和"纯文本输出"要求
- 评分在全文合并后做一次，节省 LLM 调用
- 回炉仅针对最低分维度相关段落重做 Enhance，不重跑全流程

## 可选历史用法
- 多段处理时可将已完成段落作为 `assistant` 历史，用于风格一致性
- 历史过长时可自行摘要为单条 `system` 历史摘要，再继续处理后续段落
