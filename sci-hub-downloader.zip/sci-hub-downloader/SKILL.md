---
name: sci-hub-downloader
description: 兼容别名技能。Sci-Hub 下载流程已并入 library-researcher 的兜底分支。
---

# Sci-Hub Downloader（兼容别名）

> 说明：该技能已并入 `library-researcher`，用于降低技能分散与认知负担。

## 当前策略

- 主通道：`library-researcher`（学校/VPN 下载）
- 兜底通道：`library-researcher/references/scihub-fallback.md`

## 触发行为

当用户提到“sci-hub 下载/DOI 下载”时：

1. 直接调用 `library-researcher` 主流程。
2. 若学校渠道失败，再按 `references/scihub-fallback.md` 执行兜底。
3. 所有成功/失败都统一写入 `literature_success.md` 与 `literature_failed.md`。

## 维护原则

- 不再维护单独的 Sci-Hub 操作细节文档。
- 新规则只更新到 `library-researcher` 体系，避免双份漂移。
