---
name: sci-hub-downloader
description: Sci-Hub文献PDF下载工具。使用Playwright浏览器MCP通过Sci-Hub镜像下载学术文献PDF，自动处理镜像切换、PDF提取和文件重命名。适用于从DOI或论文列表批量下载文献。触发词：sci-hub下载、文献下载、论文PDF、从DOI下载、批量下载文献。
---

# Sci-Hub Downloader

通过Playwright浏览器MCP自动化从Sci-Hub镜像下载学术文献PDF。

## 适用场景

- 已知DOI，需要下载对应论文PDF
- 有论文列表（含DOI），需要批量下载
- 学校数据库无权限时，使用Sci-Hub作为替代下载方式

## Sci-Hub镜像状态

| 镜像 | 状态 | 说明 |
|------|------|------|
| sci-hub.ru | ✅ **最稳定** | 重定向到sci-hub.sg，推荐使用 |
| sci-hub.st | ⚠️ 可能403 | 反爬虫限制，可能被封锁 |
| sci-hub.se | ❌ SSL错误 | 连接失败 |
| sci-hub.wf | ⚠️ 可能超时 | 服务器不稳定 |

**推荐策略**: 优先使用 `sci-hub.ru`，失败后尝试 `sci-hub.st`

## 下载限制

### 2024年后论文

**问题**: 大部分2024年发表的论文不在Sci-Hub数据库中

**提示页面特征**:
```
"The paper is recent: it was published after 2021."
"Recent papers are mostly unavailable since automatic download doesn't work on them."
```

**解决方案**:
1. 检查是否为Open Access（页面会提供链接）
2. 直接访问出版社官网下载
3. 使用 `library-researcher` skill 通过学校系统下载
4. 等待Sci-Hub数据库更新

## 下载流程

### 单篇下载

1. **打开Sci-Hub页面**
   ```
   mcp__playwright__browser_navigate({ url: "https://sci-hub.ru/{DOI}" })
   ```

2. **检查页面状态**
   - 如果显示"article is not available" → 论文不在数据库中
   - 如果显示论文标题 + PDF链接 → 可以下载

3. **下载PDF**
   - 查找PDF下载链接（通常为 `/download/xxx.pdf` 格式）
   - 点击下载链接或直接导航到PDF URL
   ```
   mcp__playwright__browser_click({ ref: "pdf_link_ref" })
   ```

4. **移动并重命名文件**
   - PDF下载到项目目录的 `.playwright-mcp/` 文件夹
   - 移动到目标目录并按论文标题重命名
   ```bash
   mv .playwright-mcp/{filename}.pdf "{目标目录}/{序号}. {标题}.pdf"
   ```

### 批量下载

1. **解析论文列表**（HTML/Markdown格式）
   - 提取标题、DOI、序号

2. **逐篇处理**
   - 按序号或DOI排序
   - 对每篇执行单篇下载流程

3. **记录结果**
   - 成功: 记录文件路径
   - 失败: 记录原因（不在数据库/网络错误）

4. **生成报告**
   - 统计成功/失败数量
   - 列出失败论文及原因

## PDF链接识别

在Sci-Hub页面中，PDF下载链接通常有以下特征：

```yaml
# 典型页面结构
- 论文标题
- 期刊/年份信息
- PDF下载链接: /download/{year}/{hash}/{filename}.pdf
- 其他链接: meta, similar等
```

**提取模式**:
```
/ref=e20  → PDF下载链接 (nth=3 的 link 元素)
```

## 文件重命名

### 文件名清理

移除非法字符，限制长度：
```python
import re

def sanitize_filename(name):
    name = re.sub(r'[<>:"/\\|?*]', '-', name)
    if len(name) > 200:
        name = name[:200]
    return name
```

### 命名格式

```
{序号}. {论文标题}.pdf
```

示例:
```
20. Reducing mental health disparities among underserved youth using technology to equip parents as agents of change.pdf
25. Understanding Supporting and Hindering Factors in Community-Based Psychotherapy for Refugees A Realist-Informed Systematic Review.pdf
```

## 常见问题处理

### 403 Forbidden

**原因**: IP被Sci-Hub封锁
**解决**:
- 更换镜像（sci-hub.ru → sci-hub.st）
- 等待一段时间后重试
- 使用代理

### 连接超时

**原因**: 镜像服务器不稳定
**解决**: 尝试其他镜像

### 论文不在数据库

**原因**:
- 论文太新（2024年后）
- Sci-Hub未收录该期刊
- DOI错误

**解决**:
- 检查DOI是否正确
- 尝试其他镜像
- 考虑使用学校数据库或出版社官网

### PDF下载失败

**原因**:
- 网络问题
- 服务器负载高
- PDF文件损坏

**解决**:
- 重试下载
- 检查网络连接
- 尝试其他镜像

## 示例用法

### 单篇下载

用户请求: "下载这篇论文: 10.1111/jcpp.13703"

```python
# 1. 导航到Sci-Hub
mcp__playwright__browser_navigate({ url: "https://sci-hub.ru/10.1111/jcpp.13703" })

# 2. 点击PDF下载
mcp__playwright__browser_click({ ref: "e20" })

# 3. 移动文件
find .playwright-mcp/ -name "*.pdf" -exec mv {} "downloads/" \;
```

### 批量下载

用户请求: "下载文献清单.html中的所有论文"

1. 解析HTML获取DOI列表
2. 循环处理每篇论文
3. 生成下载报告
