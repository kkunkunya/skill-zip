---
name: MeiGen Visual Creative
description: >-
  创意设计图像生成技能（基于 MeiGen MCP）。用于产品图、Logo、海报、品牌设计、
  社交媒体配图等创意类图像生成。提供 1300+ prompt 库搜索、prompt 增强、
  多方向并行生成等能力。触发词：产品图、Logo设计、海报、品牌设计、
  创意图片、设计灵感、prompt增强、MeiGen、批量生成、多方向设计。
  NOT for：学术图表/MATLAB仿真/实验平台照片（用image-generator）/
  文章配图（用baoyu-article-illustrator）/小红书图片（用baoyu-xhs-images）/
  信息图（用baoyu-infographic）。
  本技能专注创意商业设计，科研和内容配图请用对应专用技能。
version: 0.1.0
---

# MeiGen Visual Creative — 创意设计图像生成

> **定位**：创意/商业设计类图像生成（产品图、Logo、海报、品牌、社交媒体）
> **学术图表**请使用 `image-generator` skill（IEEE/MATLAB/实验台专用）

## 可用 MCP Tools

| Tool | 免费 | 用途 |
|------|------|------|
| `mcp__meigen__search_gallery` | Yes | 搜索 1300+ 策展 prompt 库，带预览图 |
| `mcp__meigen__get_inspiration` | Yes | 获取某条 gallery 的完整 prompt + 所有图片 |
| `mcp__meigen__enhance_prompt` | Yes | 将简短描述增强为专业 prompt |
| `mcp__meigen__list_models` | Yes | 列出可用模型 |
| `mcp__meigen__upload_reference_image` | Yes | 上传本地参考图获取 URL |
| `mcp__meigen__generate_image` | Key | 生成图片（自动路由到配置的 provider） |

## 核心工作流

### Phase 1: 意图分类

| 类型 | 特征 | 处理 |
|------|------|------|
| **探索型** | "帮我想想"、"找灵感" | search_gallery → get_inspiration → 展示 |
| **简短描述** | <30词，缺视觉细节 | enhance_prompt → 确认 → generate |
| **详细 prompt** | 有具体视觉描述 | 直接 generate |
| **编辑修改** | 提供图片+描述改动 | upload_reference → 简短 prompt → generate |
| **批量生成** | "4个方向"、"多版本" | 规划方向 → AskUserQuestion → 并行 generate |
| **创意+衍生** | "设计Logo+做mockup" | 分步：设计→确认→衍生 |

### Phase 2: 执行规则

**规则 1: 生成必须委派给 subagent**
```
Task(subagent_type="general-purpose",
     prompt="调用 mcp__meigen__generate_image，prompt: '[完整prompt]', aspectRatio: '1:1'。返回完整响应。")
```
多张图 → 在单条消息中并行 spawn 多个 Task。

**规则 2: 选择用 AskUserQuestion**
呈现设计方向时，必须用 AskUserQuestion 工具让用户选择，不要纯文本提问。

**规则 3: 只展示 URL 和路径**
生成后只转述 Image URL + Saved to 路径。不要描述或想象图片内容。

**规则 4: 不指定 model/provider**
除非用户明确要求，不传 model 或 provider 参数，让 MCP server 自动选择。

## Prompt 工程速查

### 写实/摄影
- 镜头：焦距、光圈、景深
- 光线：方向、质感、色温
- 材质纹理、空间层次

### 动漫/2D
- 触发词：anime screenshot, key visual, masterpiece
- 角色细节：眼睛、发型、服装、表情、姿势

### 插画/概念艺术
- 媒介：digital painting, watercolor, oil
- 明确色彩方案、构图方向

## 参考图使用

- `referenceImages` 接受公开 URL 数组
- 来源：gallery URL / 上次生成的 URL / upload_reference_image 转换的 URL
- 始终搭配详细文字 prompt（参考图引导风格，prompt 引导内容）

## 与 image-generator 的分工

| 需求 | 使用 |
|------|------|
| 产品图、Logo、海报、品牌、社交媒体 | **meigen-design**（本 skill） |
| IEEE/Springer 学术图表 | image-generator |
| MATLAB 仿真波形图 | image-generator |
| 实验平台实拍照片 | image-generator |
| 找创意灵感、浏览 prompt 库 | **meigen-design**（本 skill） |
