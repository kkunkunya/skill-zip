---
name: multi-model-collaborator
description: Enables multi-AI collaboration by integrating Codex and Gemini calling methods. Supports independent task delegation or parallel multi-model verification. Activates when users request multi-model collaboration, AI collaboration, or mention Codex/Gemini. Useful for complex problems requiring diverse AI perspectives or validation.
context: fork
---

# Multi-Model Collaborator (多模型协作)

## 核心理念

整合 Codex 和 Gemini 两个外部 AI 的调用方式，提供统一的协作接口。

**核心原则：**
- 独立思考、相互验证、追求真理
- 让 AI 自己遍历文件，不要喂代码
- 后台运行，避免阻塞

## 调用方式统一

### Codex 调用

```bash
# 后台启动（常规任务）
Bash(run_in_background: true, timeout: 600000):
  codex exec --skip-git-repo-check -c sandbox_mode="danger-full-access" -c approval_policy="never" -c network_access="enabled" -C "/project/path" "你的prompt"

# 后台启动（调试任务 - 最高推理强度 xhigh）
Bash(run_in_background: true, timeout: 600000):
  codex exec --skip-git-repo-check -c sandbox_mode="danger-full-access" -c approval_policy="never" -c network_access="enabled" -c model_reasoning_effort="xhigh" -C "/project/path" "你的prompt"

# 获取结果
TaskOutput(task_id: "<task_id>", block: true)
```

**关键参数：**
- `-c sandbox_mode="danger-full-access"` - 完全文件访问
- `-c approval_policy="never"` - 自动执行
- `-c network_access="enabled"` - 网络访问
- `-c model_reasoning_effort="xhigh"` - 最高推理强度（**调试必须使用**）
- `-C "/path"` - 工作目录

### Gemini 调用

```bash
# 后台启动
Bash(run_in_background: true, timeout: 600000):
  cd "/project/path" && gemini -y -o text "你的prompt"

# 获取结果
TaskOutput(task_id: "<task_id>", block: true)
```

**关键参数：**
- `-y` - 自动批准所有操作
- `-o text` - 纯文本输出

## 使用场景

### 场景1：单模型任务委派

当需要让外部 AI 独立完成任务时：

```bash
# Codex 完成任务
codex exec --skip-git-repo-check -c sandbox_mode="danger-full-access" -c approval_policy="never" -c network_access="enabled" -C "/project/path" "
任务：[功能描述]

请你：
1. 分析项目结构
2. 实现功能
3. 运行测试
4. 报告结果
"

# 或 Gemini 完成任务
cd "/project/path" && gemini -y -o text "
任务：[功能描述]

请你：
1. 分析项目结构
2. 实现功能
3. 运行测试
4. 报告结果
"
```

### 场景2：代码审查

```bash
# Codex 审查
codex review --skip-git-repo-check --uncommitted -c sandbox_mode="danger-full-access" -c approval_policy="never" -C "/project/path"

# Gemini 审查
cd "/project/path" && gemini -y -o text "
请自行遍历项目文件，审查最近的代码改动：
1. 是否正确实现需求
2. 是否存在潜在bug
3. 代码质量如何
4. 改进建议
"
```

### 场景3：多模型并行验证

当需要多个 AI 独立思考同一问题时，**在同一条消息中**并行发起两个后台任务：

```
# 消息中同时发起两个 Bash 调用（并行）

Bash 1 (run_in_background: true):
  codex exec ... "问题描述，请独立分析..."

Bash 2 (run_in_background: true):
  cd "/path" && gemini -y -o text "问题描述，请独立分析..."

# 然后用两个 TaskOutput 获取结果
TaskOutput(task_id: "<codex_task_id>", block: true)
TaskOutput(task_id: "<gemini_task_id>", block: true)
```

**重要：** 两个 AI 必须独立思考，不能看到彼此的结果。

## 禁止行为

**绝对禁止在 prompt 中包含代码！**

```
❌ 错误：
codex exec "请审查以下代码：
def foo():
    return 1
"

✅ 正确：
codex exec -C "/project" "请自行遍历项目文件，审查 src/foo.py"
```

**原因：** 让 AI 自己读取文件，才能发现你可能遗漏的问题。

## 参数速查

### Codex

| 参数 | 说明 |
|------|------|
| `exec` | 非交互式执行 |
| `review` | 代码审查模式 |
| `--skip-git-repo-check` | 允许非Git仓库（必需） |
| `-C <path>` | 工作目录 |
| `-c sandbox_mode="danger-full-access"` | 完全文件访问 |
| `-c approval_policy="never"` | 自动执行 |
| `-c network_access="enabled"` | 网络访问 |
| `-c model_reasoning_effort="xhigh"` | 最高推理强度（**调试必须使用**） |

### Gemini

| 参数 | 说明 |
|------|------|
| `-y` | 自动批准所有操作 |
| `-o text` | 纯文本输出 |
| `-o json` | JSON输出 |
| `-m <model>` | 指定模型 |
| `--include-directories` | 额外目录 |

## 注意事项

1. **后台运行**: 必须 `run_in_background: true`
2. **超时设置**: 建议 `timeout: 600000` (10分钟)
3. **工作目录**: Codex 用 `-C`，Gemini 用 `cd ... &&`
4. **不要喂代码**: 让 AI 自己遍历文件
5. **独立思考**: 多模型验证时，确保各自独立分析

---

<!-- Evolution: 2026-01-18 | source: 开关电源/数据传递函数-200/MASAC收敛修复 | author: @用户 -->

## 🎯 共识度评估机制

### 评估维度

收到多模型结果后，必须评估以下维度：

| 维度 | 评估问题 | 权重 |
|------|---------|------|
| **根因诊断** | 是否指向同一根本原因？ | ⭐⭐⭐ 高 |
| **解决方向** | 建议的解决策略是否一致？ | ⭐⭐⭐ 高 |
| **具体参数** | 数值/配置建议是否接近？ | ⭐⭐ 中 |
| **实现细节** | 代码实现方式是否相同？ | ⭐ 低 |

### 共识度计算

```
共识度 = (一致项数 / 总检查项数) × 100%

高共识 (≥80%): 直接采用共识方案
中共识 (50-80%): 需要分析分歧点
低共识 (<50%): 需要用户决策或第三方验证
```

### 评估模板

```markdown
## 多模型协作结果

### 各模型结论

| 模型 | 根因诊断 | 解决方向 | 具体参数 |
|------|---------|---------|---------|
| Claude | ... | ... | ... |
| Codex | ... | ... | ... |
| Gemini | ... | ... | ... |

### 共识度评估

- 根因诊断: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧
- 解决方向: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧
- 具体参数: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧

**综合共识度**: XX%
```

---

## 🔀 分歧处理决策树

### 分歧类型与处理

```
                     收到多模型结果
                           │
              ┌────────────┴────────────┐
              ▼                         ▼
         根因一致                    根因分歧
              │                         │
     ┌────────┴────────┐               ▼
     ▼                 ▼         需要更多证据
  参数一致          参数分歧          │
     │                 │              ├→ 运行诊断命令
     ▼                 ▼              ├→ 添加日志
  直接采用        分析参数差异        └→ 重新提问
                       │
              ┌────────┴────────┐
              ▼                 ▼
         差异可接受          差异显著
              │                 │
              ▼                 ▼
         取中间值          呈报用户决策
```

### 真实案例：开关电源项目三模型分歧

**问题**：LLC 谐振变换器设计参数

| 模型 | 开关频率 | 谐振电感 | 谐振电容 |
|------|---------|---------|---------|
| Claude | 100kHz | 47µH | 22nF |
| Codex | 100kHz | 50µH | 20nF |
| Gemini | 100kHz | 45µH | 25nF |

**共识分析**：
- ✅ 开关频率：完全一致 (100kHz)
- ⚠️ 谐振电感：±5µH 差异（可接受范围内）
- ⚠️ 谐振电容：±3nF 差异（可接受范围内）

**决策**：高共识度，取中间值 (48µH, 22nF)

### 真实案例：系统辨识项目根因分歧

**问题**：ARX 模型 R²=0.9999 但多步预测失败

| 模型 | 根因诊断 |
|------|---------|
| Claude | 闭环数据高自相关，ARX 过拟合 |
| Codex | 闭环数据高自相关，需要分段辨识 |
| Gemini | 采样率过高导致输入动态被掩盖 |

**共识分析**：
- ✅ 根因方向一致：都指向闭环数据问题
- ⚠️ 解决策略略有差异

**决策**：综合采用 → 分段辨识 + 选取高激励窗口

---

## 📝 分歧记录模板

在 `docs/findings.md` 中记录：

```markdown
## 多模型协作记录: {问题名}

### 问题描述
{问题的详细描述}

### 各模型独立分析

#### Claude 分析
- 根因: ...
- 建议: ...

#### Codex 分析
- 根因: ...
- 建议: ...

#### Gemini 分析
- 根因: ...
- 建议: ...

### 共识度评估

| 维度 | 状态 | 说明 |
|------|------|------|
| 根因 | ✅/⚠️/❌ | ... |
| 方向 | ✅/⚠️/❌ | ... |
| 参数 | ✅/⚠️/❌ | ... |

**综合共识度**: XX%

### 分歧点

| 分歧项 | Claude | Codex | Gemini | 决策 |
|--------|--------|-------|--------|------|
| ... | ... | ... | ... | 采用X |

### 最终决策

{采用的方案及理由}

### 验证结果

{实施后的效果}
```

---

## 🔄 低共识度处理流程

当共识度 < 50% 时：

1. **不要直接采用任何一个方案**
2. **收集更多证据**：
   - 运行诊断命令
   - 添加详细日志
   - 检查相关文档/论文
3. **重新提问**（提供更多上下文）
4. **呈报用户决策**（如果仍无法达成共识）

### 重新提问模板

```bash
codex exec ... "
之前的分析出现分歧：

【Claude 认为】...
【Codex 认为】...
【Gemini 认为】...

我收集了更多证据：
{新的诊断输出/日志/文档}

请基于新证据重新分析，哪个判断更可能正确？
"
```

---

## ⚡ 快速参考

| 共识度 | 处理方式 |
|--------|---------|
| ≥80% | 直接采用共识方案 |
| 50-80% | 分析分歧点，取最佳或中间值 |
| <50% | 收集更多证据，重新评估或呈报用户 |

| 分歧类型 | 处理方式 |
|---------|---------|
| 参数微调分歧 | 取中间值或保守值 |
| 方法论分歧 | 选择有更多证据支持的 |
| 根因判断分歧 | 必须收集更多证据 |
