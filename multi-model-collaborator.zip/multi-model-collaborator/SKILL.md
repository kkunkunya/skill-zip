---
name: multi-model-collaborator
description: 多模型协作技能（Team 嵌套并行模式）。通过 Team 机制将 Codex 作为持久团队成员，支持双向通信、多轮追问、Squad Leader 裂变并行。激活词：多模型协作、AI协作、Codex协作、多模型验证。
context: fork
---

# Multi-Model Collaborator（多模型协作 · Team 模式）

## 核心理念

- **独立思考、相互验证、追求真理**
- 让 AI 自己遍历文件，不要喂代码
- Codex 是持久团队成员，不是一次性工具

---

## 架构概览

```
Claude Code Team Leader (编排 + 综合分析)
  │
  ├── Claude Teammate (持久, 独立分析视角)
  │
  └── Codex Proxy / Squad Leader (general-purpose, 持久)
        │
        ├── 普通任务: Bash(bg) → codex exec → 汇报
        │
        └── 复杂任务 [DEEP]: 自动裂变
              ├── Bash(bg) → codex exec 子任务A
              ├── Bash(bg) → codex exec 子任务B
              └── 内部综合 → SendMessage 汇报 Leader
```

**通信**: 双向 SendMessage（Leader↔Codex Proxy, Leader↔Claude TM, Claude TM↔Codex Proxy）
**生命周期**: 持久（idle/wake 循环，支持多轮追问）

---

## 调用流程

### Step 1: 创建 Team

```
TeamCreate(team_name="multi-model-{问题简称}", description="多模型协作: {问题描述}")
```

### Step 2: 创建任务

```
TaskCreate(subject="[分析] {问题}", description="独立分析: {详细描述}")
```

### Step 3: 启动 Teammates

在同一条消息中并行启动（关键！）：

```
# Claude Teammate — 独立分析视角
Task(
  subagent_type="general-purpose",
  team_name="multi-model-{名称}",
  name="claude-analyst",
  model="sonnet",
  prompt="你是独立分析师。请自行遍历项目文件，独立分析以下问题：{问题}。
         完成后通过 SendMessage 汇报你的分析结论。"
)

# Codex Proxy — 外部 AI 视角
Task(
  subagent_type="general-purpose",
  team_name="multi-model-{名称}",
  name="codex-proxy",
  model="sonnet",
  prompt="你是 Codex Proxy Agent。请阅读你的 Agent 定义：~/.claude/agents/codex-proxy.md
         然后执行以下任务：{问题}
         工作目录：{项目路径}"
)
```

### Step 4: 收集结果 & 共识度评估

等待两个 Teammate 汇报后，Leader 进行共识度评估（见下方机制）。

### Step 5: 分歧处理（如需要）

```
# 针对性追问 Codex Proxy
SendMessage(
  type="message",
  recipient="codex-proxy",
  content="Claude 的分析认为 {Claude结论}，与你的 {Codex结论} 存在分歧。
           请针对 {具体分歧点} 重新验证。",
  summary="追问分歧点"
)

# 或让 Claude TM 直接质疑 Codex Proxy（Peer 通信）
SendMessage(
  type="message",
  recipient="claude-analyst",
  content="请直接联系 codex-proxy，质疑其关于 {分歧点} 的结论。",
  summary="发起 Peer 质疑"
)
```

### Step 6: 综合结论 & 清理

```
# Leader 综合分析后
SendMessage(type="shutdown_request", recipient="claude-analyst", content="分析完成")
SendMessage(type="shutdown_request", recipient="codex-proxy", content="分析完成")
TeamDelete()
```

---

## Squad Leader 裂变模式

当任务需要深度多维分析时，在任务前加 `[DEEP]` 前缀：

```
SendMessage(
  type="message",
  recipient="codex-proxy",
  content="[DEEP] 请从以下维度全面分析 {问题}：
           1. {维度A}
           2. {维度B}
           3. {维度C}",
  summary="深度多维分析任务"
)
```

Codex Proxy 会自动裂变为多个并行 `codex exec`，内部综合后汇报。

---

## Codex 参数速查

| 参数 | 说明 |
|------|------|
| `exec` | 非交互式执行 |
| `review` | 代码审查模式 |
| `--skip-git-repo-check` | 允许非Git仓库（必需） |
| `-C <path>` | 工作目录 |
| `-c sandbox_mode="danger-full-access"` | 完全文件访问 |
| `-c approval_policy="never"` | 自动执行 |
| `-c network_access="enabled"` | 网络访问 |
| `-c model_reasoning_effort="xhigh"` | 最高推理强度（调试必须使用） |

---

## 禁止行为

**绝对禁止在 prompt 中包含代码！**

```
❌ 错误：
codex exec "请审查以下代码：
def foo():
    return 1
"

✅ 正确：
codex exec -C "/project" "请自行遍历项目文件，审查 src/foo.py"
```

**原因：** 让 AI 自己读取文件，才能发现你可能遗漏的问题。

---

## 🎯 共识度评估机制

### 评估维度

收到多模型结果后，必须评估以下维度：

| 维度 | 评估问题 | 权重 |
|------|---------|------|
| **根因诊断** | 是否指向同一根本原因？ | ⭐⭐⭐ 高 |
| **解决方向** | 建议的解决策略是否一致？ | ⭐⭐⭐ 高 |
| **具体参数** | 数值/配置建议是否接近？ | ⭐⭐ 中 |
| **实现细节** | 代码实现方式是否相同？ | ⭐ 低 |

### 共识度计算

```
共识度 = (一致项数 / 总检查项数) × 100%

高共识 (≥80%): 直接采用共识方案
中共识 (50-80%): 需要分析分歧点 → 多轮追问
低共识 (<50%): 收集更多证据，重新评估或呈报用户
```

### 评估模板

```markdown
## 多模型协作结果

### 各模型结论

| 模型 | 根因诊断 | 解决方向 | 具体参数 |
|------|---------|---------|---------|
| Claude | ... | ... | ... |
| Codex | ... | ... | ... |

### 共识度评估

- 根因诊断: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧
- 解决方向: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧
- 具体参数: ✅ 一致 / ⚠️ 部分一致 / ❌ 分歧

**综合共识度**: XX%
```

---

## 🔀 分歧处理决策树

```
                     收到多模型结果
                           │
              ┌────────────┴────────────┐
              ▼                         ▼
         根因一致                    根因分歧
              │                         │
     ┌────────┴────────┐               ▼
     ▼                 ▼         多轮追问分歧点
  参数一致          参数分歧     (SendMessage 追问)
     │                 │              │
     ▼                 ▼         ┌────┴────┐
  直接采用        分析参数差异   ▼         ▼
                       │      达成共识   仍有分歧
              ┌────────┴────────┐  │         │
              ▼                 ▼  ▼         ▼
         差异可接受          差异显著  采用   收集更多证据
              │                 │         或呈报用户
              ▼                 ▼
         取中间值          呈报用户决策
```

### 多轮追问流程（升级点）

```
Round 1: 独立分析 → 收集结果 → 评估共识度
  │
  ├─ 高共识 → 直接采用
  │
  └─ 中/低共识 → Round 2
       │
       ├─ Leader 向 Codex Proxy 追问分歧点
       ├─ Leader 向 Claude TM 追问分歧点
       │  （或让 Claude TM 直接质疑 Codex Proxy）
       │
       └─ 收集更新分析 → 重新评估共识度
            │
            ├─ 共识提升 → 采用
            └─ 仍有分歧 → Round 3 或呈报用户
```

**关键优势**：Proxy 保持上下文，追问是增量的（不需要重发完整 prompt）。

---

## 🔄 低共识度处理流程

当共识度 < 50% 时：

1. **不要直接采用任何一个方案**
2. **多轮追问**：
   - 向 Codex Proxy 发送针对性追问（自动注入历史上下文）
   - 让 Claude TM 和 Codex Proxy 直接对话（Peer 通信）
3. **收集更多证据**：
   - 运行诊断命令
   - 添加详细日志
   - 检查相关文档/论文
4. **呈报用户决策**（如果多轮追问仍无法达成共识）

---

## 📝 分歧记录模板

在 `docs/findings.md` 中记录：

```markdown
## 多模型协作记录: {问题名}

### 问题描述
{问题的详细描述}

### 各模型独立分析

#### Claude 分析
- 根因: ...
- 建议: ...

#### Codex 分析
- 根因: ...
- 建议: ...

### 共识度评估

| 维度 | 状态 | 说明 |
|------|------|------|
| 根因 | ✅/⚠️/❌ | ... |
| 方向 | ✅/⚠️/❌ | ... |
| 参数 | ✅/⚠️/❌ | ... |

**综合共识度**: XX%

### 追问记录（如有）

| 轮次 | 追问内容 | Codex 更新 | Claude 更新 | 共识变化 |
|------|---------|-----------|-----------|---------|
| R2 | ... | ... | ... | 50%→70% |

### 分歧点

| 分歧项 | Claude | Codex | 决策 |
|--------|--------|-------|------|
| ... | ... | ... | 采用X |

### 最终决策
{采用的方案及理由}

### 验证结果
{实施后的效果}
```

---

## ⚡ 快速参考

| 共识度 | 处理方式 |
|--------|---------|
| ≥80% | 直接采用共识方案 |
| 50-80% | 多轮追问分歧点 → 再评估 |
| <50% | 深度追问 + 证据收集 → 呈报用户 |

| 分歧类型 | 处理方式 |
|---------|---------|
| 参数微调分歧 | 取中间值或保守值 |
| 方法论分歧 | 多轮追问 → 选择有更多证据支持的 |
| 根因判断分歧 | 必须多轮追问 + 收集更多证据 |

| Team 组合 | 场景 |
|-----------|------|
| 1 Claude TM + 1 Codex Proxy | 标准多模型验证 |
| 1 Claude TM + 1 Codex Squad Leader | 深度多维分析（[DEEP]） |
| 2 Builder + 1 Guardian + 1 Codex Proxy | 全栈开发 + 多模型验证 |

---

<!-- Evolution: 2026-02-11 | source: @blackanger 推文 Team嵌套并行架构 | upgrade: subprocess→Team模式 -->
