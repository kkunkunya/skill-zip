#!/usr/bin/env python3
"""
PDF元数据提取与引用生成脚本

功能：
1. 从PDF文件提取元数据（标题、作者、关键词等）
2. 从PDF首页文本识别论文信息
3. 生成GB/T 7714格式引用

依赖：pip install pymupdf

用法：
    python extract_metadata.py <pdf_path>
    python extract_metadata.py ./downloads/*.pdf
"""

import sys
import re
import json
from pathlib import Path
from datetime import datetime

try:
    import fitz  # pymupdf
except ImportError:
    print("错误: 需要安装 pymupdf")
    print("运行: pip install pymupdf")
    sys.exit(1)


def extract_metadata(pdf_path: str) -> dict:
    """从PDF提取元数据"""
    doc = fitz.open(pdf_path)

    # 基础元数据
    metadata = doc.metadata

    # 提取首页文本用于识别更多信息
    first_page_text = ""
    if len(doc) > 0:
        first_page_text = doc[0].get_text()[:2000]  # 只取前2000字符

    doc.close()

    result = {
        "file_path": str(pdf_path),
        "file_name": Path(pdf_path).name,
        "title": metadata.get("title", ""),
        "author": metadata.get("author", ""),
        "subject": metadata.get("subject", ""),
        "keywords": metadata.get("keywords", ""),
        "creator": metadata.get("creator", ""),
        "producer": metadata.get("producer", ""),
        "creation_date": metadata.get("creationDate", ""),
        "first_page_preview": first_page_text[:500],
    }

    # 尝试从文本识别缺失信息
    if not result["title"]:
        result["title"] = extract_title_from_text(first_page_text)

    if not result["author"]:
        result["author"] = extract_authors_from_text(first_page_text)

    return result


def extract_title_from_text(text: str) -> str:
    """从文本中提取标题（通常是最前面的大段文字）"""
    lines = text.strip().split('\n')
    for line in lines[:5]:  # 检查前5行
        line = line.strip()
        if len(line) > 10 and len(line) < 200:  # 标题通常10-200字符
            return line
    return ""


def extract_authors_from_text(text: str) -> str:
    """从文本中提取作者信息"""
    # 常见作者标识模式
    patterns = [
        r"作者[：:]\s*(.+)",
        r"Author[s]?[：:]\s*(.+)",
        r"^([^\n]+?)\s*(?:摘要|Abstract)",
    ]

    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()[:100]

    return ""


def generate_citation(metadata: dict, index: int = 1) -> str:
    """生成GB/T 7714格式引用"""
    title = metadata.get("title", "未知标题")
    author = metadata.get("author", "未知作者")
    year = ""

    # 从creation_date提取年份
    creation_date = metadata.get("creation_date", "")
    if creation_date:
        year_match = re.search(r"(\d{4})", creation_date)
        if year_match:
            year = year_match.group(1)

    if not year:
        year = str(datetime.now().year)

    # 简化的引用格式
    citation = f"[{index}] {author}. {title}[J/OL]. {year}."

    return citation


def generate_markdown_report(pdf_files: list, output_path: str = None) -> str:
    """生成Markdown汇总报告"""
    results = []

    for pdf_path in pdf_files:
        try:
            metadata = extract_metadata(pdf_path)
            results.append(metadata)
        except Exception as e:
            results.append({
                "file_path": str(pdf_path),
                "file_name": Path(pdf_path).name,
                "error": str(e)
            })

    # 生成Markdown
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    md = f"""# 文献检索报告

## 检索信息
- 生成时间: {now}
- 文献数量: {len(results)}

## 文献列表

"""

    citations = []

    for i, r in enumerate(results, 1):
        if "error" in r:
            md += f"""### {i}. {r['file_name']}
- **状态**: ❌ 提取失败
- **错误**: {r['error']}

"""
        else:
            citation = generate_citation(r, i)
            citations.append(citation)

            md += f"""### {i}. {r.get('title', r['file_name'])}
- **作者**: {r.get('author', '未知')}
- **关键词**: {r.get('keywords', '无')}
- **文件**: `{r['file_name']}`
- **引用**: {citation}

"""

    # 添加引用汇总
    md += """## 引用汇总（可直接复制）

```
"""
    md += "\n".join(citations)
    md += """
```
"""

    if output_path:
        Path(output_path).write_text(md, encoding="utf-8")
        print(f"报告已保存: {output_path}")

    return md


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    pdf_files = []
    for arg in sys.argv[1:]:
        path = Path(arg)
        if path.is_file() and path.suffix.lower() == ".pdf":
            pdf_files.append(path)
        elif "*" in arg:
            # 支持通配符
            import glob
            pdf_files.extend([Path(p) for p in glob.glob(arg) if p.endswith(".pdf")])

    if not pdf_files:
        print("错误: 未找到PDF文件")
        sys.exit(1)

    print(f"找到 {len(pdf_files)} 个PDF文件")

    # 生成报告
    report = generate_markdown_report(pdf_files, "./literature_summary.md")
    print("\n" + "="*50)
    print(report)


if __name__ == "__main__":
    main()
