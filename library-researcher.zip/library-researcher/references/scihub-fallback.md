# Sci-Hub 兜底下载（并入 library-researcher）

> 用途：当学校图书馆渠道无法下载（无权限/无按钮/超时）时，作为二级兜底通道。

## 触发条件

满足任一即可触发：

- 学校系统无 PDF 入口（`NO_BUTTON`）
- 有权限提示但无法实际下载（`NEED_LOGIN` / `BLOCKED`）
- 文献已知 DOI，且需快速补齐 PDF

## 使用顺序

1. 先走学校系统（主通道）
2. 失败后再走 Sci-Hub（兜底）
3. 仍失败时记录失败并保留 DOI/URL 供后续人工处理

## 最小执行流程

1. 打开 `https://sci-hub.ru/{DOI}`
2. 检查页面状态：
   - 若显示不可用/过新论文提示，直接记录失败原因
   - 若存在 PDF 链接，点击下载并移动到目标目录
3. 下载后立即重命名并追加到 `literature_success.md`
4. 失败则追加到 `literature_failed.md`（原因示例：`SCIHUB_NOT_FOUND` / `SCIHUB_TIMEOUT`）

## 注意事项

- 2024 年后的新论文在 Sci-Hub 命中率偏低，优先尝试 OA 链接与出版社官网。
- 只把 Sci-Hub 作为兜底，不作为首选下载通道。
- 记录必须完整：标题、DOI、来源 URL、失败原因。
