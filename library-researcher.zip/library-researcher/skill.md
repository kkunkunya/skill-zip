---
name: library-researcher
description: 学术文献搜索下载工具。确认VPN登录后，在学校发现系统批量检索下载，智能记录成功/失败文献。
trigger_keywords:
  - 搜索论文
  - 下载文献
  - 学术检索
  - 图书馆搜索
  - 文献检索
  - 找论文
---

# Library Researcher

通过 Playwright MCP 浏览器自动化，在学校图书馆发现系统中批量检索文献并下载 PDF。
支持智能文档记录，自动追踪成功/失败下载状态。

---

## 工作流概览

```
确认VPN登录 → 批量搜索下载 → 成功:即时重命名+记录 → 失败:记录原因+保留URL
                                                    ↓
                              用户手动下载失败文献 → 批量重命名
```

---

## Phase 1: 环境确认

### 1.1 确认VPN登录状态

向用户确认：
```
🔐 环境检查

请确认以下条件已满足：
- [ ] VPN 已连接
- [ ] 校园网已登录

确认后回复"已登录"开始检索。
```

### 1.2 参数确认

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 搜索关键词 | 支持中英文组合 | **必填** |
| 下载数量 | 目标论文数量 | 10篇 |
| 记录目录 | 文档保存位置 | 项目根目录 |

**关键词组合策略**：
- ✅ 组合搜索更精准：`电缆故障 CNN` 比单独搜索 `电缆故障` 更好
- ✅ 添加技术限定：`行波 深度学习 高电压技术`

### 1.3 初始化记录文档

在项目根目录创建两个记录文件：

**成功文献记录** (`literature_success.md`)：
```markdown
# 成功下载文献记录

| 序号 | 标题 | 作者 | 期刊 | 年份 | 文件名 | 下载时间 |
|------|------|------|------|------|--------|----------|
```

**失败文献记录** (`literature_failed.md`)：
```markdown
# 失败下载文献记录

| 序号 | 标题 | 详情页URL | 失败原因 | 记录时间 |
|------|------|-----------|----------|----------|
```

---

## Phase 2: 批量搜索

### 2.1 导航到发现系统

```
http://fx.shieplib.chaoxing.com/
```

### 2.2 执行搜索

```javascript
// 在搜索框输入关键词并搜索
await page.getByRole('textbox').fill('用户提供的关键词');
await page.getByRole('button', { name: '检索' }).click();
await page.waitForTimeout(3000);
```

### 2.3 提取搜索结果

```javascript
const results = await page.evaluate(() => {
  const links = Array.from(document.querySelectorAll('a'));
  return links.filter(a => {
    const text = a.textContent || '';
    const href = a.href || '';
    return text.length > 10 && text.length < 200 &&
           (href.includes('detail') || href.includes('view'));
  }).slice(0, 15).map(a => ({
    title: a.textContent.trim().substring(0, 100),
    link: a.href
  }));
});
```

---

## Phase 3: 遍历下载与智能记录

对每条搜索结果执行以下流程：

### 3.1 打开详情页并提取元数据

```javascript
await page.goto(result.link);
await page.waitForTimeout(2000);

// 提取论文元数据
const metadata = await page.evaluate(() => {
  // 提取标题、作者、期刊、年份等
  return {
    title: document.querySelector('.title')?.textContent || '',
    author: document.querySelector('.author')?.textContent || '',
    journal: document.querySelector('.journal')?.textContent || '',
    year: document.querySelector('.year')?.textContent || '',
    detailUrl: window.location.href
  };
});
```

### 3.2 检测下载按钮

```javascript
const downloadInfo = await page.evaluate(() => {
  const links = Array.from(document.querySelectorAll('a'));
  return links.filter(a => {
    const text = a.textContent || '';
    const href = a.href || '';
    return text.includes('PDF') || text.includes('下载') || href.includes('goread');
  }).map(a => ({
    text: a.textContent.trim(),
    href: a.href
  }));
});
```

### 3.3 下载决策与记录

#### ✅ 成功路径：有下载按钮

```javascript
// 1. 点击下载
await page.goto(downloadInfo[0].href);
await page.waitForTimeout(5000);

// 2. 即时重命名
// 命名格式：文献名_期刊_作者.pdf
// mv ~/Downloads/原文件.pdf ~/Downloads/基于CNN的故障定位_高电压技术_张三.pdf

// 3. 追加到成功记录
// 写入 literature_success.md
```

**追加记录格式**：
```markdown
| 1 | 基于CNN的电缆故障定位方法 | 张三 | 高电压技术 | 2024 | 基于CNN的故障定位_高电压技术_张三.pdf | 2024-01-15 14:30 |
```

#### ❌ 失败路径：无下载按钮或下载失败

**失败原因分类**：
| 原因代码 | 说明 |
|----------|------|
| `NO_BUTTON` | 页面无下载按钮 |
| `NEED_LOGIN` | 需要额外登录/权限 |
| `TIMEOUT` | 下载超时 |
| `BLOCKED` | 访问被拦截 |
| `OTHER` | 其他原因 |

**追加到失败记录**：
```markdown
| 1 | 基于深度学习的故障诊断 | http://fx.shieplib.../detail/123 | NO_BUTTON: 未找到PDF下载入口 | 2024-01-15 14:32 |
```

**不暂停，继续下一篇**：失败后立即记录，继续处理下一篇文献。

---

## Phase 4: 批量完成汇报

所有文献处理完毕后，输出汇报：

```
📊 批量下载完成

搜索关键词: [用户关键词]
处理总数: X 篇

✅ 成功下载: Y 篇
   → 已重命名并保存到 ~/Downloads/
   → 记录文件: literature_success.md

❌ 下载失败: Z 篇
   → 失败原因已记录
   → 记录文件: literature_failed.md

---
💡 后续操作提示:
如需手动下载失败文献，回复"打开失败文献"，我将逐一打开详情页。
手动下载完成后，回复"批量重命名"进行统一处理。
```

---

## Phase 5: 失败文献手动处理（可选）

### 5.1 用户指令："打开失败文献"

读取 `literature_failed.md`，逐一打开详情页URL：

```
📂 打开失败文献 (1/Z)

标题: [论文标题]
失败原因: [原因]
详情页已打开，请手动下载。

完成后回复"下一篇"继续，或"全部完成"结束。
```

### 5.2 用户指令："批量重命名"

扫描 `~/Downloads/` 中的新PDF文件，根据 `literature_failed.md` 中的标题信息进行重命名：

```bash
# 对每个新下载的PDF
mv ~/Downloads/未命名文件.pdf ~/Downloads/文献名_期刊_作者.pdf
```

重命名完成后，将该文献从失败记录移动到成功记录。

---

## 完成汇报

```
✅ 文献检索全部完成

- 检索平台: 学校图书馆发现系统
- 搜索关键词: [用户关键词]
- 成功下载: X 篇 (自动Y篇 + 手动Z篇)
- 保存位置: ~/Downloads/

📄 记录文件：
- literature_success.md (完整下载清单)
- literature_failed.md (如有剩余未处理)
```

---

## 智能记录文档规范

### 文件位置
- 默认：项目根目录
- 可指定：用户提供的任意目录

### 文件命名
- `literature_success.md` - 成功下载记录
- `literature_failed.md` - 失败下载记录

### 记录时机
- **成功**：下载完成 + 重命名完成后立即追加
- **失败**：检测到无法下载时立即追加

### 记录内容
| 字段 | 成功记录 | 失败记录 |
|------|----------|----------|
| 序号 | ✅ | ✅ |
| 标题 | ✅ | ✅ |
| 作者 | ✅ | - |
| 期刊 | ✅ | - |
| 年份 | ✅ | - |
| 文件名 | ✅ | - |
| 详情页URL | - | ✅ |
| 失败原因 | - | ✅ |
| 时间戳 | ✅ | ✅ |

---

## 浏览器使用规范

### 实例管理
- ✅ 单实例复用：整个检索流程只打开一次浏览器
- ✅ 及时释放：所有下载完成后关闭浏览器
- ❌ 禁止：每篇论文都重新打开浏览器

### 操作间隔
- 每次操作间隔 2-3 秒
- 单次下载不超过 10 篇
- 避免频繁刷新页面

---

## 常见问题处理

| 问题 | 解决方案 |
|------|----------|
| 页面内容过大 | 使用 JavaScript 提取而非 snapshot |
| 找不到 PDF 按钮 | 记录到失败文档，继续下一篇 |
| 下载文件位置 | 检查 `~/Downloads/` 目录 |
| 需要额外登录 | 记录失败原因为 NEED_LOGIN |
| VPN断开 | 暂停操作，提示用户重新连接 |
