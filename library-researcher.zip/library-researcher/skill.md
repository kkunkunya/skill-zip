---
name: library-researcher
description: 学术文献搜索下载工具（简化版）。假设用户已完成登录，直接在学校发现系统执行搜索和下载。
trigger_keywords:
  - 搜索论文
  - 下载文献
  - 学术检索
  - 图书馆搜索
  - 文献检索
  - 找论文
---

# Library Researcher - 简化版

通过 Playwright MCP 浏览器自动化，在学校图书馆发现系统中检索文献并下载 PDF。

## 前置条件（用户手动完成）

在使用此技能前，用户必须已完成：
- ✅ VPN 已连接
- ✅ 校园网已登录
- ✅ 图书馆系统已登录
- ✅ 浏览器会话已就绪

---

## Phase 1: 参数确认

仅确认搜索关键词，其他使用默认值：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 搜索关键词 | 支持中英文组合 | **必填** |
| 下载数量 | 目标论文数量 | 10篇 |

**关键词组合策略**：
- ✅ 组合搜索更精准：`电缆故障 CNN` 比单独搜索 `电缆故障` 更好
- ✅ 添加技术限定：`行波 深度学习 高电压技术`

---

## Phase 2: 直接搜索

### 2.1 导航到固定入口

```
http://fx.shieplib.chaoxing.com/s?strchoren=1&size=15&isort=1&strchannel=&x=914_1948&sw=ppo
```

### 2.2 执行搜索

```javascript
// 在搜索框输入关键词
await page.getByRole('textbox').fill('用户提供的关键词');
await page.getByRole('button', { name: '检索' }).click();
await page.waitForTimeout(3000);
```

### 2.3 提取搜索结果

```javascript
// 使用 JavaScript 提取结果列表
const results = await page.evaluate(() => {
  const links = Array.from(document.querySelectorAll('a'));
  return links.filter(a => {
    const text = a.textContent || '';
    const href = a.href || '';
    return text.length > 10 && text.length < 200 &&
           (href.includes('detail') || href.includes('view'));
  }).slice(0, 15).map(a => ({
    title: a.textContent.trim().substring(0, 100),
    link: a.href
  }));
});
```

---

## Phase 3: 遍历结果并下载

对每条搜索结果执行以下流程：

### 3.1 打开详情页

```javascript
await page.goto(result.link);
await page.waitForTimeout(2000);
```

### 3.2 检测下载按钮

```javascript
const downloadInfo = await page.evaluate(() => {
  const links = Array.from(document.querySelectorAll('a'));
  return links.filter(a => {
    const text = a.textContent || '';
    const href = a.href || '';
    return text.includes('PDF') || text.includes('下载') || href.includes('goread');
  }).map(a => ({
    text: a.textContent.trim(),
    href: a.href
  }));
});
```

### 3.3 下载策略（三分支）

| 情况 | 操作 |
|------|------|
| **有直接下载按钮** | 立即点击下载 |
| **无直接下载按钮** | 暂停，保持页面，通知用户手动操作 |
| **下载完成后** | 等待用户通知"可继续"，然后处理下一篇 |

**有下载按钮时**：
```javascript
// 点击下载
await page.goto(downloadInfo[0].href);
await page.waitForTimeout(5000);
```

**无下载按钮时**：
```
⏸️ 暂停操作

当前论文：[论文标题]
详情页已打开，但未找到直接下载按钮。

请手动操作：
1. 查看页面是否有其他下载入口
2. 完成下载后，回复"可继续"

等待用户指令...
```

---

## Phase 4: 等待与重命名

### 4.1 等待用户通知

当所有可自动下载的论文处理完毕，或遇到需要手动操作的情况时：

```
📋 当前进度汇报

已自动下载：X 篇
需手动处理：Y 篇

请完成手动下载后，回复"可继续"进行统一重命名。
```

### 4.2 统一重命名

用户通知"可继续"后，对 `~/Downloads/` 中的新下载文件进行重命名：

**命名格式**：`文献名_期刊_作者.pdf`

```bash
# 示例
mv ~/Downloads/原始文件名.pdf ~/Downloads/基于Transformer的电缆故障定位_高电压技术_张三.pdf
```

**命名规范**：
- 文献名：论文标题的核心关键词（20字以内）
- 期刊：期刊简称
- 作者：第一作者姓名
- 保存位置：`~/Downloads/`

---

## 完成汇报

```
✅ 文献检索完成

- 检索平台: 学校图书馆发现系统
- 搜索关键词: [用户关键词]
- 成功下载: X 篇
- 手动处理: Y 篇
- 保存位置: ~/Downloads/

📄 下载文件列表：
1. 文献名_期刊_作者.pdf
2. ...
```

---

## 常见问题处理

| 问题 | 解决方案 |
|------|----------|
| 页面内容过大 | 使用 JavaScript 提取而非 snapshot |
| 找不到 PDF 按钮 | 暂停，交给用户手动操作 |
| 下载文件位置 | 检查 `~/Downloads/` 目录 |
| 需要额外登录 | 暂停，通知用户手动完成后继续 |

---

## 浏览器使用规范

### 实例管理
- ✅ 单实例复用：整个检索流程只打开一次浏览器
- ✅ 及时释放：所有下载完成后关闭浏览器
- ❌ 禁止：每篇论文都重新打开浏览器

### 操作间隔
- 每次操作间隔 2-3 秒
- 单次下载不超过 10 篇
- 避免频繁刷新页面
