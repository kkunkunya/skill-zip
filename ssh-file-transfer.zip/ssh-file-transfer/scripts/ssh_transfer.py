#!/usr/bin/env python3
"""SSH File Sync - Pack & SCP approach.

Packages local files and generates scp commands for reliable transfer.
Replaces unreliable base64-over-SSH-exec method.

Usage:
  # Single file → direct scp command
  python3 ssh_transfer.py pack file.py -r /remote/dir/ --host root@host -p 38708

  # Multiple files → tar.gz + scp
  python3 ssh_transfer.py pack a.py b.py -r /remote/dir/ --host root@host -p 38708

  # Directory → tar.gz + scp
  python3 ssh_transfer.py pack-dir ./src/ -r /remote/src/ --host root@host -p 38708

  # Tar streaming (best for many small files)
  python3 ssh_transfer.py tar-stream ./src/ -r /remote/src/ --host root@host -p 38708

  # Download file/dir from server
  python3 ssh_transfer.py download /remote/file ./local/ --host root@host -p 38708

  # Decode base64 downloaded from server
  python3 ssh_transfer.py decode @/tmp/b64.txt /local/dest.py
"""

import argparse
import base64
import hashlib
import os
import subprocess
import sys
from pathlib import Path


def _md5_file(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def pack_files(files: list, remote_dir: str, host: str, port: int) -> None:
    """Pack files and print scp + unpack commands."""
    paths = []
    for f in files:
        p = Path(f).expanduser().resolve()
        if not p.exists():
            print(f"  SKIP: {p} not found", file=sys.stderr)
            continue
        paths.append(p)

    if not paths:
        print("Error: no valid files", file=sys.stderr)
        sys.exit(1)

    remote_dir = remote_dir.rstrip("/")

    if len(paths) == 1:
        # Single file → direct scp (no packing needed)
        p = paths[0]
        remote_path = f"{remote_dir}/{p.name}"
        scp = f"scp -P {port} '{p}' {host}:{remote_path}"
        verify = f"md5sum {remote_path}"

        print(f"\n{'='*50}")
        print(f"  单文件直传: {p.name}")
        print(f"  大小: {p.stat().st_size:,} bytes")
        print(f"  MD5:  {_md5_file(p)}")
        print(f"{'='*50}")
        print(f"\n[用户终端执行]:")
        print(f"  {scp}")
        print(f"\n[SSH验证] (Claude exec):")
        print(f"  {verify}")
        print()
    else:
        # Multiple files → tar.gz
        common = Path(os.path.commonpath([p.parent for p in paths]))
        rel = [str(p.relative_to(common)) for p in paths]

        archive = Path(f"/tmp/ssh_upload_{os.getpid()}.tar.gz")
        subprocess.run(
            ["tar", "czf", str(archive), "-C", str(common)] + rel,
            check=True,
        )

        remote_tmp = f"/tmp/{archive.name}"
        scp = f"scp -P {port} '{archive}' {host}:{remote_tmp}"
        unpack = (
            f"mkdir -p {remote_dir} && "
            f"tar xzf {remote_tmp} -C {remote_dir} && "
            f"rm -f {remote_tmp} && echo 'OK: {len(paths)} files unpacked'"
        )

        print(f"\n{'='*50}")
        print(f"  多文件打包: {len(paths)} files → {archive.stat().st_size:,} bytes")
        for p, r in zip(paths, rel):
            print(f"    {r} ({p.stat().st_size:,}B, md5:{_md5_file(p)[:8]}..)")
        print(f"{'='*50}")
        print(f"\n[用户终端执行]:")
        print(f"  {scp}")
        print(f"\n[SSH解压] (Claude exec):")
        print(f"  {unpack}")
        print()


def pack_dir(local_dir: str, remote_dir: str, host: str, port: int) -> None:
    """Pack directory and print scp + unpack commands."""
    src = Path(local_dir).expanduser().resolve()
    if not src.is_dir():
        print(f"Error: {src} is not a directory", file=sys.stderr)
        sys.exit(1)

    archive = Path(f"/tmp/ssh_upload_{src.name}_{os.getpid()}.tar.gz")
    subprocess.run(
        ["tar", "czf", str(archive), "-C", str(src.parent), src.name],
        check=True,
    )

    remote_dir = remote_dir.rstrip("/")
    remote_tmp = f"/tmp/{archive.name}"
    parent = str(Path(remote_dir).parent)

    scp = f"scp -P {port} '{archive}' {host}:{remote_tmp}"
    unpack = (
        f"rm -rf {remote_dir} && mkdir -p {parent} && "
        f"tar xzf {remote_tmp} -C {parent} && "
        f"rm -f {remote_tmp} && "
        f"echo 'OK' && ls {remote_dir} | head -10"
    )

    n_files = sum(1 for _ in src.rglob("*") if _.is_file())

    print(f"\n{'='*50}")
    print(f"  目录: {src.name}/ ({n_files} files)")
    print(f"  压缩: {archive.stat().st_size:,} bytes")
    print(f"{'='*50}")
    print(f"\n[用户终端执行]:")
    print(f"  {scp}")
    print(f"\n[SSH解压] (Claude exec):")
    print(f"  {unpack}")
    print()


def decode_to_file(b64_input: str, output_path: str) -> None:
    """Decode base64 string (or @file) to output file."""
    if b64_input.startswith("@"):
        b64 = Path(b64_input[1:]).read_text().strip()
    else:
        b64 = b64_input.strip()

    data = base64.b64decode(b64)
    out = Path(output_path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    md5 = hashlib.md5(data).hexdigest()
    print(f"Decoded {len(data)} bytes -> {out} (md5: {md5})")


def tar_stream(local_dir: str, remote_dir: str, host: str, port: int) -> None:
    """Generate tar streaming command (best for many small files)."""
    src = Path(local_dir).expanduser().resolve()
    if not src.is_dir():
        print(f"Error: {src} is not a directory", file=sys.stderr)
        sys.exit(1)

    remote_dir = remote_dir.rstrip("/")
    n_files = sum(1 for _ in src.rglob("*") if _.is_file())

    # 生成 tar 流式命令（COPYFILE_DISABLE=1 避免 macOS ._文件）
    cmd = (
        f"cd '{src}' && COPYFILE_DISABLE=1 tar cf - * | "
        f"ssh -p {port} {host} "
        f"\"mkdir -p {remote_dir} && cd {remote_dir} && tar xf -\""
    )

    print(f"\n{'='*50}")
    print(f"  Tar 流式传输: {src.name}/ ({n_files} files)")
    print(f"  远端目标: {remote_dir}")
    print(f"  ⚡ 无中间文件，直接管道传输")
    print(f"{'='*50}")
    print(f"\n[用户终端执行]:")
    print(f"  {cmd}")
    print(f"\n[SSH验证] (Claude exec):")
    print(f"  ls {remote_dir} | head -10")
    print()


def download(remote_path: str, local_path: str, host: str, port: int) -> None:
    """Generate scp download command."""
    local = Path(local_path).expanduser().resolve()
    remote_path = remote_path.rstrip("/")

    # 判断远端是否为目录（以 / 结尾或无扩展名）
    is_dir = "/" in remote_path.split("/")[-1] == "" or "." not in remote_path.split("/")[-1]

    if is_dir:
        flag = "-rP"
        desc = "目录下载"
    else:
        flag = "-P"
        desc = "单文件下载"

    scp = f"scp {flag} {port} {host}:{remote_path} '{local}/'"

    print(f"\n{'='*50}")
    print(f"  {desc}: {remote_path}")
    print(f"  本地目标: {local}")
    if is_dir:
        print(f"  ⚠️  注意: 是 -rP（大写P），不是 -rp！")
    print(f"{'='*50}")
    print(f"\n[用户终端执行]:")
    print(f"  {scp}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="SSH File Sync - Pack & SCP",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="action")

    # Pack files
    pk = sub.add_parser("pack", help="Pack files for scp upload")
    pk.add_argument("files", nargs="+", help="Local file paths")
    pk.add_argument("-r", "--remote-dir", required=True)
    pk.add_argument("--host", default="USER@HOST")
    pk.add_argument("-p", "--port", type=int, default=22)

    # Pack directory
    pd_cmd = sub.add_parser("pack-dir", help="Pack directory for scp upload")
    pd_cmd.add_argument("local_dir")
    pd_cmd.add_argument("-r", "--remote-dir", required=True)
    pd_cmd.add_argument("--host", default="USER@HOST")
    pd_cmd.add_argument("-p", "--port", type=int, default=22)

    # Tar stream (best for many small files)
    ts = sub.add_parser("tar-stream", help="Tar streaming for many small files")
    ts.add_argument("local_dir")
    ts.add_argument("-r", "--remote-dir", required=True)
    ts.add_argument("--host", default="USER@HOST")
    ts.add_argument("-p", "--port", type=int, default=22)

    # Download
    dl = sub.add_parser("download", help="Generate scp download command")
    dl.add_argument("remote_path", help="Remote file/dir path")
    dl.add_argument("local_path", help="Local destination path")
    dl.add_argument("--host", default="USER@HOST")
    dl.add_argument("-p", "--port", type=int, default=22)

    # Decode
    dec = sub.add_parser("decode", help="Decode base64 to local file")
    dec.add_argument("b64_input", help="Base64 string or @filepath")
    dec.add_argument("output_path")

    args = parser.parse_args()

    if args.action == "pack":
        pack_files(args.files, args.remote_dir, args.host, args.port)
    elif args.action == "pack-dir":
        pack_dir(args.local_dir, args.remote_dir, args.host, args.port)
    elif args.action == "tar-stream":
        tar_stream(args.local_dir, args.remote_dir, args.host, args.port)
    elif args.action == "download":
        download(args.remote_path, args.local_path, args.host, args.port)
    elif args.action == "decode":
        decode_to_file(args.b64_input, args.output_path)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
