#!/usr/bin/env python3
"""SSH General Ops command generator.

Hybrid workflow:
1) LLM produces a structured plan (JSON)
2) This script compiles the plan into deterministic commands and validation steps

The script can also be used directly with legacy subcommands.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path
from typing import Any

DATASET_EXCLUDES = [
    "data/",
    "dataset/",
    "datasets/",
    "**/data/",
    "**/dataset/",
    "**/datasets/",
]

ROUTE_TO_ACTION = {
    "ssh_exec": "exec",
    "scp": "scp-upload",
    "tar_stream": "tar-stream",
    "rsync": "rsync-sync",
}

VALID_ACTIONS = {
    "connect-test",
    "exec",
    "scp-upload",
    "scp-download",
    "rsync-sync",
    "tar-stream",
    "remote-fetch",
    "port-forward",
    "ops-check",
}


def q(value: str | Path) -> str:
    return shlex.quote(str(value))


def to_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        s = value.strip().lower()
        if s in {"1", "true", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "no", "n", "off"}:
            return False
    raise ValueError(f"无法解析布尔值: {value!r}")


def to_int(value: Any, *, default: int | None = None, name: str = "value") -> int:
    if value is None:
        if default is None:
            raise ValueError(f"{name} 不能为空")
        return default
    try:
        return int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} 必须是整数，收到: {value!r}") from exc


def validate_port(port: int) -> int:
    if not (1 <= port <= 65535):
        raise ValueError(f"port 超出范围: {port}")
    return port


def contains_dataset_path(path_like: str) -> bool:
    lowered = path_like.replace("\\", "/").lower()
    parts = [part for part in lowered.split("/") if part]
    return any(part in {"data", "dataset", "datasets"} for part in parts)


def extract_first_json_object(text: str) -> str:
    """从可能夹杂说明文字的输出中提取第一个 JSON 对象。"""
    start = text.find("{")
    if start < 0:
        raise ValueError("未找到 JSON 对象起始符号 '{'")

    depth = 0
    in_str = False
    escape = False
    for idx in range(start, len(text)):
        ch = text[idx]
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue

        if ch == '"':
            in_str = True
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : idx + 1]

    raise ValueError("JSON 对象不完整，缺少右花括号 '}'")


def md5_file(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()  # noqa: S324


def with_sshpass(cmd: str, password: str | None) -> str:
    if not password:
        return cmd
    return f"sshpass -p {q(password)} {cmd}"


def strip_code_fence(text: str) -> str:
    s = text.strip()
    if s.startswith("```") and s.endswith("```"):
        lines = s.splitlines()
        if len(lines) >= 2:
            return "\n".join(lines[1:-1]).strip()
    return s


def read_text_input(value: str) -> str:
    if value == "-":
        return sys.stdin.read()
    if value.startswith("@"):
        return Path(value[1:]).read_text(encoding="utf-8")
    p = Path(value)
    if p.exists() and p.is_file():
        return p.read_text(encoding="utf-8")
    return value


def ssh_base(host: str, port: int, strict: bool = True, timeout: int | None = None) -> str:
    opts: list[str] = [f"-p {port}"]
    if strict:
        opts.extend(["-o StrictHostKeyChecking=no", "-o UserKnownHostsFile=/dev/null"])
    if timeout:
        opts.append(f"-o ConnectTimeout={int(timeout)}")
    return f"ssh {' '.join(opts)} {host}"


def build_ssh_exec(host: str, port: int, command: str, *, strict: bool, password: str | None, timeout: int | None = None) -> str:
    base = ssh_base(host, port, strict=strict, timeout=timeout)
    return with_sshpass(f"{base} {q(command)}", password)


def build_scp(
    sources: list[str],
    target: str,
    *,
    port: int,
    recursive: bool,
    strict: bool,
    password: str | None,
) -> str:
    flags: list[str] = []
    if recursive:
        flags.append("-r")
    flags.extend(["-P", str(port)])
    if strict:
        flags.extend(["-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null"])

    cmd = " ".join(["scp", *flags, *(q(s) for s in sources), target])
    return with_sshpass(cmd, password)


def build_rsync(
    src: str,
    dst: str,
    *,
    host: str,
    port: int,
    direction: str,
    strict: bool,
    password: str | None,
    dry_run: bool,
    delete: bool,
    include_datasets: bool,
) -> str:
    parts: list[str] = ["rsync", "-avz", "--progress", "--partial"]
    if dry_run:
        parts.append("--dry-run")
    if delete:
        parts.append("--delete")

    if direction == "upload" and not include_datasets:
        for pattern in DATASET_EXCLUDES:
            parts.append(f"--exclude={q(pattern)}")

    ssh_inner = ssh_base("HOST_PLACEHOLDER", port, strict=strict).replace(" HOST_PLACEHOLDER", "")
    parts.extend(["-e", q(ssh_inner)])

    if direction == "upload":
        src_spec = q(src)
        dst_spec = f"{host}:{q(dst)}"
    else:
        src_spec = f"{host}:{q(src)}"
        dst_spec = q(dst)

    parts.extend([src_spec, dst_spec])
    return with_sshpass(" ".join(parts), password)


def build_tar_stream(
    local_dir: str,
    remote_dir: str,
    *,
    host: str,
    port: int,
    strict: bool,
    password: str | None,
    include_datasets: bool,
) -> str:
    src = Path(local_dir).expanduser().resolve()
    tar_excludes: list[str] = []
    if not include_datasets:
        for name in ["data", "dataset", "datasets"]:
            tar_excludes.extend(["--exclude", q(name)])

    remote_cmd = f"mkdir -p {q(remote_dir)} && cd {q(remote_dir)} && tar xf -"
    ssh_part = build_ssh_exec(host, port, remote_cmd, strict=strict, password=password)
    return f"cd {q(src)} && COPYFILE_DISABLE=1 tar cf - {' '.join(tar_excludes)} . | {ssh_part}"


def print_header(title: str) -> None:
    print(f"\n{'=' * 60}")
    print(f"  {title}")
    print(f"{'=' * 60}")


def normalize_plan(raw: dict[str, Any]) -> dict[str, Any]:
    plan = dict(raw)
    params = dict(plan.get("params") or {})

    action = plan.get("action")
    route = plan.get("route")
    direction = plan.get("direction") or params.get("direction")

    if not action and route:
        action = ROUTE_TO_ACTION.get(str(route), str(route))
        if action == "scp-upload" and direction == "download":
            action = "scp-download"

    if not action:
        raise ValueError("plan 缺少 action（或 route）")

    if action == "scp":
        action = "scp-download" if direction == "download" else "scp-upload"

    action = str(action).strip()
    if action not in VALID_ACTIONS:
        raise ValueError(f"不支持的 action: {action}")

    merged = {
        "action": action,
        "host": plan.get("host") or params.get("host"),
        "port": validate_port(to_int(plan.get("port", params.get("port", 22)), name="port")),
        "strict": to_bool(plan.get("strict", params.get("strict", True)), default=True),
        "password": plan.get("password") or params.get("password"),
        "include_datasets": to_bool(
            plan.get("include_datasets", params.get("include_datasets", False)),
            default=False,
        ),
        "params": params,
    }

    # Backward-compatible top-level params
    for key in [
        "src",
        "dst",
        "dry_run",
        "delete",
        "remote_dir",
        "local_dir",
        "remote_path",
        "local_path",
        "kind",
        "command",
        "timeout",
        "url",
        "tool",
        "sources",
        "target_dir",
        "recursive",
        "local_port",
        "remote_host",
        "remote_port",
        "service_name",
        "log_path",
        "port_check",
        "force_replace",
    ]:
        if key in plan and key not in merged["params"]:
            merged["params"][key] = plan[key]

    return merged


def _get_required(plan: dict[str, Any], key: str) -> str:
    value = plan.get(key)
    if value is None or str(value).strip() == "":
        raise ValueError(f"plan 缺少字段: {key}")
    return str(value)


def compile_plan_to_commands(plan: dict[str, Any]) -> dict[str, Any]:
    action = plan["action"]
    host = _get_required(plan, "host")
    port = validate_port(to_int(plan.get("port", 22), name="port"))
    strict = to_bool(plan.get("strict", True), default=True)
    password = plan.get("password")
    include_datasets = to_bool(plan.get("include_datasets", False), default=False)
    p = plan.get("params", {})

    commands: list[str] = []
    verify: list[str] = []
    notes: list[str] = []

    if not include_datasets and action in {"rsync-sync", "tar-stream", "scp-upload"}:
        notes.append("默认排除数据集目录（data/dataset/datasets）。")

    if action == "connect-test":
        timeout = to_int(p.get("timeout", 5), name="timeout")
        commands.append(build_ssh_exec(host, port, "echo ok", strict=strict, password=password, timeout=timeout))
        verify.append("返回值包含 ok")

    elif action == "exec":
        command = p.get("command")
        if not command:
            raise ValueError("exec 需要 params.command")
        timeout = p.get("timeout")
        commands.append(build_ssh_exec(host, port, str(command), strict=strict, password=password, timeout=timeout))
        verify.append("确认命令退出码为 0")

    elif action == "scp-upload":
        sources = p.get("sources")
        if not sources:
            single = p.get("src")
            sources = [single] if single else []
        if isinstance(sources, str):
            sources = [sources]
        if not isinstance(sources, list):
            raise ValueError("scp-upload 的 sources 必须是数组或字符串")
        if not sources:
            raise ValueError("scp-upload 需要 params.sources 或 src")
        source_list = [str(item) for item in sources]
        if not include_datasets:
            hit = next((s for s in source_list if contains_dataset_path(s)), None)
            if hit:
                raise ValueError(
                    f"检测到数据集路径 {hit!r}，默认策略禁止传输。若确需传输，请设置 include_datasets=true。"
                )
        target_dir = p.get("target_dir") or p.get("dst") or "/root/autodl-tmp/"
        recursive = to_bool(p.get("recursive", False), default=False)
        commands.append(
            build_scp(
                source_list,
                f"{host}:{q(str(target_dir))}",
                port=port,
                recursive=recursive,
                strict=strict,
                password=password,
            )
        )
        sample = Path(source_list[0]).name
        verify.append(build_ssh_exec(host, port, f"ls -lh {str(target_dir).rstrip('/')}/{sample}", strict=strict, password=password))

    elif action == "scp-download":
        remote_path = p.get("remote_path") or p.get("src")
        local_path = p.get("local_path") or p.get("dst")
        if not remote_path or not local_path:
            raise ValueError("scp-download 需要 remote_path/local_path（或 src/dst）")
        kind = str(p.get("kind", "auto"))
        if kind == "auto":
            basename = Path(str(remote_path).rstrip("/")).name
            is_dir = str(remote_path).endswith("/") or "." not in basename
        else:
            is_dir = kind == "dir"

        commands.append(
            build_scp(
                [f"{host}:{q(str(remote_path).rstrip('/'))}"],
                q(str(local_path)),
                port=port,
                recursive=is_dir,
                strict=strict,
                password=password,
            )
        )
        verify.append(f"本地检查目标路径: {local_path}")

    elif action == "rsync-sync":
        src = p.get("src")
        dst = p.get("dst")
        if not src or not dst:
            raise ValueError("rsync-sync 需要 src 和 dst")
        direction = str(p.get("direction", "upload")).strip().lower()
        if direction not in {"upload", "download"}:
            raise ValueError(f"direction 只能是 upload/download，收到: {direction!r}")
        dry_run = to_bool(p.get("dry_run", True), default=True)
        delete = to_bool(p.get("delete", False), default=False)

        commands.append(
            build_rsync(
                str(src),
                str(dst),
                host=host,
                port=port,
                direction=direction,
                strict=strict,
                password=password,
                dry_run=dry_run,
                delete=delete,
                include_datasets=include_datasets,
            )
        )
        if dry_run:
            commands.append(
                build_rsync(
                    str(src),
                    str(dst),
                    host=host,
                    port=port,
                    direction=direction,
                    strict=strict,
                    password=password,
                    dry_run=False,
                    delete=delete,
                    include_datasets=include_datasets,
                )
            )
        verify.append("先检查 dry-run 输出，再执行正式同步")
        if direction == "upload":
            verify.append(build_ssh_exec(host, port, f"ls -la {str(dst)} | head", strict=strict, password=password))

    elif action == "tar-stream":
        local_dir = p.get("local_dir") or p.get("src")
        remote_dir = p.get("remote_dir") or p.get("dst")
        if not local_dir or not remote_dir:
            raise ValueError("tar-stream 需要 local_dir/remote_dir（或 src/dst）")
        commands.append(
            build_tar_stream(
                str(local_dir),
                str(remote_dir),
                host=host,
                port=port,
                strict=strict,
                password=password,
                include_datasets=include_datasets,
            )
        )
        verify.append(build_ssh_exec(host, port, f"ls -la {str(remote_dir)} | head", strict=strict, password=password))

    elif action == "remote-fetch":
        url = p.get("url")
        if not url:
            raise ValueError("remote-fetch 需要 params.url")
        remote_dir = str(p.get("remote_dir", "/root/autodl-fs/datasets"))
        tool = str(p.get("tool", "wget"))
        if tool == "aria2c":
            cmd = f"mkdir -p {q(remote_dir)} && cd {q(remote_dir)} && aria2c -c -x 16 -s 16 -k 1M {q(str(url))}"
        else:
            cmd = f"mkdir -p {q(remote_dir)} && cd {q(remote_dir)} && wget -c {q(str(url))}"
        commands.append(build_ssh_exec(host, port, cmd, strict=strict, password=password))
        verify.append(build_ssh_exec(host, port, f"ls -lh {q(remote_dir)} | head", strict=strict, password=password))

    elif action == "port-forward":
        local_port = to_int(p.get("local_port"), name="local_port")
        remote_port = to_int(p.get("remote_port"), name="remote_port")
        validate_port(local_port)
        validate_port(remote_port)
        remote_host = str(p.get("remote_host", "127.0.0.1"))
        ssh = ssh_base(host, port, strict=strict)
        tunnel = f"ssh -L {local_port}:{remote_host}:{remote_port} {ssh[len('ssh '):]}"
        commands.append(tunnel)
        verify.append(f"本地访问: http://127.0.0.1:{local_port}")

    elif action == "ops-check":
        service_name = p.get("service_name")
        log_path = p.get("log_path")
        port_check = p.get("port_check")
        commands.append(build_ssh_exec(host, port, "ps -ef | rg 'python|service|train'", strict=strict, password=password))
        if service_name:
            commands.append(
                build_ssh_exec(host, port, f"systemctl status {service_name} --no-pager", strict=strict, password=password)
            )
        if log_path:
            commands.append(build_ssh_exec(host, port, f"tail -n 200 {log_path}", strict=strict, password=password))
        if port_check:
            commands.append(build_ssh_exec(host, port, f"ss -lntp | rg ':{port_check}'", strict=strict, password=password))
        verify.append("检查是否有异常退出、端口占用冲突、日志报错")

    else:
        raise ValueError(f"不支持的 action: {action}")

    return {"plan": plan, "commands": commands, "verify": verify, "notes": notes}


def parse_plan_input(raw_input: str) -> dict[str, Any]:
    content = strip_code_fence(read_text_input(raw_input))
    try:
        parsed = json.loads(content)
    except json.JSONDecodeError as exc:
        # 容错：允许 LLM 前后带说明文字，只提取首个 JSON 对象。
        try:
            parsed = json.loads(extract_first_json_object(content))
        except Exception as recover_exc:  # noqa: BLE001
            raise ValueError(f"计划 JSON 解析失败: {exc}") from recover_exc
    if not isinstance(parsed, dict):
        raise ValueError("计划必须是 JSON 对象")
    return normalize_plan(parsed)


def print_compiled_text(result: dict[str, Any]) -> None:
    plan = result["plan"]
    notes = result["notes"]
    commands = result["commands"]
    verify = result["verify"]

    print_header("LLM Plan -> Deterministic Commands")
    print(f"action: {plan['action']}")
    print(f"target: {plan['host']}:{plan['port']}")

    if notes:
        print("\n[策略提示]:")
        for item in notes:
            print(f"- {item}")

    print("\n[可执行命令]:")
    for idx, cmd in enumerate(commands, start=1):
        print(f"{idx}. {cmd}")

    print("\n[最小验证]:")
    for idx, step in enumerate(verify, start=1):
        print(f"{idx}. {step}")


def compile_plan(raw_input: str, fmt: str) -> None:
    plan = parse_plan_input(raw_input)
    result = compile_plan_to_commands(plan)
    if fmt == "json":
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print_compiled_text(result)


def print_plan_example() -> None:
    example = {
        "action": "rsync-sync",
        "host": "root@server",
        "port": 22,
        "strict": True,
        "password": "<optional>",
        "include_datasets": False,
        "params": {
            "src": "./local_project/",
            "dst": "/root/autodl-tmp/staging/",
            "direction": "upload",
            "dry_run": True,
            "delete": False,
        },
    }
    print(json.dumps(example, ensure_ascii=False, indent=2))


def run_self_test() -> None:
    """轻量自测：覆盖关键容错和策略逻辑。"""
    tests: list[tuple[str, bool]] = []

    # 1) 字符串布尔值解析
    tests.append(("bool-true", to_bool("true", default=False) is True))
    tests.append(("bool-false", to_bool("false", default=True) is False))

    # 2) route -> action 兼容映射
    mapped = normalize_plan(
        {
            "route": "rsync",
            "host": "root@server",
            "port": "22",
            "direction": "upload",
            "src": "./a",
            "dst": "/root/b",
        }
    )
    tests.append(("route-mapping", mapped["action"] == "rsync-sync"))

    # 3) 噪声文本 JSON 提取
    noisy = "说明文字\\n```json\\n{\"action\":\"exec\",\"host\":\"root@server\",\"port\":22,\"params\":{\"command\":\"echo ok\"}}\\n```\\n结尾"
    parsed = parse_plan_input(noisy)
    tests.append(("noisy-json-parse", parsed["action"] == "exec"))

    # 4) 默认数据集策略拦截（scp-upload）
    blocked = False
    try:
        compile_plan_to_commands(
            normalize_plan(
                {
                    "action": "scp-upload",
                    "host": "root@server",
                    "port": 22,
                    "params": {"sources": ["./datasets/train.csv"], "target_dir": "/root/autodl-tmp/"},
                }
            )
        )
    except ValueError:
        blocked = True
    tests.append(("dataset-guard", blocked))

    # 5) rsync dry-run 生成双命令
    rs = compile_plan_to_commands(
        normalize_plan(
            {
                "action": "rsync-sync",
                "host": "root@server",
                "port": 22,
                "params": {"src": "./a/", "dst": "/root/b/", "direction": "upload", "dry_run": True},
            }
        )
    )
    tests.append(("rsync-two-commands", len(rs["commands"]) == 2))

    failed = [name for name, ok in tests if not ok]
    if failed:
        raise ValueError(f"自测失败: {', '.join(failed)}")

    print_header("Self Test")
    print(f"passed: {len(tests)}")
    for name, _ in tests:
        print(f"- {name}: ok")


# ---------- Legacy deterministic actions ----------

def connect_test(host: str, port: int, password: str | None, timeout: int, strict: bool) -> None:
    print_header("SSH 连通性测试")
    print("[执行命令]:")
    print(f"  {build_ssh_exec(host, port, 'echo ok', strict=strict, password=password, timeout=timeout)}")


def pack_files(files: list[str], remote_dir: str, host: str, port: int, password: str | None, strict: bool) -> None:
    paths: list[Path] = []
    for item in files:
        p = Path(item).expanduser().resolve()
        if not p.exists() or not p.is_file():
            print(f"SKIP: not a file -> {p}", file=sys.stderr)
            continue
        paths.append(p)

    if not paths:
        raise SystemExit("Error: no valid files to upload")

    remote_dir = remote_dir.rstrip("/")

    if len(paths) == 1:
        local = paths[0]
        remote_path = f"{remote_dir}/{local.name}"
        upload = build_scp([str(local)], f"{host}:{q(remote_path)}", port=port, recursive=False, strict=strict, password=password)
        verify = build_ssh_exec(host, port, f"ls -lh {remote_path} && md5sum {remote_path}", strict=strict, password=password)
        print_header(f"单文件上传: {local.name}")
        print(f"size: {local.stat().st_size:,} bytes")
        print(f"md5:  {md5_file(local)}")
        print("\n[上传命令]:")
        print(f"  {upload}")
        print("\n[验证命令]:")
        print(f"  {verify}")
        return

    common_root = Path(os.path.commonpath([p.parent for p in paths]))
    relative_paths = [str(p.relative_to(common_root)) for p in paths]
    archive = Path(f"/tmp/ssh_upload_{os.getpid()}.tar.gz")
    subprocess.run(["tar", "czf", str(archive), "-C", str(common_root), *relative_paths], check=True)

    remote_tmp = f"/tmp/{archive.name}"
    upload = build_scp([str(archive)], f"{host}:{q(remote_tmp)}", port=port, recursive=False, strict=strict, password=password)
    unpack = build_ssh_exec(
        host,
        port,
        f"mkdir -p {remote_dir} && tar xzf {remote_tmp} -C {remote_dir} && rm -f {remote_tmp} && echo OK",
        strict=strict,
        password=password,
    )

    print_header(f"多文件上传打包: {len(paths)} files")
    print(f"archive: {archive} ({archive.stat().st_size:,} bytes)")
    print("\n[上传命令]:")
    print(f"  {upload}")
    print("\n[远端解压]:")
    print(f"  {unpack}")


def pack_dir(
    local_dir: str,
    remote_dir: str,
    host: str,
    port: int,
    password: str | None,
    strict: bool,
    force_replace: bool,
) -> None:
    src = Path(local_dir).expanduser().resolve()
    if not src.is_dir():
        raise SystemExit(f"Error: {src} is not a directory")

    archive = Path(f"/tmp/ssh_upload_{src.name}_{os.getpid()}.tar.gz")
    subprocess.run(["tar", "czf", str(archive), "-C", str(src.parent), src.name], check=True)

    remote_dir = remote_dir.rstrip("/")
    parent = str(Path(remote_dir).parent)
    remote_tmp = f"/tmp/{archive.name}"

    upload = build_scp([str(archive)], f"{host}:{q(remote_tmp)}", port=port, recursive=False, strict=strict, password=password)
    reset = f"rm -rf {q(remote_dir)} && " if force_replace else ""
    unpack = build_ssh_exec(
        host,
        port,
        f"{reset}mkdir -p {q(parent)} && tar xzf {q(remote_tmp)} -C {q(parent)} && rm -f {q(remote_tmp)} && ls -la {q(remote_dir)} | head",
        strict=strict,
        password=password,
    )

    n_files = sum(1 for item in src.rglob("*") if item.is_file())
    print_header(f"目录上传打包: {src.name}/ ({n_files} files)")
    print(f"archive: {archive} ({archive.stat().st_size:,} bytes)")
    if force_replace:
        print("warning: force_replace=True will remove remote target first")
    print("\n[上传命令]:")
    print(f"  {upload}")
    print("\n[远端解压]:")
    print(f"  {unpack}")


def tar_stream(
    local_dir: str,
    remote_dir: str,
    host: str,
    port: int,
    password: str | None,
    strict: bool,
    include_datasets: bool,
) -> None:
    src = Path(local_dir).expanduser().resolve()
    if not src.is_dir():
        raise SystemExit(f"Error: {src} is not a directory")

    cmd = build_tar_stream(
        str(src),
        remote_dir.rstrip("/"),
        host=host,
        port=port,
        strict=strict,
        password=password,
        include_datasets=include_datasets,
    )

    n_files = sum(1 for item in src.rglob("*") if item.is_file())
    print_header(f"Tar 流式传输: {src.name}/ ({n_files} files)")
    if not include_datasets:
        print("policy: exclude data/dataset/datasets by default")
    print("\n[执行命令]:")
    print(f"  {cmd}")


def download(remote_path: str, local_path: str, host: str, port: int, password: str | None, strict: bool, kind: str) -> None:
    remote_clean = remote_path.rstrip("/")
    if kind == "auto":
        basename = Path(remote_clean).name
        is_dir = remote_path.endswith("/") or "." not in basename
    else:
        is_dir = kind == "dir"

    cmd = build_scp(
        [f"{host}:{q(remote_clean)}"],
        q(str(Path(local_path).expanduser().resolve())),
        port=port,
        recursive=is_dir,
        strict=strict,
        password=password,
    )

    print_header("远端下载")
    print(f"mode: {'目录' if is_dir else '文件'}")
    print("\n[执行命令]:")
    print(f"  {cmd}")


def decode_to_file(b64_input: str, output_path: str) -> None:
    text = Path(b64_input[1:]).read_text(encoding="utf-8").strip() if b64_input.startswith("@") else b64_input.strip()
    data = base64.b64decode(text)
    out = Path(output_path).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)

    print_header("Base64 解码")
    print(f"Decoded {len(data)} bytes -> {out}")
    print(f"MD5: {hashlib.md5(data).hexdigest()}")  # noqa: S324


def generate_exec(command: str, host: str, port: int, password: str | None, strict: bool, timeout: int | None) -> None:
    print_header("远端执行命令")
    print("[执行命令]:")
    print(f"  {build_ssh_exec(host, port, command, strict=strict, password=password, timeout=timeout)}")


def generate_rsync(
    src: str,
    dst: str,
    host: str,
    port: int,
    password: str | None,
    strict: bool,
    direction: str,
    dry_run: bool,
    delete: bool,
    include_datasets: bool,
) -> None:
    cmd = build_rsync(
        src,
        dst,
        host=host,
        port=port,
        direction=direction,
        strict=strict,
        password=password,
        dry_run=dry_run,
        delete=delete,
        include_datasets=include_datasets,
    )

    print_header("Rsync 同步命令")
    if direction == "upload" and not include_datasets:
        print("policy: upload excludes dataset directories by default")
    print("\n[执行命令]:")
    print(f"  {cmd}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="SSH General Ops command generator")
    sub = parser.add_subparsers(dest="action")

    def add_conn_args(p: argparse.ArgumentParser) -> None:
        p.add_argument("--host", default="USER@HOST")
        p.add_argument("-p", "--port", type=int, default=22)
        p.add_argument("--password", default=None, help="Optional password for sshpass")
        p.add_argument(
            "--strict",
            action="store_true",
            default=False,
            help="Enable StrictHostKeyChecking=no + UserKnownHostsFile=/dev/null",
        )

    # Hybrid entry
    cp = sub.add_parser("compile-plan", help="Compile LLM JSON plan into deterministic commands")
    cp.add_argument("plan_input", help="JSON string / file path / @file / - (stdin)")
    cp.add_argument("--format", choices=["text", "json"], default="text")

    sub.add_parser("plan-example", help="Print example plan JSON")
    sub.add_parser("self-test", help="Run lightweight internal robustness tests")

    # Legacy deterministic entries
    ct = sub.add_parser("connect-test", help="Generate SSH connectivity test command")
    add_conn_args(ct)
    ct.add_argument("--timeout", type=int, default=5)

    pk = sub.add_parser("pack", help="Pack files for scp upload")
    pk.add_argument("files", nargs="+", help="Local files")
    pk.add_argument("-r", "--remote-dir", required=True)
    add_conn_args(pk)

    pd_cmd = sub.add_parser("pack-dir", help="Pack directory for scp upload")
    pd_cmd.add_argument("local_dir")
    pd_cmd.add_argument("-r", "--remote-dir", required=True)
    pd_cmd.add_argument("--force-replace", action="store_true", help="Delete remote target first")
    add_conn_args(pd_cmd)

    ts = sub.add_parser("tar-stream", help="Tar stream upload (many small files)")
    ts.add_argument("local_dir")
    ts.add_argument("-r", "--remote-dir", required=True)
    ts.add_argument("--include-datasets", action="store_true", help="Include data/dataset directories")
    add_conn_args(ts)

    dl = sub.add_parser("download", help="Generate scp download command")
    dl.add_argument("remote_path", help="Remote file or directory")
    dl.add_argument("local_path", help="Local destination directory")
    dl.add_argument("--kind", choices=["auto", "file", "dir"], default="auto")
    add_conn_args(dl)

    rs = sub.add_parser("rsync-sync", help="Generate rsync sync command")
    rs.add_argument("src", help="Source path")
    rs.add_argument("dst", help="Destination path")
    rs.add_argument("--direction", choices=["upload", "download"], default="upload")
    rs.add_argument("--dry-run", action="store_true")
    rs.add_argument("--delete", action="store_true")
    rs.add_argument("--include-datasets", action="store_true", help="Include data/dataset directories")
    add_conn_args(rs)

    ex = sub.add_parser("exec", help="Generate remote SSH exec command")
    ex.add_argument("command", help="Remote command string")
    ex.add_argument("--timeout", type=int, default=None)
    add_conn_args(ex)

    dec = sub.add_parser("decode", help="Decode base64 string or @file to local file")
    dec.add_argument("b64_input")
    dec.add_argument("output_path")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        if args.action == "compile-plan":
            compile_plan(args.plan_input, args.format)
        elif args.action == "plan-example":
            print_plan_example()
        elif args.action == "self-test":
            run_self_test()
        elif args.action == "connect-test":
            connect_test(args.host, args.port, args.password, args.timeout, args.strict)
        elif args.action == "pack":
            pack_files(args.files, args.remote_dir, args.host, args.port, args.password, args.strict)
        elif args.action == "pack-dir":
            pack_dir(
                args.local_dir,
                args.remote_dir,
                args.host,
                args.port,
                args.password,
                args.strict,
                args.force_replace,
            )
        elif args.action == "tar-stream":
            tar_stream(
                args.local_dir,
                args.remote_dir,
                args.host,
                args.port,
                args.password,
                args.strict,
                args.include_datasets,
            )
        elif args.action == "download":
            download(args.remote_path, args.local_path, args.host, args.port, args.password, args.strict, args.kind)
        elif args.action == "rsync-sync":
            generate_rsync(
                args.src,
                args.dst,
                args.host,
                args.port,
                args.password,
                args.strict,
                args.direction,
                args.dry_run,
                args.delete,
                args.include_datasets,
            )
        elif args.action == "exec":
            generate_exec(args.command, args.host, args.port, args.password, args.strict, args.timeout)
        elif args.action == "decode":
            decode_to_file(args.b64_input, args.output_path)
        else:
            parser.print_help()
    except Exception as exc:  # noqa: BLE001
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
