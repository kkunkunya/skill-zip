---
name: ssh-file-transfer
description: >
  SSH 远程文件同步技能（稳健多轨策略）。AutoDL默认交换路径：/root/autodl-tmp/（上传下载都走这里）。
  路线A：小改动通过 SSH exec 短命令（sed/python）直接修改远端代码，命令短、可靠。
  路线B：大改动本地打包后生成 scp 命令给用户手动执行，scp 原生校验、可靠。
  路线C：从远端下载文件/目录到本地。
  路线D：小文件多的目录用 tar 流式传输（官方推荐高级方法）。
  触发场景：(1) 需要将本地文件同步到 SSH 服务器；(2) 需要从 SSH 服务器下载文件；
  (3) 需要在远端修改几行代码；(4) 使用 mcp__ssh-mcp__exec 同步代码；
  (5) 用户说"传文件到服务器"、"同步到SSH"、"改远端代码"、"从服务器拉文件"。
  关键词：SSH传输、文件上传、文件下载、SSH同步、远程修改、scp、tar流式。
---

# SSH File Sync（稳健多轨策略）

## 🔌 连接信息管理（首要步骤）

**配置文件**：`~/.claude/skills/ssh-file-transfer/connection.json`

### 工作流（每次技能触发时执行）

```
1. 读取 connection.json
   ├─ 文件不存在 → 向用户索取 SSH 连接信息（host/port/password），保存后继续
   ├─ 文件存在 → 用 sshpass + ssh 快速测试连通性（timeout 5s）
   │   ├─ 连通 ✅ → 直接使用缓存信息，无需再问用户
   │   └─ 不通 ❌ → 告知用户连接失败，请求新的连接信息，更新配置后重试
   └─ 密码为空 → 生成命令但不含 sshpass，用户手动输入密码
```

### 配置格式
```json
{
  "host": "root@connect.bjb2.seetacloud.com",
  "port": 38708,
  "password": "xxx",
  "remote_base": "/root/autodl-tmp",
  "last_verified": "2026-02-10T01:49:00"
}
```

### 连通性测试命令
```bash
sshpass -p 'PASSWORD' ssh -p PORT -o StrictHostKeyChecking=no -o ConnectTimeout=5 HOST "echo ok" 2>&1
```

### 使用缓存信息
当 connection.json 存在且连通时，所有路线的 `--host` 和 `-p` 参数直接从配置读取，**无需向用户询问**。
同时可用 `sshpass` 实现全自动传输（用户无需手动执行 scp）：
```bash
sshpass -p 'PASSWORD' scp -P PORT -o StrictHostKeyChecking=no LOCAL HOST:REMOTE
```

## AutoDL 默认交换路径

> **铁律：AutoDL 上传/下载统一走 `/root/autodl-tmp/`**

| 路径 | 用途 | 说明 |
|------|------|------|
| **`/root/autodl-tmp/`** | **默认交换目录** | 本地SSD，关机保留，上传下载都放这里 |
| `/root/autodl-fs/` | 文件存储 | 跨实例共享，适合长期存放 |

- 上传到 AutoDL 时，远端目标路径默认为 `/root/autodl-tmp/`
- 从 AutoDL 下载时，远端源路径默认从 `/root/autodl-tmp/` 找
- 项目代码通常在 `/root/autodl-tmp/<项目名>/`

## ⚠️ SCP 参数注意

> **`-rP` 不是 `-rp`！** 端口参数必须用大写 `-P`（scp 与 ssh 不同，ssh 用小写 `-p`，scp 用大写 `-P`）

## 传输策略选择

### 传输前评估（先思考再选路线）

每次传输前，评估以下因素：
- **变更规模**：改了几行代码？还是整个目录？
- **文件特征**：大文件少还是小文件多？总大小多少？
- **方向**：上传还是下载？
- **网络状况**：连接稳定吗？带宽够吗？
- **安全要求**：需要密码自动化还是手动确认？

根据评估结果，参考下方路线选择最合适的方案（也可以组合使用）：

```
变更量评估
  ├─ 小改动（<50行，局部修改）→ 路线 A：SSH exec 直接改
  ├─ 上传单/多文件 → 路线 B：scp 直传
  ├─ 上传目录（小文件多）→ 路线 D：tar 流式传输（官方推荐）
  ├─ 上传目录（大文件少）→ 路线 B：tar.gz + scp
  └─ 下载（远端→本地）→ 路线 C：单文件 scp / 目录 scp -r / tar 流式
```

**核心原则**：短命令走 SSH exec（<1KB 可靠），文件传输走 scp/tar（用户终端执行）。

## 路线 A：SSH Exec 直接修改

适用：改几行代码、改变量值、添加/删除少量行。通过 `mcp__ssh-mcp__exec` 执行。

### sed 替换（单行）
```bash
sed -i 's/old_text/new_text/g' /remote/file.py
```

### Python 行级修改（多行）
```bash
python3 -c "
p='/remote/file.py'; lines=open(p).readlines()
lines[41]='    new_line_here\n'
open(p,'w').writelines(lines); print('OK')
"
```

### Python 正则替换（函数级）
```bash
python3 -c "
import re; p='/remote/file.py'; t=open(p).read()
t=re.sub(r'pattern', 'replacement', t)
open(p,'w').write(t); print('OK')
"
```

### 验证
```bash
grep 'expected_text' /remote/file.py
```

## 路线 B：SCP 上传（单/多文件、目录）

适用：新文件、大量修改、整个目录同步。

> ⚠️ **scp 用大写 `-P` 指定端口，`-rP` 递归+端口（不是 `-rp`！）**

### 步骤

1. **读取连接信息**：从 `connection.json` 获取 host/port/password（参见"连接信息管理"）
2. **生成命令**：
```bash
# 单/多文件（AutoDL 远端默认放 /root/autodl-tmp/）
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py pack \
  /local/file1.py /local/file2.py \
  -r /root/autodl-tmp/ --host root@server -p PORT

# 整个目录
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py pack-dir \
  /local/src/ -r /root/autodl-tmp/项目名/src/ --host root@server -p PORT
```
3. **呈现给用户**：脚本输出 scp 命令，用户在终端执行
4. **远端操作**：通过 `mcp__ssh-mcp__exec` 执行解压（多文件时）+ 验证

## 路线 C：从远端下载

### 单文件
```bash
# 生成下载命令
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py download \
  /root/autodl-tmp/result.csv ./local/ --host root@server -p PORT
# 输出: scp -P PORT root@server:/root/autodl-tmp/result.csv ./local/
```

### 目录
```bash
# 生成目录下载命令（自动加 -r）
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py download \
  /root/autodl-tmp/outputs/ ./local/ --host root@server -p PORT
# 输出: scp -rP PORT root@server:/root/autodl-tmp/outputs/ ./local/
```

### 小文件（<100KB，可选 SSH exec 方式）
```bash
# SSH exec 读取 base64
python3 -c "import base64; print(base64.b64encode(open('/remote/file','rb').read()).decode())"

# 本地解码
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py decode @/tmp/b64.txt /local/file
```

## 路线 D：Tar 流式传输（小文件多的目录，官方推荐）

适用：目录内小文件数量多（如 Python 项目、node_modules 等），直接 scp 会非常慢。

> 💡 **原理**：本地 tar 打包直接通过 SSH 管道流式传到远端解压，无中间文件。

```bash
# 生成 tar 流式命令
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py tar-stream \
  /local/my_project/ -r /root/autodl-tmp/my_project/ --host root@server -p PORT
# 输出: cd /local/my_project && tar cf - * | ssh -p PORT root@server "cd /root/autodl-tmp/my_project && tar xf -"
```

### 手动格式参考
```bash
cd <要拷贝的文件夹目录下>
tar cf - * | ssh -p PORT root@region-X.autodl.com "cd /root/autodl-tmp && tar xf -"
```

> **前提**：本地电脑需要有 `tar` 命令（macOS/Linux 自带，Windows 用 Cmder）
