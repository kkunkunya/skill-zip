---
name: ssh-file-transfer
description: >
  通用 SSH 操作技能（LLM 规划 + Python 编译校验）。用于任何 SSH 任务：远端命令执行、上传下载、目录增量同步、发布与回滚、日志排障、端口转发、云端数据获取。优先让大语言模型生成结构化计划 JSON，再由 Python 生成可执行命令并做确定性策略约束（如默认不传 data/dataset/datasets）。触发词：ssh、远程执行、远程同步、rsync、scp、tar 流传输、部署、回滚、日志排查、端口转发、云端下载数据集。
---

# SSH General Ops（LLM Plan + Python Compile）

## 角色边界（必须）

这个 skill 是给 **LLM/Agent** 用的，不是给终端用户手动执行的教程。

- 默认行为：LLM 生成计划、调用脚本编译、然后由 LLM 自己执行命令并返回结果
- 禁止默认让用户复制粘贴命令
- 只有在执行环境受限（无权限/无连接/无工具）时，才降级为“提供手动命令给用户”
- 对用户展示的是结果与证据，不是命令教学

## 核心思路

你说的方向采用了：

1. **LLM 负责理解需求与策略规划**（输出结构化 JSON，不直接执行命令）
2. **Python 负责命令编译与规则约束**（确定性、可复现、可审计）

这样兼顾灵活性和稳定性。

## LLM 内部执行协议（标准）

触发该 skill 后，LLM 按以下顺序行动：

1. 根据用户自然语言需求生成计划 JSON（内部中间产物）
2. 调用 `compile-plan` 生成确定性命令与最小验证步骤
3. 在可执行环境中按顺序执行命令
4. 用验证步骤确认结果
5. 向用户回报“做了什么 + 结果证据 + 如有失败给下一步”

注意：步骤 1 的 JSON 是给脚本消费，不要求用户阅读或手动编辑。

## 双阶段标准流程（LLM 内部）

### 阶段 A：LLM 只产出计划 JSON

让 LLM 输出一个计划对象，至少包含：

- `action`
- `host`
- `port`
- `params`

可选：

- `strict`
- `password`
- `include_datasets`

示例（LLM 内部可先调用脚本拿模板）：

```bash
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py plan-example
```

### 阶段 B：Python 编译命令与验证步骤

```bash
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py compile-plan @/tmp/ssh-plan.json
```

或直接传 JSON 字符串：

```bash
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py compile-plan '{"action":"exec","host":"root@server","port":22,"params":{"command":"ls -la /root/autodl-tmp"}}'
```

支持 JSON 输出：

```bash
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py compile-plan @/tmp/ssh-plan.json --format json
```

开发/更新技能后，先跑内置自测：

```bash
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py self-test
```

## 默认安全策略（强制）

- 默认不传数据集目录：`data/`、`dataset/`、`datasets/`
- 仅当 `include_datasets=true` 时才包含数据集目录
- 增量同步建议先 dry-run 再正式执行
- 生成命令时统一处理 `ssh -p` / `scp -P` 差异
- `compile-plan` 支持从噪声文本提取 JSON（LLM 输出夹杂说明时可恢复）
- 布尔参数支持字符串解析（如 `"false"` 不会被误判为 `true`）

## 支持的计划动作（action）

- `connect-test`：连通性检查
- `exec`：远端执行命令
- `scp-upload`：上传文件
- `scp-download`：下载文件/目录
- `rsync-sync`：目录增量同步
- `tar-stream`：小文件多场景的流式传输
- `remote-fetch`：在云端直接下载大文件/数据集
- `port-forward`：端口转发
- `ops-check`：进程/服务/日志排障

兼容旧字段：

- 旧 `route` 会自动映射到新 `action`
- 顶层 `src/dst/dry_run/...` 会兼容到 `params`

## 推荐提示词模板（给 LLM）

```text
请只输出一个 JSON 对象，不要输出 markdown 代码块。
根据需求生成 SSH 计划：
- action 必须从 connect-test/exec/scp-upload/scp-download/rsync-sync/tar-stream/remote-fetch/port-forward/ops-check 中选择
- 默认 include_datasets=false
- params 中填写该 action 所需最小字段
- 不要输出给用户的解释性文字
```

## 直接命令模式（仅 LLM 兜底）

当上游没有计划 JSON 或需要快速处理时，LLM 可直接调用旧子命令：

```bash
# 连通性
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py connect-test --host HOST -p PORT --strict

# 远端执行
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py exec "ls -la /root/autodl-tmp" --host HOST -p PORT --strict

# rsync
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py rsync-sync ./local/ /root/autodl-tmp/staging/ --host HOST -p PORT --direction upload --dry-run --strict

# 下载
python3 ~/.claude/skills/ssh-file-transfer/scripts/ssh_transfer.py download /root/autodl-tmp/result.csv ./local --host HOST -p PORT --kind file --strict
```

## 输出规范（技能执行时）

每次都按这个顺序输出：

1. 路线和理由（1-2 句）
2. 执行结果（成功/失败 + 关键证据）
3. 若失败，给出下一步修复动作
4. 仅在必要时附上手动命令（环境受限时）

默认不要把“完整命令清单”丢给用户，除非用户明确要求查看命令。
