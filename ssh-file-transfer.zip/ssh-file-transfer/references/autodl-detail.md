# AutoDL Detail 专项（六坑六律）

适用场景：

- 在 AutoDL 上部署/迁移项目
- 通过 SSH 与 AutoDL 交互（上传、下载、增量同步、远端执行）
- AutoDL 训练期故障排查

默认约定：

- 交换路径默认用 `/root/autodl-fs/`
- 不硬编码 `/root/autodl-fs/data/`

## 六个坑（问题）

1. 在 `.venv` 重装 `torch`，导致新架构 GPU（如 RTX 5090）不兼容。
2. `PYTHONPATH` 未处理，`from src.xxx` 导入失败。
3. `torch.cuda.is_available()` 为 True，但 CUDA 实算仍失败。
4. PyTorch 版本差异导致 `total_mem` / `total_memory` 字段不兼容。
5. 路径硬编码为 `/root/autodl-fs/data/`，实际目录结构不匹配。
6. 训练只写文件日志，终端无实时输出，无法判断进度与卡点。

## 六条铁律（对策）

1. 默认复用 AutoDL 预装 PyTorch，不主动建 venv 重装 torch。
2. `PYTHONPATH` 双保险：写入 `~/.bashrc` + 运行脚本每次 `export`。
3. CUDA 可用性必须做运行时探测（创建 CUDA tensor），不只看 `is_available()`。
4. GPU 属性读取用兼容写法：`getattr(props, "total_memory", getattr(props, "total_mem", 0))`。
5. 路径不硬编码，优先自动查找：`/root/autodl-fs` -> `/root/autodl-tmp` -> `.`。
6. 训练过程必须实时终端输出（进度、奖励、速度、ETA、关键指标，且 `flush=True`）。

## 执行前最小检查（SSH 操作）

1. 确认目标路径存在：`ls -la /root/autodl-fs`
2. 确认项目目录：`ls -la /root/autodl-fs/<project>`
3. 确认 CUDA 运行时：`python -c "import torch; torch.zeros(1, device='cuda'); print('OK')"`
4. 确认训练入口可导入：`python -c "import src"`

## 异常优先级（排障顺序）

1. 路径错误（最常见）
2. 导入错误（PYTHONPATH）
3. CUDA 运行时兼容
4. 训练输出不可观测

