# Workflow Patterns

Skills support multiple workflow paradigms. Choose the right pattern based on **where the intelligence lives**.

## 1. LLM-Driven Workflows (Primary)

The LLM reads, reasons, and acts using its own tools. No scripts needed.

**When to use**: Tasks requiring judgment, context understanding, or creative synthesis.

```markdown
## Code Review Workflow

1. Read the diff:
   - Use `git diff` to get the changes
   - Read each modified file for full context

2. Analyze each change against these criteria:
   - Security: injection, auth bypass, data exposure
   - Logic: edge cases, off-by-one, null handling
   - Style: naming conventions, code organization

3. For each issue found:
   - Classify severity (critical / warning / suggestion)
   - Quote the specific code line
   - Explain WHY it's problematic (not just WHAT)
   - Provide a concrete fix

4. Generate summary:
   - Overall assessment (approve / request changes)
   - Group issues by severity
```

**Key trait**: Every step uses LLM reasoning + built-in tools (Read, Grep, Bash). No scripts.

## 2. Script-Assisted Workflows

Scripts handle mechanical sub-tasks; the LLM orchestrates the overall flow.

**When to use**: Tasks with deterministic operations (file conversion, validation, compilation).

```markdown
Filling a PDF form involves these steps:

1. Analyze the form (run analyze_form.py)
2. Create field mapping (edit fields.json)
3. Validate mapping (run validate_fields.py)
4. Fill the form (run fill_form.py)
5. Verify output (run verify_output.py)
```

**Key trait**: Scripts do fixed transformations; the LLM decides WHAT to transform and reviews results.

## 3. Hybrid Workflows

LLM handles judgment steps; scripts handle mechanical steps. Clearly mark which is which.

**When to use**: Complex tasks mixing reasoning with deterministic operations.

```markdown
## Database Migration Workflow

1. **[LLM]** Analyze current schema and target requirements
   - Read all migration files and models
   - Identify breaking changes and data loss risks

2. **[Script]** Generate migration skeleton (run generate_migration.py)
   - Creates timestamped migration file from schema diff

3. **[LLM]** Review and refine the generated migration
   - Add data transformation logic for breaking changes
   - Ensure rollback safety

4. **[Script]** Validate migration (run validate_migration.py)
   - Checks foreign key integrity and index consistency

5. **[LLM]** Generate migration documentation
   - Summarize changes, risks, and rollback procedures
```

**Key trait**: Each step is explicitly tagged `[LLM]` or `[Script]` so the boundary is clear.

## 4. Conditional Workflows

For tasks with branching logic, guide the LLM through decision points:

```markdown
1. Determine the modification type:
   **Creating new content?** → Follow "Creation workflow" below
   **Editing existing content?** → Follow "Editing workflow" below

2. Creation workflow: [steps]
3. Editing workflow: [steps]
```

---

## Choosing the Right Pattern

| Signal | Pattern | Example |
|--------|---------|---------|
| Every step needs reasoning | LLM-Driven | Code review, refactoring |
| Every step is mechanical | Script-Assisted | File format conversion |
| Mix of reasoning + mechanical | Hybrid | Database migration |
| Different paths based on input | Conditional | Create vs. edit workflows |

**Default to LLM-Driven** unless you can identify specific steps that are purely mechanical and would benefit from a script.
