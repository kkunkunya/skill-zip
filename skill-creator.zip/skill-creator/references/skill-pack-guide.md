# 技能包（Skill Pack）指南

技能包是一种将多个相关子技能组织在一起的方式，通过统一的入口和路由机制提供服务。

## 两种创建模式

### 模式1: 创建新子技能（从零开始）

适用于：需要创建全新的子技能，子技能之间共享资源。

```
skill-pack-name/
├── SKILL.md              # 索引和路由器
├── sub-skills/           # 子技能目录
│   ├── capability-1.md   # 子技能1（单个 .md 文件）
│   └── capability-2.md   # 子技能2（单个 .md 文件）
├── scripts/              # 共享脚本
├── references/           # 共享参考文档
└── assets/               # 共享资源文件
```

### 模式2: 整合现有技能（推荐用于合并已下载技能）

适用于：将多个已存在的独立技能整合成一个统一入口。

```
skill-pack-name/
├── SKILL.md              # 索引路由器（只做路由，不含执行逻辑）
└── sub-skills/
    ├── skill-a/          # 完整的技能A（从 npm/GitHub 下载）
    │   ├── SKILL.md      # ← 实际执行逻辑在这里
    │   ├── scripts/
    │   └── references/
    ├── skill-b/          # 完整的技能B
    │   ├── SKILL.md
    │   └── ...
    └── skill-c/          # 完整的技能C
        └── ...
```

**关键区别**：
| 方面 | 模式1（新建） | 模式2（整合） |
|------|---------------|---------------|
| sub-skills 内容 | 单个 .md 文件 | 完整技能目录 |
| 执行逻辑位置 | 在 .md 文件中 | 在子技能的 SKILL.md 中 |
| 资源管理 | 共享 scripts/references/ | 每个子技能独立资源 |
| 来源 | 新创建 | 从 npm/GitHub 下载 |

## 何时使用技能包

### 适合技能包的场景

- **多格式处理**: 如 document-suite 处理 docx/xlsx/pdf/pptx
- **多模式操作**: 如同一领域的读取/创建/编辑/转换
- **工具集合**: 如一组相关的命令行工具包装
- **领域分支**: 如针对不同子领域的专门处理逻辑
- **整合现有技能**: 将多个独立技能合并为统一入口

### 不适合技能包的场景

- 单一功能，无明显分支
- 子技能之间高度耦合
- 技能本身就很简单

---

## 模式2详解：整合现有技能

### 整合流程

```bash
# 1. 创建技能包结构
python scripts/init_skill.py my-suite --path ~/.claude/skills --type pack --integrate

# 2. 下载要整合的技能
# 方式A: 使用 npx skills（社区技能，来自 skills.sh）
npx skills add <owner/repo> --skill <skill-name> -g
# 例如：
npx skills add vercel-labs/skills --skill find-skills -g

# 方式B: 使用 git clone（GitHub 技能）
git clone https://github.com/user/pdf-skill.git

# 方式C: 交互式搜索安装
npx skills find <keyword>

# 3. 移动到 sub-skills/ 目录
mv ~/.claude/skills/<skill-name> ~/.claude/skills/my-suite/sub-skills/

# 4. 编辑索引 SKILL.md，配置路由表
```

**Skills CLI 命令参考**:
```bash
npx skills find [query]      # 搜索技能
npx skills add <owner/repo>  # 从 GitHub 安装
npx skills add <owner/repo> --skill <name> -g  # 全局安装指定技能
npx skills list              # 列出已安装技能
npx skills check             # 检查更新
npx skills update            # 更新所有技能
```

浏览更多技能: https://skills.sh/

### 整合模式的索引 SKILL.md 模板

```markdown
---
name: document-suite
description: 统一文档处理技能包。整合 PDF、Word、Excel、PPT 处理能力。根据文件类型和操作意图路由到对应子技能。
---

# Document Suite

统一文档处理技能包，整合多个独立的文档处理技能。

## 路由表

| 意图/文件类型 | 子技能 | 入口文件 |
|---------------|--------|----------|
| PDF 处理 | pdf-skill | [sub-skills/pdf-skill/SKILL.md](sub-skills/pdf-skill/SKILL.md) |
| Word 文档 | docx-skill | [sub-skills/docx-skill/SKILL.md](sub-skills/docx-skill/SKILL.md) |
| Excel 表格 | xlsx-skill | [sub-skills/xlsx-skill/SKILL.md](sub-skills/xlsx-skill/SKILL.md) |

## 路由逻辑

1. **识别用户意图**: 从请求中判断文件类型或操作类型
2. **匹配子技能**: 根据路由表选择对应的子技能
3. **读取子技能 SKILL.md**: 加载 `sub-skills/<skill-name>/SKILL.md`
4. **按子技能指令执行**: 完全遵循子技能的 SKILL.md 中的工作流和指令

**重要**: 本索引只负责路由，不包含具体执行逻辑。所有执行细节在各子技能的 SKILL.md 中定义。
```

### 整合模式的优势

1. **保持技能完整性**: 每个子技能保留完整的目录结构和资源
2. **独立更新**: 可以单独更新某个子技能而不影响其他
3. **来源可追溯**: 子技能来自 npm/GitHub，有明确来源
4. **复用社区资源**: 直接使用社区已验证的技能

---

## 模式1详解：创建新子技能

### 目录结构

```
skill-pack-name/
├── SKILL.md              # 索引和路由器（必需）
├── sub-skills/           # 子技能目录（必需）
│   ├── capability-1.md   # 子技能1
│   ├── capability-2.md   # 子技能2
│   └── capability-3.md   # 子技能3
├── scripts/              # 共享脚本（可选）
├── references/           # 共享参考文档（可选）
└── assets/               # 共享资源文件（可选）
```

### 索引 SKILL.md 编写

索引文件是技能包的入口，负责：
1. 描述技能包整体功能
2. 提供路由表
3. 定义路由逻辑

### 示例模板

```markdown
---
name: document-suite
description: 统一文档处理。支持 docx/xlsx/pdf/pptx 的读取、创建、编辑。根据文件类型和操作意图路由到对应子技能。
---

# Document Suite

统一文档处理技能包，覆盖常见办公文档格式。

## 路由表

| 文件类型 | 子技能 | 触发条件 |
|----------|--------|----------|
| .docx | [docx](sub-skills/docx.md) | Word 文档相关任务 |
| .xlsx | [xlsx](sub-skills/xlsx.md) | Excel 表格任务 |
| .pdf | [pdf](sub-skills/pdf.md) | PDF 文档任务 |
| .pptx | [pptx](sub-skills/pptx.md) | PowerPoint 任务 |

## 路由逻辑

1. **识别文件类型**: 从用户请求或文件扩展名判断
2. **匹配子技能**: 根据路由表选择对应子技能
3. **读取并执行**: 加载子技能内容，按指令执行

## 通用资源

- `scripts/`: 共享的文档处理脚本
- `references/`: 格式规范和 API 文档
```

### 子技能文件格式

每个子技能是独立的 markdown 文件，有自己的 frontmatter。

```markdown
---
name: document-suite-docx
description: Word 文档处理子技能
---

# DOCX 处理

[document-suite](../SKILL.md) 技能包的子技能。

## 功能

- 读取 Word 文档内容
- 创建新的 Word 文档
- 编辑现有文档

## 工作流

### 读取文档

1. 使用 pandoc 提取文本
2. 或使用 python-docx 读取结构化内容

### 创建文档

1. 使用 docx-js (JavaScript) 或 python-docx
2. 参考 `references/docx-api.md`

### 编辑文档

1. 解压 docx 为 OOXML
2. 修改 document.xml
3. 重新打包
```

---

## 路由模式

### 模式1: 基于文件类型

```markdown
## 路由逻辑

1. 检查文件扩展名或 MIME 类型
2. 匹配到对应子技能
3. 加载并执行
```

### 模式2: 基于操作意图

```markdown
## 路由逻辑

1. 解析用户请求中的动词 (读取/创建/编辑/转换)
2. 结合目标格式选择子技能
3. 加载并执行
```

### 模式3: 混合路由

```markdown
## 路由逻辑

1. 首先判断文件类型 → 缩小范围
2. 然后判断操作意图 → 选择子流程
3. 加载子技能中的对应章节
```

---

## 共享资源管理（仅模式1）

### scripts/

存放多个子技能共用的脚本：

```
scripts/
├── common.py          # 共享工具函数
├── convert.py         # 格式转换脚本
└── validate.py        # 验证脚本
```

### references/

存放共享的参考文档：

```
references/
├── format-specs.md    # 格式规范
├── api-reference.md   # API 参考
└── best-practices.md  # 最佳实践
```

---

## 验证清单

创建技能包后，检查：

- [ ] SKILL.md 包含完整的路由表
- [ ] 每个子技能都在路由表中列出
- [ ] 子技能文件/目录都有有效的 SKILL.md 或 frontmatter
- [ ] 路由逻辑清晰明确
- [ ] 共享资源正确引用（模式1）或子技能资源完整（模式2）
- [ ] 运行 `quick_validate.py` 通过

## 初始化技能包

使用 init_skill.py 快速创建：

```bash
# 模式1: 创建新子技能
python scripts/init_skill.py my-pack --path ~/.claude/skills --type pack

# 模式2: 整合现有技能
python scripts/init_skill.py my-pack --path ~/.claude/skills --type pack --integrate
```
