# 技能发现指南

本文档提供技能发现的详细策略和决策指南。

## 搜索策略

### 关键词选择

**核心原则**: 用多个相关关键词搜索，避免遗漏。

| 策略 | 示例 |
|------|------|
| 功能词 | pdf, document, image, convert |
| 动作词 | create, edit, process, generate |
| 领域词 | web, api, database, frontend |
| 同义词 | doc/document, img/image, gen/generate |

**多关键词搜索**:
```bash
# 逗号分隔多关键词
python scripts/search_skills.py "pdf,document,convert"
```

### 替代术语

| 目标功能 | 尝试关键词 |
|----------|-----------|
| PDF处理 | pdf, document, convert, extract |
| 图像处理 | image, img, picture, photo, visual |
| 网页抓取 | scrape, crawl, fetch, web |
| 代码生成 | generate, create, build, scaffold |
| 测试 | test, spec, verify, validate |

## 常见技能分类

### Web 开发
- frontend, react, vue, svelte
- backend, api, server, express
- fullstack, webapp, dashboard

### 测试与质量
- test, spec, unit, integration
- lint, format, style, quality
- debug, trace, profile

### DevOps
- deploy, ci, cd, pipeline
- docker, container, kubernetes
- aws, gcp, azure, cloud

### 文档处理
- pdf, docx, xlsx, pptx
- markdown, html, convert
- extract, parse, transform

### 代码质量
- refactor, clean, optimize
- review, analyze, audit
- security, vulnerability

### 设计
- ui, ux, design, style
- figma, sketch, prototype
- responsive, mobile, desktop

### 生产力
- automate, workflow, task
- schedule, remind, notify
- organize, manage, track

## 社区生态

### 主要仓库

| 仓库 | 说明 | 命令 |
|------|------|------|
| vercel-labs/skills | 官方核心技能 | `npx skills add vercel-labs/skills --list` |
| vercel-labs/agent-skills | AI Agent 专用 | `npx skills add vercel-labs/agent-skills --list` |

### 命令参考

```bash
# 搜索社区技能
npx skills find "<keyword>"

# 列出仓库技能
npx skills add <repo> --list

# 安装技能
npx skills add <repo>/<skill-name>

# 列出已安装
npx skills list

# 更新技能
npx skills update [skill-name]

# 移除技能
npx skills remove <skill-name>
```

### skills.sh 目录

[skills.sh](https://skills.sh) 提供:
- 技能搜索和浏览
- 技能详情和评分
- 安装统计

## 未找到技能时的处理

### 检查清单

1. **尝试替代关键词** - 参考上方替代术语表
2. **浏览仓库列表** - `npx skills add vercel-labs/agent-skills --list`
3. **检查 skills.sh** - 可能有新发布的技能
4. **考虑组合现有技能** - 多个技能组合可能满足需求

### 决定创建新技能前

确认以下问题:
- [ ] 尝试了至少 3 个相关关键词？
- [ ] 检查了主要社区仓库？
- [ ] 现有技能无法通过扩展满足需求？

## 决策矩阵

| 匹配情况 | 建议行动 |
|----------|----------|
| 本地高匹配 (≥1) | 直接使用或扩展现有技能 |
| 本地中匹配 + 社区有 | 评估社区技能是否更合适 |
| 仅社区有 | 安装社区技能 |
| 本地低匹配 + 社区无 | 评估是否值得扩展现有技能 |
| 完全无匹配 | 创建新技能 |

### 扩展 vs 新建

**选择扩展**:
- 现有技能覆盖 60%+ 功能
- 新功能与现有技能领域一致
- 维护成本可接受

**选择新建**:
- 功能差异大
- 领域不同
- 需要独立的触发条件
