# Fork 和 Agent 配置指南

本指南说明何时以及如何使用 `context: fork` 和 `agent` 配置。

## 核心概念

### context: fork

`context: fork` 让技能在独立的子对话中运行，**隔离执行**，不污染主对话的上下文窗口。

**关键点**:
- Fork 的子对话有自己独立的上下文
- 主对话不会看到 fork 中产生的大量工具输出
- Fork 完成后只返回最终结果给主对话
- 适合长时间运行或产生大量输出的技能

### agent（可选）

`agent` 是**可选配置**，用于指定子对话使用的专用 agent 类型。

**大多数情况下不需要指定 agent**，系统会自动选择合适的执行方式。只有在特殊需求时才需要显式指定。

## 决策矩阵

| 场景 | context | agent | 说明 |
|------|---------|-------|------|
| 简单指南/参考 | 无 | 无 | 直接在主对话执行 |
| 非技术技能 | 无 | 无 | 加 `model: opus` |
| 外部 API 调用 | fork | 无 | 隔离即可 |
| 大量文件操作 | fork | 无 | 隔离即可 |
| 长时间运行任务 | fork | 无 | 隔离即可 |
| **特别需要文件搜索优化** | fork | Explore | 可选指定 |
| **特别需要规划能力** | fork | Plan | 可选指定 |

## Agent 类型说明

### Explore Agent

专为代码库探索优化：

- 擅长使用 Glob、Grep、Read 工具
- 适合需要搜索大量文件的场景
- 适合代码分析、依赖追踪任务

**何时使用**:
- 技能需要搜索整个代码库
- 技能需要分析项目结构
- 技能需要追踪依赖关系

### Plan Agent

专为规划和设计优化：

- 擅长多阶段任务分解
- 适合架构设计场景
- 适合复杂工作流协调

**何时使用**:
- 技能涉及多阶段规划
- 技能需要做架构决策
- 技能协调复杂的多步骤流程

## 配置示例

### 最常用：仅 Fork

```yaml
---
name: my-skill
description: 执行外部 API 调用的技能
context: fork
---
```

适用于大多数需要隔离执行的场景。

### 可选：Fork + Explore

```yaml
---
name: codebase-analyzer
description: 分析代码库结构和依赖
context: fork
agent: Explore
---
```

仅当技能特别依赖文件搜索时使用。

### 可选：Fork + Plan

```yaml
---
name: architecture-designer
description: 设计系统架构方案
context: fork
agent: Plan
---
```

仅当技能需要规划能力时使用。

## 现有技能配置参考

| 技能 | 配置 | 原因 |
|------|------|------|
| multi-model-collaborator | fork | 调用外部 API，长时间运行 |
| systematic-debugging | fork + Explore | 需要搜索代码定位问题 |
| req-project-dev-draft | fork + Plan | 多阶段规划流程 |
| verification-before-completion | fork | 运行验证命令，产生大量输出 |
| document-suite | 无 | 简单文档操作，无需隔离 |
| image-generator | 无 | 快速 API 调用，无需隔离 |

## 常见问题

### Q: 什么时候需要 fork？

当技能满足以下任一条件：
- 运行时间超过 30 秒
- 产生大量工具输出（>1000 行）
- 调用外部 API 或服务
- 运行后台任务

### Q: 什么时候需要指定 agent？

很少需要。只有当你确定技能有特定的执行模式需求时才指定：
- 大量文件搜索 → 考虑 Explore
- 复杂规划流程 → 考虑 Plan

### Q: Fork 会影响性能吗？

Fork 本身开销很小。实际上，通过隔离大量输出，可以让主对话保持更好的响应性能。
