# Vercel Skills 生态系统

本文档介绍 Vercel 社区技能的格式兼容性和贡献指南。

搜索策略和命令参考请见 `skill-discovery-guide.md`。

## 技能格式兼容性

Vercel skills 格式与本地技能格式基本兼容：

| 特性 | Vercel Skills | 本地技能 |
|------|---------------|----------|
| SKILL.md | ✓ | ✓ |
| frontmatter | ✓ | ✓ |
| scripts/ | ✓ | ✓ |
| references/ | ✓ | ✓ |
| assets/ | ✓ | ✓ |
| context: fork | 取决于版本 | ✓ |
| sub-skills/ | 取决于版本 | ✓ |

安装社区技能后，它们会被放置在标准的技能目录中，与本地技能一样使用。

## 与本地技能的关系

### 搜索优先级

1. **本地技能**: `~/.claude/skills/` 目录
2. **社区技能**: 通过 npx skills 安装的技能

### 统一搜索

使用 `search_skills.py` 可同时搜索本地和社区技能：

```bash
# 默认同时搜索
python scripts/search_skills.py "pdf"

# 仅本地（离线场景）
python scripts/search_skills.py "pdf" --local-only
```

## 贡献技能

如果创建了有价值的技能，可以考虑：

1. 发布到自己的 GitHub 仓库
2. 提交 PR 到社区仓库
3. 在 skills.sh 注册

### 贡献流程

1. 确保技能通过 `quick_validate.py` 验证
2. 使用 `package_skill.py` 打包
3. 创建 GitHub 仓库并推送
4. 提交到 skills.sh 目录
