# 浏览器自动化技能 - 最佳实践规则

> 创建任何需要从网站获取数据的技能时，必须遵守以下规则。

---

## 一、技术方案优先级（强制）

在处理任何需要从网站获取数据的技能时，**强制按以下优先级顺序选择技术方案**：

### 最高优先级：非浏览器方案

```
检查是否存在：
- RSS Feed
- Sitemap
- 官方 API
- JSON endpoint
- GraphQL
- Atom Feed

如果有 → 直接使用（最快、最稳定、最省资源）
```

### 第二优先级：轻量级 HTTP 请求

```
使用 requests / httpx + 智能正文提取库

推荐库优先级：
1. trafilatura     - 最佳通用提取
2. readability-lxml - 类 Readability 算法
3. newspaper3k     - 新闻文章专用
4. BeautifulSoup + lxml - 自定义提取

优点：速度快、并发强、Token消耗极低、易维护
```

### 最低优先级：无头浏览器（兜底）

```
仅在以下情况才使用 Playwright（推荐）或 Selenium：
- 需要登录、Cookie、复杂 JS 渲染
- 动态加载内容（无限滚动、懒加载）
- 反爬严重（验证码、指纹检测）
- 必须模拟真实用户交互
```

---

## 二、浏览器使用原则（当必须使用时）

### 2.1 实例管理

```
✅ 单实例复用：整个流程只打开一次浏览器
✅ 及时释放：任务完成后立即关闭浏览器
✅ 资源清理：关闭前清理 cookies/缓存（如需要）
❌ 禁止：每个操作都重新打开浏览器
```

### 2.2 并发控制

```yaml
# 多标签页并发配置
max_tabs: 3              # 最大同时标签页数
tab_delay: 1000          # 标签页切换间隔(ms)
close_after_use: true    # 用完立即关闭标签页
```

**并发策略**：
- 主标签页保持列表/导航页
- 子标签页处理详情页
- 避免同时打开过多标签页（触发反爬）

### 2.3 超时与重试

```javascript
// 带指数退避的重试机制
async function withRetry(fn, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i === maxRetries - 1) throw e;
      const delay = Math.min(1000 * Math.pow(2, i), 10000);
      await sleep(delay);
    }
  }
}
```

**超时配置参考**：

| 操作类型 | 超时时间 | 重试次数 |
|---------|---------|---------|
| 页面加载 | 30s | 3 |
| 元素等待 | 10s | 2 |
| 文件下载 | 60s | 2 |
| API 请求 | 15s | 3 |

### 2.4 反爬策略

```yaml
# 反爬配置
anti_detection:
  delay_base: 2000        # 基础操作间隔(ms)
  delay_random: 500       # 随机浮动范围(±ms)
  max_requests_per_min: 20
  user_agent_rotation: true
  proxy_support: true     # 可选代理支持
```

**必须实现**：
- 操作间隔随机化（避免机器人特征）
- 模拟人类行为（滚动、鼠标移动）
- 合理的请求频率限制

---

## 三、通用优化要求（所有方案必须实现）

### 3.1 并发处理

```python
# 并发处理多个源
import asyncio

async def process_sources(urls, max_concurrent=5):
    semaphore = asyncio.Semaphore(max_concurrent)

    async def process_one(url):
        async with semaphore:
            return await fetch_and_extract(url)

    return await asyncio.gather(*[process_one(u) for u in urls])
```

### 3.2 自动重试 + 指数退避

```python
import asyncio
from typing import TypeVar, Callable

T = TypeVar('T')

async def retry_with_backoff(
    fn: Callable[[], T],
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0
) -> T:
    for attempt in range(max_retries):
        try:
            return await fn()
        except Exception as e:
            if attempt == max_retries - 1:
                raise
            delay = min(base_delay * (2 ** attempt), max_delay)
            await asyncio.sleep(delay)
```

### 3.3 内容清洗

```python
# 清洗提取的内容
def clean_content(html: str) -> str:
    """去除广告、导航栏、脚本、样式等"""
    from trafilatura import extract

    return extract(
        html,
        include_comments=False,
        include_tables=True,
        no_fallback=False,
        favor_precision=True
    )
```

**必须清洗**：
- 广告和推广内容
- 导航栏和页脚
- 脚本和样式标签
- 隐藏元素
- 重复内容

### 3.4 缓存机制

```python
from functools import lru_cache
from datetime import datetime, timedelta

# 内存缓存
@lru_cache(maxsize=100)
def get_cached_content(url: str) -> str:
    return fetch_content(url)

# 文件缓存（跨会话）
class FileCache:
    def __init__(self, cache_dir: str, ttl_hours: int = 24):
        self.cache_dir = Path(cache_dir)
        self.ttl = timedelta(hours=ttl_hours)

    def get(self, key: str) -> Optional[str]:
        cache_file = self.cache_dir / f"{hash(key)}.cache"
        if cache_file.exists():
            mtime = datetime.fromtimestamp(cache_file.stat().st_mtime)
            if datetime.now() - mtime < self.ttl:
                return cache_file.read_text()
        return None

    def set(self, key: str, value: str):
        cache_file = self.cache_dir / f"{hash(key)}.cache"
        cache_file.write_text(value)
```

### 3.5 详细日志 + 错误处理

```python
import logging
from dataclasses import dataclass
from typing import Optional

@dataclass
class OperationLog:
    timestamp: str
    action: str
    url: str
    status: str  # success | failed | skipped
    error: Optional[str]
    duration_ms: int

# 错误分类处理
class ErrorHandler:
    @staticmethod
    def handle(error: Exception, context: dict) -> str:
        if isinstance(error, TimeoutError):
            return "retry"  # 重试
        elif isinstance(error, HTTPError) and error.status == 429:
            return "backoff"  # 退避等待
        elif isinstance(error, HTTPError) and error.status in [403, 404]:
            return "skip"  # 跳过
        elif "captcha" in str(error).lower():
            return "pause"  # 暂停等待用户
        else:
            return "fail"  # 记录失败
```

### 3.6 参数化配置

```yaml
# 技能配置模板
config:
  # 数据源配置
  sources:
    urls: []              # URL 列表
    selectors: {}         # CSS/XPath 选择器
    filters: []           # 内容过滤规则

  # 请求配置
  request:
    timeout: 30000
    retry_count: 3
    delay_between: 2000
    max_concurrent: 5

  # 输出配置
  output:
    format: "json"        # json | csv | markdown
    directory: "./output"
    filename_pattern: "{date}_{source}.{ext}"

  # 缓存配置
  cache:
    enabled: true
    ttl_hours: 24
    directory: "./.cache"
```

---

## 四、技能模板结构

创建浏览器自动化技能时，建议使用以下结构：

```
skill-name/
├── SKILL.md              # 技能主文件
├── scripts/
│   ├── fetcher.py        # 数据获取逻辑
│   ├── parser.py         # 内容解析逻辑
│   └── cache.py          # 缓存管理
├── config/
│   └── default.yaml      # 默认配置
└── references/
    └── selectors.md      # 选择器参考
```

---

## 五、SKILL.md 必须包含的章节

```markdown
## 技术方案选择

说明为什么选择当前方案（API/HTTP/浏览器），以及尝试过的替代方案。

## 浏览器使用优化（如使用浏览器）

### 实例管理
[单实例复用策略]

### 并发控制
[多标签页/多实例策略]

### 超时与重试
[重试机制和超时配置]

### 缓存机制
[会话内/跨会话缓存]

### 错误处理
[错误分类和处理策略]

### 反爬策略
[操作间隔、频率限制等]

## 参数化配置
[可配置项列表]
```

---

## 六、检查清单

创建浏览器自动化技能前，确认以下事项：

- [ ] 已检查是否有 API/RSS 等非浏览器方案
- [ ] 已评估 HTTP + 提取库是否可行
- [ ] 如必须用浏览器，已实现单实例复用
- [ ] 已实现超时和重试机制（指数退避）
- [ ] 已实现缓存机制（避免重复抓取）
- [ ] 已实现内容清洗（去广告/导航等）
- [ ] 已实现详细日志和错误处理
- [ ] 已支持参数化配置
- [ ] 已实现反爬策略（随机间隔等）
- [ ] 已在 SKILL.md 中说明技术方案选择原因
