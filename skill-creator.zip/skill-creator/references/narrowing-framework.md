# 5-Layer Narrowing Framework

> A systematic approach to narrow broad skill requests into specific, actionable definitions. Essential for non-technical skills where quality varies dramatically based on context.

## Why Narrowing Matters

**The Problem**: Most users start with broad requests like "help me write better emails" or "make product decisions." These are too vague to create effective skills.

**The Solution**: Use this 5-layer framework to systematically narrow the request until it's specific enough that:
- Methodology and quality criteria are unambiguous
- The skill has a clear, focused purpose
- Another Claude instance can execute it effectively

---

## The 5-Layer Framework

```
Broad Request
    ↓
Layer 1: Domain Identification → [Pick one domain]
    ↓
Layer 2: 5W1H Context → [Answer constraints]
    ↓
Layer 3: Comparative Narrowing → [Choose from 2-3 options]
    ↓
Layer 4: Boundary Validation → [Confirm what's excluded]
    ↓
Layer 5: Concrete Case Anchoring → [Describe real example]
    ↓
Check Stop Condition → [All 5 YES?]
    ↓
✅ Narrow enough → Proceed to methodology research
❌ Still broad → Continue narrowing
```

---

## Layer 1: Domain Identification

**Goal**: Identify the core domain(s) of the broad task.

**Template Question**:
```
"[Broad task] can mean different things depending on the domain.
Which of these is closest to what you need?
- [Domain A - description]
- [Domain B - description]
- [Domain C - description]
- Something else?"
```

**Example**:
```
User: "I want a skill for making decisions"

You: "Decision-making varies greatly by domain. Which is closest?
- Product decisions (features, roadmap, prioritization)?
- Hiring decisions (candidate evaluation, role definition)?
- Investment decisions (startups, projects, resource allocation)?
- Strategic business decisions (market entry, partnerships)?
- Something else?"
```

**Output**: Single domain selected (e.g., "Product decisions")

---

## Layer 2: 5W1H Context Constraints

**Goal**: Use structured questions to narrow the context.

**Template Questions**:
```
- WHO: Who will use this skill? (Role, seniority, expertise level)
- WHAT: What specific output or decision does it produce?
- WHERE: What organizational context? (Startup, enterprise, remote, industry)
- WHEN: At what stage/timing is it used? (Launch, crisis, quarterly, daily)
- WHY: What's the primary goal/outcome? (Alignment, approval, action, learning)
- HOW: What constraints exist? (Time limits, process requirements, stakeholders)
```

**Example**:
```
User: "Product decisions"

You: "Let me understand the context better:
- WHO: Are you a PM, founder, or executive making these decisions?
- WHAT: Is this about choosing features, prioritization, or go/no-go launches?
- WHERE: Startup (limited resources) or enterprise (many stakeholders)?
- WHEN: Daily sprint planning or quarterly roadmap decisions?
- WHY: Main goal - team alignment, exec approval, or customer validation?"

User: "I'm a PM at a B2B SaaS startup. Quarterly roadmap planning.
Goal is team alignment and exec approval."
```

**Output**: Contextual constraints defined

---

## Layer 3: Comparative Narrowing

**Goal**: Present 2-3 similar but distinct scenarios. Force a choice or clarification.

**Template**:
```
"Within [narrowed domain], I want to make sure we're targeting the right scenario.
Which is closest?

A. [Specific scenario A - with context]
B. [Specific scenario B - with context]
C. [Specific scenario C - with context]
D. None of these / Combination

Which matches best?"
```

**Example**:
```
User: "Feature prioritization for a PM at a B2B SaaS startup"

You: "Got it. Let me narrow further:

A. Weekly sprint planning: Prioritizing stories within a committed roadmap
B. Quarterly roadmap planning: Deciding which themes/initiatives for next quarter
C. Reactive prioritization: Customer escalation or urgent bug vs planned work
D. Resource allocation: Multiple products/teams competing for engineering time

Which scenario is most common for you, or do you need to handle multiple?"

User: "Mostly B, quarterly roadmap planning"
```

**Output**: Specific scenario selected

---

## Layer 4: Boundary Validation (Via Negativa)

**Goal**: Confirm what the skill does NOT include. This clarifies the edges.

**Template**:
```
"To make sure we're aligned, let me confirm the boundaries. This skill:
- ✅ INCLUDES: [Specific scenario X]
- ✅ INCLUDES: [Specific scenario Y]
- ❌ EXCLUDES: [Related but different scenario A]
- ❌ EXCLUDES: [Related but different scenario B]
- ❌ EXCLUDES: [Related but different scenario C]

Does this match your needs?"
```

**Example**:
```
User confirms: "Quarterly roadmap planning for a B2B SaaS PM"

You: "Perfect. To confirm scope, this skill:
- ✅ INCLUDES: Quarterly planning with engineering constraints
- ✅ INCLUDES: Balancing customer requests, tech debt, and strategic bets
- ❌ EXCLUDES: Daily sprint story prioritization
- ❌ EXCLUDES: Crisis/reactive priority decisions
- ❌ EXCLUDES: Multi-product portfolio prioritization (VP-level)

Is this right?"

User: "Yes, that's exactly right"
```

**Output**: Clear boundaries established

---

## Layer 5: Concrete Case Anchoring

**Goal**: Ask for a real, specific example from their experience. This locks in the scope.

**Template**:
```
"Can you describe a specific recent situation where you needed this skill? Include:
- What was the situation/context?
- What inputs did you have?
- What decision/output did you need to produce?
- What made it difficult or time-consuming?
- What would an ideal outcome have looked like?"
```

**Example**:
```
User: "Yes, the scope is right"

You: "Great! One last thing to anchor our methodology research.
Can you describe a recent quarterly planning session? For example:
- How many features/initiatives were you choosing between?
- What stakeholders were involved?
- What made it hard? (Conflicting data? Stakeholder disagreement? Technical uncertainty?)
- How long did the process take?
- What would have made it easier or better?"

User: "Last quarter I had 15 feature requests, 3 tech debt items,
and 2 strategic bets. Had to present to CEO and CTO. The hard part
was quantifying impact when we had limited data. Took 2 weeks of
back-and-forth. Would love a framework to structure the analysis."
```

**Output**: Concrete example with specific details

---

## Stop Condition: Is It Narrow Enough?

**Stop narrowing when you can answer YES to all 5 questions**:

1. ✅ **Unique methodology**: Would experts in this specific scenario have unique advice (not generic)?
2. ✅ **Clear quality bar**: Could someone judge if the output is "excellent" vs "mediocre"?
3. ✅ **Specific constraints**: Are there context-specific rules, tradeoffs, or failure modes?
4. ✅ **Concrete example**: Has the user described a real scenario where they'd use this?
5. ✅ **Excludes alternatives**: Is it clear what related tasks this does NOT cover?

**If ANY answer is NO, keep narrowing.**

---

## Common Mistakes: Still Too Broad

Even after narrowing, watch for these signs the scope is still too broad:

❌ **Too broad**:
- "Write better emails" → Includes too many email types
- "Make product decisions" → Covers too many decision types
- "Create marketing content" → Content types vary wildly
- "Improve team communication" → Communication contexts differ greatly

✅ **Narrow enough**:
- "Write B2B cold outreach emails to enterprise CTOs"
- "Quarterly roadmap prioritization for B2B SaaS PMs with 3-5 eng team"
- "Create LinkedIn thought leadership posts for technical founders"
- "Run effective incident postmortems for distributed systems teams"

**Rule of thumb**: If you can describe the skill in one sentence with specific role, context, and output type, you're probably narrow enough.

---

## Quick Reference Card

| Layer | Key Question | Output |
|-------|--------------|--------|
| 1. Domain | "Which domain?" | Single domain |
| 2. 5W1H | "Who/What/Where/When/Why/How?" | Context constraints |
| 3. Comparative | "Which specific scenario?" | Scenario choice |
| 4. Boundary | "What's excluded?" | Clear boundaries |
| 5. Concrete | "Give me a real example" | Specific case |

**Then check**: All 5 stop conditions = YES? → Proceed to methodology research

---

## Example: Full Narrowing Process

**Initial Request**: "I want a skill for writing product requirement documents"

**After Layer 1**: Engineering-focused specs (not stakeholder alignment docs)

**After Layer 2**: Senior PM at B2B SaaS startup, quarterly major features, 1-2 pages, goal is minimize eng questions

**After Layer 3**: Net-new features and major enhancements (not small stories or custom builds)

**After Layer 4**:
- ✅ Includes: Major features with engineering constraints
- ❌ Excludes: Small stories, exec docs, customer-specific builds

**After Layer 5**: Real example - API rate limiting feature, 6 hours over 3 days, 2 rounds of clarification, want to reduce to 3 hours and 1 round

**Final Definition**: "Create engineering-focused PRDs for B2B SaaS senior PMs writing specs for net-new features and major enhancements. PRDs should be 1-2 pages, clearly communicate business logic and user needs without over-specifying technical implementation, and enable engineering teams to estimate and start building with minimal back-and-forth."

**Stop Condition Check**:
1. ✅ Unique methodology - Yes (balancing business logic vs technical freedom)
2. ✅ Clear quality bar - Yes (minimize eng questions, enable estimation)
3. ✅ Specific constraints - Yes (B2B SaaS, 1-2 pages, major features)
4. ✅ Concrete example - Yes (API rate limiting, 6→3 hours)
5. ✅ Excludes alternatives - Yes (not small stories, not exec docs)

**Result**: ✅ Ready for methodology research

---

## Tips for Effective Narrowing

1. **Don't rush**: Take time to understand the user's real needs
2. **Ask one layer at a time**: Don't overwhelm with all questions at once
3. **Use examples**: Help users understand what you're asking
4. **Validate understanding**: Repeat back what you heard
5. **Be patient**: Users often don't know how specific they need to be
6. **Use the stop condition**: Don't proceed until all 5 checks pass

---

## When to Skip Narrowing

**Skip this framework for**:
- Technical skills with standard approaches (e.g., "rotate a PDF")
- Skills where the user has already provided very specific requirements
- Simple, straightforward tasks with obvious scope

**Always use this framework for**:
- Non-technical skills (writing, decision-making, communication, etc.)
- Skills involving judgment or persuasion
- Any skill where quality varies dramatically by context
