---
name: skill-creator
description: Guide for creating effective skills. This skill should be used when users want to create a new skill (or update an existing skill) that extends Claude's capabilities with specialized knowledge, workflows, or tool integrations.
license: Complete terms in LICENSE.txt
---

# Skill Creator

This skill provides guidance for creating effective skills.

## About Skills

Skills are modular, self-contained packages that extend Claude's capabilities by providing
specialized knowledge, workflows, and tools. Think of them as "onboarding guides" for specific
domains or tasks—they transform Claude from a general-purpose agent into a specialized agent
equipped with procedural knowledge that no model can fully possess.

### What Skills Provide

1. Specialized workflows - Multi-step procedures for specific domains
2. Tool integrations - Instructions for working with specific file formats or APIs
3. Domain expertise - Company-specific knowledge, schemas, business logic
4. Bundled resources - Scripts, references, and assets for complex and repetitive tasks

## Core Principles

### Concise is Key

The context window is a public good. Skills share the context window with everything else Claude needs: system prompt, conversation history, other Skills' metadata, and the actual user request.

**Default assumption: Claude is already very smart.** Only add context Claude doesn't already have. Challenge each piece of information: "Does Claude really need this explanation?" and "Does this paragraph justify its token cost?"

Prefer concise examples over verbose explanations.

### Set Appropriate Degrees of Freedom

Match the level of specificity to the task's fragility and variability:

**High freedom (text-based instructions)**: Use when multiple approaches are valid, decisions depend on context, or heuristics guide the approach.

**Medium freedom (pseudocode or scripts with parameters)**: Use when a preferred pattern exists, some variation is acceptable, or configuration affects behavior.

**Low freedom (specific scripts, few parameters)**: Use when operations are fragile and error-prone, consistency is critical, or a specific sequence must be followed.

Think of Claude as exploring a path: a narrow bridge with cliffs needs specific guardrails (low freedom), while an open field allows many routes (high freedom).

### Anatomy of a Skill

Every skill consists of a required SKILL.md file and optional bundled resources:

```
skill-name/
├── SKILL.md (required)
│   ├── YAML frontmatter metadata (required)
│   │   ├── name: (required)
│   │   └── description: (required)
│   └── Markdown instructions (required)
└── Bundled Resources (optional)
    ├── scripts/          - Executable code (Python/Bash/etc.)
    ├── references/       - Documentation intended to be loaded into context as needed
    └── assets/           - Files used in output (templates, icons, fonts, etc.)
```

#### SKILL.md (required)

Every SKILL.md consists of:

- **Frontmatter** (YAML): Contains `name` and `description` fields. These are the only fields that Claude reads to determine when the skill gets used, thus it is very important to be clear and comprehensive in describing what the skill is, and when it should be used.
- **Body** (Markdown): Instructions and guidance for using the skill. Only loaded AFTER the skill triggers (if at all).

#### Bundled Resources (optional)

##### Scripts (`scripts/`)

Executable code (Python/Bash/etc.) for tasks that require deterministic reliability or are repeatedly rewritten.

- **When to include**: When the same code is being rewritten repeatedly or deterministic reliability is needed
- **Example**: `scripts/rotate_pdf.py` for PDF rotation tasks
- **Benefits**: Token efficient, deterministic, may be executed without loading into context
- **Note**: Scripts may still need to be read by Claude for patching or environment-specific adjustments

##### References (`references/`)

Documentation and reference material intended to be loaded as needed into context to inform Claude's process and thinking.

- **When to include**: For documentation that Claude should reference while working
- **Examples**: `references/finance.md` for financial schemas, `references/mnda.md` for company NDA template, `references/policies.md` for company policies, `references/api_docs.md` for API specifications
- **Use cases**: Database schemas, API documentation, domain knowledge, company policies, detailed workflow guides
- **Benefits**: Keeps SKILL.md lean, loaded only when Claude determines it's needed
- **Best practice**: If files are large (>10k words), include grep search patterns in SKILL.md
- **Avoid duplication**: Information should live in either SKILL.md or references files, not both. Prefer references files for detailed information unless it's truly core to the skill—this keeps SKILL.md lean while making information discoverable without hogging the context window. Keep only essential procedural instructions and workflow guidance in SKILL.md; move detailed reference material, schemas, and examples to references files.

##### Assets (`assets/`)

Files not intended to be loaded into context, but rather used within the output Claude produces.

- **When to include**: When the skill needs files that will be used in the final output
- **Examples**: `assets/logo.png` for brand assets, `assets/slides.pptx` for PowerPoint templates, `assets/frontend-template/` for HTML/React boilerplate, `assets/font.ttf` for typography
- **Use cases**: Templates, images, icons, boilerplate code, fonts, sample documents that get copied or modified
- **Benefits**: Separates output resources from documentation, enables Claude to use files without loading them into context

#### What to Not Include in a Skill

A skill should only contain essential files that directly support its functionality. Do NOT create extraneous documentation or auxiliary files, including:

- README.md
- INSTALLATION_GUIDE.md
- QUICK_REFERENCE.md
- CHANGELOG.md
- etc.

The skill should only contain the information needed for an AI agent to do the job at hand. It should not contain auxilary context about the process that went into creating it, setup and testing procedures, user-facing documentation, etc. Creating additional documentation files just adds clutter and confusion.

### Progressive Disclosure Design Principle

Skills use a three-level loading system to manage context efficiently:

1. **Metadata (name + description)** - Always in context (~100 words)
2. **SKILL.md body** - When skill triggers (<5k words)
3. **Bundled resources** - As needed by Claude (Unlimited because scripts can be executed without reading into context window)

#### Progressive Disclosure Patterns

Keep SKILL.md body to the essentials and under 500 lines to minimize context bloat. Split content into separate files when approaching this limit. When splitting out content into other files, it is very important to reference them from SKILL.md and describe clearly when to read them, to ensure the reader of the skill knows they exist and when to use them.

**Key principle:** When a skill supports multiple variations, frameworks, or options, keep only the core workflow and selection guidance in SKILL.md. Move variant-specific details (patterns, examples, configuration) into separate reference files.

**Pattern 1: High-level guide with references**

```markdown
# PDF Processing

## Quick start

Extract text with pdfplumber:
[code example]

## Advanced features

- **Form filling**: See [FORMS.md](FORMS.md) for complete guide
- **API reference**: See [REFERENCE.md](REFERENCE.md) for all methods
- **Examples**: See [EXAMPLES.md](EXAMPLES.md) for common patterns
```

Claude loads FORMS.md, REFERENCE.md, or EXAMPLES.md only when needed.

**Pattern 2: Domain-specific organization**

For Skills with multiple domains, organize content by domain to avoid loading irrelevant context:

```
bigquery-skill/
├── SKILL.md (overview and navigation)
└── reference/
    ├── finance.md (revenue, billing metrics)
    ├── sales.md (opportunities, pipeline)
    ├── product.md (API usage, features)
    └── marketing.md (campaigns, attribution)
```

When a user asks about sales metrics, Claude only reads sales.md.

Similarly, for skills supporting multiple frameworks or variants, organize by variant:

```
cloud-deploy/
├── SKILL.md (workflow + provider selection)
└── references/
    ├── aws.md (AWS deployment patterns)
    ├── gcp.md (GCP deployment patterns)
    └── azure.md (Azure deployment patterns)
```

When the user chooses AWS, Claude only reads aws.md.

**Pattern 3: Conditional details**

Show basic content, link to advanced content:

```markdown
# DOCX Processing

## Creating documents

Use docx-js for new documents. See [DOCX-JS.md](DOCX-JS.md).

## Editing documents

For simple edits, modify the XML directly.

**For tracked changes**: See [REDLINING.md](REDLINING.md)
**For OOXML details**: See [OOXML.md](OOXML.md)
```

Claude reads REDLINING.md or OOXML.md only when the user needs those features.

**Important guidelines:**

- **Avoid deeply nested references** - Keep references one level deep from SKILL.md. All reference files should link directly from SKILL.md.
- **Structure longer reference files** - For files longer than 100 lines, include a table of contents at the top so Claude can see the full scope when previewing.

## Skill Creation Process

Skill creation involves these steps:

0. **Skill discovery** (always do first)
1. Understand the skill and determine its type
2. Narrow the scope (for non-technical skills)
3. Research methodologies (for non-technical skills)
4. Plan reusable skill contents (scripts, references, assets)
5. Design test scenarios
6. Initialize the skill (run init_skill.py)
7. Edit the skill (implement resources and write SKILL.md)
8. Package the skill (run package_skill.py)
9. Test and iterate

Follow these steps in order, skipping only if there is a clear reason why they are not applicable.

### Step 0: Skill Discovery (Always Do First)

Before creating a new skill, search existing skills to avoid duplication. This step is **mandatory**.

#### 0.1 Search Skills (Local + Community)

Use the unified search script:

```bash
# 默认搜索本地+社区
python scripts/search_skills.py "<keyword>"

# 多关键词搜索
python scripts/search_skills.py "pdf,convert,document"

# 仅本地（离线场景）
python scripts/search_skills.py "<keyword>" --local-only

# 仅社区
python scripts/search_skills.py "<keyword>" --community-only
```

For detailed search strategies and keyword suggestions, see `references/skill-discovery-guide.md`.

#### 0.2 User Confirmation Checkpoint

**Pause and wait for user decision**:

| Match Level | Criteria | Recommended Action |
|-------------|----------|-------------------|
| **High match** | Existing skill meets 80%+ requirements | Use directly or extend |
| **Medium match** | 40-80% match | Ask user: extend or create new? |
| **Low/No match** | <40% match | Proceed to create new skill |

**Only proceed to Step 1 after user confirms the decision.**

### Technical vs Non-Technical Skills

**CRITICAL DISTINCTION**: Technical and non-technical skills require fundamentally different creation approaches.

**Technical skills** have relatively objective quality bars:
- Writing code, debugging, configuring systems
- Standard approaches exist
- Quality is measurable and consistent

**Non-technical skills** vary dramatically in quality:
- Writing, decision-making, communication, persuasion, judgment
- Quality depends heavily on context and methodology
- Require expert frameworks to reach world-class level

**For non-technical skills, Steps 2-3 are MANDATORY**. Skipping them results in mediocre skills.

### Step 1: Understanding the Skill and Determining Its Type

Skip this step only when the skill's usage patterns are already clearly understood. It remains valuable even when working with an existing skill.

#### 1.1 Gather Concrete Examples

To create an effective skill, clearly understand concrete examples of how the skill will be used. This understanding can come from either direct user examples or generated examples that are validated with user feedback.

For example, when building an image-editor skill, relevant questions include:

- "What functionality should the image-editor skill support? Editing, rotating, anything else?"
- "Can you give some examples of how this skill would be used?"
- "I can imagine users asking for things like 'Remove the red-eye from this image' or 'Rotate this image'. Are there other ways you imagine this skill being used?"
- "What would a user say that should trigger this skill?"

To avoid overwhelming users, avoid asking too many questions in a single message. Start with the most important questions and follow up as needed for better effectiveness.

#### 1.2 Determine Skill Type

**Identify if this is a technical or non-technical skill**:

**Technical skill indicators**:
- Involves code, systems, or tools
- Has standard, objective approaches
- Quality is measurable (works/doesn't work)
- Examples: PDF rotation, API integration, database queries

**Non-technical skill indicators**:
- Involves writing, communication, judgment, or persuasion
- Quality varies dramatically by context
- Requires understanding of human behavior or domain expertise
- Examples: Writing emails, making decisions, conducting interviews, creating presentations

**If non-technical**: Proceed to Step 2 (Narrowing) and Step 3 (Methodology Research) - these are MANDATORY.

**If technical**: Skip to Step 4 (Planning Reusable Contents).

#### 1.3 Classify the Skill Type (Non-Technical Skills Only)

For non-technical skills, identify which of the 11 skill types applies. See `references/skill-taxonomy.md` for detailed definitions.

| Type | Core Operation | When to Use |
|------|----------------|-------------|
| Summary | Compress | Need comprehensive overview |
| Insight | Extract key signals | Need to understand what matters |
| Generation | Create new content | Need content created |
| Decision | Choose and commit | Need to make a choice |
| Evaluation | Judge quality | Need quality judgment |
| Diagnosis | Find root cause | Something is broken |
| Persuasion | Change minds | Need to convince someone |
| Planning | Decompose into steps | Need a roadmap |
| Research | Discover knowledge | Need information gathered |
| Facilitation | Elicit from others | Need to extract information |
| Transformation | Convert formats | Need format conversion |

**Why this matters**: Each type requires different methodologies, quality criteria, and output formats.

Conclude this step when there is a clear sense of:
1. The functionality the skill should support
2. Whether it's technical or non-technical
3. (If non-technical) Which of the 11 types it belongs to

### Step 2: Narrowing the Scope (Non-Technical Skills ONLY)

**MANDATORY for non-technical skills. Skip for technical skills.**

Most users start with broad requests like "help me write emails" or "make product decisions." These are too vague to create effective skills. Use the 5-Layer Narrowing Framework to systematically narrow the request.

See `references/narrowing-framework.md` for the complete framework. Summary:

**The 5 Layers**:
1. **Domain Identification**: Which specific domain? (e.g., "sales emails" vs "internal updates")
2. **5W1H Context**: Who/What/Where/When/Why/How constraints
3. **Comparative Narrowing**: Choose from 2-3 specific scenarios
4. **Boundary Validation**: Confirm what's excluded (via negativa)
5. **Concrete Case Anchoring**: Get a real example from user's experience

**Stop Condition** - Only proceed when ALL 5 are YES:
1. ✅ Unique methodology exists for this specific scenario
2. ✅ Clear quality bar (can judge "excellent" vs "mediocre")
3. ✅ Specific constraints identified
4. ✅ Concrete example provided
5. ✅ Excludes alternatives (clear boundaries)

**Example of narrow enough**:
- ❌ Too broad: "Write better emails"
- ✅ Narrow enough: "Write B2B cold outreach emails to enterprise CTOs"

**Output**: A one-sentence skill definition with specific role, context, and output type.

### Step 3: Research Methodologies (Non-Technical Skills ONLY)

**MANDATORY for non-technical skills. Skip for technical skills.**

Non-technical skills require expert methodologies to reach world-class quality. Don't skip this step or the skill will be mediocre.

#### 3.1 Identify Relevant Domains

Map the skill to 1-3 methodology domains. Consult `references/methodology-database.md`.

Examples:
- "Sales email skill" → Sales, Writing, Persuasion
- "User interview skill" → User Research, Facilitation, Product Discovery
- "PRD writing skill" → Product Management, Business Writing

#### 3.2 Search for Expert Methodologies

**Layer 1: Local Database**
- Check `references/methodology-database.md` for known frameworks
- Identify 2-3 relevant experts and their core frameworks

**Layer 2: Web Search for Experts**
- Search: "[domain] best practices expert"
- Search: "[domain] framework methodology"
- Look for: books with 1000+ reviews, popular talks, influential practitioners

**Layer 3: Deep Dive on Primary Sources**
- Search: "[expert name] methodology interview"
- Search: "[expert name] framework explained"
- Fetch and read primary sources (articles, transcripts, blog posts)

**Layer 4: Continue Until Crystal Clear**
- Don't stop at first results
- Keep searching until you have **very clear, reliable conclusions**
- Look for: golden examples, anti-patterns, specific processes

#### 3.3 Find Golden Examples

Search for exemplary outputs to define the quality bar:
- Search: "best [output type] examples"
- Search: "[output type] template [top company]"
- Analyze what makes them excellent

#### 3.4 Identify Anti-Patterns

Search for common mistakes to avoid:
- Search: "[domain] common mistakes"
- Search: "[methodology] pitfalls avoid"
- Document what NOT to do

#### 3.5 Cross-Validate

Compare insights across multiple sources:
- What principles appear consistently? (high confidence)
- Where do experts disagree? (flag for user)
- What's unique to each approach? (differentiation)

#### 3.6 Collaborative Selection

Present methodologies to the user:
- Which frameworks resonate with their goals?
- Any conflicts to resolve?
- Should they combine multiple approaches?
- Any specific principles to emphasize or exclude?

Guide the user to select 1-3 primary methodologies that will form the skill's foundation.

**Output**:
- Selected expert methodologies (1-3)
- Golden examples identified
- Anti-patterns documented
- Cross-validated principles

### Step 4: Planning the Reusable Skill Contents

To turn concrete examples into an effective skill, analyze each example by:

1. Considering how to execute on the example from scratch
2. Identifying what scripts, references, and assets would be helpful when executing these workflows repeatedly

Example: When building a `pdf-editor` skill to handle queries like "Help me rotate this PDF," the analysis shows:

1. Rotating a PDF requires re-writing the same code each time
2. A `scripts/rotate_pdf.py` script would be helpful to store in the skill

Example: When designing a `frontend-webapp-builder` skill for queries like "Build me a todo app" or "Build me a dashboard to track my steps," the analysis shows:

1. Writing a frontend webapp requires the same boilerplate HTML/React each time
2. An `assets/hello-world/` template containing the boilerplate HTML/React project files would be helpful to store in the skill

Example: When building a `big-query` skill to handle queries like "How many users have logged in today?" the analysis shows:

1. Querying BigQuery requires re-discovering the table schemas and relationships each time
2. A `references/schema.md` file documenting the table schemas would be helpful to store in the skill

To establish the skill's contents, analyze each concrete example to create a list of the reusable resources to include: scripts, references, and assets.

### Step 5: Design Test Scenarios

**IMPORTANT**: Design test scenarios BEFORE generating the skill. This ensures the skill will be validated against real-world usage.

#### 5.1 Identify Test Cases

Work with the user to identify:

**Diverse Test Cases**:
- Typical scenarios (the common case)
- Edge cases (unusual but valid situations)
- Boundary conditions (where the methodology might break down)
- Failure modes (what could go wrong)

**Context Variations**:
- Different user expertise levels
- Different organizational contexts (startup vs enterprise)
- Different constraints (time, resources, stakeholder complexity)
- Cultural or industry differences

#### 5.2 Define Quality Validation

Establish clear criteria:
- What does "excellent" output look like?
- What are the most common mistakes to avoid?
- How will we know if the skill is working?

**For non-technical skills**: Use the quality criteria from the skill taxonomy and selected methodologies.

**Output**: Documented test scenarios that will be used in Step 9 to validate and iterate.

### Step 6: Initializing the Skill

At this point, it is time to actually create the skill.

Skip this step only if the skill being developed already exists, and iteration or packaging is needed. In this case, continue to the next step.

When creating a new skill from scratch, always run the `init_skill.py` script. The script conveniently generates a new template skill directory that automatically includes everything a skill requires, making the skill creation process much more efficient and reliable.

#### Basic Usage

```bash
# Standard skill (default)
scripts/init_skill.py <skill-name> --path <output-directory>

# Example
scripts/init_skill.py my-new-skill --path ~/.claude/skills
```

#### Skill Types

The script supports three skill types via `--type`:

```bash
# Standard skill (default)
scripts/init_skill.py my-skill --path ~/.claude/skills --type standard

# Fork skill (runs in isolated context)
scripts/init_skill.py my-api-skill --path ~/.claude/skills --type fork

# Skill pack (multiple sub-skills with routing)
scripts/init_skill.py my-suite --path ~/.claude/skills --type pack
```

#### Fork Skills (Context Isolation)

For skills that need context isolation, use `--type fork`. Optionally specify an agent type:

```bash
# Fork only (most common - system auto-selects agent)
scripts/init_skill.py my-api --path ~/.claude/skills --type fork

# Fork with Explore agent (for file-heavy operations)
scripts/init_skill.py my-analyzer --path ~/.claude/skills --type fork --agent Explore

# Fork with Plan agent (for planning workflows)
scripts/init_skill.py my-planner --path ~/.claude/skills --type fork --agent Plan
```

See `references/fork-agent-guide.md` for when to use each configuration.

#### Non-Technical Skills

For non-technical skills that need Opus model:

```bash
scripts/init_skill.py my-writing-skill --path ~/.claude/skills --model opus
```

#### Skill Packs

Skill packs have two creation modes:

**Mode 1: Create New Sub-Skills**

For creating a skill pack with new sub-skills from scratch:

```bash
scripts/init_skill.py document-suite --path ~/.claude/skills --type pack
```

This creates:
- `SKILL.md` with routing table template
- `sub-skills/` directory with example sub-skill files
- Shared `scripts/` and `references/` directories

**Mode 2: Integrate Existing Skills (Recommended for combining downloaded skills)**

When user requests to combine multiple existing skills into a skill pack:

```bash
# Step 1: Create the skill pack structure
scripts/init_skill.py my-suite --path ~/.claude/skills --type pack --integrate

# Step 2: Download existing skills into sub-skills/
# Option A: Using npx skills (community skills from skills.sh)
npx skills add <owner/repo> --skill <skill-name> -g
mv ~/.claude/skills/<skill-name> ~/.claude/skills/my-suite/sub-skills/

# Option B: Using git clone (GitHub skills)
git clone <skill-repo-url> ~/.claude/skills/my-suite/sub-skills/<skill-name>

# Option C: Search and install interactively
npx skills find <keyword>
```

**Skills CLI Commands Reference**:
```bash
npx skills find [query]      # Search for skills
npx skills add <owner/repo>  # Install from GitHub
npx skills add <owner/repo> --skill <name> -g  # Install specific skill globally
npx skills list              # List installed skills
npx skills check             # Check for updates
npx skills update            # Update all skills
```

Browse skills at: https://skills.sh/

**Integration Mode Directory Structure**:
```
my-suite/
├── SKILL.md                    # Index router (routes to sub-skill SKILL.md files)
└── sub-skills/
    ├── skill-a/                # Complete skill A (downloaded)
    │   ├── SKILL.md            # ← LLM reads this for execution
    │   ├── scripts/
    │   └── references/
    ├── skill-b/                # Complete skill B (downloaded)
    │   ├── SKILL.md
    │   └── ...
    └── skill-c/                # Complete skill C (downloaded)
        └── ...
```

**Key Difference**: In integration mode, sub-skills are **complete skill directories** (with their own SKILL.md), not single .md files. The index SKILL.md only routes; actual execution logic lives in each sub-skill's SKILL.md.

See `references/skill-pack-guide.md` for detailed skill pack patterns.

#### What the Script Creates

| Type | Creates |
|------|---------|
| standard | SKILL.md, scripts/, references/, assets/ |
| fork | SKILL.md (with context: fork), scripts/, references/ |
| pack | SKILL.md (with routing), sub-skills/, scripts/, references/, assets/ |

After initialization, customize or remove the generated SKILL.md and example files as needed.

### Step 7: Edit the Skill

When editing the (newly-generated or existing) skill, remember that the skill is being created for another instance of Claude to use. Include information that would be beneficial and non-obvious to Claude. Consider what procedural knowledge, domain-specific details, or reusable assets would help another Claude instance execute these tasks more effectively.

#### Learn Proven Design Patterns

Consult these helpful guides based on your skill's needs:

- **Multi-step processes**: See references/workflows.md for sequential workflows and conditional logic
- **Specific output formats or quality standards**: See references/output-patterns.md for template and example patterns
- **Non-technical skills**: See references/skill-taxonomy.md for quality criteria by skill type
- **Expert methodologies**: See references/methodology-database.md for proven frameworks
- **Narrowing scope**: See references/narrowing-framework.md for the 5-layer framework
- **Browser automation / web scraping**: See references/browser-automation-best-practices.md for technology selection, instance management, retry mechanisms, caching, and anti-detection strategies
- **Fork and agent configuration**: See references/fork-agent-guide.md for context isolation and agent selection
- **Skill packs**: See references/skill-pack-guide.md for multi-skill organization
- **Community skills**: See references/vercel-ecosystem.md for npx skills and community resources

These files contain established best practices for effective skill design.

#### Start with Reusable Skill Contents

To begin implementation, start with the reusable resources identified above: `scripts/`, `references/`, and `assets/` files. Note that this step may require user input. For example, when implementing a `brand-guidelines` skill, the user may need to provide brand assets or templates to store in `assets/`, or documentation to store in `references/`.

Added scripts must be tested by actually running them to ensure there are no bugs and that the output matches what is expected. If there are many similar scripts, only a representative sample needs to be tested to ensure confidence that they all work while balancing time to completion.

Any example files and directories not needed for the skill should be deleted. The initialization script creates example files in `scripts/`, `references/`, and `assets/` to demonstrate structure, but most skills won't need all of them.

#### Update SKILL.md

**Writing Guidelines:** Always use imperative/infinitive form.

##### Frontmatter

Write the YAML frontmatter with `name` and `description`:

- `name`: The skill name
- `description`: This is the primary triggering mechanism for your skill, and helps Claude understand when to use the skill.
  - Include both what the Skill does and specific triggers/contexts for when to use it.
  - Include all "when to use" information here - Not in the body. The body is only loaded after triggering, so "When to Use This Skill" sections in the body are not helpful to Claude.
  - Example description for a `docx` skill: "Comprehensive document creation, editing, and analysis with support for tracked changes, comments, formatting preservation, and text extraction. Use when Claude needs to work with professional documents (.docx files) for: (1) Creating new documents, (2) Modifying or editing content, (3) Working with tracked changes, (4) Adding comments, or any other document tasks"

**For non-technical skills, add `model: opus` to the frontmatter**:
```yaml
---
name: skill-name
description: Skill description here
model: opus
---
```

This ensures the skill uses Claude Opus (claude-opus-4-5), which has the reasoning depth needed for nuanced, judgment-based tasks. Non-technical skills involving writing, decision-making, communication, or persuasion MUST use Opus for quality.

**Subagent Configuration (Context Protection)**:

Consider whether the skill should run in a forked subagent context to protect the main conversation's context window. Add subagent configuration when the skill meets ANY of these criteria:

**Add `context: fork` when**:
- The skill involves long-running operations (>30 seconds)
- The skill produces large tool outputs that shouldn't pollute main context
- The skill runs background tasks or waits for external processes
- The skill is for logging, memory, or session management
- Examples: multi-model-collaborator, notebooklm, verification-before-completion

**Add `context: fork` + `agent: Explore` when**:
- The skill requires extensive file searching (Glob/Grep/Read)
- The skill involves codebase exploration or analysis
- The skill scans project structure or dependencies
- Examples: systematic-debugging, project-cleanup, cli-logger, scientific-skills

**Add `context: fork` + `agent: Plan` when**:
- The skill involves multi-phase planning or design
- The skill requires architectural decision-making
- The skill coordinates complex workflows
- Examples: req-project-dev-draft

**Configuration examples**:

```yaml
# Background task isolation
---
name: multi-model-collaborator
description: ...
context: fork
---

# Codebase exploration
---
name: systematic-debugging
description: ...
context: fork
agent: Explore
---

# Planning and design
---
name: req-project-dev-draft
description: ...
context: fork
agent: Plan
---
```

**When NOT to add subagent configuration**:
- Simple, fast operations (<10 seconds)
- Single-file operations without extensive searching
- Tools that need to interact with main conversation context
- Examples: pdf, docx, image-generator, mermaid-visualizer

**Decision framework**:
1. Will this skill produce >1000 lines of tool output? → Consider `context: fork`
2. Does this skill need to search/explore many files? → Consider `agent: Explore`
3. Does this skill involve planning/design phases? → Consider `agent: Plan`
4. Does this skill run background processes? → Consider `context: fork`

Do not include any other fields in YAML frontmatter unless specifically needed.

##### Body

Write instructions for using the skill and its bundled resources.

**For non-technical skills**: Include the selected methodologies, quality criteria, and anti-patterns in the body. Credit the methodology sources.

### Step 8: Packaging a Skill

Once development of the skill is complete, it must be packaged into a distributable .skill file that gets shared with the user. The packaging process automatically validates the skill first to ensure it meets all requirements:

```bash
scripts/package_skill.py <path/to/skill-folder>
```

Optional output directory specification:

```bash
scripts/package_skill.py <path/to/skill-folder> ./dist
```

The packaging script will:

1. **Validate** the skill automatically, checking:

   - YAML frontmatter format and required fields
   - Skill naming conventions and directory structure
   - Description completeness and quality
   - File organization and resource references

2. **Package** the skill if validation passes, creating a .skill file named after the skill (e.g., `my-skill.skill`) that includes all files and maintains the proper directory structure for distribution. The .skill file is a zip file with a .skill extension.

If validation fails, the script will report the errors and exit without creating a package. Fix any validation errors and run the packaging command again.

### Step 9: Test and Iterate

**CRITICAL**: Don't stop at first generation. Quality emerges through iteration.

#### 9.1 Run Test Scenarios

Apply the skill to each test case designed in Step 5:
- Typical scenarios
- Edge cases
- Boundary conditions
- Failure modes

#### 9.2 Evaluate Results

Compare outputs against quality criteria:
- Does it meet the quality bar defined in Step 5?
- Are there gaps or weaknesses?
- Does it handle edge cases well?

**For non-technical skills**: Use the quality criteria from the skill taxonomy and selected methodologies.

#### 9.3 Identify Gaps

Where did the skill fall short?
- Missing information or guidance?
- Unclear instructions?
- Wrong methodology emphasis?
- Need additional examples or anti-patterns?

#### 9.4 Refine and Regenerate

Based on learnings:
- Update SKILL.md with improvements
- Add missing guidance or examples
- Clarify ambiguous instructions
- Consider if additional methodology research is needed

#### 9.5 Repeat Until Quality

Continue the test-evaluate-refine cycle until the skill consistently produces excellent results.

**Iteration workflow**:
1. Use the skill on real tasks (or test scenarios)
2. Notice struggles or inefficiencies
3. Identify how SKILL.md or bundled resources should be updated
4. Implement changes and test again
5. Repeat until quality is consistently high

Involve the user in this evaluation — they know their domain and can spot nuances.

**For non-technical skills**: Expect multiple iterations. The first version is rarely excellent.
