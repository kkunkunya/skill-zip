#!/usr/bin/env python3
"""
Skill Initializer - Creates a new skill from template

Usage:
    init_skill.py <skill-name> --path <path> [--type <type>] [--agent <agent>] [--model <model>]

Arguments:
    --type    Skill type: standard (default), fork, pack
    --agent   Agent type for fork skills: Explore, Plan (optional, only with --type fork)
    --model   Model override: opus (for non-technical skills)

Examples:
    init_skill.py my-new-skill --path skills/public
    init_skill.py my-api-helper --path skills/private --type fork
    init_skill.py my-explorer --path skills/private --type fork --agent Explore
    init_skill.py my-skill-pack --path skills/public --type pack
    init_skill.py my-writing-skill --path skills/public --model opus
"""

import sys
from pathlib import Path


# =============================================================================
# Templates
# =============================================================================

SKILL_TEMPLATE_STANDARD = """---
name: {skill_name}
description: "[TODO: Complete and informative explanation of what the skill does and when to use it. Include WHEN to use this skill - specific scenarios, file types, or tasks that trigger it.]"
---

# {skill_title}

## Overview

[TODO: 1-2 sentences explaining what this skill enables]

## Structuring This Skill

[TODO: Choose the structure that best fits this skill's purpose. Common patterns:

**1. Workflow-Based** (best for sequential processes)
- Works well when there are clear step-by-step procedures
- Example: DOCX skill with "Workflow Decision Tree" → "Reading" → "Creating" → "Editing"
- Structure: ## Overview → ## Workflow Decision Tree → ## Step 1 → ## Step 2...

**2. Task-Based** (best for tool collections)
- Works well when the skill offers different operations/capabilities
- Example: PDF skill with "Quick Start" → "Merge PDFs" → "Split PDFs" → "Extract Text"
- Structure: ## Overview → ## Quick Start → ## Task Category 1 → ## Task Category 2...

**3. Reference/Guidelines** (best for standards or specifications)
- Works well for brand guidelines, coding standards, or requirements
- Example: Brand styling with "Brand Guidelines" → "Colors" → "Typography" → "Features"
- Structure: ## Overview → ## Guidelines → ## Specifications → ## Usage...

**4. Capabilities-Based** (best for integrated systems)
- Works well when the skill provides multiple interrelated features
- Example: Product Management with "Core Capabilities" → numbered capability list
- Structure: ## Overview → ## Core Capabilities → ### 1. Feature → ### 2. Feature...

Patterns can be mixed and matched as needed. Most skills combine patterns (e.g., start with task-based, add workflow for complex operations).

Delete this entire "Structuring This Skill" section when done - it's just guidance.]

## [TODO: Replace with the first main section based on chosen structure]

[TODO: Add content here. See examples in existing skills:
- Code samples for technical skills
- Decision trees for complex workflows
- Concrete examples with realistic user requests
- References to scripts/templates/references as needed]

## Resources

This skill includes example resource directories that demonstrate how to organize different types of bundled resources:

### scripts/
Executable code (Python/Bash/etc.) that can be run directly to perform specific operations.

### references/
Documentation and reference material intended to be loaded into context to inform Claude's process and thinking.

### assets/
Files not intended to be loaded into context, but rather used within the output Claude produces.

---

**Any unneeded directories can be deleted.** Not every skill requires all three types of resources.
"""

SKILL_TEMPLATE_FORK = """---
name: {skill_name}
description: "[TODO: Complete and informative explanation of what the skill does and when to use it. Include WHEN to use this skill - specific scenarios, file types, or tasks that trigger it.]"
context: fork{agent_line}{model_line}
---

# {skill_title}

## Overview

[TODO: 1-2 sentences explaining what this skill enables]

This skill runs in a forked context to protect the main conversation's context window.
{agent_note}

## Workflow

[TODO: Define the workflow steps]

## Resources

### scripts/
Executable code for specific operations.

### references/
Documentation loaded into context as needed.
"""

SKILL_TEMPLATE_PACK = """---
name: {skill_name}
description: "[TODO: Unified skill pack description. Explain what this pack provides and when to use it. Include routing logic summary.]"
---

# {skill_title}

This is a **skill pack** - a collection of related sub-skills with unified routing.

## Sub-Skills

| Sub-Skill | Description | Trigger |
|-----------|-------------|---------|
| [sub-skill-1](sub-skills/sub-skill-1.md) | [TODO: Description] | [TODO: When to use] |
| [sub-skill-2](sub-skills/sub-skill-2.md) | [TODO: Description] | [TODO: When to use] |

## Routing Logic

1. Identify the user's intent from the request
2. Match to the appropriate sub-skill using the trigger criteria
3. Read and follow the sub-skill instructions

## Shared Resources

### scripts/
Shared executable code used by multiple sub-skills.

### references/
Shared documentation and reference material.

### assets/
Shared templates or files used in outputs.
"""

SKILL_TEMPLATE_PACK_INTEGRATE = """---
name: {skill_name}
description: "[TODO: Unified skill pack description. Explain what this pack provides and when to use it. List integrated skills and routing logic.]"
---

# {skill_title}

This is a **skill pack** that integrates multiple existing skills with unified routing.

## Integrated Skills

| Intent/File Type | Skill | Entry Point |
|------------------|-------|-------------|
| [TODO: Intent 1] | [skill-a](sub-skills/skill-a/SKILL.md) | sub-skills/skill-a/SKILL.md |
| [TODO: Intent 2] | [skill-b](sub-skills/skill-b/SKILL.md) | sub-skills/skill-b/SKILL.md |

## Routing Logic

1. **Identify user intent**: Determine file type or operation type from request
2. **Match to skill**: Select the appropriate skill from the routing table
3. **Read skill's SKILL.md**: Load `sub-skills/<skill-name>/SKILL.md`
4. **Execute per skill instructions**: Follow the workflow defined in the sub-skill's SKILL.md

**Important**: This index only handles routing. All execution logic is defined in each sub-skill's SKILL.md.

## Integration Instructions

To add a new skill to this pack:

```bash
# Option A: Using npx skills (community skills from skills.sh)
npx skills add <owner/repo> --skill <skill-name> -g
mv ~/.claude/skills/<skill-name> {skill_path}/sub-skills/

# Option B: Search and install interactively
npx skills find <keyword>

# Option C: Using git clone (GitHub skills)
git clone <skill-repo-url> {skill_path}/sub-skills/<skill-name>
```

Browse more skills at: https://skills.sh/

Then update the routing table above.
"""

SUB_SKILL_TEMPLATE = """---
name: {skill_name}-{sub_skill_name}
description: "[TODO: Sub-skill description]"
---

# {sub_skill_title}

Part of the [{skill_title}](../SKILL.md) skill pack.

## Overview

[TODO: What this sub-skill does]

## Workflow

[TODO: Step-by-step instructions]
"""

EXAMPLE_SCRIPT = '''#!/usr/bin/env python3
"""
Example helper script for {skill_name}

This is a placeholder script that can be executed directly.
Replace with actual implementation or delete if not needed.
"""

def main():
    print("This is an example script for {skill_name}")
    # TODO: Add actual script logic here

if __name__ == "__main__":
    main()
'''

EXAMPLE_REFERENCE = """# Reference Documentation for {skill_title}

This is a placeholder for detailed reference documentation.
Replace with actual reference content or delete if not needed.

## When Reference Docs Are Useful

Reference docs are ideal for:
- Comprehensive API documentation
- Detailed workflow guides
- Complex multi-step processes
- Information too lengthy for main SKILL.md
"""

EXAMPLE_ASSET = """# Example Asset File

This placeholder represents where asset files would be stored.
Replace with actual asset files (templates, images, fonts, etc.) or delete if not needed.

Asset files are NOT intended to be loaded into context, but rather used within
the output Claude produces.
"""


# =============================================================================
# Helper Functions
# =============================================================================

def title_case_skill_name(skill_name):
    """Convert hyphenated skill name to Title Case for display."""
    return ' '.join(word.capitalize() for word in skill_name.split('-'))


def init_skill(skill_name, path, skill_type='standard', agent=None, model=None, integrate=False):
    """
    Initialize a new skill directory with template SKILL.md.

    Args:
        skill_name: Name of the skill
        path: Path where the skill directory should be created
        skill_type: Type of skill - 'standard', 'fork', or 'pack'
        agent: Agent type for fork skills - 'Explore' or 'Plan' (optional)
        model: Model override - 'opus' for non-technical skills
        integrate: For pack type, use integration mode (for combining existing skills)

    Returns:
        Path to created skill directory, or None if error
    """
    # Validate skill_type
    valid_types = {'standard', 'fork', 'pack'}
    if skill_type not in valid_types:
        print(f"❌ Error: Invalid skill type '{skill_type}'. Must be one of: {', '.join(valid_types)}")
        return None

    # Validate agent
    valid_agents = {'Explore', 'Plan', None}
    if agent not in valid_agents:
        print(f"❌ Error: Invalid agent '{agent}'. Must be one of: Explore, Plan")
        return None

    # Agent requires fork type
    if agent and skill_type != 'fork':
        print(f"❌ Error: --agent requires --type fork")
        return None

    # Integrate requires pack type
    if integrate and skill_type != 'pack':
        print(f"❌ Error: --integrate requires --type pack")
        return None

    # Validate model
    valid_models = {'opus', None}
    if model not in valid_models:
        print(f"❌ Error: Invalid model '{model}'. Currently supported: opus")
        return None

    # Determine skill directory path
    skill_dir = Path(path).resolve() / skill_name

    # Check if directory already exists
    if skill_dir.exists():
        print(f"❌ Error: Skill directory already exists: {skill_dir}")
        return None

    # Create skill directory
    try:
        skill_dir.mkdir(parents=True, exist_ok=False)
        print(f"✅ Created skill directory: {skill_dir}")
    except Exception as e:
        print(f"❌ Error creating directory: {e}")
        return None

    # Create SKILL.md based on type
    skill_title = title_case_skill_name(skill_name)

    if skill_type == 'standard':
        skill_content = SKILL_TEMPLATE_STANDARD.format(
            skill_name=skill_name,
            skill_title=skill_title
        )
        # Add model to frontmatter if specified
        if model:
            skill_content = skill_content.replace(
                'description: [TODO:',
                f'description: [TODO:',
            )
            # Insert model after description line
            lines = skill_content.split('\n')
            for i, line in enumerate(lines):
                if line.startswith('description:'):
                    lines.insert(i + 1, f'model: {model}')
                    break
            skill_content = '\n'.join(lines)

    elif skill_type == 'fork':
        agent_line = f'\nagent: {agent}' if agent else ''
        model_line = f'\nmodel: {model}' if model else ''
        agent_note = f'\nUsing agent type: **{agent}** for optimized execution.' if agent else ''
        skill_content = SKILL_TEMPLATE_FORK.format(
            skill_name=skill_name,
            skill_title=skill_title,
            agent_line=agent_line,
            model_line=model_line,
            agent_note=agent_note
        )

    elif skill_type == 'pack':
        if integrate:
            skill_content = SKILL_TEMPLATE_PACK_INTEGRATE.format(
                skill_name=skill_name,
                skill_title=skill_title,
                skill_path=skill_dir
            )
        else:
            skill_content = SKILL_TEMPLATE_PACK.format(
                skill_name=skill_name,
                skill_title=skill_title
            )

    skill_md_path = skill_dir / 'SKILL.md'
    try:
        skill_md_path.write_text(skill_content)
        print(f"✅ Created SKILL.md (type: {skill_type})")
    except Exception as e:
        print(f"❌ Error creating SKILL.md: {e}")
        return None

    # Create resource directories with example files
    try:
        # Create scripts/ directory with example script
        scripts_dir = skill_dir / 'scripts'
        scripts_dir.mkdir(exist_ok=True)
        example_script = scripts_dir / 'example.py'
        example_script.write_text(EXAMPLE_SCRIPT.format(skill_name=skill_name))
        example_script.chmod(0o755)
        print("✅ Created scripts/example.py")

        # Create references/ directory with example reference doc
        references_dir = skill_dir / 'references'
        references_dir.mkdir(exist_ok=True)
        example_reference = references_dir / 'api_reference.md'
        example_reference.write_text(EXAMPLE_REFERENCE.format(skill_title=skill_title))
        print("✅ Created references/api_reference.md")

        # Create assets/ directory with example asset placeholder (not for fork type)
        if skill_type != 'fork':
            assets_dir = skill_dir / 'assets'
            assets_dir.mkdir(exist_ok=True)
            example_asset = assets_dir / 'example_asset.txt'
            example_asset.write_text(EXAMPLE_ASSET)
            print("✅ Created assets/example_asset.txt")

        # Create sub-skills/ directory for pack type
        if skill_type == 'pack':
            sub_skills_dir = skill_dir / 'sub-skills'
            sub_skills_dir.mkdir(exist_ok=True)

            if integrate:
                # Integration mode: create empty sub-skills directory
                # User will download and move existing skills here
                print("✅ Created sub-skills/ (empty - for integrating existing skills)")
                print("   Download skills and move them here:")
                print("   npx @anthropic-ai/claude-code-skill install <skill-name>")
                print(f"   mv ~/.claude/skills/<skill-name> {sub_skills_dir}/")
            else:
                # Standard mode: create example sub-skill files
                for sub_name in ['sub-skill-1', 'sub-skill-2']:
                    sub_skill_content = SUB_SKILL_TEMPLATE.format(
                        skill_name=skill_name,
                        skill_title=skill_title,
                        sub_skill_name=sub_name,
                        sub_skill_title=title_case_skill_name(sub_name)
                    )
                    sub_skill_file = sub_skills_dir / f'{sub_name}.md'
                    sub_skill_file.write_text(sub_skill_content)
                    print(f"✅ Created sub-skills/{sub_name}.md")

    except Exception as e:
        print(f"❌ Error creating resource directories: {e}")
        return None

    # Print summary and next steps
    print(f"\n✅ Skill '{skill_name}' initialized successfully at {skill_dir}")
    print(f"   Type: {skill_type}")
    if agent:
        print(f"   Agent: {agent}")
    if model:
        print(f"   Model: {model}")
    if integrate:
        print(f"   Mode: Integration (for combining existing skills)")

    print("\nNext steps:")
    print("1. Edit SKILL.md to complete the TODO items and update the description")
    if skill_type == 'pack':
        if integrate:
            print("2. Download existing skills and move them to sub-skills/")
            print("3. Update the routing table in SKILL.md with actual skill paths")
        else:
            print("2. Edit sub-skills/ files to define each sub-skill")
            print("3. Update the routing table in SKILL.md")
    print("4. Customize or delete the example files in scripts/, references/")
    print("5. Run the validator when ready to check the skill structure")

    return skill_dir


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='Initialize a new skill from template',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s my-skill --path skills/public
  %(prog)s my-api --path skills/private --type fork
  %(prog)s my-explorer --path skills/private --type fork --agent Explore
  %(prog)s my-pack --path skills/public --type pack
  %(prog)s my-suite --path skills/public --type pack --integrate
  %(prog)s my-writing --path skills/public --model opus
        """
    )

    parser.add_argument('skill_name', help='Name of the skill (hyphen-case)')
    parser.add_argument('--path', required=True, help='Path where the skill directory should be created')
    parser.add_argument('--type', dest='skill_type', default='standard',
                        choices=['standard', 'fork', 'pack'],
                        help='Skill type: standard (default), fork, pack')
    parser.add_argument('--agent', choices=['Explore', 'Plan'],
                        help='Agent type for fork skills (optional, only with --type fork)')
    parser.add_argument('--model', choices=['opus'],
                        help='Model override (e.g., opus for non-technical skills)')
    parser.add_argument('--integrate', action='store_true',
                        help='Integration mode for pack type: create structure for combining existing skills')

    args = parser.parse_args()

    print(f"🚀 Initializing skill: {args.skill_name}")
    print(f"   Location: {args.path}")
    print(f"   Type: {args.skill_type}")
    if args.agent:
        print(f"   Agent: {args.agent}")
    if args.model:
        print(f"   Model: {args.model}")
    if args.integrate:
        print(f"   Mode: Integration")
    print()

    result = init_skill(
        args.skill_name,
        args.path,
        skill_type=args.skill_type,
        agent=args.agent,
        model=args.model,
        integrate=args.integrate
    )

    if result:
        sys.exit(0)
    else:
        sys.exit(1)


if __name__ == "__main__":
    main()
