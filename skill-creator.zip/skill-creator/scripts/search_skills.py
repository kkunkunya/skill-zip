#!/usr/bin/env python3
"""
技能发现工具 - 搜索本地和社区技能，避免重复创建。

用法:
    python search_skills.py <keyword> [options]

选项:
    --local-only, -l    仅搜索本地技能（跳过社区）
    --community-only, -c 仅搜索社区技能（跳过本地）
    --json              输出 JSON 格式
    --verbose           显示详细信息

说明:
    默认同时搜索本地和社区技能，提供完整的技能发现视图。

示例:
    python search_skills.py "pdf"                    # 搜索本地+社区
    python search_skills.py "pdf" --local-only      # 仅本地
    python search_skills.py "pdf" --community-only  # 仅社区
    python search_skills.py "pdf,convert" --verbose # 多关键词详细搜索
"""

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Optional


# =============================================================================
# Configuration
# =============================================================================

MATCH_THRESHOLDS = {
    'high': 50,      # High match: name contains keyword
    'medium': 30,    # Medium match: description contains keyword
    'low': 20,       # Low match: content contains keyword
}

NPX_TIMEOUT = 120      # 社区搜索超时时间（秒）- 2分钟
NPX_INSTALL_TIMEOUT = 300  # 技能安装/下载超时时间（秒）- 5分钟


# =============================================================================
# Local Search
# =============================================================================

def get_skills_dir() -> Path:
    """获取技能目录路径"""
    return Path.home() / ".claude" / "skills"


def extract_frontmatter(content: str) -> dict:
    """从 SKILL.md 提取 frontmatter"""
    match = re.match(r'^---\s*\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return {}

    frontmatter = {}
    for line in match.group(1).split('\n'):
        if ':' in line:
            key, value = line.split(':', 1)
            frontmatter[key.strip()] = value.strip().strip('"\'')
    return frontmatter


def search_local(keyword: str) -> list[dict]:
    """搜索本地技能"""
    skills_dir = get_skills_dir()
    results = []

    if not skills_dir.exists():
        return results

    keyword_lower = keyword.lower()
    # 支持多关键词搜索（逗号分隔）
    keywords = [k.strip().lower() for k in keyword_lower.split(',') if k.strip()]

    for skill_dir in skills_dir.iterdir():
        if not skill_dir.is_dir() or skill_dir.name.startswith('.'):
            continue

        # 检查是否是 symlink
        is_symlink = skill_dir.is_symlink()

        # 查找 SKILL.md (大小写不敏感)
        skill_md = None
        for f in skill_dir.iterdir():
            if f.name.lower() == 'skill.md':
                skill_md = f
                break

        if not skill_md or not skill_md.exists():
            continue

        try:
            content = skill_md.read_text(encoding='utf-8')
        except Exception:
            continue

        # 提取 frontmatter
        fm = extract_frontmatter(content)
        name = fm.get('name', skill_dir.name)
        description = fm.get('description', '')

        # 计算匹配度 (支持多关键词)
        match_score = 0
        matched_keywords = []

        for kw in keywords:
            kw_score = 0
            if kw in name.lower():
                kw_score += 50
            if kw in description.lower():
                kw_score += 30
            if kw in content.lower():
                kw_score += 20
            if kw_score > 0:
                matched_keywords.append(kw)
                match_score += kw_score

        if match_score > 0:
            # 检查是否是技能包
            is_pack = (skill_dir / 'sub-skills').is_dir()

            results.append({
                'name': name,
                'description': description[:200] + '...' if len(description) > 200 else description,
                'path': str(skill_dir),
                'is_symlink': is_symlink,
                'is_pack': is_pack,
                'match_score': match_score,
                'match_level': 'High' if match_score >= 50 else 'Medium' if match_score >= 30 else 'Low',
                'matched_keywords': matched_keywords,
            })

    # 按匹配度排序
    results.sort(key=lambda x: x['match_score'], reverse=True)
    return results


# =============================================================================
# Community Search
# =============================================================================

def search_community(keyword: str) -> tuple[list[dict], Optional[str]]:
    """
    搜索社区技能（通过 npx skills find）

    返回: (结果列表, 错误信息)
    """
    # 取第一个关键词用于社区搜索
    first_keyword = keyword.split(',')[0].strip()

    try:
        result = subprocess.run(
            ['npx', 'skills', 'find', first_keyword],
            capture_output=True,
            text=True,
            timeout=NPX_TIMEOUT
        )

        if result.returncode != 0:
            # npx 命令失败
            error_msg = result.stderr.strip() if result.stderr else "npx skills find 命令失败"
            return [], error_msg

        return parse_npx_output(result.stdout), None

    except subprocess.TimeoutExpired:
        return [], f"社区搜索超时 ({NPX_TIMEOUT}秒)"
    except FileNotFoundError:
        return [], "未找到 npx 命令，请确保已安装 Node.js"
    except Exception as e:
        return [], f"社区搜索出错: {str(e)}"


def parse_npx_output(stdout: str) -> list[dict]:
    """
    解析 npx skills find 的输出

    输出格式示例（可能包含 ANSI 颜色代码）:
    anthropics/skills/pdf@pdf
    vercel-labs/skills/document
    """
    results = []

    # 移除 ANSI 颜色代码
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    stdout = ansi_escape.sub('', stdout)

    for line in stdout.strip().split('\n'):
        line = line.strip()
        if not line:
            continue

        # 跳过非技能行（如标题、分隔符、URL行等）
        if (line.startswith('#') or line.startswith('-') or
            line.startswith('=') or line.startswith('└') or
            line.startswith('Install with') or 'https://' in line):
            continue

        # 解析技能路径 (格式: owner/repo/skill@name 或 owner/repo)
        # 移除 @name 后缀
        skill_path = line.split('@')[0] if '@' in line else line
        parts = skill_path.split('/')

        if len(parts) >= 2:
            results.append({
                'full_path': skill_path,
                'owner': parts[0],
                'repo': parts[1] if len(parts) > 1 else '',
                'skill_name': parts[2] if len(parts) > 2 else parts[1],
                'install_cmd': f"npx skills add {skill_path}",
            })

    return results


# =============================================================================
# Output Formatting
# =============================================================================

def format_results(
    local_results: list[dict],
    community_results: list[dict],
    keyword: str,
    verbose: bool = False,
    community_error: Optional[str] = None,
    search_mode: str = 'all'  # 'all', 'local', 'community'
) -> str:
    """格式化输出结果"""
    lines = []
    lines.append("")
    lines.append("=" * 60)
    lines.append(f"📋 技能发现结果 (关键词: {keyword})")
    lines.append("=" * 60)

    # 本地技能结果
    if search_mode in ('all', 'local'):
        lines.append("")
        lines.append(f"🏠 本地技能 ({len(local_results)} 个):")

        if not local_results:
            lines.append("  (未找到匹配的本地技能)")
        else:
            # 按匹配级别分组
            high = [s for s in local_results if s['match_level'] == 'High']
            medium = [s for s in local_results if s['match_level'] == 'Medium']
            low = [s for s in local_results if s['match_level'] == 'Low']

            if high:
                lines.append(f"  🔴 高匹配 ({len(high)} 个):")
                for skill in high:
                    _format_local_skill(lines, skill, verbose)

            if medium:
                lines.append(f"  🟡 中匹配 ({len(medium)} 个):")
                for skill in medium:
                    _format_local_skill(lines, skill, verbose)

            if low and verbose:
                lines.append(f"  🟢 低匹配 ({len(low)} 个):")
                for skill in low:
                    _format_local_skill(lines, skill, verbose)

    # 社区技能结果
    if search_mode in ('all', 'community'):
        lines.append("")
        lines.append(f"🌐 社区技能 ({len(community_results)} 个):")

        if community_error:
            lines.append(f"  ⚠️ {community_error}")
        elif not community_results:
            lines.append("  (未找到匹配的社区技能)")
        else:
            for skill in community_results[:10]:  # 最多显示10个
                _format_community_skill(lines, skill)
            if len(community_results) > 10:
                lines.append(f"  ... 还有 {len(community_results) - 10} 个结果")

    # 建议
    lines.append("")
    lines.append("-" * 60)
    _add_suggestion(lines, local_results, community_results, search_mode)

    lines.append("")
    lines.append("=" * 60)
    return '\n'.join(lines)


def _format_local_skill(lines: list, skill: dict, verbose: bool):
    """格式化单个本地技能"""
    pack_tag = " [Pack]" if skill.get('is_pack') else ""
    symlink_tag = " [Symlink]" if skill.get('is_symlink') else ""
    lines.append(f"    • {skill['name']}{pack_tag}{symlink_tag}")
    lines.append(f"      路径: {skill['path']}")
    if verbose and skill['description']:
        desc = skill['description'][:100] + '...' if len(skill['description']) > 100 else skill['description']
        lines.append(f"      描述: {desc}")


def _format_community_skill(lines: list, skill: dict):
    """格式化单个社区技能"""
    lines.append(f"  • {skill['full_path']}")
    lines.append(f"    安装: {skill['install_cmd']}")


def _add_suggestion(
    lines: list,
    local_results: list[dict],
    community_results: list[dict],
    search_mode: str
):
    """添加建议"""
    high_local = [s for s in local_results if s.get('match_level') == 'High']

    if search_mode == 'local':
        if high_local:
            lines.append(f"💡 建议: 发现 {len(high_local)} 个高匹配本地技能，建议先查看是否满足需求")
        elif local_results:
            lines.append("💡 建议: 匹配度较低，可考虑搜索社区技能或创建新技能")
        else:
            lines.append("💡 建议: 未找到本地技能，可搜索社区技能或创建新技能")
    elif search_mode == 'community':
        if community_results:
            lines.append(f"💡 建议: 发现 {len(community_results)} 个社区技能，可使用 npx skills add 安装")
        else:
            lines.append("💡 建议: 未找到社区技能，可创建新技能")
    else:  # all
        if high_local:
            lines.append(f"💡 建议: 发现 {len(high_local)} 个高匹配本地技能，建议先查看是否满足需求")
        elif community_results:
            lines.append(f"💡 建议: 本地无高匹配，但发现 {len(community_results)} 个社区技能可供选择")
        elif local_results:
            lines.append("💡 建议: 匹配度较低，建议创建新技能")
        else:
            lines.append("💡 建议: 未找到匹配技能，建议创建新技能")


# =============================================================================
# Main
# =============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='技能发现工具 - 搜索本地和社区技能',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
说明:
  默认同时搜索本地和社区技能，提供完整的技能发现视图。

示例:
  %(prog)s "pdf"                    # 搜索本地+社区
  %(prog)s "pdf" --local-only       # 仅本地
  %(prog)s "pdf" --community-only   # 仅社区
  %(prog)s "pdf,convert" --verbose  # 多关键词详细搜索
        """
    )

    parser.add_argument('keyword', help='搜索关键词 (支持逗号分隔多关键词)')
    parser.add_argument('--local-only', '-l', action='store_true',
                        help='仅搜索本地技能（跳过社区）')
    parser.add_argument('--community-only', '-c', action='store_true',
                        help='仅搜索社区技能（跳过本地）')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--verbose', '-v', action='store_true', help='显示详细信息')

    args = parser.parse_args()

    # 检查互斥参数
    if args.local_only and args.community_only:
        print("错误: --local-only 和 --community-only 不能同时使用", file=sys.stderr)
        sys.exit(2)

    # 确定搜索模式
    if args.local_only:
        search_mode = 'local'
    elif args.community_only:
        search_mode = 'community'
    else:
        search_mode = 'all'

    # 执行搜索
    local_results = []
    community_results = []
    community_error = None

    if search_mode in ('all', 'local'):
        local_results = search_local(args.keyword)

    if search_mode in ('all', 'community'):
        community_results, community_error = search_community(args.keyword)

    # 输出
    if args.json:
        output = {
            'keyword': args.keyword,
            'search_mode': search_mode,
            'local': {
                'count': len(local_results),
                'high_match': len([s for s in local_results if s.get('match_level') == 'High']),
                'medium_match': len([s for s in local_results if s.get('match_level') == 'Medium']),
                'low_match': len([s for s in local_results if s.get('match_level') == 'Low']),
                'skills': local_results,
            },
            'community': {
                'count': len(community_results),
                'skills': community_results,
                'error': community_error,
            },
        }
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print(format_results(
            local_results,
            community_results,
            args.keyword,
            args.verbose,
            community_error,
            search_mode
        ))

    # 返回码: 0=无高匹配, 1=有高匹配本地技能
    high_matches = [s for s in local_results if s.get('match_level') == 'High']
    sys.exit(1 if high_matches else 0)


if __name__ == '__main__':
    main()
