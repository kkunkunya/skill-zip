#!/usr/bin/env python3
"""
Quick validation script for skills - enhanced version

Validates:
- SKILL.md existence and frontmatter format
- Required fields: name, description
- Optional fields: license, allowed-tools, metadata, context, agent, model
- context/agent combination rules
- Skill pack structure (sub-skills/ directory)
"""

import sys
import re
import yaml
from pathlib import Path


# =============================================================================
# Configuration
# =============================================================================

# Allowed frontmatter properties
ALLOWED_PROPERTIES = {
    'name',
    'description',
    'license',
    'allowed-tools',
    'metadata',
    # New properties for fork/agent support
    'context',
    'agent',
    'model',
}

# Valid values for new properties
VALID_CONTEXT_VALUES = {'fork'}
VALID_AGENT_VALUES = {'Explore', 'Plan'}
VALID_MODEL_VALUES = {'opus'}


# =============================================================================
# Validation Functions
# =============================================================================

def validate_frontmatter(frontmatter: dict, skill_path: Path) -> tuple[bool, str]:
    """Validate frontmatter content and rules"""

    # Check for unexpected properties
    unexpected_keys = set(frontmatter.keys()) - ALLOWED_PROPERTIES
    if unexpected_keys:
        return False, (
            f"Unexpected key(s) in SKILL.md frontmatter: {', '.join(sorted(unexpected_keys))}. "
            f"Allowed properties are: {', '.join(sorted(ALLOWED_PROPERTIES))}"
        )

    # Check required fields
    if 'name' not in frontmatter:
        return False, "Missing 'name' in frontmatter"
    if 'description' not in frontmatter:
        return False, "Missing 'description' in frontmatter"

    # Validate name
    name = frontmatter.get('name', '')
    if not isinstance(name, str):
        return False, f"Name must be a string, got {type(name).__name__}"
    name = name.strip()
    if name:
        # Check naming convention (hyphen-case: lowercase with hyphens)
        if not re.match(r'^[a-z0-9-]+$', name):
            return False, f"Name '{name}' should be hyphen-case (lowercase letters, digits, and hyphens only)"
        if name.startswith('-') or name.endswith('-') or '--' in name:
            return False, f"Name '{name}' cannot start/end with hyphen or contain consecutive hyphens"
        # Check name length (max 64 characters per spec)
        if len(name) > 64:
            return False, f"Name is too long ({len(name)} characters). Maximum is 64 characters."

    # Validate description
    description = frontmatter.get('description', '')
    if not isinstance(description, str):
        return False, f"Description must be a string, got {type(description).__name__}"
    description = description.strip()
    if description:
        # Check for angle brackets
        if '<' in description or '>' in description:
            return False, "Description cannot contain angle brackets (< or >)"
        # Check description length (max 1024 characters per spec)
        if len(description) > 1024:
            return False, f"Description is too long ({len(description)} characters). Maximum is 1024 characters."

    # Validate context
    context = frontmatter.get('context')
    if context is not None:
        if context not in VALID_CONTEXT_VALUES:
            return False, f"Invalid context value '{context}'. Valid values: {', '.join(VALID_CONTEXT_VALUES)}"

    # Validate agent
    agent = frontmatter.get('agent')
    if agent is not None:
        if agent not in VALID_AGENT_VALUES:
            return False, f"Invalid agent value '{agent}'. Valid values: {', '.join(VALID_AGENT_VALUES)}"
        # Agent requires context: fork
        if context != 'fork':
            return False, f"'agent: {agent}' requires 'context: fork' to be set"

    # Validate model
    model = frontmatter.get('model')
    if model is not None:
        if model not in VALID_MODEL_VALUES:
            return False, f"Invalid model value '{model}'. Valid values: {', '.join(VALID_MODEL_VALUES)}"

    return True, ""


def validate_skill_pack(skill_path: Path) -> tuple[bool, str, list[str]]:
    """
    Validate skill pack structure if sub-skills/ directory exists

    Returns: (is_pack, error_message, warnings)
    """
    sub_skills_dir = skill_path / 'sub-skills'
    warnings = []

    if not sub_skills_dir.exists():
        return False, "", warnings

    if not sub_skills_dir.is_dir():
        return False, "sub-skills must be a directory", warnings

    # Check for sub-skill files
    sub_skill_files = list(sub_skills_dir.glob('*.md'))
    if not sub_skill_files:
        warnings.append("sub-skills/ directory exists but contains no .md files")

    # Validate each sub-skill
    for sub_skill_file in sub_skill_files:
        try:
            content = sub_skill_file.read_text(encoding='utf-8')

            # Check frontmatter exists
            if not content.startswith('---'):
                return False, f"Sub-skill {sub_skill_file.name}: No YAML frontmatter found", warnings

            # Extract frontmatter
            match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
            if not match:
                return False, f"Sub-skill {sub_skill_file.name}: Invalid frontmatter format", warnings

            # Parse YAML
            try:
                fm = yaml.safe_load(match.group(1))
                if not isinstance(fm, dict):
                    return False, f"Sub-skill {sub_skill_file.name}: Frontmatter must be a YAML dictionary", warnings
            except yaml.YAMLError as e:
                return False, f"Sub-skill {sub_skill_file.name}: Invalid YAML - {e}", warnings

            # Check required fields
            if 'name' not in fm:
                warnings.append(f"Sub-skill {sub_skill_file.name}: Missing 'name' in frontmatter")
            if 'description' not in fm:
                warnings.append(f"Sub-skill {sub_skill_file.name}: Missing 'description' in frontmatter")

        except Exception as e:
            return False, f"Error reading sub-skill {sub_skill_file.name}: {e}", warnings

    return True, "", warnings


def validate_skill(skill_path: str) -> tuple[bool, str, list[str]]:
    """
    Complete validation of a skill

    Returns: (is_valid, error_message, warnings)
    """
    skill_path = Path(skill_path)
    warnings = []

    # Check SKILL.md exists
    skill_md = skill_path / 'SKILL.md'
    if not skill_md.exists():
        return False, "SKILL.md not found", warnings

    # Read content
    try:
        content = skill_md.read_text(encoding='utf-8')
    except Exception as e:
        return False, f"Error reading SKILL.md: {e}", warnings

    # Check frontmatter exists
    if not content.startswith('---'):
        return False, "No YAML frontmatter found", warnings

    # Extract frontmatter
    match = re.match(r'^---\n(.*?)\n---', content, re.DOTALL)
    if not match:
        return False, "Invalid frontmatter format", warnings

    frontmatter_text = match.group(1)

    # Parse YAML frontmatter
    try:
        frontmatter = yaml.safe_load(frontmatter_text)
        if not isinstance(frontmatter, dict):
            return False, "Frontmatter must be a YAML dictionary", warnings
    except yaml.YAMLError as e:
        return False, f"Invalid YAML in frontmatter: {e}", warnings

    # Validate frontmatter content
    valid, error = validate_frontmatter(frontmatter, skill_path)
    if not valid:
        return False, error, warnings

    # Check if this is a skill pack and validate structure
    is_pack, pack_error, pack_warnings = validate_skill_pack(skill_path)
    warnings.extend(pack_warnings)
    if is_pack and pack_error:
        return False, pack_error, warnings

    # Additional checks for skill packs
    if is_pack:
        # Check if SKILL.md mentions sub-skills
        if 'sub-skills/' not in content and 'sub-skills\\' not in content:
            warnings.append("Skill pack detected but SKILL.md doesn't reference sub-skills/ directory")

    return True, "Skill is valid!", warnings


# =============================================================================
# Main
# =============================================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='Validate skill structure and frontmatter',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Validates:
  - SKILL.md existence and frontmatter format
  - Required fields: name, description
  - Optional fields: license, allowed-tools, metadata, context, agent, model
  - context/agent combination rules (agent requires context: fork)
  - Skill pack structure (sub-skills/ directory)

Examples:
  %(prog)s /path/to/skill
  %(prog)s ~/.claude/skills/my-skill
        """
    )

    parser.add_argument('skill_directory', help='Path to the skill directory')
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='Show detailed validation output')

    args = parser.parse_args()

    valid, message, warnings = validate_skill(args.skill_directory)

    # Output
    if valid:
        print(f"✅ {message}")
        if warnings:
            print("\n⚠️  Warnings:")
            for w in warnings:
                print(f"  - {w}")
    else:
        print(f"❌ {message}")
        if warnings:
            print("\n⚠️  Additional warnings:")
            for w in warnings:
                print(f"  - {w}")

    if args.verbose:
        print(f"\nValidated: {args.skill_directory}")
        skill_path = Path(args.skill_directory)
        if (skill_path / 'sub-skills').is_dir():
            print("Type: Skill Pack")
            sub_skills = list((skill_path / 'sub-skills').glob('*.md'))
            print(f"Sub-skills: {len(sub_skills)}")
        else:
            print("Type: Standard Skill")

    sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
