---
name: threejs-suite
description: "Three.js 3D开发全栈技能包，涵盖场景搭建、几何体、材质、光照、纹理、动画、交互、模型加载、着色器、后处理。Use when working with Three.js or WebGL 3D development: (1) setting up scenes, cameras, renderers; (2) creating geometries or meshes; (3) configuring materials or PBR; (4) adding lights or shadows; (5) loading textures, UV mapping, HDR; (6) loading GLTF/OBJ/FBX models; (7) animating objects, skeletal/morph animation; (8) raycasting, controls, mouse/touch interaction; (9) writing GLSL shaders or custom effects; (10) post-processing bloom, DOF, color grading. Triggers on: Three.js, three.js, WebGL, 3D scene, 3D rendering, mesh, geometry, material, light, shadow, texture, GLTF, animation, raycaster, shader, GLSL, post-processing, bloom, EffectComposer."
---

# Three.js Suite

Three.js 3D 开发全栈技能包，整合 10 个子技能，按需加载。

## Routing Table

根据用户意图匹配子技能，Read 对应的 SKILL.md 后按其指导执行。

| 关键词/意图 | 子技能 | 路径 |
|------------|--------|------|
| scene, camera, renderer, Object3D, group, transform, coordinate | [fundamentals](sub-skills/fundamentals/SKILL.md) | `sub-skills/fundamentals/SKILL.md` |
| geometry, BufferGeometry, shape, vertices, edges, instanced, points, lines | [geometry](sub-skills/geometry/SKILL.md) | `sub-skills/geometry/SKILL.md` |
| material, PBR, MeshStandard, MeshPhysical, phong, lambert, toon | [materials](sub-skills/materials/SKILL.md) | `sub-skills/materials/SKILL.md` |
| light, shadow, ambient, directional, point, spot, hemisphere, IBL, environment lighting | [lighting](sub-skills/lighting/SKILL.md) | `sub-skills/lighting/SKILL.md` |
| texture, UV, cubemap, HDR, environment map, canvas texture, video texture, render target | [textures](sub-skills/textures/SKILL.md) | `sub-skills/textures/SKILL.md` |
| load, GLTF, GLB, OBJ, FBX, STL, model, LoadingManager, asset | [loaders](sub-skills/loaders/SKILL.md) | `sub-skills/loaders/SKILL.md` |
| animation, keyframe, skeletal, morph target, AnimationMixer, AnimationClip, tween | [animation](sub-skills/animation/SKILL.md) | `sub-skills/animation/SKILL.md` |
| raycaster, click, mouse, touch, OrbitControls, DragControls, selection, interaction | [interaction](sub-skills/interaction/SKILL.md) | `sub-skills/interaction/SKILL.md` |
| shader, GLSL, ShaderMaterial, uniform, varying, vertex shader, fragment shader | [shaders](sub-skills/shaders/SKILL.md) | `sub-skills/shaders/SKILL.md` |
| post-processing, EffectComposer, bloom, DOF, FXAA, SSAO, glitch, outline, color grading | [postprocessing](sub-skills/postprocessing/SKILL.md) | `sub-skills/postprocessing/SKILL.md` |

## Routing Logic

1. Identify keywords/intent from user request
2. Match one or more sub-skills from the table above
3. Read matched sub-skill's SKILL.md: `sub-skills/<name>/SKILL.md`
4. For cross-domain tasks (e.g. "PBR material with custom lighting"), load multiple sub-skills
5. Execute per each sub-skill's instructions

**Important**: This index only routes. All execution logic lives in sub-skill SKILL.md files.
