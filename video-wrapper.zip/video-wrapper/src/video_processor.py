#!/usr/bin/env python3
"""
Interview video processor - Main script
Adds fancy text and term definition cards to interview videos

Supports two rendering backends:
- browser: HTML/CSS/Anime.js via Playwright (default, better visual quality)
- pil: Python PIL (fallback, no additional dependencies)
"""
import json
import sys
import os
import argparse
import shutil
import tempfile
import subprocess
import re
from pathlib import Path
from collections import Counter

# 将 src 目录加入 Python 路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from moviepy import VideoFileClip, CompositeVideoClip


_EN_STOPWORDS = {
    'a', 'an', 'the', 'and', 'or', 'but', 'if', 'then', 'so', 'because',
    'of', 'to', 'in', 'on', 'for', 'with', 'as', 'at', 'by', 'from',
    'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'this', 'that', 'these', 'those',
    'i', 'you', 'he', 'she', 'it', 'we', 'they',
    'me', 'him', 'her', 'us', 'them',
    'my', 'your', 'his', 'her', 'its', 'our', 'their',
    'not', 'no', 'yes', 'do', 'does', 'did', 'done',
    'have', 'has', 'had', 'will', 'would', 'can', 'could', 'should', 'may', 'might',
    'there', 'here', 'about', 'into', 'over', 'under', 'than', 'also', 'just',
    'who', 'whom', 'which', 'what', 'when', 'where', 'why', 'how',
    'all', 'any', 'both', 'some', 'such', 'only', 'even', 'ever', 'much', 'many',
    'more', 'most', 'other', 'another', 'each', 'every',
    'very', 'really', 'quite', 'rather', 'still', 'yet', 'too',
    'up', 'down', 'out', 'off', 'back', 'again',
    'include', 'includes', 'including',
    'happen', 'happens', 'happened', 'happening',
    'get', 'gets', 'getting', 'got',
    'make', 'makes', 'making', 'made',
    'say', 'says', 'said',
    'go', 'goes', 'going', 'went'
}

_SPECIAL_TERM_BOOST = {
    'ai', 'llm', 'gpt', 'rlhf', 'r1', 'deepseek', 'transformer',
    'diffusion', 'alignment', 'tokens', 'prompt', 'inference', 'training'
}

_SPECIAL_PHRASES = [
    'machine learning',
    'artificial intelligence',
    'deep learning',
    'large language model',
    'language model',
    'reinforcement learning',
    'state-of-the-art',
    'open source'
]

_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9'’\\-]*")

_ARPABET_VOWELS = {
    'AA', 'AE', 'AH', 'AO', 'AW', 'AY', 'EH', 'ER', 'EY', 'IH', 'IY', 'OW', 'OY', 'UH', 'UW'
}

_ARPABET_ONSET_MAP = {
    'B': 'b', 'CH': 'ch', 'D': 'd', 'DH': 'z', 'F': 'f', 'G': 'g', 'HH': 'h',
    'JH': 'j', 'K': 'k', 'L': 'l', 'M': 'm', 'N': 'n', 'NG': 'ng', 'P': 'p',
    'R': 'r', 'S': 's', 'SH': 'sh', 'T': 't', 'TH': 's', 'V': 'w', 'W': 'w',
    'Y': 'y', 'Z': 'z', 'ZH': 'zh'
}

_ARPABET_VOWEL_MAP = {
    'AA': 'a', 'AE': 'ai', 'AH': 'e', 'AO': 'ao', 'AW': 'ao', 'AY': 'ai',
    'EH': 'e', 'ER': 'er', 'EY': 'ei', 'IH': 'i', 'IY': 'yi', 'OW': 'ou',
    'OY': 'oi', 'UH': 'u', 'UW': 'wu'
}

_ARPABET_CODA_MAP = {
    'N': 'n', 'NG': 'ng', 'M': 'm', 'L': 'l', 'R': 'r', 'S': 's', 'Z': 'z',
    'T': 't', 'D': 'd', 'K': 'k', 'P': 'p', 'F': 'f', 'V': 'w', 'CH': 'ch', 'SH': 'sh'
}

def check_browser_renderer_available():
    """检查浏览器渲染器 (Playwright) 是否可用"""
    try:
        from browser_renderer import check_playwright_installed
        return check_playwright_installed()
    except ImportError:
        return False


def check_ffmpeg_available(ffmpeg_path='ffmpeg'):
    """检查 ffmpeg 是否可用"""
    return shutil.which(ffmpeg_path) is not None


def check_ffmpeg_subtitles_filter(ffmpeg_path='ffmpeg'):
    """检查 ffmpeg 是否支持 subtitles 滤镜"""
    try:
        result = subprocess.run(
            [ffmpeg_path, '-filters'],
            capture_output=True,
            text=True,
            check=False
        )
    except FileNotFoundError:
        return False
    output = (result.stdout or '') + (result.stderr or '')
    return 'subtitles' in output


def _resolve_ffprobe_path(ffmpeg_path='ffmpeg'):
    """根据 ffmpeg 路径推断 ffprobe 路径"""
    if ffmpeg_path:
        base = os.path.basename(ffmpeg_path)
        if base == 'ffmpeg':
            cand = os.path.join(os.path.dirname(ffmpeg_path), 'ffprobe') if os.path.dirname(ffmpeg_path) else 'ffprobe'
            if shutil.which(cand):
                return cand
    if shutil.which('ffprobe'):
        return 'ffprobe'
    return 'ffprobe'


def _probe_stream_bitrate(video_path, stream_selector, ffprobe_path):
    """获取指定流码率 (bps)，失败返回 None"""
    try:
        result = subprocess.run(
            [
                ffprobe_path, '-v', 'error',
                '-select_streams', stream_selector,
                '-show_entries', 'stream=bit_rate',
                '-of', 'default=nokey=1:noprint_wrappers=1',
                video_path
            ],
            capture_output=True,
            text=True,
            check=False
        )
    except FileNotFoundError:
        return None
    value = (result.stdout or '').strip()
    if value.isdigit():
        return int(value)
    return None


def _probe_format_bitrate(video_path, ffprobe_path):
    """获取整体码率 (bps)，失败返回 None"""
    try:
        result = subprocess.run(
            [
                ffprobe_path, '-v', 'error',
                '-show_entries', 'format=bit_rate',
                '-of', 'default=nokey=1:noprint_wrappers=1',
                video_path
            ],
            capture_output=True,
            text=True,
            check=False
        )
    except FileNotFoundError:
        return None
    value = (result.stdout or '').strip()
    if value.isdigit():
        return int(value)
    return None


def _parse_bitrate_to_bps(bitrate):
    """将码率字符串转换为 bps"""
    if bitrate is None:
        return None
    if isinstance(bitrate, (int, float)):
        return int(bitrate)
    text = str(bitrate).strip().lower()
    if not text:
        return None
    if text.endswith('k'):
        try:
            return int(float(text[:-1]) * 1000)
        except ValueError:
            return None
    if text.endswith('m'):
        try:
            return int(float(text[:-1]) * 1000 * 1000)
        except ValueError:
            return None
    if text.isdigit():
        return int(text)
    return None


def _normalize_bitrate_arg(bitrate):
    """返回 ffmpeg 可用的码率字符串与 bps"""
    if bitrate is None:
        return None, None
    bps = _parse_bitrate_to_bps(bitrate)
    if bps is None:
        return str(bitrate), None
    kbps = max(1, int(bps / 1000))
    return f"{kbps}k", bps


def _format_bitrate_from_bps(bps):
    """将 bps 格式化为 ffmpeg 的 k 字符串"""
    if not bps or bps <= 0:
        return None
    kbps = max(1, int(bps / 1000))
    return f"{kbps}k"


def _load_profile(profile_path, profile_label):
    """加载画像配置文件（JSON 对象）"""
    if not profile_path:
        return {}
    resolved_path = Path(profile_path).expanduser().resolve()
    if not resolved_path.exists():
        raise FileNotFoundError(f"{profile_label} 画像文件不存在: {resolved_path}")
    with open(resolved_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"{profile_label} 画像必须是 JSON 对象")
    profile = dict(data)
    profile['__path__'] = str(resolved_path)
    return profile


def _profile_value(profile, *keys):
    """按优先顺序读取画像字段"""
    if not profile:
        return None
    for key in keys:
        if key in profile and profile[key] is not None:
            return profile[key]
    return None


def _normalize_profile_choice(value, choices):
    """标准化画像中的枚举值"""
    if value is None:
        return None
    text = str(value).strip()
    return text if text in choices else None


def _normalize_profile_positive_int(value):
    """标准化画像中的正整数"""
    if value is None:
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _normalize_profile_positive_float(value):
    """标准化画像中的正浮点数"""
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if number > 0 else None


def _ffmpeg_cmd_prefix(ffmpeg_path, ffmpeg_loglevel):
    """构建统一 ffmpeg 命令前缀"""
    cmd = [ffmpeg_path]
    if ffmpeg_loglevel:
        cmd.extend(['-hide_banner', '-loglevel', ffmpeg_loglevel])
    return cmd


def _format_bytes_human(size_bytes):
    """格式化字节数为可读字符串"""
    if size_bytes is None:
        return "N/A"
    value = float(size_bytes)
    units = ['B', 'KB', 'MB', 'GB', 'TB']
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.2f}{unit}"
        value /= 1024
    return f"{size_bytes}B"


def _probe_output_summary(output_path, ffprobe_path):
    """探测输出文件摘要信息"""
    try:
        result = subprocess.run(
            [
                ffprobe_path,
                '-v', 'error',
                '-print_format', 'json',
                '-show_entries',
                'format=duration,size,bit_rate:stream=index,codec_type,codec_name,width,height,avg_frame_rate,channels:stream_tags=language,title:stream_disposition=default',
                output_path
            ],
            capture_output=True,
            text=True,
            check=False
        )
    except FileNotFoundError:
        return None
    if result.returncode != 0:
        return None
    try:
        return json.loads(result.stdout or '{}')
    except json.JSONDecodeError:
        return None


def _print_delivery_summary(output_path, ffprobe_path):
    """打印交付摘要（体积/时长/轨道）"""
    summary = _probe_output_summary(output_path, ffprobe_path)
    if not summary:
        print("⚠️ 无法生成交付摘要（ffprobe 不可用或输出异常）")
        return

    format_info = summary.get('format', {})
    duration_raw = format_info.get('duration')
    size_raw = format_info.get('size')
    bit_rate_raw = format_info.get('bit_rate')

    try:
        duration_text = f"{float(duration_raw):.2f}s" if duration_raw is not None else "N/A"
    except (TypeError, ValueError):
        duration_text = "N/A"

    try:
        size_value = int(size_raw)
    except (TypeError, ValueError):
        size_value = None

    try:
        bitrate_value = int(bit_rate_raw)
    except (TypeError, ValueError):
        bitrate_value = None

    print("📦 交付摘要:")
    print(f"   - 大小: {_format_bytes_human(size_value)} ({size_value if size_value is not None else 'N/A'} bytes)")
    print(f"   - 时长: {duration_text}")
    if bitrate_value is not None:
        print(f"   - 总码率: {int(bitrate_value / 1000)}k")
    else:
        print("   - 总码率: N/A")

    streams = summary.get('streams', [])
    for stream in streams:
        stream_index = stream.get('index', '?')
        codec_type = stream.get('codec_type', 'unknown')
        codec_name = stream.get('codec_name', 'unknown')
        default_disposition = (stream.get('disposition') or {}).get('default', 0)
        language = (stream.get('tags') or {}).get('language')
        if codec_type == 'video':
            width = stream.get('width')
            height = stream.get('height')
            print(f"   - 轨道#{stream_index}: video {codec_name} {width}x{height} default={default_disposition}")
        elif codec_type == 'audio':
            channels = stream.get('channels')
            language_text = f" language={language}" if language else ''
            print(f"   - 轨道#{stream_index}: audio {codec_name} ch={channels} default={default_disposition}{language_text}")
        elif codec_type == 'subtitle':
            language_text = f" language={language}" if language else ''
            print(f"   - 轨道#{stream_index}: subtitle {codec_name} default={default_disposition}{language_text}")
        else:
            print(f"   - 轨道#{stream_index}: {codec_type} {codec_name} default={default_disposition}")


def _estimate_source_video_bitrate(video_path, duration_sec, ffprobe_path):
    """估算源视频码率 (bps)，优先视频流码率"""
    video_bps = _probe_stream_bitrate(video_path, 'v:0', ffprobe_path)
    if video_bps:
        return video_bps
    total_bps = _probe_format_bitrate(video_path, ffprobe_path)
    if not total_bps and duration_sec and duration_sec > 0:
        total_bps = int(os.path.getsize(video_path) * 8 / duration_sec)
    if not total_bps:
        return None
    audio_bps = _probe_stream_bitrate(video_path, 'a:0', ffprobe_path)
    if audio_bps and total_bps > audio_bps:
        return int(total_bps - audio_bps)
    return int(total_bps * 0.92)


def _calc_video_bitrate_from_size(target_gb, duration_sec, audio_bps=None):
    """根据目标体积估算视频码率 (bps)"""
    if not duration_sec or duration_sec <= 0:
        return None
    target_total_bps = target_gb * 1024 * 1024 * 1024 * 8 / duration_sec
    if audio_bps:
        return max(1, int(target_total_bps - audio_bps))
    return int(target_total_bps * 0.95)


def process_video(
    video_path,
    subtitle_path,
    config_path,
    output_path,
    renderer='auto',
    pipeline='auto',
    overlay_fps=None,
    codec=None,
    preset=None,
    video_bitrate=None,
    audio_bitrate='128k',
    size_target=None,
    video_crf=None,
    ffmpeg_path='ffmpeg',
    ffmpeg_loglevel='warning',
    keep_temp=False,
    burn_subs=False,
    subs_style=None,
    soft_subs=False,
    bilingual=None,
    english_srt_path=None,
    subtitle_output=None,
    highlight_limit=1,
    pronunciation_mode='syllable-zh',
    subtitle_layout='two-line',
    style_profile=None,
    export_profile=None
):
    """
    主处理函数

    参数:
        video_path: 输入视频路径
        subtitle_path: 字幕文件路径（用于字幕处理）
        config_path: 配置文件路径
        output_path: 输出视频路径
        renderer: 渲染器类型 ('browser', 'pil', 'auto')
    """
    print(f"🎬 正在处理视频: {video_path}")

    # 验证输入文件存在
    if not os.path.exists(video_path):
        print(f"❌ 错误: 视频文件不存在: {video_path}")
        sys.exit(1)

    if not os.path.exists(config_path):
        print(f"❌ 错误: 配置文件不存在: {config_path}")
        sys.exit(1)

    if burn_subs and soft_subs:
        print("❌ 不能同时开启 burn_subs 和 soft_subs")
        sys.exit(1)

    style_profile = style_profile or {}
    export_profile = export_profile or {}

    if style_profile.get('__path__'):
        print(f"🧠 使用风格画像: {style_profile['__path__']}")
    if export_profile.get('__path__'):
        print(f"📦 使用导出画像: {export_profile['__path__']}")

    profile_renderer = _normalize_profile_choice(
        _profile_value(style_profile, 'renderer'),
        {'auto', 'browser', 'pil'}
    )
    if renderer == 'auto' and profile_renderer:
        renderer = profile_renderer
        print(f"🧩 画像覆盖渲染器: {renderer}")

    profile_pipeline = _normalize_profile_choice(
        _profile_value(style_profile, 'pipeline'),
        {'auto', 'moviepy', 'hybrid'}
    )
    if pipeline == 'auto' and profile_pipeline:
        pipeline = profile_pipeline
        print(f"🧩 画像覆盖管线: {pipeline}")

    profile_subtitle_layout = _normalize_profile_choice(
        _profile_value(style_profile, 'subtitle_layout', 'subtitleLayout'),
        {'single-line', 'two-line', 'stacked'}
    )
    if subtitle_layout == 'two-line' and profile_subtitle_layout:
        subtitle_layout = profile_subtitle_layout
        print(f"🧩 画像覆盖双语排版: {subtitle_layout}")

    profile_pronunciation_mode = _normalize_profile_choice(
        _profile_value(style_profile, 'pronunciation', 'pronunciation_mode', 'pronunciationMode'),
        {'syllable', 'syllable-zh'}
    )
    if pronunciation_mode == 'syllable-zh' and profile_pronunciation_mode:
        pronunciation_mode = profile_pronunciation_mode
        print(f"🧩 画像覆盖拼读模式: {pronunciation_mode}")

    profile_highlight_limit = _normalize_profile_positive_int(
        _profile_value(style_profile, 'highlight_limit', 'highlightLimit')
    )
    if highlight_limit == 1 and profile_highlight_limit:
        highlight_limit = profile_highlight_limit
        print(f"🧩 画像覆盖每句高亮数: {highlight_limit}")

    profile_codec = _profile_value(export_profile, 'codec')
    if codec is None and profile_codec:
        codec = str(profile_codec)
        print(f"🧩 画像覆盖编码器: {codec}")

    profile_preset = _profile_value(export_profile, 'preset')
    if preset is None and profile_preset:
        preset = str(profile_preset)
        print(f"🧩 画像覆盖编码预设: {preset}")

    profile_video_bitrate = _profile_value(export_profile, 'video_bitrate', 'videoBitrate')
    if video_bitrate is None and profile_video_bitrate:
        video_bitrate = str(profile_video_bitrate)
        print(f"🧩 画像覆盖视频码率: {video_bitrate}")

    profile_audio_bitrate = _profile_value(export_profile, 'audio_bitrate', 'audioBitrate')
    if (audio_bitrate in [None, '128k']) and profile_audio_bitrate:
        audio_bitrate = str(profile_audio_bitrate)
        print(f"🧩 画像覆盖音频码率: {audio_bitrate}")

    profile_size_target = _normalize_profile_positive_float(
        _profile_value(export_profile, 'size_target', 'size_target_gb', 'sizeTargetGb', 'sizeTarget')
    )
    if size_target is None and profile_size_target:
        size_target = profile_size_target
        print(f"🧩 画像覆盖目标体积: {size_target}GB")

    profile_ffmpeg_path = _profile_value(export_profile, 'ffmpeg_path', 'ffmpegPath')
    if ffmpeg_path == 'ffmpeg' and profile_ffmpeg_path:
        ffmpeg_path = str(profile_ffmpeg_path)
        print(f"🧩 画像覆盖 ffmpeg 路径: {ffmpeg_path}")

    profile_ffmpeg_loglevel = _normalize_profile_choice(
        _profile_value(export_profile, 'ffmpeg_loglevel', 'ffmpegLoglevel', 'ffmpegLogLevel'),
        {'quiet', 'panic', 'fatal', 'error', 'warning', 'info', 'verbose', 'debug', 'trace'}
    )
    if ffmpeg_loglevel == 'warning' and profile_ffmpeg_loglevel:
        ffmpeg_loglevel = profile_ffmpeg_loglevel
        print(f"🧩 画像覆盖 ffmpeg 日志级别: {ffmpeg_loglevel}")

    if size_target and size_target > 20:
        print("⚠️ --size-target 单位是 GB，若你想输入 MB 请改用 GB 换算值")

    # 确定渲染器
    if renderer == 'auto':
        if check_browser_renderer_available():
            renderer = 'browser'
            print("🌐 使用浏览器渲染器 (HTML/CSS/Anime.js)")
        else:
            renderer = 'pil'
            print("🎨 使用 PIL 渲染器 (Playwright 不可用)")
    elif renderer == 'browser':
        if not check_browser_renderer_available():
            print("❌ 错误: 浏览器渲染器不可用")
            print("请运行以下命令安装:")
            print("  pip install playwright")
            print("  playwright install chromium")
            sys.exit(1)
        print("🌐 使用浏览器渲染器 (HTML/CSS/Anime.js)")
    else:
        print("🎨 使用 PIL 渲染器")

    # 1. 加载配置
    print("📋 加载配置文件...")
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    profile_theme = _profile_value(style_profile, 'theme')
    if profile_theme:
        config['theme'] = str(profile_theme)
        print(f"🧩 画像覆盖主题: {config['theme']}")

    # 2. 加载原始视频
    print("📹 加载原始视频...")
    video = VideoFileClip(video_path)
    print(f"   - 分辨率: {video.w}x{video.h}")
    print(f"   - 帧率: {video.fps} fps")
    print(f"   - 时长: {video.duration:.2f} 秒")

    # 记录临时目录，便于清理
    temp_dirs = []
    soft_subs_path = subtitle_path

    if (burn_subs or soft_subs) and not os.path.exists(subtitle_path):
        print(f"❌ 字幕文件不存在: {subtitle_path}")
        sys.exit(1)

    if soft_subs:
        resolved_english = _resolve_english_srt(
            subtitle_path,
            english_srt_path,
            video_path
        )
        if bilingual is None:
            bilingual = bool(resolved_english)
        if bilingual:
            if not resolved_english:
                print("⚠️ 未找到英文字幕，已回退为单语字幕")
                bilingual = False
            else:
                if subtitle_output is None:
                    subtitle_output = _default_ass_output_path(output_path)
                _generate_bilingual_ass(
                    english_srt_path=resolved_english,
                    chinese_srt_path=subtitle_path,
                    output_path=subtitle_output,
                    highlight_limit=highlight_limit,
                    pronunciation_mode=pronunciation_mode,
                    video_width=video.w,
                    video_height=video.h,
                    video_duration=video.duration,
                    subtitle_layout=subtitle_layout
                )
                soft_subs_path = subtitle_output
                if Path(output_path).suffix.lower() != '.mkv':
                    new_output = str(Path(output_path).with_suffix('.mkv'))
                    print(f"⚠️ 双语 ASS 字幕将输出为 MKV: {new_output}")
                    output_path = new_output

    # 根据源视频动态推断目标码率
    ffprobe_path = _resolve_ffprobe_path(ffmpeg_path)
    audio_bitrate_arg, audio_bps = _normalize_bitrate_arg(audio_bitrate)
    video_bitrate_arg, _ = _normalize_bitrate_arg(video_bitrate)
    source_video_bps = _estimate_source_video_bitrate(video_path, video.duration, ffprobe_path)
    if size_target:
        source_audio_bps = audio_bps or _probe_stream_bitrate(video_path, 'a:0', ffprobe_path)
        target_video_bps = _calc_video_bitrate_from_size(size_target, video.duration, source_audio_bps)
        video_bitrate_arg = _format_bitrate_from_bps(target_video_bps)
    elif not video_bitrate_arg and source_video_bps:
        video_bitrate_arg = _format_bitrate_from_bps(source_video_bps)

    if video_bitrate_arg:
        print(f"📏 输出视频码率目标: {video_bitrate_arg}")
    else:
        print("⚠️ 未能获取源视频码率，使用编码器默认码率")

    try:
        if pipeline == 'auto':
            if renderer == 'browser' and check_ffmpeg_available(ffmpeg_path):
                pipeline = 'hybrid'
            else:
                pipeline = 'moviepy'

        if pipeline == 'hybrid' and renderer != 'browser':
            print("⚠️ hybrid 管线需要浏览器渲染器，已回退到 moviepy")
            pipeline = 'moviepy'

        if pipeline == 'hybrid':
            if burn_subs and not check_ffmpeg_subtitles_filter(ffmpeg_path):
                print("❌ 当前 ffmpeg 缺少 subtitles 滤镜，无法内嵌字幕")
                print("请安装带 libass 的 ffmpeg，或改用软字幕方案")
                sys.exit(1)

            # 使用浏览器渲染透明叠加层，再用 ffmpeg 合成
            render_fps = overlay_fps if overlay_fps else video.fps
            overlays = _generate_overlays_browser(
                config,
                video.w,
                video.h,
                render_fps,
                temp_dirs,
                ffmpeg_path,
                ffmpeg_loglevel
            )

            if not overlays and not burn_subs and not soft_subs:
                print("⚠️ 未生成任何特效叠加层，直接复制原视频")
                _copy_video_with_ffmpeg(
                    video_path,
                    output_path,
                    ffmpeg_path,
                    ffmpeg_loglevel
                )
            elif not overlays and soft_subs and not burn_subs:
                print(f"💾 导出最终视频到: {output_path}")
                print("   (这可能需要几分钟，请耐心等待...)")
                _mux_soft_subs_with_ffmpeg(
                    base_video_path=video_path,
                    subs_path=soft_subs_path,
                    output_path=output_path,
                    ffmpeg_path=ffmpeg_path,
                    ffmpeg_loglevel=ffmpeg_loglevel
                )
            else:
                out_codec = codec if codec else _default_output_codec()
                out_preset = preset if preset else _default_output_preset(out_codec)
                print(f"💾 导出最终视频到: {output_path}")
                print("   (这可能需要几分钟，请耐心等待...)")
                _compose_overlays_with_ffmpeg(
                    base_video_path=video_path,
                    overlays=overlays,
                    output_path=output_path,
                    codec=out_codec,
                    preset=out_preset,
                    video_bitrate=video_bitrate_arg,
                    video_crf=video_crf,
                    audio_bitrate=audio_bitrate_arg,
                    ffmpeg_path=ffmpeg_path,
                    ffmpeg_loglevel=ffmpeg_loglevel,
                    burn_subs=burn_subs,
                    subs_path=soft_subs_path,
                    subs_style=subs_style,
                    soft_subs=soft_subs
                )
        else:
            if burn_subs:
                print("⚠️ moviepy 管线暂不支持内嵌字幕，请使用 --pipeline hybrid")
            if soft_subs:
                print("⚠️ moviepy 管线暂不支持软字幕，请使用 --pipeline hybrid")
            if renderer == 'browser':
                text_clips, card_clips = _generate_clips_browser(
                    config, video.w, video.h, video.fps, temp_dirs
                )
            else:
                text_clips, card_clips = _generate_clips_pil(
                    config, video.w, video.h, video.fps
                )

            # 5. 合成所有图层
            print("🎨 合成视频图层...")
            all_clips = [video] + text_clips + card_clips
            final_video = CompositeVideoClip(all_clips, size=(video.w, video.h))

            # 6. 导出最终视频（moviepy）
            print(f"💾 导出最终视频到: {output_path}")
            print("   (这可能需要几分钟，请耐心等待...)")
            export_kwargs = {
                'codec': 'libx264',
                'audio_codec': 'aac',
                'fps': video.fps,
                'preset': 'medium',
                'threads': 4,
                'logger': 'bar'
            }
            if video_bitrate_arg:
                export_kwargs['bitrate'] = video_bitrate_arg
            if audio_bitrate_arg:
                export_kwargs['audio_bitrate'] = audio_bitrate_arg
            final_video.write_videofile(
                output_path,
                **export_kwargs
            )

            # 清理
            final_video.close()

        video.close()

    finally:
        # 清理临时目录
        if not keep_temp:
            for temp_dir in temp_dirs:
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir, ignore_errors=True)

    print("✅ 处理完成！")
    print(f"📁 输出文件: {output_path}")
    _print_delivery_summary(output_path, ffprobe_path)


def _generate_clips_browser(config, width, height, fps, temp_dirs):
    """Generate clips using browser renderer"""
    from browser_renderer import BrowserRenderer
    from moviepy import ImageSequenceClip

    all_effect_clips = []

    # Get theme from config (default: notion)
    theme = config.get('theme', 'notion')
    print(f"🎨 主题: {theme}")

    with BrowserRenderer(width=width, height=height, fps=fps) as renderer:

        # 1. 生成人物条片段
        lower_thirds = config.get('lowerThirds', [])
        if lower_thirds:
            print(f"👤 生成人物条 ({len(lower_thirds)} 个)...")
            for i, lt in enumerate(lower_thirds):
                print(f"   - 人物条: {lt['name']}")
                temp_dir = tempfile.mkdtemp(prefix=f'lower_third_{i}_')
                temp_dirs.append(temp_dir)

                lt_config = {
                    'name': lt['name'],
                    'role': lt.get('role', ''),
                    'company': lt.get('company', ''),
                    'theme': theme,
                    'durationMs': lt.get('durationMs', 5000)
                }
                frame_paths = renderer.render_lower_third_frames(lt_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(lt['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 2. 生成章节标题片段
        chapters = config.get('chapterTitles', [])
        if chapters:
            print(f"📑 生成章节标题 ({len(chapters)} 个)...")
            for i, ch in enumerate(chapters):
                print(f"   - 章节: {ch['title']}")
                temp_dir = tempfile.mkdtemp(prefix=f'chapter_{i}_')
                temp_dirs.append(temp_dir)

                ch_config = {
                    'number': ch.get('number', ''),
                    'title': ch['title'],
                    'subtitle': ch.get('subtitle', ''),
                    'theme': theme,
                    'durationMs': ch.get('durationMs', 4000)
                }
                frame_paths = renderer.render_chapter_title_frames(ch_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(ch['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 3. 生成花字片段
        key_phrases = config.get('keyPhrases', [])
        if key_phrases:
            print(f"✨ 生成花字动画 ({len(key_phrases)} 个)...")
            for i, phrase in enumerate(key_phrases):
                print(f"   - 花字 {i+1}: {phrase['text']}")
                temp_dir = tempfile.mkdtemp(prefix=f'fancy_text_{i}_')
                temp_dirs.append(temp_dir)

                # Calculate position: above subtitles area, alternating left/right
                # Subtitles typically at bottom 15-20% of screen, so place fancy text at top 15-25%
                x_offset = (i % 2) * 300  # Slight horizontal offset for variety
                position = phrase.get('position', {
                    'x': width // 2 - 150 + x_offset,
                    'y': 120 + (i % 3) * 40  # Top area: 120-200px from top
                })

                frame_config = {
                    'text': phrase['text'],
                    'style': phrase.get('style', 'emphasis'),
                    'theme': theme,
                    'position': position,
                    'startMs': phrase['startMs'],
                    'endMs': phrase['endMs']
                }
                frame_paths = renderer.render_fancy_text_frames(frame_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(phrase['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 4. 生成名词卡片片段
        term_defs = config.get('termDefinitions', [])
        if term_defs:
            print(f"📋 生成名词卡片 ({len(term_defs)} 个)...")
            for i, term in enumerate(term_defs):
                print(f"   - 卡片: {term['chinese']}")
                temp_dir = tempfile.mkdtemp(prefix=f'term_card_{i}_')
                temp_dirs.append(temp_dir)

                card_config = {
                    'chinese': term['chinese'],
                    'english': term['english'],
                    'description': term['description'],
                    'theme': theme,
                    'displayDurationSeconds': term.get('displayDurationSeconds', 6)
                }
                frame_paths = renderer.render_term_card_frames(card_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(term['firstAppearanceMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 5. 生成金句卡片片段
        quotes = config.get('quotes', [])
        if quotes:
            print(f"💬 生成金句卡片 ({len(quotes)} 个)...")
            for i, quote in enumerate(quotes):
                print(f"   - 金句: {quote['text'][:20]}...")
                temp_dir = tempfile.mkdtemp(prefix=f'quote_{i}_')
                temp_dirs.append(temp_dir)

                quote_config = {
                    'text': quote['text'],
                    'author': quote.get('author', ''),
                    'theme': theme,
                    'position': quote.get('position', {'x': width // 2, 'y': height // 2}),
                    'durationMs': quote.get('durationMs', 5000)
                }
                frame_paths = renderer.render_quote_callout_frames(quote_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(quote['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 6. 生成数据动画片段
        stats = config.get('stats', [])
        if stats:
            print(f"📊 生成数据动画 ({len(stats)} 个)...")
            for i, stat in enumerate(stats):
                print(f"   - 数据: {stat.get('prefix', '')}{stat['number']}{stat.get('unit', '')}")
                temp_dir = tempfile.mkdtemp(prefix=f'stats_{i}_')
                temp_dirs.append(temp_dir)

                stat_config = {
                    'prefix': stat.get('prefix', ''),
                    'number': stat['number'],
                    'unit': stat.get('unit', ''),
                    'label': stat.get('label', ''),
                    'theme': theme,
                    'position': stat.get('position', {'x': width // 2, 'y': height // 2}),
                    'durationMs': stat.get('durationMs', 4000)
                }
                frame_paths = renderer.render_animated_stats_frames(stat_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(stat['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 7. 生成要点列表片段
        bullet_points = config.get('bulletPoints', [])
        if bullet_points:
            print(f"📝 生成要点列表 ({len(bullet_points)} 个)...")
            for i, bp in enumerate(bullet_points):
                print(f"   - 要点: {bp.get('title', '要点列表')}")
                temp_dir = tempfile.mkdtemp(prefix=f'bullets_{i}_')
                temp_dirs.append(temp_dir)

                bp_config = {
                    'title': bp.get('title', ''),
                    'points': bp['points'],
                    'theme': theme,
                    'position': bp.get('position', {'x': 100, 'y': 300}),
                    'durationMs': bp.get('durationMs', 6000)
                }
                frame_paths = renderer.render_bullet_points_frames(bp_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(bp['startMs'] / 1000.0)
                all_effect_clips.append(clip)

        # 8. 生成社交媒体条片段
        social_bars = config.get('socialBars', [])
        if social_bars:
            print(f"📱 生成社交媒体条 ({len(social_bars)} 个)...")
            for i, sb in enumerate(social_bars):
                print(f"   - 社交: {sb['handle']}")
                temp_dir = tempfile.mkdtemp(prefix=f'social_{i}_')
                temp_dirs.append(temp_dir)

                sb_config = {
                    'platform': sb.get('platform', 'twitter'),
                    'label': sb.get('label', '关注'),
                    'handle': sb['handle'],
                    'theme': theme,
                    'position': sb.get('position', {'x': width - 320, 'y': height - 130}),
                    'durationMs': sb.get('durationMs', 8000)  # Default 8 seconds for social bar
                }
                frame_paths = renderer.render_social_bar_frames(sb_config, temp_dir)
                clip = ImageSequenceClip(frame_paths, fps=fps)
                clip = clip.with_start(sb['startMs'] / 1000.0)
                all_effect_clips.append(clip)

    # Return all clips (split into two lists for compatibility)
    return all_effect_clips, []


def _default_output_codec():
    """根据平台选择默认编码器"""
    return 'h264_videotoolbox' if sys.platform == 'darwin' else 'libx264'


def _default_output_preset(codec):
    """软件编码器默认预设"""
    if codec == 'libx264':
        return 'veryfast'
    return None


def _encode_overlay_video(frame_dir, fps, output_path, ffmpeg_path, ffmpeg_loglevel):
    """将 PNG 序列编码为带透明通道的叠加层视频"""
    frame_pattern = os.path.join(frame_dir, 'frame_%05d.png')
    cmd = _ffmpeg_cmd_prefix(ffmpeg_path, ffmpeg_loglevel) + [
        '-y',
        '-framerate', str(fps),
        '-start_number', '0',
        '-i', frame_pattern,
        '-c:v', 'qtrle',
        '-pix_fmt', 'argb',
        output_path
    ]
    subprocess.run(cmd, check=True)


def _escape_filter_value(value):
    """转义 ffmpeg filter 参数中的特殊字符"""
    value = value.replace('\\', '\\\\')
    value = value.replace(':', '\\:')
    value = value.replace(',', '\\,')
    value = value.replace('[', '\\[')
    value = value.replace(']', '\\]')
    value = value.replace(' ', '\\ ')
    return value


def _default_subs_style():
    """默认字幕样式（适配中文）"""
    return 'FontName=PingFang SC,FontSize=28,Outline=1,Shadow=0,MarginV=40'


def _build_subtitles_filter(subs_path, style):
    """构建字幕滤镜"""
    escaped_path = _escape_filter_value(subs_path)
    if style:
        escaped_style = _escape_filter_value(style)
        return f"subtitles=filename={escaped_path}:force_style={escaped_style}"
    return f"subtitles=filename={escaped_path}"


def _subtitle_codec_for_output(subs_path, output_path):
    """根据输出容器选择字幕编码"""
    subs_ext = Path(subs_path).suffix.lower()
    out_ext = Path(output_path).suffix.lower()
    if subs_ext == '.ass':
        if out_ext != '.mkv':
            raise ValueError("ASS 字幕需要输出为 MKV 容器")
        return 'ass'
    if subs_ext == '.srt':
        if out_ext in ['.mp4', '.m4v', '.mov']:
            return 'mov_text'
        return 'subrip'
    return 'mov_text'


def _subtitle_language_tag(subs_path):
    """根据字幕文件名推断语言标签"""
    name = Path(subs_path).name.lower()
    if re.search(r'(^|[._-])zh', name):
        return 'zho'
    if re.search(r'(^|[._-])en', name):
        return 'eng'
    return 'und'


def _default_ass_output_path(output_path):
    """默认 ASS 字幕输出路径"""
    return str(Path(output_path).with_suffix('.ass'))


def _resolve_english_srt(chinese_srt_path, english_srt_path, video_path):
    """自动推断英文字幕路径"""
    if english_srt_path and os.path.exists(english_srt_path):
        return english_srt_path

    if chinese_srt_path:
        base_dir = os.path.dirname(chinese_srt_path)
        base_name = os.path.basename(chinese_srt_path)
        candidates = []
        if '.zh-Hans.' in base_name:
            candidates.append(base_name.replace('.zh-Hans.', '.en.'))
        if '.zh-Hant.' in base_name:
            candidates.append(base_name.replace('.zh-Hant.', '.en.'))
        if base_name.endswith('.srt'):
            candidates.append(base_name.replace('.srt', '.en.srt'))
        for cand in candidates:
            cand_path = os.path.join(base_dir, cand)
            if os.path.exists(cand_path):
                return cand_path

    if video_path:
        video_dir = os.path.dirname(video_path)
        video_base = Path(video_path).stem
        cand_path = os.path.join(video_dir, f'{video_base}.en.srt')
        if os.path.exists(cand_path):
            return cand_path

    original_cwd = os.environ.get('ORIGINAL_CWD', os.getcwd())
    for cand in ['video.en.srt']:
        cand_path = os.path.join(original_cwd, cand)
        if os.path.exists(cand_path):
            return cand_path

    return None


def _load_srt_items(path):
    """读取 SRT 字幕"""
    import pysrt
    subs = pysrt.open(path, encoding='utf-8')
    items = []
    for s in subs:
        text = ' '.join(s.text.split()).strip()
        text = re.sub(r'\\+\s*$', '', text)
        if not text:
            continue
        start = s.start.ordinal / 1000.0
        end = s.end.ordinal / 1000.0
        items.append({
            'start': start,
            'end': end,
            'text': text
        })
    return items


def _is_incremental_text(text_a, text_b):
    """判断是否是增量扩展文本（避免重复堆叠）"""
    a = text_a.lower()
    b = text_b.lower()
    if a in b or b in a:
        return True
    prefix = os.path.commonprefix([a, b])
    min_len = max(1, min(len(a), len(b)))
    return len(prefix) / min_len >= 0.6


def _merge_overlapping_items(items):
    """合并时间上重叠且内容为增量扩展的字幕段"""
    if not items:
        return []
    items = sorted(items, key=lambda x: (x['start'], x['end']))
    merged = []
    group = [items[0]]
    group_start = items[0]['start']
    group_end = items[0]['end']
    best_text = items[0]['text']

    for item in items[1:]:
        if item['start'] <= group_end and _is_incremental_text(item['text'], best_text):
            group.append(item)
            group_end = max(group_end, item['end'])
            if len(item['text']) > len(best_text):
                best_text = item['text']
            continue

        merged.append({
            'start': group_start,
            'end': group_end,
            'text': best_text
        })
        group = [item]
        group_start = item['start']
        group_end = item['end']
        best_text = item['text']

    merged.append({
        'start': group_start,
        'end': group_end,
        'text': best_text
    })
    return merged


def _resolve_overlaps(items, min_gap=0.02):
    """确保字幕不重叠（避免多行叠在一起）"""
    if not items:
        return []
    resolved = [items[0]]
    for item in items[1:]:
        prev = resolved[-1]
        if item['start'] < prev['end']:
            new_end = max(prev['start'], item['start'] - min_gap)
            if new_end <= prev['start']:
                resolved[-1] = item
            else:
                prev['end'] = new_end
                resolved[-1] = prev
                resolved.append(item)
        else:
            resolved.append(item)
    return resolved


def _align_bilingual(en_items, zh_items, max_gap=0.5):
    """按时间对齐英中字幕"""
    zh_idx = 0
    total_zh = len(zh_items)
    for en in en_items:
        while zh_idx < total_zh and zh_items[zh_idx]['end'] < en['start'] - max_gap:
            zh_idx += 1
        best = None
        best_overlap = -1.0
        j = zh_idx
        zh_end = en['end']
        while j < total_zh and zh_items[j]['start'] <= en['end'] + max_gap:
            zh_item = zh_items[j]
            overlap = min(en['end'], zh_item['end']) - max(en['start'], zh_item['start'])
            if overlap < 0:
                overlap = -abs(zh_item['start'] - en['start'])
            if overlap > best_overlap:
                best_overlap = overlap
                best = zh_item
            zh_end = max(zh_end, zh_item['end'])
            j += 1

        if best is None and total_zh > 0:
            candidates = []
            for k in [zh_idx - 1, zh_idx, zh_idx + 1]:
                if 0 <= k < total_zh:
                    diff = abs(zh_items[k]['start'] - en['start'])
                    candidates.append((diff, zh_items[k]))
            if candidates:
                _, best = min(candidates, key=lambda x: x[0])
                zh_end = max(zh_end, best['end'])

        yield {
            'start': en['start'],
            'end': en['end'],
            'en': en['text'],
            'zh': (best['text'] if best else '').strip()
        }


def _tokenize_words(text):
    """英文分词"""
    return [m.group(0) for m in _WORD_RE.finditer(text)]


def _build_frequency_index(en_items):
    """构建英文词频"""
    counter = Counter()
    for item in en_items:
        for token in _tokenize_words(item['text']):
            lower = token.lower()
            if lower in _EN_STOPWORDS:
                continue
            counter[lower] += 1
    return counter


def _find_special_phrases(text):
    """识别专有名词/缩写短语"""
    phrases = []
    lowered = text.lower()
    for phrase in _SPECIAL_PHRASES:
        start = 0
        phrase_lower = phrase.lower()
        while True:
            idx = lowered.find(phrase_lower, start)
            if idx == -1:
                break
            phrases.append({
                'phrase': text[idx:idx + len(phrase)],
                'span': (idx, idx + len(phrase)),
                'score': 1200 + len(phrase)
            })
            start = idx + len(phrase_lower)
    patterns = [
        re.compile(r"\\b[A-Z]{2,}(?:-[A-Z0-9]+)*\\b"),
        re.compile(r"\\b[A-Za-z]+[0-9]+\\b"),
        re.compile(r"\\b(?:[A-Z][a-z]+(?:\\s+[A-Z][a-z]+){1,2})\\b")
    ]
    for pattern in patterns:
        for m in pattern.finditer(text):
            phrase = m.group(0).strip()
            if len(phrase) < 2:
                continue
            phrases.append({
                'phrase': phrase,
                'span': m.span(),
                'score': 1000 + len(phrase)
            })
    return phrases


def _select_highlight_phrase(text, freq_index, highlight_limit=1):
    """选择需要高亮的英文短语"""
    if highlight_limit <= 0:
        return None
    specials = _find_special_phrases(text)
    if specials:
        return max(specials, key=lambda x: x['score'])

    best = None
    for m in _WORD_RE.finditer(text):
        token = m.group(0)
        lower = token.lower()
        if lower in _EN_STOPWORDS:
            continue
        freq = freq_index.get(lower, 0)
        score = max(0, 5 - min(freq, 5))
        if lower in _SPECIAL_TERM_BOOST:
            score += 5
        if len(lower) >= 6:
            score += 2
        if len(lower) >= 9:
            score += 2
        if best is None or score > best['score']:
            best = {'phrase': token, 'span': m.span(), 'score': score}
    return best


def _ass_escape(text):
    """ASS 字幕转义"""
    return text.replace('\\', '\\\\').replace('{', '\\{').replace('}', '\\}')


def _apply_ass_highlight(text, highlight, color='&H00F0FF&'):
    """在 ASS 字幕中高亮短语"""
    escaped = _ass_escape(text)
    if not highlight:
        return escaped
    start, end = highlight['span']
    before = _ass_escape(text[:start])
    mid = _ass_escape(text[start:end])
    after = _ass_escape(text[end:])
    return f"{before}{{\\c{color}\\b1}}{mid}{{\\rEN}}{after}"


def _apply_ass_highlight_inline(text, highlight, pron_line, color='&H00F0FF&'):
    """在 ASS 字幕中高亮短语并内联拼读提示"""
    escaped = _ass_escape(text)
    if not highlight:
        return escaped
    start, end = highlight['span']
    before = _ass_escape(text[:start])
    mid = _ass_escape(text[start:end])
    after = _ass_escape(text[end:])
    pron_text = ''
    if pron_line:
        pron_text = f" {{\\rPRON}}({_ass_escape(pron_line)}){{\\rEN}}"
    return f"{before}{{\\c{color}\\b1}}{mid}{{\\rEN}}{pron_text}{after}"


def _lazy_pronouncing():
    """延迟加载 pronouncing"""
    if (not hasattr(_lazy_pronouncing, 'module')) or _lazy_pronouncing.module is None:
        try:
            import pronouncing
            _lazy_pronouncing.module = pronouncing
        except ImportError:
            _lazy_pronouncing.module = None
    return _lazy_pronouncing.module


def _lazy_pyphen():
    """延迟加载 pyphen"""
    if (not hasattr(_lazy_pyphen, 'module')) or _lazy_pyphen.module is None:
        try:
            import pyphen
            _lazy_pyphen.module = pyphen.Pyphen(lang='en_US')
        except ImportError:
            _lazy_pyphen.module = None
    return _lazy_pyphen.module


def _fallback_syllables(word):
    """简易分音节回退"""
    parts = re.findall(r"[^aeiouy]*[aeiouy]+(?:[^aeiouy]*)", word.lower())
    return parts if parts else [word.lower()]


def _approx_zh_from_arpabet(word):
    """基于 ARPAbet 的中文拼读提示"""
    pronouncing = _lazy_pronouncing()
    if not pronouncing:
        return None
    lower = word.lower()
    phones_list = pronouncing.phones_for_word(lower)
    if not phones_list:
        return None
    phones = phones_list[0].split()
    stresses = pronouncing.stresses(phones_list[0])
    syllables = []
    buffer = []
    vowel_index = 0
    for phone in phones:
        base = re.sub(r'\d', '', phone)
        if base in _ARPABET_VOWELS:
            onset = buffer
            buffer = []
            stress = stresses[vowel_index] if vowel_index < len(stresses) else '0'
            vowel_index += 1
            syllables.append({'onset': onset, 'vowel': base, 'coda': [], 'stress': stress})
        else:
            buffer.append(base)
    if buffer and syllables:
        syllables[-1]['coda'].extend(buffer)

    rendered = []
    for syl in syllables:
        onset_parts = [_ARPABET_ONSET_MAP.get(p, '') for p in syl['onset']]
        onset_parts = [p for p in onset_parts if p]
        if len(onset_parts) > 1:
            onset = onset_parts[-1]
        elif onset_parts:
            onset = onset_parts[0]
        else:
            onset = ''
        vowel = _ARPABET_VOWEL_MAP.get(syl['vowel'], '')
        coda_parts = [_ARPABET_CODA_MAP.get(p, '') for p in syl['coda']]
        coda_parts = [c for c in coda_parts if c in ['n', 'ng', 'm', 'l', 'r']]
        coda = ''.join(coda_parts)
        text = f"{onset}{vowel}{coda}".strip('-')
        if not text:
            continue
        if syl['stress'] == '1':
            text = text.upper()
        rendered.append(text)
    return '-'.join(rendered) if rendered else None


def _approx_zh_from_syllables(word):
    """基于分音节的中文拼读回退"""
    syllables = _fallback_syllables(word)
    mapped = []
    for syl in syllables:
        s = syl.lower()
        s = s.replace('th', 's').replace('ph', 'f').replace('sh', 'sh').replace('ch', 'ch')
        s = s.replace('tion', 'shen').replace('sion', 'shen').replace('tial', 'xiao')
        s = s.replace('ci', 'xi').replace('ce', 'se').replace('ge', 'ge')
        s = s.replace('v', 'w').replace('r', 'l')
        s = re.sub(r'[^a-z]', '', s)
        if s:
            mapped.append(s)
    return '-'.join(mapped) if mapped else None


def _syllabify_word(word):
    """生成拼读分音节"""
    lower = word.lower()
    if lower.isdigit():
        return lower
    if word.isupper() and len(word) <= 5:
        return '-'.join(list(word))

    hyphenator = _lazy_pyphen()
    if hyphenator:
        syllables = [s for s in hyphenator.inserted(lower).split('-') if s]
    else:
        syllables = _fallback_syllables(lower)

    pronouncing = _lazy_pronouncing()
    if pronouncing:
        phones = pronouncing.phones_for_word(lower)
        if phones:
            stress = pronouncing.stresses(phones[0])
            if len(stress) == len(syllables):
                idx = stress.find('1')
                if idx == -1:
                    idx = stress.find('2')
                if idx != -1:
                    syllables[idx] = syllables[idx].upper()
    return '-'.join(syllables)


def _pronounce_phrase(phrase):
    """生成短语拼读提示"""
    words = re.findall(r"[A-Za-z]+|[0-9]+", phrase)
    return ' '.join(_syllabify_word(w) for w in words if w)


def _pronounce_phrase_zh(phrase):
    """生成中文拼读提示"""
    words = re.findall(r"[A-Za-z]+|[0-9]+", phrase)
    rendered = []
    for w in words:
        if w.isdigit():
            rendered.append(w)
            continue
        zh = _approx_zh_from_arpabet(w)
        if not zh:
            zh = _approx_zh_from_syllables(w)
        if zh:
            rendered.append(zh)
    return ' '.join(rendered)


def _format_ass_time(seconds):
    """格式化 ASS 时间"""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = seconds % 60
    return f"{hours}:{minutes:02d}:{secs:05.2f}"


def _build_ass_header(play_res_x, play_res_y, subtitle_layout):
    """生成 ASS 头部"""
    if subtitle_layout == 'single-line':
        en_size = 34
        zh_size = 28
        pron_size = 24
    elif subtitle_layout == 'two-line':
        en_size = 38
        zh_size = 32
        pron_size = 24
    else:
        en_size = 42
        zh_size = 38
        pron_size = 24
    return f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_res_x}
PlayResY: {play_res_y}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: EN,Arial,{en_size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,2,0,2,60,60,70,1
Style: PRON,Arial,{pron_size},&H0000D6FF,&H0000D6FF,&H00000000,&H64000000,0,0,0,0,100,100,0,0,1,1,0,2,60,60,70,1
Style: ZH,PingFang SC,{zh_size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,2,0,2,60,60,70,1
Style: ZH_HI,PingFang SC,{zh_size},&H00F0FF,&H00F0FF,&H00000000,&H64000000,1,0,0,0,100,100,0,0,1,2,0,2,60,60,70,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def _generate_bilingual_ass(
    english_srt_path,
    chinese_srt_path,
    output_path,
    highlight_limit,
    pronunciation_mode,
    video_width,
    video_height,
    video_duration,
    subtitle_layout
):
    """生成双语 ASS 字幕"""
    en_items = _resolve_overlaps(
        _merge_overlapping_items(_load_srt_items(english_srt_path))
    )
    zh_items = _merge_overlapping_items(_load_srt_items(chinese_srt_path))
    freq_index = _build_frequency_index(en_items)
    layout = subtitle_layout if subtitle_layout else 'single-line'
    header = _build_ass_header(video_width, video_height, layout)

    lines = [header]
    max_duration = max(0.0, float(video_duration))
    for item in _align_bilingual(en_items, zh_items):
        if item['start'] >= max_duration:
            continue
        highlight = _select_highlight_phrase(item['en'], freq_index, highlight_limit)
        pron_line = ''
        if highlight and pronunciation_mode in ['syllable', 'syllable-zh']:
            pron_en = _pronounce_phrase(highlight['phrase'])
            if pronunciation_mode == 'syllable-zh':
                pron_zh = _pronounce_phrase_zh(highlight['phrase'])
                if pron_zh:
                    pron_line = f"{pron_en} | {pron_zh}"
                else:
                    pron_line = pron_en
            else:
                pron_line = pron_en

        zh_line = _ass_escape(item['zh'])
        if highlight and zh_line:
            zh_style = 'ZH_HI'
        else:
            zh_style = 'ZH'

        if layout == 'stacked':
            en_line = _apply_ass_highlight(item['en'], highlight)
            if pron_line:
                text = f"{{\\rEN}}{en_line}\\N{{\\rPRON}}{_ass_escape(pron_line)}\\N{{\\r{zh_style}}}{zh_line}"
            else:
                text = f"{{\\rEN}}{en_line}\\N{{\\r{zh_style}}}{zh_line}"
        elif layout == 'two-line':
            en_line = _apply_ass_highlight_inline(item['en'], highlight, pron_line)
            if zh_line:
                text = f"{{\\rEN}}{en_line}\\N{{\\r{zh_style}}}{zh_line}"
            else:
                text = f"{{\\rEN}}{en_line}"
        else:
            en_line = _apply_ass_highlight_inline(item['en'], highlight, pron_line)
            if zh_line:
                text = f"{{\\rEN}}{en_line} {{\\r{zh_style}}}｜{zh_line}"
            else:
                text = f"{{\\rEN}}{en_line}"

        start = _format_ass_time(item['start'])
        end = _format_ass_time(min(item['end'], max_duration))
        lines.append(f"Dialogue: 0,{start},{end},EN,,0,0,0,,{text}\n")

    with open(output_path, 'w', encoding='utf-8') as f:
        f.writelines(lines)


def _compose_overlays_with_ffmpeg(
    base_video_path,
    overlays,
    output_path,
    codec,
    preset,
    ffmpeg_path,
    ffmpeg_loglevel,
    video_bitrate=None,
    video_crf=None,
    audio_bitrate=None,
    burn_subs=False,
    subs_path=None,
    subs_style=None,
    soft_subs=False
):
    """使用 ffmpeg 合成叠加层"""
    cmd = _ffmpeg_cmd_prefix(ffmpeg_path, ffmpeg_loglevel) + ['-y', '-i', base_video_path]
    for ov in overlays:
        cmd.extend(['-i', ov['path']])
    subs_input_index = None
    if soft_subs:
        if not subs_path or not os.path.exists(subs_path):
            raise FileNotFoundError(f"字幕文件不存在: {subs_path}")
        subs_input_index = 1 + len(overlays)
        cmd.extend(['-i', subs_path])

    filter_parts = []
    last_label = '[0:v]'
    for idx, ov in enumerate(overlays, start=1):
        ov_label = f'[ov{idx}]'
        out_label = f'[v{idx}]'
        start_time = ov['start']
        filter_parts.append(f'[{idx}:v]setpts=PTS-STARTPTS+{start_time}/TB{ov_label}')
        filter_parts.append(f'{last_label}{ov_label}overlay=0:0:eof_action=pass{out_label}')
        last_label = out_label

    if burn_subs:
        if not subs_path or not os.path.exists(subs_path):
            raise FileNotFoundError(f"字幕文件不存在: {subs_path}")
        style = subs_style if subs_style else _default_subs_style()
        subs_filter = _build_subtitles_filter(subs_path, style)
        out_label = '[vsub]'
        filter_parts.append(f'{last_label}{subs_filter}{out_label}')
        last_label = out_label

    filter_complex = ';'.join(filter_parts)

    cmd.extend(['-filter_complex', filter_complex, '-map', last_label, '-map', '0:a?'])
    if soft_subs and subs_input_index is not None:
        cmd.extend(['-map', f'{subs_input_index}:s:0?'])
    cmd.extend(['-c:v', codec])
    if video_bitrate:
        cmd.extend(['-b:v', video_bitrate])
        video_bps = _parse_bitrate_to_bps(video_bitrate)
        if video_bps:
            kbps = max(1, int(video_bps / 1000))
            cmd.extend(['-maxrate', f"{kbps}k", '-bufsize', f"{kbps * 2}k"])
    elif video_crf and codec in ['libx264', 'libx265']:
        cmd.extend(['-crf', str(video_crf)])
    if preset and codec == 'libx264':
        cmd.extend(['-preset', preset])
    cmd.extend(['-pix_fmt', 'yuv420p', '-movflags', '+faststart'])

    try:
        cmd_with_audio = cmd + ['-c:a', 'copy']
        if soft_subs and subs_input_index is not None:
            cmd_with_audio += [
                '-c:s', _subtitle_codec_for_output(subs_path, output_path),
                '-metadata:s:s:0', f"language={_subtitle_language_tag(subs_path)}",
                '-disposition:s:0', 'default'
            ]
        cmd_with_audio += [output_path]
        subprocess.run(cmd_with_audio, check=True)
    except subprocess.CalledProcessError:
        cmd_with_audio = cmd + ['-c:a', 'aac']
        if audio_bitrate:
            cmd_with_audio += ['-b:a', audio_bitrate]
        if soft_subs and subs_input_index is not None:
            cmd_with_audio += [
                '-c:s', _subtitle_codec_for_output(subs_path, output_path),
                '-metadata:s:s:0', f"language={_subtitle_language_tag(subs_path)}",
                '-disposition:s:0', 'default'
            ]
        cmd_with_audio += [output_path]
        subprocess.run(cmd_with_audio, check=True)


def _copy_video_with_ffmpeg(input_path, output_path, ffmpeg_path, ffmpeg_loglevel):
    """快速路径：直接复制流"""
    cmd = _ffmpeg_cmd_prefix(ffmpeg_path, ffmpeg_loglevel) + [
        '-y',
        '-i', input_path,
        '-c', 'copy',
        '-movflags', '+faststart',
        output_path
    ]
    subprocess.run(cmd, check=True)


def _mux_soft_subs_with_ffmpeg(base_video_path, subs_path, output_path, ffmpeg_path, ffmpeg_loglevel):
    """将字幕作为软字幕轨道写入输出文件"""
    if not subs_path or not os.path.exists(subs_path):
        raise FileNotFoundError(f"字幕文件不存在: {subs_path}")
    subtitle_codec = _subtitle_codec_for_output(subs_path, output_path)
    cmd = _ffmpeg_cmd_prefix(ffmpeg_path, ffmpeg_loglevel) + [
        '-y',
        '-i', base_video_path,
        '-i', subs_path,
        '-map', '0:v:0',
        '-map', '0:a?',
        '-map', '1:s:0?',
        '-c:v', 'copy',
        '-c:a', 'copy',
        '-c:s', subtitle_codec,
        '-metadata:s:s:0', f"language={_subtitle_language_tag(subs_path)}",
        '-disposition:s:0', 'default',
        '-movflags', '+faststart',
        output_path
    ]
    subprocess.run(cmd, check=True)


def _generate_overlays_browser(config, width, height, fps, temp_dirs, ffmpeg_path, ffmpeg_loglevel):
    """使用浏览器渲染叠加层并编码为透明视频"""
    from browser_renderer import BrowserRenderer

    overlays = []
    theme = config.get('theme', 'notion')
    print(f"🎨 主题: {theme}")

    with BrowserRenderer(width=width, height=height, fps=fps) as renderer:

        # 1. 生成人物条片段
        lower_thirds = config.get('lowerThirds', [])
        if lower_thirds:
            print(f"👤 生成人物条 ({len(lower_thirds)} 个)...")
            for i, lt in enumerate(lower_thirds):
                print(f"   - 人物条: {lt['name']}")
                temp_dir = tempfile.mkdtemp(prefix=f'lower_third_{i}_')
                temp_dirs.append(temp_dir)

                lt_config = {
                    'name': lt['name'],
                    'role': lt.get('role', ''),
                    'company': lt.get('company', ''),
                    'theme': theme,
                    'durationMs': lt.get('durationMs', 5000)
                }
                renderer.render_lower_third_frames(lt_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': lt['startMs'] / 1000.0
                })

        # 2. 生成章节标题片段
        chapters = config.get('chapterTitles', [])
        if chapters:
            print(f"📑 生成章节标题 ({len(chapters)} 个)...")
            for i, ch in enumerate(chapters):
                print(f"   - 章节: {ch['title']}")
                temp_dir = tempfile.mkdtemp(prefix=f'chapter_{i}_')
                temp_dirs.append(temp_dir)

                ch_config = {
                    'number': ch.get('number', ''),
                    'title': ch['title'],
                    'subtitle': ch.get('subtitle', ''),
                    'theme': theme,
                    'durationMs': ch.get('durationMs', 4000)
                }
                renderer.render_chapter_title_frames(ch_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': ch['startMs'] / 1000.0
                })

        # 3. 生成花字片段
        key_phrases = config.get('keyPhrases', [])
        if key_phrases:
            print(f"✨ 生成花字动画 ({len(key_phrases)} 个)...")
            for i, phrase in enumerate(key_phrases):
                print(f"   - 花字 {i+1}: {phrase['text']}")
                temp_dir = tempfile.mkdtemp(prefix=f'fancy_text_{i}_')
                temp_dirs.append(temp_dir)

                x_offset = (i % 2) * 300
                position = phrase.get('position', {
                    'x': width // 2 - 150 + x_offset,
                    'y': 120 + (i % 3) * 40
                })

                frame_config = {
                    'text': phrase['text'],
                    'style': phrase.get('style', 'emphasis'),
                    'theme': theme,
                    'position': position,
                    'startMs': phrase['startMs'],
                    'endMs': phrase['endMs']
                }
                renderer.render_fancy_text_frames(frame_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': phrase['startMs'] / 1000.0
                })

        # 4. 生成名词卡片片段
        term_defs = config.get('termDefinitions', [])
        if term_defs:
            print(f"📋 生成名词卡片 ({len(term_defs)} 个)...")
            for i, term in enumerate(term_defs):
                print(f"   - 卡片: {term['chinese']}")
                temp_dir = tempfile.mkdtemp(prefix=f'term_card_{i}_')
                temp_dirs.append(temp_dir)

                card_config = {
                    'chinese': term['chinese'],
                    'english': term['english'],
                    'description': term['description'],
                    'theme': theme,
                    'displayDurationSeconds': term.get('displayDurationSeconds', 6)
                }
                renderer.render_term_card_frames(card_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': term['firstAppearanceMs'] / 1000.0
                })

        # 5. 生成金句卡片片段
        quotes = config.get('quotes', [])
        if quotes:
            print(f"💬 生成金句卡片 ({len(quotes)} 个)...")
            for i, quote in enumerate(quotes):
                print(f"   - 金句: {quote['text'][:20]}...")
                temp_dir = tempfile.mkdtemp(prefix=f'quote_{i}_')
                temp_dirs.append(temp_dir)

                quote_config = {
                    'text': quote['text'],
                    'author': quote.get('author', ''),
                    'theme': theme,
                    'position': quote.get('position', {'x': width // 2, 'y': height // 2}),
                    'durationMs': quote.get('durationMs', 5000)
                }
                renderer.render_quote_callout_frames(quote_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': quote['startMs'] / 1000.0
                })

        # 6. 生成数据动画片段
        stats = config.get('stats', [])
        if stats:
            print(f"📊 生成数据动画 ({len(stats)} 个)...")
            for i, stat in enumerate(stats):
                print(f"   - 数据: {stat.get('prefix', '')}{stat['number']}{stat.get('unit', '')}")
                temp_dir = tempfile.mkdtemp(prefix=f'stats_{i}_')
                temp_dirs.append(temp_dir)

                stat_config = {
                    'prefix': stat.get('prefix', ''),
                    'number': stat['number'],
                    'unit': stat.get('unit', ''),
                    'label': stat.get('label', ''),
                    'theme': theme,
                    'position': stat.get('position', {'x': width // 2, 'y': height // 2}),
                    'durationMs': stat.get('durationMs', 4000)
                }
                renderer.render_animated_stats_frames(stat_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': stat['startMs'] / 1000.0
                })

        # 7. 生成要点列表片段
        bullet_points = config.get('bulletPoints', [])
        if bullet_points:
            print(f"📝 生成要点列表 ({len(bullet_points)} 个)...")
            for i, bp in enumerate(bullet_points):
                print(f"   - 要点: {bp.get('title', '要点列表')}")
                temp_dir = tempfile.mkdtemp(prefix=f'bullets_{i}_')
                temp_dirs.append(temp_dir)

                bp_config = {
                    'title': bp.get('title', ''),
                    'points': bp['points'],
                    'theme': theme,
                    'position': bp.get('position', {'x': 100, 'y': 300}),
                    'durationMs': bp.get('durationMs', 6000)
                }
                renderer.render_bullet_points_frames(bp_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': bp['startMs'] / 1000.0
                })

        # 8. 生成社交媒体条片段
        social_bars = config.get('socialBars', [])
        if social_bars:
            print(f"📱 生成社交媒体条 ({len(social_bars)} 个)...")
            for i, sb in enumerate(social_bars):
                print(f"   - 社交: {sb['handle']}")
                temp_dir = tempfile.mkdtemp(prefix=f'social_{i}_')
                temp_dirs.append(temp_dir)

                sb_config = {
                    'platform': sb.get('platform', 'twitter'),
                    'label': sb.get('label', '关注'),
                    'handle': sb['handle'],
                    'theme': theme,
                    'position': sb.get('position', {'x': width - 320, 'y': height - 130}),
                    'durationMs': sb.get('durationMs', 8000)
                }
                renderer.render_social_bar_frames(sb_config, temp_dir)
                overlay_path = os.path.join(temp_dir, 'overlay.mov')
                _encode_overlay_video(temp_dir, fps, overlay_path, ffmpeg_path, ffmpeg_loglevel)
                overlays.append({
                    'path': overlay_path,
                    'start': sb['startMs'] / 1000.0
                })

    return overlays


def _generate_clips_pil(config, width, height, fps):
    """Generate clips using PIL renderer (legacy)"""
    from fancy_text import FancyTextGenerator
    from term_card import TermCardGenerator

    # 3. 生成花字片段
    print(f"✨ 生成花字动画 ({len(config.get('keyPhrases', []))} 个)...")
    text_gen = FancyTextGenerator(width=width, height=height, fps=fps)
    text_clips = []
    for i, phrase in enumerate(config.get('keyPhrases', [])):
        print(f"   - 花字 {i+1}: {phrase['text']}")
        clip = text_gen.generate_text_clip(phrase, i)
        text_clips.append(clip)

    # 4. 生成卡片片段
    print(f"📋 生成名词卡片 ({len(config.get('termDefinitions', []))} 个)...")
    card_gen = TermCardGenerator(width=width, height=height, fps=fps)
    card_clips = []
    for term in config.get('termDefinitions', []):
        print(f"   - 卡片: {term['chinese']}")
        clip = card_gen.generate_card_clip(term)
        card_clips.append(clip)

    return text_clips, card_clips


def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(
        description='为访谈视频添加花字和名词解释卡片',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python video_processor.py video.mp4 subs.srt config.json output.mp4
  python video_processor.py video.mp4 subs.srt config.json -r pil  # 使用 PIL 渲染器
  python video_processor.py video.mp4 subs.srt config.json -r browser  # 使用浏览器渲染器
  python video_processor.py video.mp4 subs.srt config.json output.mp4 --pipeline hybrid  # 叠加层+ffmpeg
  python video_processor.py video.mp4 subs.srt config.json output.mp4 --pipeline hybrid --burn-subs  # 内嵌字幕
  python video_processor.py video.mp4 subs.srt config.json output.mkv --size-target-mb 1800  # MB 目标体积
  python video_processor.py video.mp4 subs.srt config.json output.mkv --style-profile style.json --export-profile export.json
        """
    )

    parser.add_argument('video', help='输入视频文件路径')
    parser.add_argument('subtitles', help='字幕文件路径 (.srt)')
    parser.add_argument('config', help='配置文件路径 (.json)')
    parser.add_argument('output', nargs='?', default=None, help='输出视频路径 (默认: output.mp4)')
    parser.add_argument(
        '-r', '--renderer',
        choices=['auto', 'browser', 'pil'],
        default='auto',
        help='渲染器类型: auto (自动选择), browser (HTML/CSS), pil (Python PIL)'
    )
    parser.add_argument(
        '--pipeline',
        choices=['auto', 'moviepy', 'hybrid'],
        default='auto',
        help='处理管线: auto (自动选择), moviepy (传统合成), hybrid (叠加层+ffmpeg)'
    )
    parser.add_argument(
        '--overlay-fps',
        type=float,
        default=None,
        help='叠加层渲染帧率 (默认跟随原视频)'
    )
    parser.add_argument(
        '--codec',
        default=None,
        help='输出视频编码器 (默认自动选择)'
    )
    parser.add_argument(
        '--preset',
        default=None,
        help='软件编码预设 (如 veryfast/fast)'
    )
    parser.add_argument(
        '--video-bitrate',
        default=None,
        help='输出视频码率 (如 3000k，默认跟随源视频码率)'
    )
    parser.add_argument(
        '--audio-bitrate',
        default='128k',
        help='输出音频码率 (如 128k)'
    )
    parser.add_argument(
        '--size-target',
        type=float,
        default=None,
        help='目标体积(GB)，自动换算视频码率'
    )
    parser.add_argument(
        '--size-target-mb',
        type=float,
        default=None,
        help='目标体积(MB)，内部自动换算为 GB'
    )
    parser.add_argument(
        '--video-crf',
        type=int,
        default=None,
        help='x264/x265 的 CRF 值 (可选)'
    )
    parser.add_argument(
        '--ffmpeg-path',
        default='ffmpeg',
        help='ffmpeg 可执行文件路径'
    )
    parser.add_argument(
        '--ffmpeg-loglevel',
        choices=['quiet', 'panic', 'fatal', 'error', 'warning', 'info', 'verbose', 'debug', 'trace'],
        default='warning',
        help='ffmpeg 日志级别（默认 warning，减少长任务刷屏）'
    )
    parser.add_argument(
        '--style-profile',
        default=None,
        help='风格画像 JSON（沉淀主题/排版/拼读等创作偏好）'
    )
    parser.add_argument(
        '--export-profile',
        default=None,
        help='导出画像 JSON（沉淀体积/码率/编码器等导出偏好）'
    )
    parser.add_argument(
        '--burn-subs',
        action='store_true',
        help='将字幕内嵌到视频（仅 hybrid 管线）'
    )
    parser.add_argument(
        '--soft-subs',
        action='store_true',
        help='将字幕作为软字幕轨道写入（仅 hybrid 管线）'
    )
    parser.add_argument(
        '--english-srt',
        default=None,
        help='英文字幕路径（用于双语字幕）'
    )
    parser.add_argument(
        '--bilingual',
        action='store_true',
        help='启用双语字幕（默认自动识别英文字幕）'
    )
    parser.add_argument(
        '--mono-subs',
        action='store_true',
        help='强制单语字幕'
    )
    parser.add_argument(
        '--subtitle-output',
        default=None,
        help='字幕文件输出路径（ASS）'
    )
    parser.add_argument(
        '--highlight-limit',
        type=int,
        default=1,
        help='每条字幕高亮数量（默认 1）'
    )
    parser.add_argument(
        '--pronunciation',
        choices=['syllable', 'syllable-zh'],
        default='syllable-zh',
        help='发音提示方式'
    )
    parser.add_argument(
        '--subtitle-layout',
        choices=['single-line', 'two-line', 'stacked'],
        default='two-line',
        help='双语字幕排版方式'
    )
    parser.add_argument(
        '--subs-style',
        default=None,
        help='字幕样式（ASS force_style 格式）'
    )
    parser.add_argument(
        '--keep-temp',
        action='store_true',
        help='保留临时文件用于调试'
    )

    args = parser.parse_args()

    if args.size_target is not None and args.size_target_mb is not None:
        print("❌ --size-target 和 --size-target-mb 不能同时使用")
        sys.exit(1)

    size_target_gb = args.size_target
    if size_target_gb is None and args.size_target_mb is not None:
        size_target_gb = args.size_target_mb / 1024
        print(f"📏 已将目标体积从 MB 换算为 GB: {size_target_gb:.4f}GB")

    try:
        style_profile = _load_profile(args.style_profile, '风格')
        export_profile = _load_profile(args.export_profile, '导出')
    except Exception as profile_error:
        print(f"❌ 加载画像失败: {profile_error}")
        sys.exit(1)

    # 获取调用脚本时的工作目录（保存在环境变量中）
    original_cwd = os.environ.get('ORIGINAL_CWD', os.getcwd())

    # 默认输出路径为原始工作目录下的 output.mp4
    if args.output:
        output_path = args.output
        # 如果是相对路径，相对于原始工作目录
        if not os.path.isabs(output_path):
            output_path = os.path.join(original_cwd, output_path)
    else:
        output_path = os.path.join(original_cwd, 'output.mp4')

    try:
        process_video(
            args.video,
            args.subtitles,
            args.config,
            output_path,
            renderer=args.renderer,
            pipeline=args.pipeline,
            overlay_fps=args.overlay_fps,
            codec=args.codec,
            preset=args.preset,
            video_bitrate=args.video_bitrate,
            audio_bitrate=args.audio_bitrate,
            size_target=size_target_gb,
            video_crf=args.video_crf,
            ffmpeg_path=args.ffmpeg_path,
            ffmpeg_loglevel=args.ffmpeg_loglevel,
            keep_temp=args.keep_temp,
            burn_subs=args.burn_subs,
            subs_style=args.subs_style,
            soft_subs=args.soft_subs,
            bilingual=(False if args.mono_subs else (True if args.bilingual else None)),
            english_srt_path=args.english_srt,
            subtitle_output=args.subtitle_output,
            highlight_limit=args.highlight_limit,
            pronunciation_mode=args.pronunciation,
            subtitle_layout=args.subtitle_layout,
            style_profile=style_profile,
            export_profile=export_profile
        )
    except Exception as e:
        print(f"❌ 处理失败: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
