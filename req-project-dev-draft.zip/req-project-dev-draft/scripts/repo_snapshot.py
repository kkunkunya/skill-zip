#!/usr/bin/env python3
"""Generate a quick Markdown snapshot of a code repository.

Usage:
  python scripts/repo_snapshot.py /path/to/repo > snapshot.md

What it does:
- Prints a shallow directory tree (depth 3) with common heavy folders excluded
- Detects likely tech stack from well-known config files
- Lists "interesting" files found at repo root

This is intentionally lightweight and dependency-free.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Iterable, List, Tuple

EXCLUDE_DIRS = {
    ".git",
    ".hg",
    ".svn",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    "target",
    ".idea",
    ".vscode",
    ".next",
    ".turbo",
}

STACK_MARKERS = {
    "package.json": "Node.js / JavaScript (check frameworks in deps)",
    "pnpm-lock.yaml": "Node.js (pnpm)",
    "yarn.lock": "Node.js (yarn)",
    "package-lock.json": "Node.js (npm)",
    "pom.xml": "Java (Maven)",
    "build.gradle": "Java/Kotlin (Gradle)",
    "build.gradle.kts": "Kotlin (Gradle)",
    "go.mod": "Go modules",
    "pyproject.toml": "Python (pyproject)",
    "requirements.txt": "Python (requirements)",
    "Pipfile": "Python (pipenv)",
    "Cargo.toml": "Rust (cargo)",
    "composer.json": "PHP (composer)",
    "Gemfile": "Ruby (bundler)",
    "Dockerfile": "Containerized (Docker)",
    "docker-compose.yml": "Multi-service local dev (compose)",
    "kustomization.yaml": "Kubernetes (kustomize)",
    "Chart.yaml": "Kubernetes (Helm)",
    ".github/workflows": "CI/CD (GitHub Actions)",
}

INTERESTING_ROOT_FILES = {
    "README.md",
    "README",
    "CONTRIBUTING.md",
    "ARCHITECTURE.md",
    "docs",
    "openapi.yaml",
    "openapi.yml",
    "swagger.yaml",
    "swagger.yml",
    "Makefile",
}


def iter_tree(root: Path, max_depth: int = 3) -> List[str]:
    """Return a list of tree lines."""
    lines: List[str] = []

    def walk(dir_path: Path, prefix: str, depth: int) -> None:
        if depth > max_depth:
            return
        try:
            entries = sorted(
                [p for p in dir_path.iterdir() if p.name not in EXCLUDE_DIRS],
                key=lambda p: (p.is_file(), p.name.lower()),
            )
        except PermissionError:
            lines.append(prefix + "[permission denied]")
            return

        for i, p in enumerate(entries):
            is_last = i == len(entries) - 1
            connector = "└── " if is_last else "├── "
            lines.append(prefix + connector + p.name + ("/" if p.is_dir() else ""))
            if p.is_dir():
                extension = "    " if is_last else "│   "
                walk(p, prefix + extension, depth + 1)

    lines.append(root.resolve().as_posix())
    walk(root, "", 1)
    return lines


def detect_markers(root: Path) -> List[Tuple[str, str]]:
    found: List[Tuple[str, str]] = []

    # Exact file markers
    for marker, desc in STACK_MARKERS.items():
        p = root / marker
        if p.exists():
            found.append((marker, desc))

    # Folder marker: .github/workflows
    wf = root / ".github" / "workflows"
    if wf.exists() and wf.is_dir():
        found.append((".github/workflows", STACK_MARKERS[".github/workflows"]))

    # Helm chart marker
    chart = root / "Chart.yaml"
    if chart.exists():
        found.append(("Chart.yaml", STACK_MARKERS["Chart.yaml"]))

    return sorted(set(found))


def list_interesting(root: Path) -> List[str]:
    hits: List[str] = []
    for name in sorted(INTERESTING_ROOT_FILES):
        p = root / name
        if p.exists():
            hits.append(name + ("/" if p.is_dir() else ""))
    return hits


def main(argv: List[str]) -> int:
    repo = Path(argv[1]) if len(argv) > 1 else Path(".")
    if not repo.exists():
        print(f"ERROR: path not found: {repo}", file=sys.stderr)
        return 2

    print("# Repo Snapshot\n")

    print("## Stack hints")
    markers = detect_markers(repo)
    if not markers:
        print("- (No common stack markers found at repo root.)")
    else:
        for m, d in markers:
            print(f"- `{m}` → {d}")

    print("\n## Interesting root files")
    interesting = list_interesting(repo)
    if not interesting:
        print("- (None found from the default list.)")
    else:
        for x in interesting:
            print(f"- {x}")

    print("\n## Directory tree (depth 3)")
    print("```text")
    for line in iter_tree(repo, max_depth=3):
        print(line)
    print("```")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
