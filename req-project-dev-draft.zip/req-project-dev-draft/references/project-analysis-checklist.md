# Project Analysis Checklist

Use this to understand the current system before proposing changes.

---

## 1) Identify the stack

**Skip if**: Stack already known from previous analysis or documentation.

**Common pitfalls**:
- Missing secondary stacks (e.g., Python scripts in a Java project)
- Ignoring infra-as-code that defines deployment constraints

**Checklist** - Look for:
- Language & framework markers: `package.json`, `pom.xml`, `build.gradle`, `go.mod`, `pyproject.toml`, `requirements.txt`, `Cargo.toml`
- Runtime/deploy: `Dockerfile`, `docker-compose.yml`, `kubernetes/`, `helm/`, CI configs
- Infrastructure-as-code: Terraform, Pulumi, CloudFormation

---

## 2) Architecture snapshot (as-is)

**Skip if**: Architecture diagram already provided and up-to-date.

**Common pitfalls**:
- Trusting outdated diagrams over code reality
- Missing side-effect services (notifications, analytics, audit logs)

**Checklist**:
- Main services/modules and their responsibilities
- Request flow / event flow (entry → core logic → storage → side effects)
- Where state lives (DB/cache/queue/object storage)
- Integration points (3rd party APIs, internal services)
- Authn/authz approach (sessions/JWT/OAuth, RBAC/ABAC)
- Configuration and secrets management

---

## 3) Code hotspots (likely impact surface)

**Skip if**: Change is isolated to a single file with no dependencies.

**Common pitfalls**:
- Underestimating ripple effects in shared utilities
- Missing validation layers that enforce invariants

**Checklist**:
- Where similar features exist (search for analogous endpoints/components)
- Common abstractions / service layers / repositories
- Validation layers (schema validators, DTOs)
- Error handling patterns and response formats
- Background job framework (queues, cron, workers)

---

## 4) Data model & migrations

**Skip if**: No data model changes required.

**Common pitfalls**:
- Forgetting to check for foreign key constraints
- Ignoring existing migration history that may conflict

**Checklist**:
- Primary schema ownership (which service owns which tables)
- Migration tooling (Flyway/Liquibase/Alembic/Prisma/etc.)
- Backfill patterns (one-off scripts, async jobs)
- Consistency model (transactional, eventual)
- Indexing and query patterns (likely perf risks)

---

## 5) Operational posture

**Skip if**: Greenfield project with no existing ops.

**Common pitfalls**:
- Adding features without corresponding alerts
- Breaking existing dashboard queries

**Checklist**:
- Logging, metrics, tracing (what is available today)
- Feature flags / config toggles
- Rate limiting / abuse prevention
- Alerting / dashboards / SLOs
- On-call/runbook posture

---

## 6) Delivery constraints

**Skip if**: Solo developer with full control.

**Common pitfalls**:
- Ignoring CI gates that will block merge
- Assuming deploy windows that don't exist

**Checklist**:
- Build/test commands and local dev setup
- Linting/formatting and CI gates
- Release process (tags, environments, approvals)
- Backward compatibility constraints
- Deployment constraints (maintenance windows, multi-region, canary support)

---

## 7) Non-code artifacts to consult

**Skip if**: No existing documentation or all docs are stale.

**Common pitfalls**:
- Ignoring past incident postmortems that reveal hidden constraints
- Missing API docs that define contracts

**Checklist**:
- PRD / spec docs
- API docs (OpenAPI, gRPC proto)
- Architecture diagrams
- Past incident postmortems relevant to the feature
