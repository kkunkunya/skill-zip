# Requirements Analysis Checklist

Use this to turn messy requirement text into engineering-ready inputs.

---

## A. Identify intent & user journey

**Skip if**: User already provided clear user stories with acceptance criteria.

**Common pitfalls**:
- Assuming single persona when multiple exist (admin vs end-user vs operator)
- Confusing the requester's job with the actual user's job

**Checklist**:
- Primary job-to-be-done (what the user is trying to achieve)
- Personas / roles involved (end user, admin, internal operator)
- Entry points (UI page, API call, scheduled job, webhook)
- Success criteria (what "good" looks like)

---

## B. Define scope boundaries

**Skip if**: Scope already documented in PRD/spec.

**Common pitfalls**:
- Implicit scope creep ("while we're at it...")
- Forgetting supporting work (migrations, config changes)

**Checklist**:
- What is explicitly requested (must-have)
- What is implicitly required to make it work (supporting work)
- Out-of-scope items (call them out explicitly)
- Phase 2 / nice-to-have items (park them)

---

## C. Extract functional requirements (FR)

**Skip if**: FR already listed with clear inputs/outputs.

**Common pitfalls**:
- Mixing FR with NFR (e.g., "fast login" is NFR, "login with SSO" is FR)
- Vague verbs ("handle", "process") instead of specific actions

**Checklist** (for each FR):
- Unique ID (FR-1…)
- Description in one sentence
- Inputs (who/what triggers it)
- Outputs (what changes, what response is returned)
- Preconditions / permissions
- Failure behavior (what happens when it can't complete)

---

## D. Define non-functional requirements (NFR)

**Skip if**: NFR already quantified with SLOs.

**Common pitfalls**:
- Vague NFRs ("should be fast") instead of measurable targets
- Ignoring cost/budget constraints

**Checklist**:
- Performance/latency (p50/p95 targets, throughput, payload sizes)
- Reliability (retries, idempotency, consistency)
- Security/privacy (PII, auth scopes, audit logs, data retention)
- Compatibility (backward/forward compatibility, supported versions)
- Operability (monitoring, alerts, runbooks)
- Cost constraints (if applicable)

---

## E. Data & domain rules

**Skip if**: Domain model already documented or trivial CRUD.

**Common pitfalls**:
- Missing hidden invariants ("order total must equal sum of items")
- Ignoring concurrency rules

**Checklist**:
- Entities and relationships (nouns in the requirement)
- Invariants (must always be true)
- Ordering rules and concurrency rules
- Validation rules (required fields, ranges, formats)

---

## F. Edge cases & failure modes

**Skip if**: Comprehensive test cases already exist.

**Common pitfalls**:
- Only considering happy path
- Assuming external dependencies always work

**Checklist**:
- Missing/invalid inputs
- Partial failures (one downstream fails)
- Timeouts and retries
- Duplicate requests / idempotency
- Concurrency races
- Rate limiting / abuse scenarios
- Permissions denied / auth expired
- Data migrations and backward compatibility hazards

---

## G. Acceptance criteria

**Skip if**: User stories already have AC in Given-When-Then format.

**Common pitfalls**:
- Untestable criteria ("should feel fast")
- Missing negative tests

**Checklist** (for each FR):
- 2–6 testable "done" statements
- Example inputs/outputs where helpful
- Negative tests (should reject / should not change state)
- Observability checks (a metric/log exists)

---

## H. Open questions (only blockers)

**Skip if**: All architecture/API/data model decisions already made.

**Common pitfalls**:
- Listing nice-to-know questions instead of blockers
- Not prioritizing questions by impact

Only keep questions that block:
- architecture choice
- data model choice
- API contract
- rollout/migration safety
- security/privacy posture
