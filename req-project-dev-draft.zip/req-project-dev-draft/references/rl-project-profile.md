# RL 专项画像（从 results-driven-rl 迁移）

> 用途：当项目属于强化学习（RL）训练与论文级实验交付时，作为 `learning-project-playbook` 的专项补充。

## 快速入口

先读：

1. `learning-project-playbook.md`（通用学习类闭环）
2. `rl-diagnosis-playbook.md`（症状 -> 根因 -> 修复）
3. `rl-chart-patterns.md`（图表模板）
4. `rl-experiment-experience.md`（历史经验）

## RL 专项铁律

1. 先写“预期结果表”（排序、指标区间、预算），再写训练代码。
2. 奖励函数先审查后训练，先排除 reward hacking 再调参。
3. 环境/奖励/约束有任何变更，旧模型必须作废并重训。
4. 快速试跑（100 ep）后先诊断再扩大训练。

## 交付最小包

- baseline + proposed 对比表
- 收敛曲线
- 关键调度/策略可视化
- 实验配置快照（可复现）
- 结论与失效边界
