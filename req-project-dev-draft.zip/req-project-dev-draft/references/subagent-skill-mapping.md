# Subagent 与 Skill 执行映射表

> 本文件定义任务类型到执行工具的映射，用于在开发提案的执行计划中标注具体实施工具。

## 一、Subagent 映射（Task 工具调用）

### 代码理解与分析类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| 项目架构分析 | `codebase-digest-caller` | 理解项目整体结构、生成架构图、代码概览 |
| 代码探索搜索 | `Explore` | 找文件、搜索关键词、定位代码位置 |
| 技术问答调查 | `codebase-analyst` | 代码实现原理、功能调查、技术问答 |
| 方案设计规划 | `Plan` | 设计方案、实现计划、架构评审 |

### 开发实现类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| Python 开发 | `python-pro` | 数据处理、AI模型、后端逻辑、脚本编写 |
| Java 开发 | `java-architect` | Spring Boot、JVM、后端架构 |
| Vue 前端 | `vue-expert` | Vue组件、状态管理、前端交互 |
| API 设计 | `api-spec-designer` | 接口规划、前后端协作、OpenAPI |
| MATLAB 开发 | `matlab-code-writer` | 数值计算、科学可视化、算法实现 |

### 文档与研究类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| 库/框架文档 | `context7-tech-researcher` | 查最新API、框架用法、库文档 |
| Claude Code 指南 | `claude-code-guide` | Claude Code用法、Agent SDK |

### 测试与调试类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| 浏览器调试 | `chrome-devtools-debugger` | DOM检查、网络请求、前端调试 |
| 测试执行 | `code-test-executor` | 运行测试、验证功能、错误诊断 |

### 环境与部署类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| 环境搭建 | `env-deployer` | 依赖安装、环境配置、模块缺失 |
| Python 环境 | `python-env-manager` | 虚拟环境、依赖冲突、uv管理 |
| 项目打包 | `project-zip-packager` | 文件整理、压缩打包 |

### 通用类

| 任务类型 | Subagent | 适用场景 |
|---------|----------|---------|
| 复杂多步骤 | `general-purpose` | 复杂研究、多步骤任务、通用处理 |

---

## 二、Skill 映射（Skill 工具调用）

### 包管理

| 任务类型 | Skill | 适用场景 |
|---------|-------|---------|
| Python 依赖 | `uv-package-manager` | pip install、uv add、依赖管理 |

### 文档处理

| 任务类型 | Skill | 适用场景 |
|---------|-------|---------|
| Word 文档 | `docx` | .docx创建、编辑、格式化 |
| PDF 处理 | `pdf` | PDF提取、合并、表单填写 |
| Excel 表格 | `xlsx` | 电子表格、数据分析、公式 |

### 开发辅助

| 任务类型 | Skill | 适用场景 |
|---------|-------|---------|
| 需求分析 | `req-project-dev-draft` | 需求转方案、技术提案 |
| 神经网络 | `neural-lab` | PyTorch、TensorFlow、模型训练 |
| 技能创建 | `skill-creator` | 创建/更新Claude Code技能 |
| 代码提交 | `commit` | Git提交、规范化commit message |

### 其他

| 任务类型 | Skill | 适用场景 |
|---------|-------|---------|
| 论文降重 | `ai-deweight` | 学术文本润色、降重 |
| 项目打包 | `project-zip` | 压缩代码、创建zip |
| 架构概览 | `codebase-digest` | 代码压缩、思维导图、Mermaid图 |

---

## 三、任务-工具快速查找表

按开发阶段组织：

### 阶段1：需求分析与设计

```
需求结构化      → Skill: req-project-dev-draft
架构设计        → Subagent: Plan
技术调研        → Subagent: context7-tech-researcher
项目理解        → Subagent: codebase-digest-caller
```

### 阶段2：开发实现

```
Python后端      → Subagent: python-pro
Java后端        → Subagent: java-architect
Vue前端         → Subagent: vue-expert
API开发         → Subagent: api-spec-designer
数据库迁移      → Subagent: python-pro / java-architect
```

### 阶段3：测试验证

```
单元测试        → Subagent: code-test-executor
集成测试        → Subagent: code-test-executor
前端调试        → Subagent: chrome-devtools-debugger
```

### 阶段4：文档与交付

```
技术文档        → Skill: docx
数据报告        → Skill: xlsx
代码提交        → Skill: commit
项目打包        → Skill: project-zip
```

---

## 四、并行调用建议

某些任务可以并行执行以提高效率：

| 主任务 | 可并行任务 | 说明 |
|-------|-----------|------|
| `python-pro` | `context7-tech-researcher` | 开发时同时查文档 |
| `vue-expert` | `chrome-devtools-debugger` | 前端开发+调试 |
| `codebase-digest-caller` | `Explore` | 架构分析+代码搜索 |
| `java-architect` | `context7-tech-researcher` | Java开发+Spring文档 |

---

## 五、使用示例

### 示例1：添加用户认证功能

```markdown
## 7.2 Task Breakdown

| 任务 | 执行工具 | 依赖 |
|-----|---------|------|
| 调研JWT库最佳实践 | `context7-tech-researcher` | - |
| 设计认证流程 | `Plan` | 调研完成 |
| 实现后端认证API | `python-pro` | 设计完成 |
| 实现前端登录页 | `vue-expert` | API完成 |
| 编写测试用例 | `code-test-executor` | 实现完成 |
| 提交代码 | `commit` | 测试通过 |
```

### 示例2：数据分析报告

```markdown
## 7.2 Task Breakdown

| 任务 | 执行工具 | 依赖 |
|-----|---------|------|
| 数据处理脚本 | `python-pro` | - |
| 生成分析图表 | `python-pro` + `xlsx` | 数据处理 |
| 导出PDF报告 | `pdf` | 图表完成 |
```
