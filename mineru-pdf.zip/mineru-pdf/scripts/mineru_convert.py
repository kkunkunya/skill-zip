#!/usr/bin/env python3
"""
MinerU API 文档转换脚本
支持: PDF, DOCX, PPT, 图片, HTML → Markdown

用法:
    # 本地文件（自动上传）
    python mineru_convert.py document.pdf
    python mineru_convert.py presentation.pptx

    # URL 文件
    python mineru_convert.py https://example.com/doc.pdf

    # HTML 文件
    python mineru_convert.py page.html --html
    python mineru_convert.py https://example.com --html

    # 指定输出目录
    python mineru_convert.py document.pdf -o ./output
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

# API 配置
API_BASE = "https://mineru.net/api/v4"
API_TOKEN = os.environ.get("MINERU_API_TOKEN", "eyJ0eXBlIjoiSldUIiwiYWxnIjoiSFM1MTIifQ.eyJqdGkiOiI0MzgwMDY3OSIsInJvbCI6IlJPTEVfUkVHSVNURVIiLCJpc3MiOiJPcGVuWExhYiIsImlhdCI6MTc2OTYwODU2NCwiY2xpZW50SWQiOiJsa3pkeDU3bnZ5MjJqa3BxOXgydyIsInBob25lIjoiIiwib3BlbklkIjpudWxsLCJ1dWlkIjoiOGU0MzIxYWYtN2I2ZC00NzY4LTk3ZmItZDEzYzlhMzNmY2EwIiwiZW1haWwiOiIiLCJleHAiOjE3NzA4MTgxNjR9._GuE4YLJtMfr39wom94diIWsGq-gmtMDQq4MEqF_SwE5cRwb6an0IAKGOZuWuybxu98yAUmWhdlLG1SQ_1HKuA")

# 支持的文件格式
SUPPORTED_FORMATS = {
    "document": [".pdf", ".doc", ".docx", ".ppt", ".pptx"],
    "image": [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp"],
    "html": [".html", ".htm"],
}


def get_headers():
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_TOKEN}",
    }


def is_url(path: str) -> bool:
    """判断是否为 URL"""
    parsed = urlparse(path)
    return parsed.scheme in ("http", "https")


def get_file_type(path: str) -> str:
    """获取文件类型"""
    ext = Path(path).suffix.lower()
    for ftype, exts in SUPPORTED_FORMATS.items():
        if ext in exts:
            return ftype
    return "unknown"


def upload_file(file_path: str) -> str:
    """上传本地文件到 MinerU，返回文件 URL"""
    # 获取上传凭证
    url = f"{API_BASE}/file/upload"
    headers = get_headers()

    file_name = Path(file_path).name
    data = {"file_name": file_name}

    resp = requests.post(url, headers=headers, json=data)
    resp.raise_for_status()
    result = resp.json()

    if result.get("code") != 0:
        raise Exception(f"获取上传凭证失败: {result.get('msg')}")

    upload_info = result["data"]

    # 上传文件到 OSS
    with open(file_path, "rb") as f:
        files = {"file": (file_name, f)}
        upload_resp = requests.post(
            upload_info["upload_url"],
            data=upload_info.get("form_data", {}),
            files=files,
        )
        upload_resp.raise_for_status()

    return upload_info["file_url"]


def create_task(file_url: str, is_html: bool = False) -> str:
    """创建转换任务，返回 task_id"""
    url = f"{API_BASE}/extract/task"
    headers = get_headers()

    data = {
        "url": file_url,
        "model_version": "MinerU-HTML" if is_html else "vlm",
    }

    resp = requests.post(url, headers=headers, json=data)
    resp.raise_for_status()
    result = resp.json()

    if result.get("code") != 0:
        raise Exception(f"创建任务失败: {result.get('msg')}")

    return result["data"]["task_id"]


def poll_task(task_id: str, timeout: int = 600, interval: int = 5) -> dict:
    """轮询任务状态，返回结果"""
    url = f"{API_BASE}/extract/task/{task_id}"
    headers = get_headers()

    start_time = time.time()
    while time.time() - start_time < timeout:
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        result = resp.json()

        if result.get("code") != 0:
            raise Exception(f"查询任务失败: {result.get('msg')}")

        status = result["data"]["state"]
        print(f"任务状态: {status}", file=sys.stderr)

        if status == "done":
            return result["data"]
        elif status == "failed":
            raise Exception(f"任务失败: {result['data'].get('err_msg', '未知错误')}")

        time.sleep(interval)

    raise Exception(f"任务超时 ({timeout}s)")


def download_result(result_data: dict, output_dir: Path) -> Path:
    """下载转换结果"""
    output_dir.mkdir(parents=True, exist_ok=True)

    # 获取结果 URL
    full_zip_url = result_data.get("full_zip_url")
    md_url = result_data.get("md_url")

    if full_zip_url:
        # 下载完整 ZIP
        zip_path = output_dir / "result.zip"
        resp = requests.get(full_zip_url)
        resp.raise_for_status()
        zip_path.write_bytes(resp.content)

        # 解压
        import zipfile
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(output_dir)
        zip_path.unlink()

        print(f"结果已保存到: {output_dir}", file=sys.stderr)
        return output_dir
    elif md_url:
        # 只下载 Markdown
        md_path = output_dir / "output.md"
        resp = requests.get(md_url)
        resp.raise_for_status()
        md_path.write_text(resp.text, encoding="utf-8")

        print(f"Markdown 已保存到: {md_path}", file=sys.stderr)
        return md_path
    else:
        raise Exception("未找到结果下载链接")


def convert(input_path: str, output_dir: str = None, is_html: bool = False) -> Path:
    """主转换函数"""
    # 确定输出目录
    if output_dir:
        out_path = Path(output_dir)
    else:
        if is_url(input_path):
            out_path = Path("./mineru_output")
        else:
            out_path = Path(input_path).parent / f"{Path(input_path).stem}_mineru"

    # 获取文件 URL
    if is_url(input_path):
        file_url = input_path
    else:
        # 本地文件需要上传
        if not Path(input_path).exists():
            raise FileNotFoundError(f"文件不存在: {input_path}")
        print(f"上传文件: {input_path}", file=sys.stderr)
        file_url = upload_file(input_path)
        print(f"文件 URL: {file_url}", file=sys.stderr)

    # 创建任务
    print("创建转换任务...", file=sys.stderr)
    task_id = create_task(file_url, is_html)
    print(f"任务 ID: {task_id}", file=sys.stderr)

    # 等待完成
    print("等待转换完成...", file=sys.stderr)
    result = poll_task(task_id)

    # 下载结果
    return download_result(result, out_path)


def main():
    parser = argparse.ArgumentParser(
        description="MinerU 文档转换 (PDF/DOCX/PPT/图片/HTML → Markdown)"
    )
    parser.add_argument("input", help="输入文件路径或 URL")
    parser.add_argument("-o", "--output", help="输出目录")
    parser.add_argument("--html", action="store_true", help="HTML 模式")
    parser.add_argument("--timeout", type=int, default=600, help="超时时间(秒)")

    args = parser.parse_args()

    try:
        result_path = convert(args.input, args.output, args.html)
        print(f"\n转换完成: {result_path}")
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
