---
name: project-zip
description: Intelligently compresses and packages projects into ZIP archives with environment setup guide. Analyzes project dependencies (Python/Node.js/Java), generates Chinese setup documentation with mirror source configurations for mainland China users, then packages with smart file exclusion. Activates when users request project compression, including requests like "compress project", "package project", "archive project", "create zip", "zip project", "export project", or "project archiving".
context: fork
agent: Explore
---

# 项目压缩打包 Skill

按照以下工作流程执行任务。**核心原则：打包前必须预览确认，用户有最终决定权。**

## 步骤1：项目分析与文档理解

### 1.1 扫描项目结构
使用Glob工具扫描项目，识别项目类型：
- Python: requirements.txt, pyproject.toml, setup.py
- Node.js: package.json, package-lock.json, yarn.lock
- Java: pom.xml, build.gradle
- 其他: go.mod, Cargo.toml, composer.json

### 1.2 读取项目文档（重要）
读取以下文档理解项目需求和交付目的：
- README.md - 项目说明和使用方式
- docs/ 目录 - 详细文档
- CHANGELOG.md - 版本信息

根据文档判断：
- 项目是否需要包含演示数据？
- 是否有预训练模型需要交付？
- 客户是否需要开箱即用？

### 1.3 采集环境信息
收集当前开发环境详情，用于后续生成配置文稿：

**Python 项目：**
```bash
python --version
pip --version
# 检查是否使用 uv/conda/poetry
uv --version 2>/dev/null || conda --version 2>/dev/null || poetry --version 2>/dev/null
```

**Node.js 项目：**
```bash
node --version
npm --version
# 检查包管理器
yarn --version 2>/dev/null || pnpm --version 2>/dev/null
```

**Java 项目：**
```bash
java --version
mvn --version 2>/dev/null || gradle --version 2>/dev/null
```

## 步骤2：生成环境配置文稿（必须）

**在打包前，必须生成 `环境配置指南.md` 文件，帮助客户自行配置环境。**

### 2.1 文稿模板

```markdown
# {项目名} 环境配置指南

> 本文档帮助您在新电脑上配置与开发环境一致的运行环境。
> 生成时间：{YYYY-MM-DD}

## 一、系统要求

- 操作系统：{Windows 10/11 | macOS | Linux}
- 内存要求：{根据项目评估}
- 磁盘空间：{压缩包大小 + 依赖空间估算}

## 二、基础环境安装

{根据项目类型生成对应内容}

## 三、依赖安装

{依赖安装命令，包含镜像源配置}

## 四、项目启动

{启动命令和验证方式}

## 五、常见问题

{预判可能遇到的问题及解决方案}
```

### 2.2 Python 项目配置内容

```markdown
## 二、基础环境安装

### 2.1 安装 Python {版本号}

**Windows 用户：**
1. 访问 https://www.python.org/downloads/
2. 下载 Python {版本号} 安装包
3. 安装时勾选 "Add Python to PATH"
4. 验证：打开命令提示符，输入 `python --version`

**macOS 用户：**
```bash
# 使用 Homebrew（推荐）
brew install python@{主版本}
```

### 2.2 配置 pip 镜像源（国内用户必做）

**临时使用：**
```bash
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```

**永久配置（推荐）：**

Windows：在 `%APPDATA%\pip\pip.ini` 创建/编辑：
```ini
[global]
index-url = https://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.aliyun.com
```

macOS/Linux：在 `~/.pip/pip.conf` 创建/编辑：
```ini
[global]
index-url = https://mirrors.aliyun.com/pypi/simple/
trusted-host = mirrors.aliyun.com
```

**其他可用镜像源：**
- 清华：https://pypi.tuna.tsinghua.edu.cn/simple/
- 中科大：https://pypi.mirrors.ustc.edu.cn/simple/
- 豆瓣：https://pypi.douban.com/simple/

## 三、依赖安装

```bash
# 创建虚拟环境（推荐）
python -m venv venv

# 激活虚拟环境
# Windows:
venv\Scripts\activate
# macOS/Linux:
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt -i https://mirrors.aliyun.com/pypi/simple/
```
```

### 2.3 Node.js 项目配置内容

```markdown
## 二、基础环境安装

### 2.1 安装 Node.js {版本号}

**Windows/macOS 用户：**
1. 访问 https://nodejs.org/
2. 下载 LTS 版本 ({版本号}) 安装包
3. 按提示完成安装
4. 验证：打开终端，输入 `node --version` 和 `npm --version`

### 2.2 配置 npm 镜像源（国内用户必做）

**永久配置（推荐）：**
```bash
npm config set registry https://registry.npmmirror.com
```

**验证配置：**
```bash
npm config get registry
# 应输出：https://registry.npmmirror.com
```

**其他可用镜像源：**
- 淘宝新镜像：https://registry.npmmirror.com
- 腾讯云：https://mirrors.cloud.tencent.com/npm/

## 三、依赖安装

```bash
# 进入项目目录后执行
npm install

# 如果使用 yarn
yarn install

# 如果使用 pnpm
pnpm install
```
```

### 2.4 Java 项目配置内容

```markdown
## 二、基础环境安装

### 2.1 安装 JDK {版本号}

**Windows 用户：**
1. 访问 https://adoptium.net/
2. 下载 Temurin JDK {版本号}
3. 安装并配置环境变量 JAVA_HOME
4. 验证：`java --version`

**macOS 用户：**
```bash
brew install openjdk@{版本}
```

### 2.2 配置 Maven 镜像源（国内用户必做）

编辑 Maven 配置文件：
- Windows: `%USERPROFILE%\.m2\settings.xml`
- macOS/Linux: `~/.m2/settings.xml`

```xml
<settings>
  <mirrors>
    <mirror>
      <id>aliyunmaven</id>
      <mirrorOf>*</mirrorOf>
      <name>阿里云公共仓库</name>
      <url>https://maven.aliyun.com/repository/public</url>
    </mirror>
  </mirrors>
</settings>
```

## 三、依赖安装

```bash
# Maven 项目
mvn clean install

# Gradle 项目
./gradlew build
```
```

### 2.5 常见问题模板

```markdown
## 五、常见问题

### Q1: 安装依赖时提示网络超时？
A: 请确认已正确配置国内镜像源，参考第二节配置说明。

### Q2: 提示缺少某个系统库？
A: {根据项目依赖预判，如 Python 的 opencv 需要 libgl1 等}

### Q3: 版本不兼容问题？
A: 请严格按照本文档指定的版本安装，版本差异可能导致兼容性问题。

### Q4: 如何联系技术支持？
A: {作者联系方式或留空让用户填写}
```

### 2.6 文稿存放位置

- 文件名：`环境配置指南.md`（默认中文）或 `SETUP_GUIDE.md`（用户要求英文时）
- 存放位置：项目根目录
- **必须包含在打包文件中**

## 步骤3：智能分类扫描

### 3.1 识别特殊文件类型

**模型文件（⭐标记）：**
```
.pt, .pth, .onnx, .h5, .hdf5, .pkl, .pickle
.safetensors, .bin, .model, .weights, .ckpt
```

**数据集目录和文件（📊标记）：**
```
目录: data/, dataset/, datasets/, train/, test/, val/, validation/
文件: .csv, .json, .jsonl, .parquet, .tfrecord, .npy, .npz, .arrow
```

### 3.2 大小感知规则

| 大小 | 处理方式 |
|-----|---------|
| < 10MB | 默认推荐包含，标记 ✅ |
| 10-100MB | 提示用户确认，标记 ⚠️ |
| > 100MB | 默认排除，标记 🚫 |

### 3.3 通用排除列表

**始终排除：**
- .git/, .idea/, .vscode/, .claude/
- *.log, .DS_Store, Thumbs.db, *.tmp, *.bak
- .env, .env.local（敏感信息）

**Python项目：**
- venv/, .venv/, __pycache__/, *.pyc
- .pytest_cache/, .mypy_cache/, dist/, build/

**Node.js项目：**
- node_modules/, .next/, .nuxt/, dist/, build/

**Java项目：**
- target/, *.class, .gradle/, build/

## 步骤4：生成预览清单（必须）

**在执行任何打包操作前，必须先向用户展示以下清单：**

```
📋 项目打包预览 - {项目名}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📦 准备打包 ({N}个文件, {总大小}):
  ├── src/ ({n}个文件)
  ├── config/ ({n}个文件)
  ├── models/best.pt (8.5MB) ⭐模型
  └── data/sample.csv (2.1MB) 📊数据集

🚫 准备排除:
  ├── .venv/ (虚拟环境)
  ├── __pycache__/ (缓存)
  ├── node_modules/ (依赖)
  └── data/large_train.csv (500MB) ⚠️文件过大

⚠️ 需确认:
  ├── models/checkpoint.pth (45MB) ⭐模型-中等大小
  └── data/test_set.csv (25MB) 📊数据集-中等大小

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
请确认：
1. 以上分类是否正确？
2. 是否需要额外包含或排除某些文件？
3. 确认后输入 "确认打包" 开始打包
```

## 步骤5：等待用户确认

**必须等待用户明确确认后才能继续。用户可能：**
- 要求包含某些被排除的文件
- 要求排除某些准备打包的文件
- 调整模型/数据集的处理方式
- 直接确认打包

根据用户反馈调整清单，必要时重新展示。

## 步骤6：路径检查

检查硬编码路径并提示修复：
- 搜索 `C:\`, `/home/`, `/Users/` 等绝对路径
- 检查配置文件中的路径设置
- 建议修复为相对路径

## 步骤7：执行压缩

用户确认后执行：

**macOS/Linux（推荐）:**
```bash
zip -r 项目名_YYYYMMDD.zip . -x "排除模式..."
```

**Windows (PowerShell):**
```powershell
# 根据确认的清单构建排除列表
$excludePatterns = @('.git', '.venv', '__pycache__', ...)
# 使用Compress-Archive
```

文件名格式：`{项目名}_{YYYYMMDD}.zip`

## 步骤8：生成报告

```
✅ 打包完成
━━━━━━━━━━━━━━━━━━━━━
📁 文件: {项目名}_20240115.zip
📏 大小: {压缩后大小} (压缩前 {原大小})
📊 包含: {文件数}个文件
⭐ 模型: {模型文件列表}
📊 数据: {数据集列表}
📖 配置指南: 环境配置指南.md (已包含)

💡 使用提示:
- 解压后运行: {启动命令}
- 需安装依赖: {依赖安装命令}
- 环境配置: 请参考压缩包内的「环境配置指南.md」
```
