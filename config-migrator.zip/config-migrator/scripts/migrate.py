#!/usr/bin/env python3
"""
Config Migrator - 将 Claude Code 配置迁移到 Codex CLI 和 Gemini CLI

Usage:
    migrate.py --target codex|gemini|all [--source <path>]
"""

import argparse
import json
import re
from pathlib import Path
from datetime import datetime


def get_home_dir():
    """获取用户主目录"""
    return Path.home()


def analyze_claude_config():
    """分析 Claude Code 配置"""
    home = get_home_dir()
    config = {
        "global_md": None,
        "project_md": None,
        "rules": [],
        "settings": None,
        "skills_index": [],
        "subagents_index": []
    }

    # 检查全局 CLAUDE.md
    global_md = home / ".claude" / "CLAUDE.md"
    if global_md.exists():
        config["global_md"] = global_md.read_text(encoding="utf-8")
        print(f"✅ 找到全局配置: {global_md}")

    # 检查项目 CLAUDE.md
    for path in [Path("CLAUDE.md"), Path(".claude/CLAUDE.md")]:
        if path.exists():
            config["project_md"] = path.read_text(encoding="utf-8")
            print(f"✅ 找到项目配置: {path}")
            break

    # 检查规则文件
    rules_dir = Path(".claude/rules")
    if rules_dir.exists():
        for rule_file in rules_dir.glob("*.md"):
            config["rules"].append({
                "name": rule_file.stem,
                "content": rule_file.read_text(encoding="utf-8")
            })
            print(f"✅ 找到规则: {rule_file.name}")

    # 检查 settings.json
    settings_path = home / ".claude" / "settings.json"
    if settings_path.exists():
        config["settings"] = json.loads(settings_path.read_text(encoding="utf-8"))
        print(f"✅ 找到设置: {settings_path}")

    return config


def filter_claude_specific(content: str) -> str:
    """过滤 Claude 特有内容（subagent/skill 索引等）"""
    if not content:
        return ""

    lines = content.split("\n")
    filtered = []
    skip_section = False

    for line in lines:
        # 跳过 Subagent/Skill 索引部分
        if re.match(r"^##\s*(Subagent|Skill)\s*索引", line, re.IGNORECASE):
            skip_section = True
            continue
        # 遇到新的二级标题，停止跳过
        if skip_section and re.match(r"^##\s+", line):
            skip_section = False

        if not skip_section:
            filtered.append(line)

    return "\n".join(filtered)


def migrate_to_codex(config: dict):
    """迁移到 Codex CLI"""
    home = get_home_dir()
    codex_dir = home / ".codex"
    codex_dir.mkdir(exist_ok=True)

    # 生成 AGENTS.md
    content = filter_claude_specific(config.get("global_md", ""))
    agents_md = f"""# Project Guidelines for Codex

{content}

## Agent Swarm 使用指南

### 何时使用子代理

适用场景：
- 多文件/多模块独立修改
- 代码探索、搜索、分析任务
- 大型调研需要大量上下文
- 测试执行、验证任务

### 并行执行策略

```
单任务多文件 → 拆分为多个子代理并行
多独立任务 → 每个任务一个子代理
主智能体 → 分配任务 + 审查结果 + 整合输出
```

### 信任度评审

| 信任度 | 评审方式 |
|--------|----------|
| ≥85% | 快速review |
| 70-85% | 详细review |
| <70% | 多模型验证 |

## Codex 配置建议

### 审批策略
- 文件修改：需要确认
- 命令执行：需要确认
"""

    agents_path = codex_dir / "AGENTS.md"
    agents_path.write_text(agents_md, encoding="utf-8")
    print(f"✅ 生成: {agents_path}")

    # 生成 config.toml
    config_toml = """# Codex CLI 配置
model = "o3"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
"""
    config_path = codex_dir / "config.toml"
    config_path.write_text(config_toml, encoding="utf-8")
    print(f"✅ 生成: {config_path}")


def migrate_to_gemini(config: dict):
    """迁移到 Gemini CLI"""
    home = get_home_dir()
    gemini_dir = home / ".gemini"
    gemini_dir.mkdir(exist_ok=True)

    # 生成 GEMINI.md
    content = filter_claude_specific(config.get("global_md", ""))
    gemini_md = f"""# Project Context for Gemini

{content}
"""

    gemini_path = gemini_dir / "GEMINI.md"
    gemini_path.write_text(gemini_md, encoding="utf-8")
    print(f"✅ 生成: {gemini_path}")

    # 生成 settings.json
    settings = {"theme": "dark", "context": {"fileName": ["GEMINI.md"]}}
    settings_path = gemini_dir / "settings.json"
    settings_path.write_text(json.dumps(settings, indent=2), encoding="utf-8")
    print(f"✅ 生成: {settings_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="配置迁移工具")
    parser.add_argument("--target", choices=["codex", "gemini", "all"], required=True)
    args = parser.parse_args()

    print("🚀 Config Migrator - 配置迁移工具\n")

    # 分析配置
    config = analyze_claude_config()

    if not config["global_md"]:
        print("❌ 未找到 Claude Code 配置")
        exit(1)

    # 执行迁移
    if args.target in ["codex", "all"]:
        print("\n📦 迁移到 Codex CLI...")
        migrate_to_codex(config)

    if args.target in ["gemini", "all"]:
        print("\n📦 迁移到 Gemini CLI...")
        migrate_to_gemini(config)

    print("\n✅ 迁移完成！")
