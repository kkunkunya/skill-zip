#!/usr/bin/env python3
"""Config Migrator: AI-first workflow (scan -> plan -> apply).

Design:
- Python负责确定性能力：扫描、统计、备份、原子写入、回滚。
- AI负责高语义决策：通过 plan 产物 + decision overrides 决定执行动作。

默认策略：
- 仅支持 Codex 目标（Gemini 本轮不处理）
- configure（~/.codex/config.toml）默认保护，不同步
- full mode 仅显式参数触发；增量不可行时只给建议
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
from dataclasses import dataclass
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

try:
    import tomllib
except Exception:  # pragma: no cover
    tomllib = None


IGNORED_SKILL_NAMES = {".DS_Store"}
CONFIG_GUARDED_KEYS = [
    "approval_policy",
    "sandbox_mode",
    "model_provider",
    "model",
    "model_reasoning_effort",
    "web_search",
]

# 高置信重命名映射（可被 decision file 覆盖）
KNOWN_RENAMES = {
    "mineru-pdf": "mineru-transfer",
}


@dataclass
class EnvPaths:
    home: Path
    claude_dir: Path
    codex_dir: Path
    gemini_dir: Path
    project_root: Path

    @property
    def claude_md(self) -> Path:
        return self.claude_dir / "CLAUDE.md"

    @property
    def codex_agents(self) -> Path:
        return self.codex_dir / "AGENTS.md"

    @property
    def codex_config(self) -> Path:
        return self.codex_dir / "config.toml"

    @property
    def claude_skills(self) -> Path:
        return self.claude_dir / "skills"

    @property
    def codex_skills(self) -> Path:
        return self.codex_dir / "skills"


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def now_fs() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip())


def read_text(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return path.read_text(encoding="utf-8", errors="replace")


def sha256_file(path: Path) -> str | None:
    if not path.exists() or not path.is_file():
        return None
    hasher = hashlib.sha256()
    with path.open("rb") as file_obj:
        while True:
            chunk = file_obj.read(1024 * 1024)
            if not chunk:
                break
            hasher.update(chunk)
    return hasher.hexdigest()


def file_inventory(path: Path) -> dict[str, Any]:
    item: dict[str, Any] = {
        "path": str(path),
        "exists": path.exists(),
        "is_symlink": path.is_symlink(),
    }

    if path.is_symlink():
        try:
            item["symlink_target"] = os.readlink(path)
        except OSError:
            item["symlink_target"] = None
        item["broken_symlink"] = not path.exists()

    if path.exists():
        stat = path.stat()
        item["type"] = "dir" if path.is_dir() else "file"
        item["size"] = stat.st_size
        item["mtime"] = stat.st_mtime
        item["sha256"] = sha256_file(path)
    else:
        item["type"] = "missing"
        item["size"] = None
        item["mtime"] = None
        item["sha256"] = None

    return item


def parse_toml(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    if not path.exists() or not path.is_file():
        return None, "missing"

    if tomllib is not None:
        try:
            with path.open("rb") as file_obj:
                return tomllib.load(file_obj), None
        except Exception as exc:  # pragma: no cover
            return None, str(exc)

    # Fallback for Python <3.11: parse only top-level `key = value` pairs.
    # This is intentionally conservative and used for config-guard snapshots only.
    result: dict[str, Any] = {}
    for line in read_text(path).splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("["):
            continue
        match = re.match(r'^([A-Za-z0-9_\-]+)\s*=\s*(.+)$', stripped)
        if not match:
            continue
        key = match.group(1).strip()
        raw = match.group(2).strip()
        if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
            value: Any = raw[1:-1]
        elif raw in {"true", "false"}:
            value = raw == "true"
        else:
            try:
                value = int(raw)
            except ValueError:
                try:
                    value = float(raw)
                except ValueError:
                    value = raw
        result[key] = value

    return result, "fallback_parser"


def extract_h2_sections(text: str) -> tuple[str, list[dict[str, str]]]:
    lines = text.splitlines()
    title = ""
    sections: list[dict[str, str]] = []
    current_heading = None
    current_lines: list[str] = []

    for line in lines:
        if not title and line.startswith("# "):
            title = line.strip()
            continue

        heading_match = re.match(r"^##\s+(.+?)\s*$", line)
        if heading_match:
            if current_heading is not None:
                sections.append(
                    {
                        "heading": current_heading,
                        "content": "\n".join(current_lines).strip("\n"),
                    }
                )
            current_heading = heading_match.group(1).strip()
            current_lines = []
            continue

        if current_heading is not None:
            current_lines.append(line)

    if current_heading is not None:
        sections.append(
            {
                "heading": current_heading,
                "content": "\n".join(current_lines).strip("\n"),
            }
        )

    return title, sections


def markdown_diff(source_text: str, target_text: str) -> dict[str, Any]:
    source_title, source_sections = extract_h2_sections(source_text)
    target_title, target_sections = extract_h2_sections(target_text)

    source_map = {item["heading"]: item["content"] for item in source_sections}
    target_map = {item["heading"]: item["content"] for item in target_sections}

    changed_sections = []
    added_sections = []
    removed_sections = []

    for heading, content in source_map.items():
        if heading not in target_map:
            added_sections.append(heading)
        elif normalize_text(content) != normalize_text(target_map[heading]):
            changed_sections.append(heading)

    for heading in target_map:
        if heading not in source_map:
            removed_sections.append(heading)

    total = max(1, len(source_sections))
    drift_ratio = (len(changed_sections) + len(added_sections) + len(removed_sections)) / total

    return {
        "source_title": source_title,
        "target_title": target_title,
        "source_section_count": len(source_sections),
        "target_section_count": len(target_sections),
        "changed_sections": changed_sections,
        "added_sections": added_sections,
        "removed_sections": removed_sections,
        "drift_ratio": round(drift_ratio, 4),
    }


def find_project_candidates(project_root: Path) -> dict[str, list[str]]:
    patterns = [
        "CLAUDE.md",
        ".claude/CLAUDE.md",
        ".claude/settings.json",
        ".claude/rules/**/*.md",
        "AGENTS.md",
        ".gemini/GEMINI.md",
        ".gemini/settings.json",
    ]
    result: dict[str, list[str]] = {}
    for pattern in patterns:
        found = [str(path) for path in project_root.glob(pattern)]
        if found:
            result[pattern] = sorted(found)
    return result


def _norm_name(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def list_entries(path: Path) -> list[str]:
    if not path.exists() or not path.is_dir():
        return []
    return sorted([item.name for item in path.iterdir() if item.name not in IGNORED_SKILL_NAMES])


def best_name_candidates(name: str, source_entries: list[str]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []

    if name in KNOWN_RENAMES and KNOWN_RENAMES[name] in source_entries:
        candidates.append(
            {
                "name": KNOWN_RENAMES[name],
                "score": 1.0,
                "evidence": "known_rename",
            }
        )

    left = _norm_name(name)
    prefix = name.split("-")[0].lower() if "-" in name else name.lower()

    for entry in source_entries:
        right = _norm_name(entry)
        ratio = SequenceMatcher(None, left, right).ratio()
        bonus = 0.08 if prefix and prefix in entry.lower() else 0.0
        score = min(1.0, ratio + bonus)
        candidates.append(
            {
                "name": entry,
                "score": round(score, 4),
                "evidence": "string_similarity",
            }
        )

    dedup: dict[str, dict[str, Any]] = {}
    for item in candidates:
        old = dedup.get(item["name"])
        if old is None or item["score"] > old["score"]:
            dedup[item["name"]] = item

    return sorted(dedup.values(), key=lambda item: item["score"], reverse=True)[:3]


def analyze_broken_link(link_path: Path, source_skills_dir: Path, source_entries: list[str]) -> dict[str, Any]:
    name = link_path.name
    link_target = os.readlink(link_path)
    expected = source_skills_dir / name

    analysis: dict[str, Any] = {
        "name": name,
        "path": str(link_path),
        "link_target": link_target,
        "expected_source": str(expected),
        "expected_exists": expected.exists(),
        "root_cause": "source_removed",
        "candidates": [],
        "python_proposal": {
            "action": "delete_link",
            "target": None,
            "confidence": 0.6,
            "requires_ai_review": True,
            "rationale": "源路径不存在，默认建议删除历史失效软链",
        },
    }

    if expected.exists():
        analysis["root_cause"] = "broken_link_target"
        analysis["python_proposal"] = {
            "action": "relink",
            "target": str(expected),
            "confidence": 1.0,
            "requires_ai_review": False,
            "rationale": "源路径存在但链接失效，安全重连",
        }
        return analysis

    candidates = best_name_candidates(name, source_entries)
    analysis["candidates"] = candidates
    if not candidates:
        analysis["root_cause"] = "invalid_legacy"
        return analysis

    best = candidates[0]
    score = best["score"]

    if best.get("evidence") == "known_rename" and score >= 0.99:
        analysis["root_cause"] = "source_renamed"
        analysis["python_proposal"] = {
            "action": "relink",
            "target": str(source_skills_dir / best["name"]),
            "confidence": score,
            "requires_ai_review": False,
            "rationale": f"命中已知重命名映射 {name} -> {best['name']}",
        }
    elif score >= 0.9:
        analysis["root_cause"] = "source_renamed_likely"
        analysis["python_proposal"] = {
            "action": "relink",
            "target": str(source_skills_dir / best["name"]),
            "confidence": score,
            "requires_ai_review": True,
            "rationale": f"高相似候选 {best['name']} (score={score})，建议 AI 复核",
        }
    elif score >= 0.72:
        analysis["root_cause"] = "source_relocated_or_renamed_ambiguous"
        analysis["python_proposal"] = {
            "action": "delete_link",
            "target": None,
            "confidence": score,
            "requires_ai_review": True,
            "rationale": f"候选不确定 (best={best['name']}, score={score})，默认建议删除",
        }
    else:
        analysis["root_cause"] = "invalid_legacy"

    return analysis


def build_scan(env: EnvPaths, target: str) -> dict[str, Any]:
    if target != "codex":
        raise ValueError("当前版本仅支持 --target codex")

    source_md = read_text(env.claude_md)
    target_md = read_text(env.codex_agents)
    doc_diffs = markdown_diff(source_md, target_md)

    codex_cfg, codex_cfg_err = parse_toml(env.codex_config)
    config_guard = {
        "protected": True,
        "reason": "codex configure 与 claude 不同，默认保护不迁移",
        "keys": CONFIG_GUARDED_KEYS,
        "parse_error": codex_cfg_err,
        "snapshot": {},
    }
    if codex_cfg:
        for key in CONFIG_GUARDED_KEYS:
            config_guard["snapshot"][key] = codex_cfg.get(key)

    source_entries = list_entries(env.claude_skills)
    target_entries = list_entries(env.codex_skills)

    source_set = set(source_entries)
    target_set = set(target_entries)

    missing_in_codex = sorted(source_set - target_set)
    extra_in_codex = sorted(target_set - source_set - {".system"})

    broken_links: list[dict[str, Any]] = []
    if env.codex_skills.exists():
        for path in sorted(env.codex_skills.iterdir(), key=lambda item: item.name):
            if path.name in IGNORED_SKILL_NAMES:
                continue
            if path.is_symlink() and not path.exists():
                broken_links.append(analyze_broken_link(path, env.claude_skills, source_entries))

    high_uncertainty = [
        item
        for item in broken_links
        if item["python_proposal"]["requires_ai_review"] and item["python_proposal"]["confidence"] >= 0.72
    ]

    skills_issue_ratio = (
        len(missing_in_codex) + len(extra_in_codex) + len(broken_links)
    ) / max(1, len(source_entries))

    full_mode_reasons: list[str] = []
    if doc_diffs["drift_ratio"] > 0.55:
        full_mode_reasons.append(f"文档漂移率过高({doc_diffs['drift_ratio']})")
    if len(doc_diffs["added_sections"]) + len(doc_diffs["removed_sections"]) >= 2:
        full_mode_reasons.append("章节增删较多")
    if len(high_uncertainty) >= 5:
        full_mode_reasons.append("高不确定冲突较多")
    if skills_issue_ratio > 0.35:
        full_mode_reasons.append(f"skills 异常比例偏高({round(skills_issue_ratio, 4)})")

    full_mode_hint = {
        "recommended": bool(full_mode_reasons),
        "reasons": full_mode_reasons,
    }

    change_list = {
        "docs": {
            "changed_sections": doc_diffs["changed_sections"],
            "added_sections": doc_diffs["added_sections"],
            "removed_sections": doc_diffs["removed_sections"],
        },
        "skills": {
            "missing_in_codex": missing_in_codex,
            "extra_in_codex": extra_in_codex,
            "broken_links": [
                {
                    "name": item["name"],
                    "root_cause": item["root_cause"],
                    "python_proposal": item["python_proposal"],
                    "top_candidate": item["candidates"][0] if item["candidates"] else None,
                }
                for item in broken_links
            ],
        },
        "config": {
            "protected": True,
            "sync_skipped": True,
            "reason": config_guard["reason"],
        },
    }

    conflicts = {
        "blocker": [],
        "warn": [],
        "info": [],
    }
    conflicts["info"].append("configure 默认保护，不参与同步")
    for item in broken_links:
        proposal = item["python_proposal"]
        label = f"失效软链 {item['name']} -> {proposal['action']} (confidence={proposal['confidence']})"
        if proposal["requires_ai_review"]:
            conflicts["warn"].append(label + " [needs_ai_review]")
        else:
            conflicts["info"].append(label)

    if full_mode_hint["recommended"]:
        conflicts["warn"].append("检测到建议全量模式（仅建议，不自动切换）")

    return {
        "meta": {
            "version": "2.2",
            "generated_at": now_iso(),
            "target": target,
            "project_root": str(env.project_root),
        },
        "inventory": {
            "claude_md": file_inventory(env.claude_md),
            "codex_agents": file_inventory(env.codex_agents),
            "codex_config": file_inventory(env.codex_config),
            "claude_skills": file_inventory(env.claude_skills),
            "codex_skills": file_inventory(env.codex_skills),
        },
        "project_candidates": find_project_candidates(env.project_root),
        "doc_diffs": doc_diffs,
        "config_guard": config_guard,
        "skills_diffs": {
            "source_count": len(source_entries),
            "target_count": len(target_entries),
            "missing_in_codex": missing_in_codex,
            "extra_in_codex": extra_in_codex,
            "broken_links": broken_links,
        },
        "change_list": change_list,
        "full_mode_hint": full_mode_hint,
        "conflicts": conflicts,
    }


def build_incremental_agents(source_text: str, target_text: str) -> str:
    source_title, source_sections = extract_h2_sections(source_text)
    target_title, target_sections = extract_h2_sections(target_text)

    if source_title:
        final_title = "# Codex CLI 配置"
    else:
        final_title = target_title or "# Codex CLI 配置"

    source_map = {item["heading"]: item["content"] for item in source_sections}
    target_map = {item["heading"]: item["content"] for item in target_sections}

    order = [item["heading"] for item in target_sections]
    for item in source_sections:
        if item["heading"] not in order:
            order.append(item["heading"])

    lines = [final_title, ""]
    for heading in order:
        if heading in source_map and heading in target_map:
            content = source_map[heading] if normalize_text(source_map[heading]) != normalize_text(target_map[heading]) else target_map[heading]
        elif heading in source_map:
            content = source_map[heading]
        else:
            content = target_map[heading]

        lines.append(f"## {heading}")
        if content:
            lines.append(content.rstrip("\n"))
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


def build_full_agents(source_text: str) -> str:
    if not source_text.strip():
        return "# Codex CLI 配置\n"
    lines = source_text.splitlines()
    out: list[str] = []
    replaced = False
    for line in lines:
        if not replaced and line.startswith("# "):
            out.append("# Codex CLI 配置")
            replaced = True
        else:
            out.append(line)
    if not replaced:
        out.insert(0, "# Codex CLI 配置")
    return "\n".join(out).rstrip() + "\n"


def default_plan_actions(scan: dict[str, Any], mode: str) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []

    has_doc_changes = bool(
        scan["doc_diffs"]["changed_sections"]
        or scan["doc_diffs"]["added_sections"]
        or scan["doc_diffs"]["removed_sections"]
    )

    if mode == "full":
        actions.append(
            {
                "id": "docs.sync.full",
                "kind": "docs",
                "op": "write_agents_full",
                "enabled": True,
                "requires_ai_review": True,
                "confidence": 0.7,
                "rationale": "全量模式重写 AGENTS.md",
                "evidence": {
                    "drift_ratio": scan["doc_diffs"]["drift_ratio"],
                },
            }
        )
    else:
        actions.append(
            {
                "id": "docs.sync.incremental",
                "kind": "docs",
                "op": "write_agents_incremental",
                "enabled": has_doc_changes,
                "requires_ai_review": False,
                "confidence": 0.9,
                "rationale": "增量同步文档章节" if has_doc_changes else "无文档差异，跳过写入",
                "evidence": {
                    "changed_sections": scan["doc_diffs"]["changed_sections"],
                    "added_sections": scan["doc_diffs"]["added_sections"],
                    "removed_sections": scan["doc_diffs"]["removed_sections"],
                },
            }
        )

    for name in scan["skills_diffs"]["missing_in_codex"]:
        actions.append(
            {
                "id": f"skills.link_missing.{name}",
                "kind": "skill",
                "op": "link_missing",
                "name": name,
                "target": str(Path(scan["inventory"]["claude_skills"]["path"]) / name),
                "enabled": True,
                "requires_ai_review": False,
                "confidence": 1.0,
                "rationale": "Codex 缺失，补充软链",
                "evidence": {},
            }
        )

    for item in scan["skills_diffs"]["broken_links"]:
        proposal = item["python_proposal"]
        action_id = f"skills.broken.{item['name']}"
        actions.append(
            {
                "id": action_id,
                "kind": "skill",
                "name": item["name"],
                "op": proposal["action"],
                "target": proposal["target"],
                "enabled": not proposal["requires_ai_review"],
                "requires_ai_review": proposal["requires_ai_review"],
                "confidence": proposal["confidence"],
                "rationale": proposal["rationale"],
                "evidence": {
                    "root_cause": item["root_cause"],
                    "candidates": item["candidates"],
                },
            }
        )

    actions.append(
        {
            "id": "config.guard.skip",
            "kind": "config",
            "op": "skip_config_sync",
            "enabled": True,
            "requires_ai_review": False,
            "confidence": 1.0,
            "rationale": "configure 默认保护，防止降级",
            "evidence": {
                "guarded_keys": CONFIG_GUARDED_KEYS,
            },
        }
    )

    return actions


def apply_decision_overrides(actions: list[dict[str, Any]], decision: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not decision:
        return actions

    action_map = {item["id"]: item for item in actions}

    for action_id in decision.get("enable", []):
        if action_id in action_map:
            action_map[action_id]["enabled"] = True
            action_map[action_id]["decision_source"] = "ai_override"

    for action_id in decision.get("disable", []):
        if action_id in action_map:
            action_map[action_id]["enabled"] = False
            action_map[action_id]["decision_source"] = "ai_override"

    for override in decision.get("overrides", []):
        action_id = override.get("id")
        if action_id not in action_map:
            continue
        for key in ["op", "target", "enabled", "rationale"]:
            if key in override:
                action_map[action_id][key] = override[key]
        action_map[action_id]["decision_source"] = "ai_override"

    return list(action_map.values())


def load_json_file(path: str | None) -> dict[str, Any] | None:
    if not path:
        return None
    file_path = Path(path).expanduser()
    if not file_path.exists() or not file_path.is_file():
        raise FileNotFoundError(f"JSON file not found: {file_path}")
    return json.loads(file_path.read_text(encoding="utf-8"))


def load_decision_overrides(decision_file: str | None, decision_json: str | None) -> dict[str, Any] | None:
    if decision_json:
        try:
            data = json.loads(decision_json)
        except json.JSONDecodeError as exc:
            raise ValueError(f"decision-json 不是合法 JSON: {exc}") from exc
        if not isinstance(data, dict):
            raise ValueError("decision-json 必须是 JSON 对象")
        return data
    return load_json_file(decision_file) if decision_file else None


def build_plan(scan: dict[str, Any], mode: str, decision_overrides: dict[str, Any] | None) -> dict[str, Any]:
    actions = default_plan_actions(scan, mode)
    actions = apply_decision_overrides(actions, decision_overrides)

    enabled = [item for item in actions if item.get("enabled")]
    needs_review = [item for item in actions if item.get("requires_ai_review")]

    return {
        "meta": {
            "generated_at": now_iso(),
            "target": scan["meta"]["target"],
            "mode": mode,
            "decision_overrides_loaded": bool(decision_overrides),
        },
        "full_mode_hint": scan["full_mode_hint"],
        "actions": actions,
        "summary": {
            "total": len(actions),
            "enabled": len(enabled),
            "needs_ai_review": len(needs_review),
            "enabled_ids": [item["id"] for item in enabled],
        },
    }


def write_report(payload: dict[str, Any], report_path: str | None) -> None:
    if not report_path:
        return
    path = Path(report_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def print_scan_text(scan: dict[str, Any]) -> None:
    print("=== Scan Summary ===")
    print(f"target: {scan['meta']['target']}")
    print(f"generated_at: {scan['meta']['generated_at']}")
    print(f"doc_drift_ratio: {scan['doc_diffs']['drift_ratio']}")
    print(f"doc_changed_sections: {', '.join(scan['doc_diffs']['changed_sections']) or 'None'}")
    print(f"skills_missing_in_codex: {len(scan['skills_diffs']['missing_in_codex'])}")
    print(f"skills_broken_links: {len(scan['skills_diffs']['broken_links'])}")
    print(f"config_guarded: {scan['config_guard']['protected']}")
    if scan["skills_diffs"]["broken_links"]:
        print("- broken links:")
        for item in scan["skills_diffs"]["broken_links"]:
            proposal = item["python_proposal"]
            print(
                f"  * {item['name']} root={item['root_cause']} proposal={proposal['action']} confidence={proposal['confidence']} needs_ai={proposal['requires_ai_review']}"
            )
    if scan["full_mode_hint"]["recommended"]:
        print("full_mode_hint: recommended")
        for reason in scan["full_mode_hint"]["reasons"]:
            print(f"  - {reason}")
    else:
        print("full_mode_hint: no")


def print_plan_text(plan: dict[str, Any]) -> None:
    print("=== Plan Summary ===")
    print(f"mode: {plan['meta']['mode']}")
    print(f"decision_overrides_loaded: {plan['meta']['decision_overrides_loaded']}")
    print(f"actions_total: {plan['summary']['total']}")
    print(f"actions_enabled: {plan['summary']['enabled']}")
    print(f"actions_need_ai_review: {plan['summary']['needs_ai_review']}")

    print("- enabled actions:")
    for item in plan["actions"]:
        if item.get("enabled"):
            print(f"  * {item['id']} -> {item['op']}")

    pending = [item for item in plan["actions"] if item.get("requires_ai_review") and not item.get("enabled")]
    if pending:
        print("- pending AI review actions:")
        for item in pending:
            print(f"  * {item['id']} -> {item['op']} (confidence={item.get('confidence')})")

    if plan["full_mode_hint"]["recommended"]:
        print("[hint] 建议评估 --mode full（不会自动切换）")


def write_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(content, encoding="utf-8")
    temp_path.replace(path)


def backup_file(path: Path, backup_dir: Path) -> str | None:
    if not path.exists() or not path.is_file():
        return None
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"{path.name}.bak"
    shutil.copy2(path, target)
    return str(target)


def execute_apply(env: EnvPaths, scan: dict[str, Any], plan: dict[str, Any]) -> dict[str, Any]:
    report = {
        "meta": {
            "generated_at": now_iso(),
            "target": scan["meta"]["target"],
            "mode": plan["meta"]["mode"],
        },
        "executed": [],
        "skipped": [],
        "warnings": [],
        "backups": {},
    }

    enabled_actions = [item for item in plan["actions"] if item.get("enabled")]

    backup_root = env.codex_dir / "tmp" / "config-migrator-backups" / now_fs()
    backup_root.mkdir(parents=True, exist_ok=True)

    source_agents_hash = sha256_file(env.claude_md)
    target_agents_hash_before = sha256_file(env.codex_agents)

    report["hash_guard"] = {
        "source_agents_sha256": source_agents_hash,
        "target_agents_sha256_before": target_agents_hash_before,
    }

    agents_backup = backup_file(env.codex_agents, backup_root)
    if agents_backup:
        report["backups"]["agents"] = agents_backup

    try:
        source_md = read_text(env.claude_md)
        target_md = read_text(env.codex_agents)

        for action in enabled_actions:
            action_id = action["id"]
            op = action["op"]

            if op == "write_agents_incremental":
                content = build_incremental_agents(source_md, target_md)
                write_atomic(env.codex_agents, content)
                report["executed"].append({"id": action_id, "op": op, "path": str(env.codex_agents)})

            elif op == "write_agents_full":
                content = build_full_agents(source_md)
                write_atomic(env.codex_agents, content)
                report["executed"].append({"id": action_id, "op": op, "path": str(env.codex_agents)})

            elif op == "link_missing":
                name = action["name"]
                dst = env.codex_skills / name
                src = env.claude_skills / name
                if dst.exists() or dst.is_symlink():
                    report["skipped"].append({"id": action_id, "reason": "destination_exists"})
                    continue
                dst.symlink_to(src)
                report["executed"].append({"id": action_id, "op": op, "path": str(dst), "target": str(src)})

            elif op == "relink":
                name = action["name"]
                dst = env.codex_skills / name
                target = action.get("target")
                if not target:
                    report["skipped"].append({"id": action_id, "reason": "missing_target"})
                    continue
                if dst.exists() and not dst.is_symlink():
                    report["skipped"].append({"id": action_id, "reason": "non_symlink_exists"})
                    continue
                if dst.is_symlink():
                    dst.unlink()
                dst.symlink_to(Path(target))
                report["executed"].append({"id": action_id, "op": op, "path": str(dst), "target": target})

            elif op == "delete_link":
                name = action["name"]
                dst = env.codex_skills / name
                if dst.is_symlink():
                    dst.unlink()
                    report["executed"].append({"id": action_id, "op": op, "path": str(dst)})
                else:
                    report["skipped"].append({"id": action_id, "reason": "not_symlink"})

            elif op == "skip_config_sync":
                report["executed"].append({"id": action_id, "op": op, "path": str(env.codex_config)})

            else:
                report["warnings"].append(f"unknown op skipped: {op}")

    except Exception as exc:
        if agents_backup and Path(agents_backup).exists():
            shutil.copy2(agents_backup, env.codex_agents)
            report["warnings"].append("apply failed, AGENTS rollback attempted")
        raise RuntimeError(f"apply failed: {exc}") from exc

    report["hash_guard"]["target_agents_sha256_after"] = sha256_file(env.codex_agents)

    if plan["full_mode_hint"]["recommended"] and plan["meta"]["mode"] == "incremental":
        report["warnings"].append("当前场景建议 full mode，但本次按 incremental 执行")

    return report


def build_env(project_root: str | None) -> EnvPaths:
    home = Path.home()
    return EnvPaths(
        home=home,
        claude_dir=home / ".claude",
        codex_dir=home / ".codex",
        gemini_dir=home / ".gemini",
        project_root=Path(project_root).expanduser().resolve() if project_root else Path.cwd().resolve(),
    )


def cmd_scan(args: argparse.Namespace) -> int:
    env = build_env(args.project_root)
    scan = build_scan(env, target=args.target)
    if args.format == "json":
        print(json.dumps(scan, ensure_ascii=False, indent=2))
    else:
        print_scan_text(scan)
    write_report(scan, args.report)
    return 0


def cmd_plan(args: argparse.Namespace) -> int:
    env = build_env(args.project_root)

    if args.scan_report:
        scan = load_json_file(args.scan_report)
        if scan is None:
            raise RuntimeError("scan_report 加载失败")
    else:
        scan = build_scan(env, target=args.target)

    decision = load_decision_overrides(args.decision_file, args.decision_json)
    plan = build_plan(scan, mode=args.mode, decision_overrides=decision)

    payload = {"scan": scan, "plan": plan}
    if args.format == "json":
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print_plan_text(plan)

    write_report(payload, args.report)
    return 0


def cmd_apply(args: argparse.Namespace) -> int:
    env = build_env(args.project_root)

    if args.plan_report:
        bundle = load_json_file(args.plan_report)
        if not bundle or "scan" not in bundle or "plan" not in bundle:
            raise RuntimeError("plan_report 格式无效，需包含 scan 与 plan")
        scan = bundle["scan"]
        plan = bundle["plan"]
    else:
        scan = build_scan(env, target=args.target)
        decision = load_decision_overrides(args.decision_file, args.decision_json)
        plan = build_plan(scan, mode=args.mode, decision_overrides=decision)

    apply_report = execute_apply(env, scan, plan)

    output = {"scan": scan, "plan": plan, "apply": apply_report}
    if args.format == "json":
        print(json.dumps(output, ensure_ascii=False, indent=2))
    else:
        print_plan_text(plan)
        print("=== Apply Summary ===")
        print(f"executed: {len(apply_report['executed'])}")
        print(f"skipped: {len(apply_report['skipped'])}")
        if apply_report["warnings"]:
            print("warnings:")
            for warning in apply_report["warnings"]:
                print(f"- {warning}")

    write_report(output, args.report)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Config Migrator (AI-first workflow)")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    def add_common(subparser: argparse.ArgumentParser) -> None:
        subparser.add_argument("--target", default="codex", choices=["codex"], help="当前仅支持 codex")
        subparser.add_argument("--project-root", default=None, help="项目根目录（默认当前目录）")
        subparser.add_argument("--report", default=None, help="可选：JSON 报告文件路径")
        subparser.add_argument("--format", default="text", choices=["text", "json"], help="终端输出格式")

    scan_parser = subparsers.add_parser("scan", help="详细扫描并生成变更清单")
    add_common(scan_parser)
    scan_parser.set_defaults(func=cmd_scan)

    plan_parser = subparsers.add_parser("plan", help="基于 scan 生成可执行补丁计划")
    add_common(plan_parser)
    plan_parser.add_argument("--mode", default="incremental", choices=["incremental", "full"], help="计划模式")
    plan_parser.add_argument("--scan-report", default=None, help="可选：复用已有 scan JSON")
    plan_parser.add_argument("--decision-file", default=None, help="AI 决策覆盖文件(JSON)")
    plan_parser.add_argument("--decision-json", default=None, help="AI 决策覆盖 JSON 字符串（优先于 decision-file）")
    plan_parser.set_defaults(func=cmd_plan)

    apply_parser = subparsers.add_parser("apply", help="执行计划（默认保护 config）")
    add_common(apply_parser)
    apply_parser.add_argument("--mode", default="incremental", choices=["incremental", "full"], help="当无 plan_report 时生效")
    apply_parser.add_argument("--plan-report", default=None, help="优先执行该计划文件(JSON, 含 scan+plan)")
    apply_parser.add_argument("--decision-file", default=None, help="当无 plan_report 时用于覆盖默认计划")
    apply_parser.add_argument("--decision-json", default=None, help="当无 plan_report 时用于覆盖默认计划（JSON 字符串）")
    apply_parser.set_defaults(func=cmd_apply)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
