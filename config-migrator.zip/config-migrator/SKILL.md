---
name: config-migrator
description: Migrates Claude Code configurations to Codex CLI with an AI-first workflow (scan -> plan -> apply). Uses deterministic scanning/execution in Python and keeps high-level decisions in AI decision patches.
context: fork
---

# Config Migrator

## Overview

将 Claude 配置迁移到 Codex，采用 **AI-first 工作流**：

1. `scan`：Python 做详细扫描与证据收集
2. `plan`：基于扫描结果生成补丁计划（支持 AI 决策覆盖）
3. `apply`：按计划执行，支持备份与回滚

默认保护 `~/.codex/config.toml`（configure 不同步，避免降级）。

## 核心原则

- Python 只做确定性任务：扫描、哈希、差异统计、备份、原子写入
- AI 负责高语义判断：是否删除失效软链、是否切换全量模式、如何覆盖默认计划
- 默认增量模式；全量模式仅显式参数触发
- Gemini 本轮不处理（`--target codex`）

## 命令

### 1) scan（详细扫描）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py scan \
  --target codex \
  --format text \
  --report /tmp/config_migrator_scan.json
```

输出：
- 文档章节差异
- skills 缺失/冗余/失效软链分析
- config guard 快照
- full mode 建议（仅建议，不自动切换）

### 2) plan（生成补丁计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex \
  --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --report /tmp/config_migrator_plan.json
```

可选 AI 决策覆盖：

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex \
  --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-file /tmp/config_migrator_decision.json \
  --report /tmp/config_migrator_plan.json

# 或者直接传 JSON（更适合对话内决策）
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex \
  --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-json '{"enable":["skills.broken.docs"]}' \
  --report /tmp/config_migrator_plan.json
```

### 3) apply（执行计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py apply \
  --target codex \
  --plan-report /tmp/config_migrator_plan.json \
  --report /tmp/config_migrator_apply.json
```

## AI 决策覆盖（decision-file）

`decision-file` 是一个可选 JSON，用于覆盖默认计划动作。

示例：

```json
{
  "enable": [
    "skills.broken.obsidian-skills",
    "skills.broken.cli-logger"
  ],
  "disable": [
    "skills.broken.mineru-pdf"
  ],
  "overrides": [
    {
      "id": "skills.broken.mineru-pdf",
      "op": "relink",
      "target": "/Users/you/.claude/skills/mineru-transfer",
      "enabled": true,
      "rationale": "手动确认迁移到 mineru-transfer"
    }
  ]
}
```

## 失效软链策略

- 扫描阶段：逐条解析 root cause + 候选映射 + 置信度
- 计划阶段：
  - 高置信且确定映射可默认启用
  - 不确定项标记 `needs_ai_review`
- 执行阶段：按最终 plan 执行 `relink` 或 `delete_link`

## 注意事项

- `config.toml` 默认仅快照，不写入
- 全量模式（`--mode full`）仅显式触发
- 如果检测到增量不可行，工具只给建议，不自动切换到全量
