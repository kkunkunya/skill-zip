---
name: config-migrator
description: >
  Migrates Claude Code configurations to Codex CLI with an AI-first workflow
  (understand -> scan -> plan -> apply). Uses dual-source system understanding
  (system snapshot document + live codebase exploration) for informed migration
  decisions. Deterministic scanning/execution in Python, high-level semantic
  decisions by AI. NOT for: general system documentation (use
  system-self-iterator) / skill creation (use skill-creator) / hook management
  (use hooks-manager).
context: fork
agent: Explore
---

# Config Migrator

## Overview

将 Claude 配置迁移到 Codex，采用 **AI-first 工作流**（四阶段）：

0. `understand`：双源系统认知（文档 + 探索）→ 建立迁移上下文
1. `scan`：Python 做详细扫描与证据收集
2. `plan`：基于认知 + 扫描结果生成补丁计划（支持 AI 决策覆盖）
3. `apply`：按计划执行，支持备份与回滚

默认保护 `~/.codex/config.toml`（configure 不同步，避免降级）。

## 核心原则

- **先理解再迁移**：不盲目对比文件差异，先建立对源系统的架构级理解
- Python 只做确定性任务：扫描、哈希、差异统计、备份、原子写入
- AI 负责高语义判断：架构映射、组件取舍、失效链接处理、模式选择
- 默认增量模式；全量模式仅显式参数触发
- Gemini 本轮不处理（`--target codex`）

## Phase 0: 系统认知（understand）

迁移前必须先理解源系统。采用**双源认知**策略：

### 源1: 系统快照文档

读取系统快照文档，快速获得全局理解：

```
~/Library/CloudStorage/OneDrive-MSFT/Note/note/L1-Thinking-Garden/agent_系统自我成长.md
```

这份文档是 Claude Code 系统的完整状态记录，包含：
- 目录结构全景（`~/.claude/` 完整树）
- 铁律体系（L0/L1/L2 三层12条）
- 技能注册表（51个技能分类、大小、依赖关系）
- Hook 系统（12个 Hook 的事件-脚本映射）
- Agent/Team 系统（通信协议、角色组合）
- MCP 服务器配置
- 工作模式（三级递进决策树）
- 核心文档体系（5文件职责）
- 最近变更历史

### 源2: 实际探索验证

文档可能滞后于实际状态。读完文档后，回答以下验证问题：

1. **skills 实际数量**是否与文档记录一致？（`ls ~/.claude/skills/ | wc -l`）
2. **hooks 实际配置**是否与文档映射一致？（读 `~/.claude/settings.json` 的 hooks 段）
3. **目标环境状态**如何？（`~/.codex/` 是否存在、已有哪些配置）
4. **有无文档未记录的新增组件**？（对比 skills 目录与 registry.json）

### 认知产出

完成双源认知后，形成迁移上下文摘要（不需要写文件，在对话中保持即可）：
- 哪些组件是核心必迁的（铁律相关、日常高频使用）
- 哪些组件可以跳过（遗留文件、平台特定配置）
- 哪些组件需要适配（Claude 特有概念在 Codex 中的映射）
- 已知的坑和注意事项（从文档"已知问题"和"最近变更"中提取）

## Phase 1: scan（详细扫描）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py scan \
  --target codex \
  --format text \
  --report /tmp/config_migrator_scan.json
```

输出：
- 文档章节差异
- skills 缺失/冗余/失效软链分析
- config guard 快照
- full mode 建议（仅建议，不自动切换）

**结合 Phase 0 认知解读扫描结果**：扫描只给出文件级差异，AI 需要结合系统认知判断每个差异的语义含义（是有意为之还是遗漏）。

## Phase 2: plan（生成补丁计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex \
  --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --report /tmp/config_migrator_plan.json
```

可选 AI 决策覆盖：

```bash
# 通过文件
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-file /tmp/config_migrator_decision.json \
  --report /tmp/config_migrator_plan.json

# 或直接传 JSON（更适合对话内决策）
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-json '{"enable":["skills.broken.docs"]}' \
  --report /tmp/config_migrator_plan.json
```

**⚠️ 用户确认检查点**：plan 生成后，必须向用户展示计划摘要并获得确认后才能进入 apply。

## Phase 3: apply（执行计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py apply \
  --target codex \
  --plan-report /tmp/config_migrator_plan.json \
  --report /tmp/config_migrator_apply.json
```

## AI 决策覆盖（decision-file）

`decision-file` 是一个可选 JSON，用于覆盖默认计划动作。

```json
{
  "enable": ["skills.broken.obsidian-skills"],
  "disable": ["skills.broken.mineru-pdf"],
  "overrides": [
    {
      "id": "skills.broken.mineru-pdf",
      "op": "relink",
      "target": "/Users/you/.claude/skills/mineru-transfer",
      "enabled": true,
      "rationale": "手动确认迁移到 mineru-transfer"
    }
  ]
}
```

## 失效软链策略

- 扫描阶段：逐条解析 root cause + 候选映射 + 置信度
- 计划阶段：高置信映射默认启用，不确定项标记 `needs_ai_review`
- 执行阶段：按最终 plan 执行 `relink` 或 `delete_link`

## 注意事项

- `config.toml` 默认仅快照，不写入
- 全量模式（`--mode full`）仅显式触发
- 增量不可行时工具只给建议，不自动切换
- 系统快照文档路径可能因用户环境不同而变化，找不到时降级为纯探索模式
