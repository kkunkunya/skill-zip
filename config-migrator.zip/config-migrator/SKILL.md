---
name: config-migrator
description: >
  Migrates Claude Code configurations to Codex CLI with an AI-first workflow
  (understand -> scan -> plan -> apply). Uses dual-source system understanding
  (system snapshot document + live codebase exploration) for informed migration
  decisions. Deterministic scanning/execution in Python, high-level semantic
  decisions by AI. NOT for: general system documentation (use
  system-self-iterator) / skill creation (use skill-creator) / hook management
  (use hooks-manager).
context: fork
agent: Explore
---

# Config Migrator

## Overview

将 Claude 配置迁移到 Codex，采用 **AI-first 工作流**（四阶段）：

0. `understand`：双源系统认知（文档 + 探索）→ 建立迁移上下文
1. `scan`：Python 做详细扫描与证据收集
2. `plan`：基于认知 + 扫描结果生成补丁计划（支持 AI 决策覆盖）
3. `apply`：按计划执行，支持备份与回滚

默认保护 `~/.codex/config.toml`（configure 不同步，避免降级）。

## 核心原则

- **先理解再迁移**：不盲目对比文件差异，先建立对源系统的架构级理解
- Python 只做确定性任务：扫描、哈希、差异统计、备份、原子写入
- AI 负责高语义判断：架构映射、组件取舍、失效链接处理、模式选择
- 默认增量模式；全量模式仅显式参数触发
- Gemini 本轮不处理（`--target codex`）

## Phase 0: 系统认知（understand）

迁移前必须先理解源系统。采用**双源认知**策略：

### 源1: 系统快照文档

读取系统快照文档，快速获得全局理解：

```
~/Library/CloudStorage/OneDrive-MSFT/Note/note/L1-Thinking-Garden/agent_系统自我成长.md
```

这份文档是 Claude Code 系统的完整状态记录，包含：
- 目录结构全景（`~/.claude/` 完整树）
- 铁律体系（L0/L1/L2 三层12条）
- 技能注册表（51个技能分类、大小、依赖关系）
- Hook 系统（12个 Hook 的事件-脚本映射）
- Agent/Team 系统（通信协议、角色组合）
- MCP 服务器配置
- 工作模式（三级递进决策树）
- 核心文档体系（5文件职责）
- 最近变更历史

### 源2: 实际探索验证

文档可能滞后于实际状态。读完文档后，回答以下验证问题：

1. **skills 实际数量**是否与文档记录一致？（`ls ~/.claude/skills/ | wc -l`）
2. **hooks 实际配置**是否与文档映射一致？（读 `~/.claude/settings.json` 的 hooks 段）
3. **目标环境状态**如何？（`~/.codex/` 是否存在、已有哪些配置）
4. **有无文档未记录的新增组件**？（对比 skills 目录与 registry.json）

### 认知产出

完成双源认知后，形成迁移上下文摘要（不需要写文件，在对话中保持即可）：
- 哪些组件是核心必迁的（铁律相关、日常高频使用）
- 哪些组件可以跳过（遗留文件、平台特定配置）
- 哪些组件需要适配（Claude 特有概念在 Codex 中的映射）
- 已知的坑和注意事项（从文档"已知问题"和"最近变更"中提取）

## Claude Code vs Codex CLI 差异映射（迁移决策知识库）

> 此节是 Phase 0 认知的**先验知识补充**，在扫描前优先内化。遇到对应差异时按此表处理，无需重新分析。

### 核心平台差异

| 维度 | Claude Code | Codex CLI | 迁移策略 |
|------|------------|-----------|---------|
| **Hook 系统** | 12个 Hook 自动触发（SessionStart / PreToolUse / PostToolUse / UserPromptSubmit 等） | 无 Hook 机制 | 在 AGENTS.md §0 加入"会话启动规程"，将 SessionStart/PreToolUse 的自动行为改为显式提示 LLM 手动执行 |
| **Skill 调用** | `/skill-name` 命令展开，SessionStart Hook 自动同步 registry.json | 无 `/skill-name` 命令 | Skill 注册表说明改为"手动读取 registry.json，按描述步骤执行" |
| **Task 系统** | TaskCreate / TaskUpdate / TaskList | 原生 **TodoWrite / TodoRead** | §2 Task系统铁律改为用 TodoWrite 创建/更新；会话启动改为 TodoRead 确认任务 |
| **多 Agent** | TeamCreate / SendMessage / persistent Team | 无对等工具 | 降级为 TodoWrite 全量任务拆解 + 串行执行 + Gate 节点验证 |
| **MCP 协议** | 支持（playwright / context7 等） | 支持（与 Claude 相同） | 保持一致，无需修改 |
| **配置文件** | `~/.claude/settings.json`（含 hooks 段） | `~/.codex/config.toml`（不同 schema） | config.toml 始终受保护，不自动同步（已有 guard 机制） |

### 各差异的 AGENTS.md 处理规则

#### 1. Hook → 手动规程（最高优先级）

AGENTS.md 中**凡是依赖 Hook 的描述**，必须改写为显式手动步骤：

| 原 Hook | 原作用 | AGENTS.md 替代写法 |
|---------|--------|-------------------|
| `SessionStart` | 恢复上下文（读 docs、恢复 Task） | §0 加入"会话启动规程"4步清单（Read docs × 3 + TodoRead） |
| `PreToolUse` | 拦截 docx/xlsx/pdf 读取 | 文档处理节加警告：读取前手动判断扩展名 |
| `UserPromptSubmit` | 提交前检查 | 可选：在铁律或工作规范中加入"提交前自检"条款 |
| `PostToolUse` | 阶段性进度提醒 | 可在任务系统中加入"每个子任务完成后更新 progress.md" |

#### 2. Skill 系统 → 内嵌步骤

- 删除所有 `（SessionStart Hook 自动同步）` 表述
- `skill:systematic-debugging` / `skill:verification-before-completion` 等引用 → 改为铁律中内嵌的执行步骤描述
- Skill 注册表说明改为："每次会话手动读取 registry.json"

#### 3. Task 系统 → Todo 对齐

| Claude Code | Codex 对应 |
|-------------|-----------|
| `TaskCreate` | `TodoWrite`（创建条目，含描述和优先级） |
| `TaskUpdate` status=`in_progress` | `TodoWrite` 标为 `in_progress` |
| `TaskUpdate` status=`completed` | `TodoWrite` 标为 `completed` |
| `TaskList` | `TodoRead` |
| `docs/task-queue.md`（降级文件方案） | 废弃，用原生 Todo 替代 |

> `docs/progress.md` 保留——Todo 负责任务状态流转，progress 负责沉淀执行证据，职责分离。

#### 4. Team 模式 → 串行降级

| Claude Code Team 组合 | Codex 执行策略 |
|----------------------|----------------|
| 2 Builder + 1 Guardian | TodoWrite 按模块拆解 → 后端→前端→集成测试，每步有验收标准 |
| 调研+开发 | TodoWrite 两阶段：先研究写 findings.md，再基于结论开发 |
| 快速原型（2 Builder） | 模块串行，可跳过 Gate（接受技术债） |

### 增量迁移判断规则

扫描后，对 AGENTS.md 章节差异的处理优先级：

1. **保留差异**（Codex 刻意不同）：§0 会话启动规程、§2 Task 系统、§3 工作模式中的 Todo/串行描述
2. **应该同步**（Claude 更新了但 Codex 未跟进）：铁律内容、工具体系（非 Hook 部分）、偏好与规范
3. **不可同步**：任何含 Hook 字样的架构描述、`skill:xxx` 引用

## Phase 1: scan（详细扫描）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py scan \
  --target codex \
  --format text \
  --report /tmp/config_migrator_scan.json
```

输出：
- 文档章节差异
- skills 缺失/冗余/失效软链分析
- config guard 快照
- full mode 建议（仅建议，不自动切换）

**结合 Phase 0 认知解读扫描结果**：扫描只给出文件级差异，AI 需要结合系统认知判断每个差异的语义含义（是有意为之还是遗漏）。

## Phase 2: plan（生成补丁计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex \
  --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --report /tmp/config_migrator_plan.json
```

可选 AI 决策覆盖：

```bash
# 通过文件
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-file /tmp/config_migrator_decision.json \
  --report /tmp/config_migrator_plan.json

# 或直接传 JSON（更适合对话内决策）
python ~/.claude/skills/config-migrator/scripts/migrate.py plan \
  --target codex --mode incremental \
  --scan-report /tmp/config_migrator_scan.json \
  --decision-json '{"enable":["skills.broken.docs"]}' \
  --report /tmp/config_migrator_plan.json
```

**⚠️ 用户确认检查点**：plan 生成后，必须向用户展示计划摘要并获得确认后才能进入 apply。

## Phase 3: apply（执行计划）

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py apply \
  --target codex \
  --plan-report /tmp/config_migrator_plan.json \
  --report /tmp/config_migrator_apply.json
```

## AI 决策覆盖（decision-file）

`decision-file` 是一个可选 JSON，用于覆盖默认计划动作。

```json
{
  "enable": ["skills.broken.obsidian-skills"],
  "disable": ["skills.broken.mineru-pdf"],
  "overrides": [
    {
      "id": "skills.broken.mineru-pdf",
      "op": "relink",
      "target": "/Users/you/.claude/skills/mineru-transfer",
      "enabled": true,
      "rationale": "手动确认迁移到 mineru-transfer"
    }
  ]
}
```

## 失效软链策略

- 扫描阶段：逐条解析 root cause + 候选映射 + 置信度
- 计划阶段：高置信映射默认启用，不确定项标记 `needs_ai_review`
- 执行阶段：按最终 plan 执行 `relink` 或 `delete_link`

## 注意事项

- `config.toml` 默认仅快照，不写入
- 全量模式（`--mode full`）仅显式触发
- 增量不可行时工具只给建议，不自动切换
- 系统快照文档路径可能因用户环境不同而变化，找不到时降级为纯探索模式
