---
name: config-migrator
description: Migrates Claude Code configurations to Codex CLI and Gemini CLI. Activates when users request configuration migration, including requests like "migrate config", "sync to Codex", "sync to Gemini", "config migration", or "multi-CLI configuration". Handles compatibility differences between the three CLI tools.
context: fork
---

# Config Migrator

## Overview

将 Claude Code 的配置（CLAUDE.md、rules、skills 等）智能迁移到 OpenAI Codex CLI 和 Google Gemini CLI，处理三者之间的兼容性差异。

## 执行原则

⚠️ **分段输出原则**：使用工具输出内容时，必须分多次分段输出，避免一次性输出过大内容。

- 文件编辑：每次只修改一小部分，分多次 Edit
- Skills 复制：每次只复制 2-3 个，分批执行
- 配置生成：先写基础部分，再逐步添加

## 工作流程决策树

```
用户请求迁移配置
    │
    ├─→ Step 0: 检查目标平台已有配置 ⚠️ 必须先执行
    │       ├─ 扫描 ~/.codex/ 目录结构
    │       ├─ 扫描 ~/.gemini/ 目录结构
    │       └─ 读取已有的 AGENTS.md / GEMINI.md
    │
    ├─→ Step 1: 分析 Claude Code 配置
    │       ├─ 读取 ~/.claude/CLAUDE.md
    │       ├─ 扫描 .claude/rules/*.md
    │       └─ 识别 skills/subagents 索引
    │
    ├─→ Step 2: 询问用户迁移策略
    │       ├─ 已有配置 → 合并 or 覆盖？
    │       └─ 选择目标平台
    │
    └─→ Step 3: 执行迁移
            ├─ 合并/覆盖已有配置
            └─ 生成目标文件
```

## 配置映射关系

### 核心文件对应

| Claude Code | Codex CLI | Gemini CLI |
|-------------|-----------|------------|
| `~/.claude/CLAUDE.md` | `~/.codex/AGENTS.md` | `~/.gemini/GEMINI.md` |
| `./CLAUDE.md` | `./AGENTS.md` | `./GEMINI.md` |
| `.claude/CLAUDE.md` | `./AGENTS.md` | `.gemini/GEMINI.md` |
| `CLAUDE.local.md` | `AGENTS.override.md` | 无直接对应 |
| `.claude/rules/*.md` | 合并到 AGENTS.md | `@./rules/*.md` 导入 |
| `settings.json` | `config.toml` | `settings.json` |

### 功能兼容性

| Claude Code 功能 | Codex CLI | Gemini CLI | 迁移策略 |
|-----------------|-----------|------------|---------|
| **Skills** | ✅ 支持 | ✅ 支持 | 直接复制 SKILL.md |
| **Subagents/Agent Swarm** | ✅ Agents SDK | Extensions | 同步 Swarm 配置说明 |
| **Hooks** | ❌ 无 | ❌ 无 | 仅保留文档说明 |
| **MCP Servers** | ✅ 支持 | ✅ 支持 | 直接迁移配置 |
| **权限控制** | approval_policy | 交互确认 | 按平台特性适配 |

## Agent Swarm 功能同步

### 功能说明

Agent Swarm（子代理群）是 Claude Code 和 Codex CLI 共有的高级功能：

- **批量子代理**：可同时启动多个子代理并行执行任务
- **适用场景**：
  - 大型代码库调研
  - 多模块并行开发
  - 需要大量上下文交互的复杂问题
  - 多文件独立修改

### 平台对比

| 特性 | Claude Code | Codex CLI |
|------|-------------|-----------|
| 子代理启动 | Task tool (subagent_type) | Agents SDK |
| 并行执行 | ✅ 单消息多 Task | ✅ 多 Agent 并行 |
| 上下文共享 | 通过文件/prompt | 通过 AGENTS.md |
| 信任度评审 | agent-history.json | 手动配置 |

### 迁移策略

迁移时自动在 AGENTS.md 中添加 Agent Swarm 使用指南：
1. 子代理启动方式说明
2. 并行执行最佳实践
3. 信任度评审建议

## 迁移到 Codex CLI

### Step 0: 检查已有配置 ⚠️

```bash
# 扫描 Codex 目录结构
ls -la ~/.codex/

# 读取已有 AGENTS.md
cat ~/.codex/AGENTS.md 2>/dev/null

# 读取已有 config.toml
cat ~/.codex/config.toml 2>/dev/null
```

**如果已有配置**：询问用户选择合并或覆盖策略。

### Step 1: 分析现有配置

```bash
# 检查全局配置
cat ~/.claude/CLAUDE.md

# 检查项目配置
cat ./CLAUDE.md 2>/dev/null || cat .claude/CLAUDE.md 2>/dev/null

# 列出规则文件
ls .claude/rules/*.md 2>/dev/null
```

### Step 2: 生成 AGENTS.md

**转换规则：**
1. 直接复制通用开发规则（代码风格、命名规范等）
2. 移除 Claude 特有的 subagent/skill 索引（Codex 不支持）
3. 添加 Codex 特有配置（审批策略建议等）

**AGENTS.md 模板：**

```markdown
# Project Guidelines for Codex

## 环境信息
[从 CLAUDE.md 复制]

## 开发规范
[从 CLAUDE.md 复制通用规则]

## Agent Swarm 使用指南

### 何时使用子代理

适用场景：
- 多文件/多模块独立修改
- 代码探索、搜索、分析任务
- 大型调研需要大量上下文
- 测试执行、验证任务

### 并行执行策略

```
单任务多文件 → 拆分为多个子代理并行
多独立任务 → 每个任务一个子代理
主智能体 → 分配任务 + 审查结果 + 整合输出
```

### 信任度评审

| 信任度 | 评审方式 |
|--------|----------|
| ≥85% | 快速review |
| 70-85% | 详细review |
| <70% | 多模型验证 |

## Codex 特定配置

### 审批策略建议
- 文件修改：需要确认
- 命令执行：需要确认
- 测试运行：可自动执行
```

### Step 3: 生成 config.toml

```toml
# ~/.codex/config.toml
model = "o3"
approval_policy = "on-request"
sandbox_mode = "workspace-write"
model_reasoning_effort = "high"
```

## 迁移到 Gemini CLI

### Step 1: 生成 GEMINI.md

**转换规则：**
1. 直接复制通用开发规则
2. 将 `.claude/rules/*.md` 转为 `@import` 语法
3. Skills 索引转为 Custom Commands 说明

**GEMINI.md 模板：**

```markdown
# Project Context for Gemini

## 环境信息
[从 CLAUDE.md 复制]

## 开发规范
[从 CLAUDE.md 复制通用规则]

## 模块化规则
@./rules/coding-style.md
@./rules/workflow.md
```

### Step 2: 创建 Custom Commands

将 Skills 转换为 `.toml` 命令文件。

**位置：** `~/.gemini/commands/` 或 `.gemini/commands/`

**示例 plan.toml：**

```toml
description = "规划功能实现方案"

[prompt]
content = """
请为以下任务规划实现方案：
{args}
"""
```

### Step 3: 生成 settings.json

```json
{
  "theme": "dark",
  "context": {
    "fileName": ["GEMINI.md", "AGENTS.md"]
  }
}
```

## 快速迁移命令

```bash
# 迁移到 Codex
uv run python ~/.claude/skills/config-migrator/scripts/migrate.py --target codex

# 迁移到 Gemini
uv run python ~/.claude/skills/config-migrator/scripts/migrate.py --target gemini

# 迁移到两者
uv run python ~/.claude/skills/config-migrator/scripts/migrate.py --target all
```

## 注意事项

### 不可迁移的功能

1. **Claude Code Hooks** - Codex/Gemini 无对应机制
2. **Subagent 自动委派** - 需手动配置 MCP/Extensions
3. **Skill 自动触发** - Gemini 需显式调用 `/命令`

### 建议的目录结构

```
~/.claude/          # Claude Code（保留）
~/.codex/           # Codex CLI
    AGENTS.md
    config.toml
~/.gemini/          # Gemini CLI
    GEMINI.md
    settings.json
    commands/*.toml
```

## 参考资源

- [Claude Code Memory](https://code.claude.com/docs/en/memory)
- [Codex AGENTS.md](https://developers.openai.com/codex/guides/agents-md/)
- [Gemini GEMINI.md](https://geminicli.com/docs/cli/gemini-md/)
