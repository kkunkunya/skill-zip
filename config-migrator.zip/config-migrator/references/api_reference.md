# Config Migrator API Reference (AI-first)

## 工作流总览

```
Phase 0: understand（AI 驱动，无脚本）
  ↓ 双源认知：系统快照文档 + 实际探索
Phase 1: scan（Python 脚本）
  ↓ 文件级差异扫描
Phase 2: plan（Python 脚本 + AI 决策覆盖）
  ↓ 用户确认检查点
Phase 3: apply（Python 脚本）
```

## 脚本命令

```bash
migrate.py scan  [options]
migrate.py plan  [options]
migrate.py apply [options]
```

默认：
- target: `codex`
- mode: `incremental`
- configure 同步：禁用（保护模式）

## 系统快照文档

Phase 0 使用的系统认知源：

```
~/Library/CloudStorage/OneDrive-MSFT/Note/note/L1-Thinking-Garden/agent_系统自我成长.md
```

包含：目录结构、铁律体系、技能注册表、Hook 映射、Agent/Team 系统、MCP 配置、工作模式、最近变更。由 system-self-iterator 技能维护更新。

---

## 1) scan

### 参数

- `--target codex`
- `--project-root <path>`
- `--format text|json`
- `--report <json-file>`

### 输出关键字段

- `inventory`: 文件存在性、hash、软链状态
- `doc_diffs`: 章节增删改 + 漂移率
- `config_guard`: 关键配置快照（只读）
- `skills_diffs`: 缺失项、额外项、失效软链
- `change_list`: 供 plan 使用的最小变更清单
- `full_mode_hint`: 是否建议全量模式（仅建议）

---

## 2) plan

### 参数

- `--target codex`
- `--mode incremental|full`
- `--scan-report <scan.json>` (optional)
- `--decision-file <decision.json>` (optional)
- `--decision-json <json-string>` (optional, 优先于 decision-file)
- `--format text|json`
- `--report <plan.json>`

### 产物结构

- `actions[]`: 每条动作包含
  - `id`
  - `kind`: `docs|skill|config`
  - `op`: 如 `write_agents_incremental|relink|delete_link|skip_config_sync`
  - `enabled`
  - `requires_ai_review`
  - `confidence`
  - `rationale`
  - `evidence`
- `summary`: total/enabled/needs_ai_review

### decision-file schema

```json
{
  "enable": ["action.id"],
  "disable": ["action.id"],
  "overrides": [
    {
      "id": "action.id",
      "op": "relink",
      "target": "/abs/path",
      "enabled": true,
      "rationale": "AI decision"
    }
  ]
}
```

---

## 3) apply

### 参数

- `--target codex`
- `--plan-report <plan.json>` (recommended)
- `--decision-file <decision.json>` (only when no plan-report)
- `--decision-json <json-string>` (only when no plan-report, 优先)
- `--mode incremental|full` (only when no plan-report)
- `--format text|json`
- `--report <apply.json>`

### 执行行为

- 对启用动作按顺序执行
- `AGENTS.md` 修改前自动备份
- 写入采用临时文件 + 原子替换
- 失败触发回滚（至少恢复 AGENTS 备份）

---

## 配置保护说明

`~/.codex/config.toml` 被视为 configure 层，不做默认同步。

受保护关键键：
- `approval_policy`
- `sandbox_mode`
- `model_provider`
- `model`
- `model_reasoning_effort`
- `web_search`

原因：Claude 与 Codex configure 语义差异较大，直接迁移存在降级风险。

---

## 推荐运行序列

```bash
python ~/.claude/skills/config-migrator/scripts/migrate.py scan  --target codex --report /tmp/scan.json
python ~/.claude/skills/config-migrator/scripts/migrate.py plan  --target codex --mode incremental --scan-report /tmp/scan.json --report /tmp/plan.json
python ~/.claude/skills/config-migrator/scripts/migrate.py apply --target codex --plan-report /tmp/plan.json --report /tmp/apply.json
```
