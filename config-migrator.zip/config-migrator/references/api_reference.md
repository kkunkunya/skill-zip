# 配置映射参考文档

## 概述

本文档详细说明 Claude Code、Codex CLI、Gemini CLI 三者配置的映射关系。

## Agent Swarm 配置

### Claude Code

通过 Task tool 启动子代理：
- `subagent_type`: Explore, Plan, Bash, env-deployer, python-env-manager
- `run_in_background`: 后台运行
- 单消息多 Task 实现并行

### Codex CLI

通过 Agents SDK 启动：
- 配置在 AGENTS.md 中定义
- 支持 approval_policy 控制权限
- 并行执行无需特殊配置

## 文件位置对照

| 用途 | Claude Code | Codex CLI | Gemini CLI |
|-----|-------------|-----------|------------|
| 全局配置 | `~/.claude/CLAUDE.md` | `~/.codex/AGENTS.md` | `~/.gemini/GEMINI.md` |
| 项目配置 | `./CLAUDE.md` | `./AGENTS.md` | `./GEMINI.md` |
| 本地覆盖 | `CLAUDE.local.md` | `AGENTS.override.md` | - |
| 设置文件 | `settings.json` | `config.toml` | `settings.json` |

## Codex config.toml 选项

```toml
# 模型选择
model = "o3"

# 审批策略
# "on-request" - 每次询问
# "unless-allow-listed" - 白名单外询问
# "full-auto" - 全自动（危险）
approval_policy = "on-request"

# 沙箱模式
# "read-only" - 只读
# "workspace-write" - 工作区读写
sandbox_mode = "workspace-write"
```

## Gemini settings.json 选项

```json
{
  "theme": "dark",
  "context": {
    "fileName": ["GEMINI.md", "AGENTS.md"]
  }
}
```
