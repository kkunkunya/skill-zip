# Lab Platform Photo Reuse Contract（实验平台实拍复用合同）

## 适用场景
- 论文中的实验平台全景图
- 需要“实拍感 + 统一标注”风格
- 需要批量出图并保持一致性

## 一、固定风格块（必须冻结）

### 1) 场景合同
- 轻色木桌面（light wooden desk）
- 真实实验室拍摄视角（oblique top-down）
- 中度整洁：不假整齐、不杂乱
- 轻微手机拍摄感模糊（mild blur），但保持论文可读

### 2) 标注合同
- 仅允许一种标注样式：
  - 白色圆角框
  - 黑色中文文字
  - 黑色箭头
- 禁止混用对话泡泡、贴纸、漫画引线

### 3) 文本合同
- 纯中文
- 默认无标题
- 设备本体默认不写部件名（除非用户明确要求）

### 4) 构图合同
- 功能链路从左到右排列：
  电源 → 信号源 → 逆变/发射 → 耦合线圈 → 接收/整流 → 负载

## 二、负面约束（必须写入提示词）
- no mixed annotation styles
- no speech bubbles
- no sticky notes
- do not print component names on device surfaces unless explicitly requested
- no duplicated labels
- no overlapping elements

## 三、可复用英文提示词骨架

```text
A realistic smartphone photo of a lab experiment platform on a light wooden desk,
oblique top-down angle, publication-usable clarity.

Scene realism:
- moderately tidy and realistic (not perfectly neat, not messy)
- extra irrelevant tools removed
- mild natural camera softness (slight blur)

Layout:
- components arranged in clear functional chain from source to load

Annotation style (STRICT, one style only):
- white rounded rectangular callout labels
- black Chinese text and black arrows
- no speech bubbles, no mixed annotation styles

Text rules:
- Chinese labels only
- no title/header
- do not print component names on device surfaces unless explicitly requested

Quality:
- realistic lighting/shadows
- no overlapping elements
- no duplicated labels
```

## 四、迭代策略（防扩散）
- 一次迭代只改一个问题
- 结构问题优先重生成，不做后处理补丁叠加
- 批量任务先冻结“基准图”，其余仅替换对象内容

## 五、5秒验收清单
- [ ] 纯中文、无标题
- [ ] 标注样式单一
- [ ] 设备本体无重复部件名
- [ ] 轻微真实感模糊但可读
- [ ] 构图和同批图一致
