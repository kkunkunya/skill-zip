#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Image Generator - 通过 tu-zi.com API 生成图片
Input: prompt, size, input_reference (可选)
Output: 生成的图片文件路径
Pos: ~/.claude/skills/image-generator/scripts/
"""

import os
import sys
import time
import json
import argparse
import requests
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv

# 加载环境变量
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

# 配置
API_KEY = os.getenv("GEMINI_API_KEY")
BASE_URL = os.getenv("GEMINI_BASE_URL", "https://api.tu-zi.com")
MODEL = os.getenv("GEMINI_MODEL", "gemini-3-pro-image-preview-async")

# 默认输出目录
DEFAULT_OUTPUT_DIR = Path.home() / "Downloads" / "ai-images"


def generate_image(prompt: str, size: str = "1:1", input_reference: str = None, output: str = None) -> str:
    """
    调用 API 生成图片

    Args:
        prompt: 图片描述
        size: 图片比例 (1:1, 16:9, 9:16, 4:3, 3:4)
        input_reference: 参考图片 URL (可选)
        output: 输出文件路径 (可选)

    Returns:
        生成的图片文件路径
    """
    if not API_KEY:
        print("错误: 未配置 GEMINI_API_KEY，请检查 .env 文件")
        sys.exit(1)

    # 1. 发起生成请求
    print(f"📤 正在发起生成请求...")
    print(f"   Prompt: {prompt}")
    print(f"   Size: {size}")
    print(f"   Model: {MODEL}")
    if input_reference:
        print(f"   Reference: {input_reference}")

    headers = {
        "Authorization": f"Bearer {API_KEY}"
    }

    form_data = {
        "model": MODEL,
        "prompt": prompt,
        "size": size
    }

    if input_reference:
        form_data["input_reference"] = input_reference

    try:
        response = requests.post(
            f"{BASE_URL}/v1/videos",
            headers=headers,
            data=form_data,
            timeout=30
        )
        response.raise_for_status()
        result = response.json()
    except requests.exceptions.RequestException as e:
        print(f"❌ API 请求失败: {e}")
        sys.exit(1)

    # 获取任务 ID
    task_id = result.get("id") or result.get("task_id")
    if not task_id:
        print(f"❌ 未获取到任务 ID，响应: {result}")
        sys.exit(1)

    print(f"✅ 任务已创建，ID: {task_id}")

    # 2. 轮询查询结果
    print(f"⏳ 等待生成完成...")

    max_attempts = 120  # 最多等待 10 分钟 (120 * 5秒)
    poll_interval = 5   # 每 5 秒查询一次

    for attempt in range(max_attempts):
        time.sleep(poll_interval)

        try:
            status_response = requests.get(
                f"{BASE_URL}/v1/videos/{task_id}",
                headers=headers,
                timeout=30
            )
            status_response.raise_for_status()
            status_result = status_response.json()
        except requests.exceptions.RequestException as e:
            print(f"⚠️ 查询状态失败 (尝试 {attempt + 1}): {e}")
            continue

        status = status_result.get("status", "").lower()

        if status in ["completed", "succeeded", "success", "done"]:
            print(f"✅ 生成完成!")

            # 获取图片 URL
            image_url = (
                status_result.get("output", {}).get("image_url") or
                status_result.get("image_url") or
                status_result.get("result", {}).get("image_url") or
                status_result.get("data", {}).get("image_url") or
                status_result.get("url")
            )

            # 如果是数组，取第一个
            if isinstance(image_url, list) and image_url:
                image_url = image_url[0]

            if not image_url:
                # 尝试打印完整响应以便调试
                print(f"⚠️ 无法找到图片 URL，完整响应:")
                print(json.dumps(status_result, indent=2, ensure_ascii=False))
                sys.exit(1)

            # 3. 下载图片
            return download_image(image_url, output, prompt)

        elif status in ["failed", "error"]:
            error_msg = status_result.get("error") or status_result.get("message") or "未知错误"
            print(f"❌ 生成失败: {error_msg}")
            sys.exit(1)

        else:
            # 显示进度
            progress = status_result.get("progress", "")
            if progress:
                print(f"   进度: {progress}%", end="\r")
            else:
                print(f"   状态: {status or 'processing'} (等待 {(attempt + 1) * poll_interval}s)", end="\r")

    print(f"\n❌ 超时: 生成任务超过 {max_attempts * poll_interval / 60} 分钟未完成")
    sys.exit(1)


def download_image(url: str, output: str, prompt: str) -> str:
    """下载图片到本地"""
    print(f"📥 正在下载图片...")

    # 确定输出路径
    if output:
        output_path = Path(output)
    else:
        DEFAULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # 从 prompt 提取简短文件名
        safe_name = "".join(c if c.isalnum() or c in " -_" else "" for c in prompt[:30]).strip()
        safe_name = safe_name.replace(" ", "_") or "image"
        output_path = DEFAULT_OUTPUT_DIR / f"{timestamp}_{safe_name}.png"

    # 确保父目录存在
    output_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        response = requests.get(url, timeout=60)
        response.raise_for_status()

        with open(output_path, "wb") as f:
            f.write(response.content)

        print(f"✅ 图片已保存: {output_path}")
        return str(output_path)

    except requests.exceptions.RequestException as e:
        print(f"❌ 下载失败: {e}")
        print(f"   图片 URL: {url}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="使用 Gemini API 生成图片")
    parser.add_argument("prompt", help="图片描述（英文效果更好）")
    parser.add_argument("--size", "-s", default="1:1",
                       choices=["1:1", "16:9", "9:16", "4:3", "3:4"],
                       help="图片比例 (默认: 1:1)")
    parser.add_argument("--ratio", "-r", dest="size",
                       help="图片比例 (--size 的别名)")
    parser.add_argument("--reference", "--ref", "-i", dest="input_reference",
                       help="参考图片 URL")
    parser.add_argument("--output", "-o", help="输出文件路径")

    args = parser.parse_args()

    # 调用生成
    result_path = generate_image(
        prompt=args.prompt,
        size=args.size,
        input_reference=args.input_reference,
        output=args.output
    )

    print(f"\n🎉 完成! 图片路径: {result_path}")


if __name__ == "__main__":
    main()
