---
name: image-generator
description: Generates AI images using Gemini API with requirement confirmation workflow. Activates when users request image generation, including requests like "generate an image", "create a picture", "draw something", or "AI image generation". Requires confirming purpose, content, style, and aspect ratio before generation to avoid wasting API calls.
context: fork
---

# Image Generator

## 核心原则

**生图前必须确认需求，避免浪费 API 调用。**

## 工作流程

### 1. 需求收集（必须）

用户说"生成图片"时，先收集以下信息：

| 维度 | 问题 | 示例 |
|-----|------|------|
| **用途** | 这张图用来做什么？ | PPT封面、文章配图、社交媒体、壁纸 |
| **内容** | 图里要有什么？ | 一只猫、城市天际线、抽象几何 |
| **风格** | 希望什么风格？ | 写实、扁平、科技感、水彩、简约 |
| **比例** | 宽高比偏好？ | 16:9(横屏)、1:1(方形)、9:16(竖屏) |

### 2. 需求确认（必须）

收集后，用以下格式总结并请求确认：

```
📋 生图需求确认：

• 用途：[用途描述]
• 内容：[主体内容]
• 风格：[风格描述]
• 比例：[宽高比]

确认后开始生成？
```

### 3. 生成图片

用户确认后，调用脚本：

```bash
python ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size [比例] \
  --output [输出路径]
```

**带参考图片生成**：
```bash
python ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size 1:1 \
  --reference "https://example.com/ref.jpg"
```

**提示词优化原则**：
- 转换为英文（Gemini 对英文理解更好）
- 具体描述优于抽象描述
- 添加风格关键词（cinematic, minimalist, vibrant, etc.）
- 添加质量关键词（high quality, detailed, professional）

## 参数

| 参数 | 说明 |
|-----|------|
| `prompt` | 图片描述（英文效果更好） |
| `--size`, `-s` | 1:1 / 16:9 / 9:16 / 4:3 / 3:4 |
| `--ratio`, `-r` | 同 --size（别名） |
| `--reference`, `-i` | 参考图片 URL（可选） |
| `--output`, `-o` | 输出路径（默认 ~/Downloads/ai-images/） |



## 环境配置

复用 `~/.claude/skills/.env`，：