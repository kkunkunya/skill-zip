---
name: image-generator
description: >
  Generates AI images using Gemini API with requirement confirmation workflow.
  Activates when users request image generation, including requests like "generate an image",
  "create a picture", "draw something", or "AI image generation".
  Supports academic diagram mode for publication-quality scientific figures.
  Requires confirming purpose, content, style, and aspect ratio before generation to avoid wasting API calls.
  NOT for：创意设计图（产品图/Logo/海报/品牌→用meigen-design）/
  文章配图（用baoyu-article-illustrator）/小红书图片（用baoyu-xhs-images）/
  信息图（用baoyu-infographic）/封面图（用baoyu-cover-image）/
  通用多源图像生成（用baoyu-image-gen）。
  本技能专注学术科研图像（IEEE图表/MATLAB仿真/实验平台/科研海报），其他图像需求请用对应专用技能。
context: fork
---

# Image Generator

> **本 skill 专注学术科研图像**（IEEE图表/MATLAB仿真/实验平台实拍）。
> 创意设计类需求（产品图/Logo/海报/品牌）请使用 `meigen-design` skill（基于 MeiGen MCP，提供 1300+ prompt 库）。

## 核心原则

**生图前必须确认需求，避免浪费 API 调用。**

---

## 通用模式

### 0. 读取经验（自动）

读取 `references/prompt-experience.md`，了解历史积累的有效模式和失败教训，指导本次执行。
- 哪些 prompt 模式效果好
- 不同场景（学术图表/MATLAB/实拍）的 API 特点
- 过去踩过的坑（如中文标注乱码、一次改太多）

### 1. 需求收集（必须）

用户说"生成图片"时，先收集以下信息：

| 维度 | 问题 | 示例 |
|-----|------|------|
| **用途** | 这张图用来做什么？ | PPT封面、文章配图、社交媒体、壁纸 |
| **内容** | 图里要有什么？ | 一只猫、城市天际线、抽象几何 |
| **风格** | 希望什么风格？ | 写实、扁平、科技感、水彩、简约 |
| **比例** | 宽高比偏好？ | 16:9(横屏)、1:1(方形)、9:16(竖屏) |

### 2. 需求确认（必须）

收集后，用以下格式总结并请求确认：

```
📋 生图需求确认：

• 用途：[用途描述]
• 内容：[主体内容]
• 风格：[风格描述]
• 比例：[宽高比]

确认后开始生成？
```

### 3. 生成图片

用户确认后，调用脚本：

```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size [比例] \
  --output [输出路径]
```

**带参考图片生成**：
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size 1:1 \
  --reference "https://example.com/ref.jpg"
```

**提示词优化原则**：
- 转换为英文（Gemini 对英文理解更好）
- 具体描述优于抽象描述
- 添加风格关键词（cinematic, minimalist, vibrant, etc.）
- 添加质量关键词（high quality, detailed, professional）

---

## 学术图表模式 ⭐

### 触发词

- "学术图表" / "论文配图" / "科研图表" / "academic diagram"
- "流程图" / "架构图" / "系统图"
- "IEEE图" / "期刊配图"

### 生成前必问（每次都问）

使用 AskUserQuestion 工具询问：

| 问题 | 选项 |
|------|------|
| **语言** | ○ 纯英文 (English only)<br>○ 纯中文 (公式/缩写用英文) |
| **标题** | ○ 不需要标题（默认）<br>○ 需要标题 → 请输入 |
| **比例** | ○ 16:9（横屏流程图）<br>○ 4:3（标准）<br>○ 1:1（方形） |

### 强制规则

#### 1. 标题规则
| 规则 | 说明 |
|------|------|
| **默认无标题** | 图片顶部不生成任何标题/header |
| **用户需要时** | 明确说明后才添加 |

#### 2. 语言规则
| 模式 | 规则 |
|------|------|
| **纯英文** | 所有文字使用英文 |
| **纯中文** | 默认中文，以下例外可用英文：<br>• 数学公式/变量（R, t, α, β, γ）<br>• 专有缩写（MAPPO, PPO, CNN, GAE）<br>• 张量维度（[N, 85], [B, T, D]） |

#### 3. 字体规范
| 类型 | 字体 |
|------|------|
| **英文** | Times New Roman |
| **中文** | 黑体 (SimHei / Heiti) |
| **公式** | Computer Modern / LaTeX 风格 |

#### 4. 渲染质量规则（核心）
| 要求 | 描述 |
|------|------|
| **清晰锐利** | 边缘无模糊，线条锐利 |
| **矢量质感** | 模拟 Visio/Draw.io/Illustrator 手绘质感 |
| **高对比度** | 文字与背景对比度高 |
| **专业图标** | 专业科研风格图标，非卡通化 |
| **均匀线宽** | 边框 2pt，箭头 1.5pt，一致 |
| **对齐工整** | 元素对齐，间距均匀 |
| **无装饰** | 无阴影、无渐变（除非必要） |
| **打印级** | 放大后仍清晰，出版级质量 |

### 学术图表提示词模板

```
[用户内容描述]

=== MANDATORY ACADEMIC RULES ===
1. NO TITLE: Do not add any title, header, or caption at the top of the image
2. LANGUAGE: [English only / Chinese only, use English for formulas, abbreviations, tensor dimensions]
3. FONTS: Times New Roman (English), SimHei/Heiti (Chinese), Computer Modern (math formulas)
4. RENDER QUALITY - CRITICAL:
   - Crisp sharp edges, vector-style rendering quality
   - High contrast between text and background
   - Professional technical icons, NOT cartoonish or cute
   - Consistent line weights: 2pt for boxes/borders, 1.5pt for arrows
   - Precise alignment, uniform spacing between elements
   - No decorative shadows, no unnecessary gradients
   - Publication-ready print quality
   - Must look like hand-drawn in Visio, Draw.io, OmniGraffle, or Adobe Illustrator
5. STYLE: Clean academic IEEE/Springer/Nature publication quality
6. COLOR: Use professional color palette (Okabe-Ito colorblind-friendly recommended)
```

### 学术图表生成命令

```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[学术图表提示词]" \
  --size 16:9 \
  --output [项目路径]/figures/[图表名].png
```

### 质量标准

生成的图表应达到以下软件的手绘质感：
- Microsoft Visio
- Draw.io / diagrams.net
- OmniGraffle
- Adobe Illustrator
- Lucidchart

---

## MATLAB仿真图模式（论文波形/曲线）⭐

### 触发词

- "MATLAB生图" / "MATLAB截图" / "仿真波形图"
- "统一工具栏" / "figure1~figureN" / "批量统一风格"
- "实验结果图" / "功率波形" / "负载阶跃" / "效率曲线"

### 生成前必问（必须）

| 问题 | 选项 |
|------|------|
| **UI模式** | ○ MATLAB窗口风格（标题栏+工具栏）<br>○ 仅纯图（无窗口UI） |
| **标题命名** | ○ `figure1~figureN`（默认批量）<br>○ 自定义标题文本 |
| **工具栏规则** | ○ 单行图标工具栏（推荐）<br>○ 不显示工具栏 |
| **比例** | ○ 4:3（默认）<br>○ 16:9（宽图） |

### 强制规则（MATLAB模式）

#### 1) UI结构规则（防乱码/防重叠）

- **只保留一行图标工具栏**（位于标题栏下方）
- **禁止菜单文字栏**（如：文件/编辑/查看/插入/工具/运行/帮助），避免乱码
- 禁止重复工具栏、禁止工具栏与图区重叠
- 图区必须从工具栏下方开始，保留清晰上边距
- 坐标轴、标题、图例、注释不得被裁切

#### 2) 批量一致性规则（多图必须统一）

- 同一批图必须统一：窗口样式、分辨率、字体、网格、线宽、配色
- 标题栏按约定统一命名：`figure1`、`figure2`、…（或用户指定格式）
- 仅允许替换“曲线内容”，其余UI与视觉风格不变

#### 3) 失败重试规则

- 若出现乱码、重叠、重复工具栏、标题错位：**删除后重生成**
- 不建议通过图像叠加打补丁修复结构错误（容易引入新重叠）
- 批量任务建议逐张验证，避免错误样式扩散

### MATLAB统一提示词骨架（推荐）

```text
MATLAB R2025a figure window screenshot style, Chinese plot labels.

STRICT UI AND LAYOUT:
- title bar text exactly "__FIGURE_NAME__"
- exactly one icon toolbar row under title bar
- no menu text row (no 文件/编辑/查看/插入/工具/运行/帮助)
- no duplicated toolbar, no overlapping elements
- chart area starts clearly below toolbar with visible top margin
- all axes/labels/annotations fully visible, not clipped

VISUAL STYLE:
- white background, light gray grid
- SimHei for Chinese text
- line width around 2
- publication-ready clean look

PLOT CONTENT:
__PLOT_SPEC__
```

### MATLAB批量生成命令模板

```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[MATLAB统一提示词，含__FIGURE_NAME__与__PLOT_SPEC__]" \
  --size 4:3 \
  --output [项目路径]/figures/[文件名].png
```

### MATLAB场景建议

- **功率时域图（有/无通信）**：用同一坐标范围与注释风格，便于对照
- **负载阶跃响应图**：固定参考线样式（例如 80W 虚线）和注释样式
- **效率曲线图**：统一 marker/线型/图例布局，突出温度或工况对比

---

## 实验平台实拍模式（论文实验台照片）⭐

> 复用参考模板：`references/lab-platform-photo-reuse.md`

### 触发词

- "实验平台全景" / "实验台照片" / "平台实拍"
- "统一标注风格" / "木桌视角" / "轻微模糊"
- "负载不要印在设备上" / "中文标注统一"

### 生成前必问（必须）

| 问题 | 选项 |
|------|------|
| **标注样式** | ○ 白色圆角框+黑字+黑箭头（推荐）<br>○ 其他（需明确） |
| **真实感等级** | ○ 中度整洁（推荐）<br>○ 更整洁<br>○ 更真实偏杂乱 |
| **清晰度** | ○ 轻微手机拍摄感（推荐）<br>○ 高清锐利 |
| **语言** | ○ 纯中文（默认）<br>○ 纯英文 |

### 强制规则（实拍模式）

#### 1) 单一标注风格（防混搭）

- 一张图中**只允许一种标注样式**
- 推荐：白色圆角标注框 + 黑字 + 黑箭头
- 禁止同时出现对话气泡、贴纸、手写框等第二套样式

#### 2) 设备文字规则（防重复信息）

- 除非用户明确要求，**设备本体不印部件名**（例如负载箱面板不写“负载”）
- 部件说明统一通过外部 callout 完成，避免“设备字样 + 标注框”重复

#### 3) 场景真实感规则

- 构图应接近真实实验室拍摄：不假整齐、不脏乱
- 常见逻辑：拍摄前会移走多余器件，但保留必要连线与轻微自然痕迹
- 允许轻微手机拍摄感模糊（mild blur），但必须保证论文可读

#### 4) 一致性与修复策略

- 批量图先锁定一张“风格基准图”，其余图复用同一风格块
- 若出现风格漂移或元素重叠：优先重生成，不建议图像补丁式叠加修复
- 每次迭代只改一个问题（如“仅改标注”或“仅改本体文字”）

### 实拍模式统一提示词骨架（推荐）

```text
A realistic smartphone photo of a lab experiment platform on a light wooden desk,
oblique top-down angle, publication-usable clarity.

Scene realism:
- moderately tidy and realistic (not perfectly neat, not messy)
- extra irrelevant tools removed
- mild natural camera softness (slight blur)

Layout:
- components arranged in clear functional chain from source to load

Annotation style (STRICT, one style only):
- white rounded rectangular callout labels
- black Chinese text and black arrows
- no speech bubbles, no mixed annotation styles

Text rules:
- Chinese labels only
- no title/header
- do not print component names on device surfaces unless explicitly requested

Quality:
- realistic lighting/shadows
- no overlapping elements
- no duplicated labels
```

### 实拍图快速验收（5秒）

- 纯中文、无标题
- 标注样式单一
- 设备本体无重复部件名
- 轻微真实感模糊但可读
- 构图与同批图风格一致

---

## 参数

| 参数 | 说明 |
|-----|------|
| `prompt` | 图片描述（英文效果更好） |
| `--size`, `-s` | 1:1 / 16:9 / 9:16 / 4:3 / 3:4 |
| `--ratio`, `-r` | 同 --size（别名） |
| `--reference`, `-i` | 参考图片 URL（可选） |
| `--output`, `-o` | 输出路径（默认 ~/Downloads/ai-images/） |

---

## 环境配置

使用 `~/.claude/skills/image-generator/.env`：

```env
GEMINI_API_KEY=sk-xxx
GEMINI_BASE_URL=https://api.tu-zi.com
GEMINI_MODEL=gemini-3-pro-image-preview-4k
GEMINI_ENDPOINT_TYPE=images
```

---

## 示例

### 通用图片生成
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "A futuristic city skyline at sunset, cyberpunk style, neon lights" \
  --size 16:9 \
  --output ~/Downloads/city.png
```

### 4. 更新经验（自动）

图片生成完成后（无论成功或需要迭代），更新 `references/prompt-experience.md`：
- 新发现的有效模式 → 更新"有效模式"（替换弱的，保留强的）
- 遇到的失败 → 更新"失败教训"（同类只保留最典型的）
- 未验证的想法 → 记入"待验证假设"
- 更新原则：精炼而非堆砌，文档不超过 150 行

### 学术图表生成
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "Create a professional flowchart showing 3-layer architecture: Environment Layer (blue), Decision Layer (green), Learning Layer (purple). Show boxes with labels: Observation, Action Selection, State Machine, Reward Calculation, Experience Store, PPO Update. Connect with arrows showing data flow with tensor dimensions [N, 85], [N, 3]. NO TITLE at top. Use Times New Roman font. Crisp vector-style rendering like Visio or Draw.io. Professional technical icons, not cartoonish. Consistent 2pt line weights. Publication-ready IEEE quality." \
  --size 16:9 \
  --output ./figures/architecture.png
```
