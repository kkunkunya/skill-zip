---
name: image-generator
description: Generates AI images using Gemini API with requirement confirmation workflow. Activates when users request image generation, including requests like "generate an image", "create a picture", "draw something", or "AI image generation". Supports academic diagram mode for publication-quality scientific figures. Requires confirming purpose, content, style, and aspect ratio before generation to avoid wasting API calls.
context: fork
---

# Image Generator

## 核心原则

**生图前必须确认需求，避免浪费 API 调用。**

---

## 通用模式

### 1. 需求收集（必须）

用户说"生成图片"时，先收集以下信息：

| 维度 | 问题 | 示例 |
|-----|------|------|
| **用途** | 这张图用来做什么？ | PPT封面、文章配图、社交媒体、壁纸 |
| **内容** | 图里要有什么？ | 一只猫、城市天际线、抽象几何 |
| **风格** | 希望什么风格？ | 写实、扁平、科技感、水彩、简约 |
| **比例** | 宽高比偏好？ | 16:9(横屏)、1:1(方形)、9:16(竖屏) |

### 2. 需求确认（必须）

收集后，用以下格式总结并请求确认：

```
📋 生图需求确认：

• 用途：[用途描述]
• 内容：[主体内容]
• 风格：[风格描述]
• 比例：[宽高比]

确认后开始生成？
```

### 3. 生成图片

用户确认后，调用脚本：

```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size [比例] \
  --output [输出路径]
```

**带参考图片生成**：
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[英文提示词]" \
  --size 1:1 \
  --reference "https://example.com/ref.jpg"
```

**提示词优化原则**：
- 转换为英文（Gemini 对英文理解更好）
- 具体描述优于抽象描述
- 添加风格关键词（cinematic, minimalist, vibrant, etc.）
- 添加质量关键词（high quality, detailed, professional）

---

## 学术图表模式 ⭐

### 触发词

- "学术图表" / "论文配图" / "科研图表" / "academic diagram"
- "流程图" / "架构图" / "系统图"
- "IEEE图" / "期刊配图"

### 生成前必问（每次都问）

使用 AskUserQuestion 工具询问：

| 问题 | 选项 |
|------|------|
| **语言** | ○ 纯英文 (English only)<br>○ 纯中文 (公式/缩写用英文) |
| **标题** | ○ 不需要标题（默认）<br>○ 需要标题 → 请输入 |
| **比例** | ○ 16:9（横屏流程图）<br>○ 4:3（标准）<br>○ 1:1（方形） |

### 强制规则

#### 1. 标题规则
| 规则 | 说明 |
|------|------|
| **默认无标题** | 图片顶部不生成任何标题/header |
| **用户需要时** | 明确说明后才添加 |

#### 2. 语言规则
| 模式 | 规则 |
|------|------|
| **纯英文** | 所有文字使用英文 |
| **纯中文** | 默认中文，以下例外可用英文：<br>• 数学公式/变量（R, t, α, β, γ）<br>• 专有缩写（MAPPO, PPO, CNN, GAE）<br>• 张量维度（[N, 85], [B, T, D]） |

#### 3. 字体规范
| 类型 | 字体 |
|------|------|
| **英文** | Times New Roman |
| **中文** | 黑体 (SimHei / Heiti) |
| **公式** | Computer Modern / LaTeX 风格 |

#### 4. 渲染质量规则（核心）
| 要求 | 描述 |
|------|------|
| **清晰锐利** | 边缘无模糊，线条锐利 |
| **矢量质感** | 模拟 Visio/Draw.io/Illustrator 手绘质感 |
| **高对比度** | 文字与背景对比度高 |
| **专业图标** | 专业科研风格图标，非卡通化 |
| **均匀线宽** | 边框 2pt，箭头 1.5pt，一致 |
| **对齐工整** | 元素对齐，间距均匀 |
| **无装饰** | 无阴影、无渐变（除非必要） |
| **打印级** | 放大后仍清晰，出版级质量 |

### 学术图表提示词模板

```
[用户内容描述]

=== MANDATORY ACADEMIC RULES ===
1. NO TITLE: Do not add any title, header, or caption at the top of the image
2. LANGUAGE: [English only / Chinese only, use English for formulas, abbreviations, tensor dimensions]
3. FONTS: Times New Roman (English), SimHei/Heiti (Chinese), Computer Modern (math formulas)
4. RENDER QUALITY - CRITICAL:
   - Crisp sharp edges, vector-style rendering quality
   - High contrast between text and background
   - Professional technical icons, NOT cartoonish or cute
   - Consistent line weights: 2pt for boxes/borders, 1.5pt for arrows
   - Precise alignment, uniform spacing between elements
   - No decorative shadows, no unnecessary gradients
   - Publication-ready print quality
   - Must look like hand-drawn in Visio, Draw.io, OmniGraffle, or Adobe Illustrator
5. STYLE: Clean academic IEEE/Springer/Nature publication quality
6. COLOR: Use professional color palette (Okabe-Ito colorblind-friendly recommended)
```

### 学术图表生成命令

```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "[学术图表提示词]" \
  --size 16:9 \
  --output [项目路径]/figures/[图表名].png
```

### 质量标准

生成的图表应达到以下软件的手绘质感：
- Microsoft Visio
- Draw.io / diagrams.net
- OmniGraffle
- Adobe Illustrator
- Lucidchart

---

## 参数

| 参数 | 说明 |
|-----|------|
| `prompt` | 图片描述（英文效果更好） |
| `--size`, `-s` | 1:1 / 16:9 / 9:16 / 4:3 / 3:4 |
| `--ratio`, `-r` | 同 --size（别名） |
| `--reference`, `-i` | 参考图片 URL（可选） |
| `--output`, `-o` | 输出路径（默认 ~/Downloads/ai-images/） |

---

## 环境配置

使用 `~/.claude/skills/image-generator/.env`：

```env
GEMINI_API_KEY=sk-xxx
GEMINI_BASE_URL=https://api.tu-zi.com
GEMINI_MODEL=gemini-3-pro-image-preview-4k
GEMINI_ENDPOINT_TYPE=images
```

---

## 示例

### 通用图片生成
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "A futuristic city skyline at sunset, cyberpunk style, neon lights" \
  --size 16:9 \
  --output ~/Downloads/city.png
```

### 学术图表生成
```bash
python3 ~/.claude/skills/image-generator/scripts/generate_image.py \
  "Create a professional flowchart showing 3-layer architecture: Environment Layer (blue), Decision Layer (green), Learning Layer (purple). Show boxes with labels: Observation, Action Selection, State Machine, Reward Calculation, Experience Store, PPO Update. Connect with arrows showing data flow with tensor dimensions [N, 85], [N, 3]. NO TITLE at top. Use Times New Roman font. Crisp vector-style rendering like Visio or Draw.io. Professional technical icons, not cartoonish. Consistent 2pt line weights. Publication-ready IEEE quality." \
  --size 16:9 \
  --output ./figures/architecture.png
```
