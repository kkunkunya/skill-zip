---
name: best-practices-lookup
description: 方案设计前自动查询相关最佳实践，保存到项目 docs/best-practices/。触发词："查找最佳实践"、"best practices"、"最佳实践"、"设计模式"、"行业标准"。在 req-project-dev-draft 阶段2自动触发。
context: fork
---

# 最佳实践查询技能

## 核心理念

- **有据可循**：方案设计前查询行业最佳实践，避免重复踩坑
- **动态收集**：不预先收集，遇到新技术栈时自动搜索并积累
- **项目级存储**：最佳实践保存在项目 `docs/best-practices/`，与项目绑定

## 触发时机

1. **自动触发**：req-project-dev-draft 阶段2（方案调研）
2. **手动触发**：用户说"查找最佳实践"、"best practices"

## 工作目录

```
[项目目录]/docs/best-practices/
├── INDEX.md             # 本项目参考的最佳实践索引
└── [domain]/            # 按领域组织
    ├── principles.md    # 核心原则
    ├── patterns.md      # 常用模式
    ├── anti-patterns.md # 需要避免的做法
    └── checklist.md     # 验证检查清单
```

## 执行流程

### 1. 识别技术关键词

从期望和交付物中提取技术栈关键词：
- 编程语言：Python, TypeScript, Go, Rust...
- 框架：FastAPI, React, Vue, Django...
- 领域：API设计, 数据库, 认证, 缓存...

### 2. 检查本地缓存

```bash
# 检查项目是否已有相关最佳实践
ls docs/best-practices/[domain]/
```

### 3. 动态收集（如果未命中）

**来源优先级**：
1. 官方文档（PEP、RFC、官方指南）
2. 权威书籍（经典技术书籍）
3. 社区最佳实践（GitHub trending、技术博客）
4. 实战经验（项目中验证过的做法）

**收集流程**：

```bash
# Step 1: Firecrawl 搜索
firecrawl search "[domain] best practices 2025" --limit 10 -o .firecrawl/bp-[domain].json

# Step 2: 提取关键信息（AI 处理）
# - 核心原则
# - 常用模式
# - 反模式
# - 检查清单

# Step 3: 保存到项目目录
mkdir -p docs/best-practices/[domain]/
# 写入 principles.md, patterns.md, anti-patterns.md, checklist.md

# Step 4: 更新索引
# 更新 docs/best-practices/INDEX.md
```

### 4. 深度研究（可选）

**触发条件**：
- 技术领域不熟悉
- 用户说"深入研究最佳实践"
- 发现多个竞争方案

**使用 NotebookLM**：
```bash
notebooklm create "Best Practices: [Domain]"
notebooklm source add [top_urls]
notebooklm ask "What are the core principles?"
notebooklm ask "What are common anti-patterns?"
notebooklm ask "What checklist should be followed?"
```

## 输出格式

### INDEX.md 模板

```markdown
# 最佳实践索引

## 本项目参考的最佳实践

| 领域 | 文件 | 更新时间 | 来源 |
|------|------|---------|------|
| [domain] | [domain]/principles.md | YYYY-MM-DD | [来源列表] |

## 快速参考

### [Domain 1]
- 核心原则：[1-2句总结]
- 关键检查项：[3-5个要点]

### [Domain 2]
...
```

### principles.md 模板

```markdown
# [Domain] 核心原则

## 来源
- [来源1](url)
- [来源2](url)

## 核心原则

### 1. [原则名称]
**描述**：[原则描述]
**原因**：[为什么重要]
**示例**：[代码或场景示例]

### 2. [原则名称]
...

## 参考资料
- [官方文档](url)
- [推荐书籍](书名)
```

### checklist.md 模板

```markdown
# [Domain] 检查清单

## 设计阶段
- [ ] [检查项1]
- [ ] [检查项2]

## 实现阶段
- [ ] [检查项1]
- [ ] [检查项2]

## 代码审查
- [ ] [检查项1]
- [ ] [检查项2]

## 部署前
- [ ] [检查项1]
- [ ] [检查项2]
```

## 缓存策略

| 场景 | 行为 |
|------|------|
| 首次查询 | 搜索 + 整理 + 保存 |
| 后续查询 | 直接读取本地文件 |
| 3个月后 | 提示"最佳实践可能已过时，是否更新？" |

## 与 req-project-dev-draft 集成

在阶段2（方案调研）中：

```
阶段2: 方案调研
├── 2a: 快速扫描 (WebSearch)
├── 2b: 深度研究 (NotebookLM) [可选]
└── 2c: 最佳实践查询 [新增]
    ├── 提取技术关键词
    ├── 检查 docs/best-practices/INDEX.md
    ├── 未命中 → 触发动态收集
    ├── 读取 principles.md 和 checklist.md
    └── 融入方案设计
```

## 使用示例

### 示例1：Python API 项目

```
用户：开始一个 FastAPI 项目

AI 执行：
1. 识别关键词：Python, FastAPI, API设计
2. 检查 docs/best-practices/python-api/
3. 未命中 → 搜索 "FastAPI best practices 2025"
4. 整理并保存到 docs/best-practices/python-api/
5. 在方案设计中引用最佳实践
```

### 示例2：前端项目

```
用户：开始一个 React 项目

AI 执行：
1. 识别关键词：React, TypeScript, 前端
2. 检查 docs/best-practices/react/
3. 命中 → 直接读取
4. 在方案设计中引用最佳实践
```

## 注意事项

1. **不要过度收集**：只收集与当前项目相关的最佳实践
2. **保持简洁**：每个领域的最佳实践控制在 1-2 页
3. **注明来源**：所有最佳实践必须注明来源
4. **定期更新**：技术发展快，3个月后提示更新
5. **项目级存储**：最佳实践跟随项目，不是全局配置
