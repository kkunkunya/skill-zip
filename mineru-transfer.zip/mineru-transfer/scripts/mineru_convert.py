#!/usr/bin/env python3
"""
MinerU API 文档转换脚本
支持: PDF, DOCX, PPT, 图片, HTML → Markdown

用法:
    # 本地文件（自动上传）
    python mineru_convert.py document.pdf
    python mineru_convert.py presentation.pptx

    # URL 文件
    python mineru_convert.py https://example.com/doc.pdf

    # HTML 文件
    python mineru_convert.py page.html --html
    python mineru_convert.py https://example.com --html

    # 指定输出目录
    python mineru_convert.py document.pdf -o ./output
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import requests

# API 配置
API_BASE = "https://mineru.net/api/v4"
API_TOKEN = os.environ.get(
    "MINERU_API_TOKEN",
    "eyJ0eXBlIjoiSldUIiwiYWxnIjoiSFM1MTIifQ.eyJqdGkiOiI0MzgwMDY3OSIsInJvbCI6IlJPTEVfUkVHSVNURVIiLCJpc3MiOiJPcGVuWExhYiIsImlhdCI6MTc3MDgyMDM4MCwiY2xpZW50SWQiOiJsa3pkeDU3bnZ5MjJqa3BxOXgydyIsInBob25lIjoiIiwib3BlbklkIjpudWxsLCJ1dWlkIjoiMDVjNTU1NGQtMzBmMi00N2E2LWIxNmMtNWVkYTQ1YjQyNjBlIiwiZW1haWwiOiIiLCJleHAiOjE3Nzg1OTYzODB9.DJ6oMIDkPDBkxY1dpD9uh8gZMcxykpZmR41JUgKkST4_TWifN2WmpCxAVMMUkspmHiSlDQVsG3Gh_J1wI1YAkA",
)

# 支持的文件格式
SUPPORTED_FORMATS = {
    "document": [".pdf", ".doc", ".docx", ".ppt", ".pptx"],
    "image": [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tiff", ".webp"],
    "html": [".html", ".htm"],
}


def get_headers():
    return {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {API_TOKEN}",
    }


def is_url(path: str) -> bool:
    """判断是否为 URL"""
    parsed = urlparse(path)
    return parsed.scheme in ("http", "https")


def get_file_type(path: str) -> str:
    """获取文件类型"""
    ext = Path(path).suffix.lower()
    for ftype, exts in SUPPORTED_FORMATS.items():
        if ext in exts:
            return ftype
    return "unknown"


# ─── 方式一：URL 直接解析（单文件） ───


def create_task_from_url(file_url: str, is_html: bool = False, **kwargs) -> str:
    """通过 URL 创建解析任务，返回 task_id

    对应 API: POST /api/v4/extract/task
    注意: 此接口不支持直接上传文件，只接受 URL
    """
    url = f"{API_BASE}/extract/task"
    headers = get_headers()

    data = {
        "url": file_url,
        "model_version": "MinerU-HTML" if is_html else "vlm",
    }
    # 可选参数透传
    for key in ("is_ocr", "enable_formula", "enable_table", "language",
                "data_id", "extra_formats", "page_ranges"):
        if key in kwargs and kwargs[key] is not None:
            data[key] = kwargs[key]

    resp = requests.post(url, headers=headers, json=data)
    resp.raise_for_status()
    result = resp.json()

    if result.get("code") != 0:
        raise Exception(f"创建任务失败 [code={result.get('code')}]: {result.get('msg')}")

    task_id = result["data"]["task_id"]
    return task_id


def poll_task(task_id: str, timeout: int = 600, interval: int = 5) -> dict:
    """轮询单文件任务状态

    对应 API: GET /api/v4/extract/task/{task_id}
    """
    url = f"{API_BASE}/extract/task/{task_id}"
    headers = get_headers()

    start_time = time.time()
    while time.time() - start_time < timeout:
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        result = resp.json()

        if result.get("code") != 0:
            raise Exception(f"查询任务失败 [code={result.get('code')}]: {result.get('msg')}")

        state = result["data"]["state"]
        progress = result["data"].get("extract_progress", {})

        if state == "running" and progress:
            extracted = progress.get("extracted_pages", "?")
            total = progress.get("total_pages", "?")
            print(f"  解析中: {extracted}/{total} 页", file=sys.stderr)
        else:
            print(f"  任务状态: {state}", file=sys.stderr)

        if state == "done":
            return result["data"]
        elif state == "failed":
            raise Exception(f"任务失败: {result['data'].get('err_msg', '未知错误')}")

        time.sleep(interval)

    raise Exception(f"任务超时 ({timeout}s)")


# ─── 方式二：本地文件上传解析（走 batch 流程） ───


def upload_and_parse_local(file_path: str, is_html: bool = False, **kwargs) -> str:
    """上传本地文件并创建解析任务，返回 batch_id

    流程:
    1. POST /api/v4/file-urls/batch → 获取预签名上传 URL + batch_id
    2. PUT 文件到预签名 URL
    3. 系统自动提交解析任务

    注意: 上传时不需要设置 Content-Type 请求头
    """
    file_name = Path(file_path).name

    # 第一步：获取预签名上传 URL
    url = f"{API_BASE}/file-urls/batch"
    headers = get_headers()

    data = {
        "files": [{"name": file_name}],
        "model_version": "MinerU-HTML" if is_html else "vlm",
    }
    # 可选参数透传
    for key in ("enable_formula", "enable_table", "language",
                "extra_formats"):
        if key in kwargs and kwargs[key] is not None:
            data[key] = kwargs[key]

    print(f"  获取上传凭证...", file=sys.stderr)
    resp = requests.post(url, headers=headers, json=data)
    resp.raise_for_status()
    result = resp.json()

    if result.get("code") != 0:
        raise Exception(f"获取上传凭证失败 [code={result.get('code')}]: {result.get('msg')}")

    batch_id = result["data"]["batch_id"]
    file_urls = result["data"]["file_urls"]

    if not file_urls:
        raise Exception("未获取到上传 URL")

    upload_url = file_urls[0]

    # 第二步：PUT 文件到预签名 URL（注意：不设置 Content-Type）
    print(f"  上传文件: {file_name}", file=sys.stderr)
    with open(file_path, "rb") as f:
        upload_resp = requests.put(upload_url, data=f)
        if upload_resp.status_code != 200:
            raise Exception(
                f"文件上传失败 [status={upload_resp.status_code}]: {upload_resp.text[:200]}"
            )

    print(f"  上传成功，batch_id: {batch_id}", file=sys.stderr)
    return batch_id


def poll_batch(batch_id: str, timeout: int = 600, interval: int = 5) -> dict:
    """轮询 batch 任务状态

    对应 API: GET /api/v4/extract-results/batch/{batch_id}
    """
    url = f"{API_BASE}/extract-results/batch/{batch_id}"
    headers = get_headers()

    start_time = time.time()
    while time.time() - start_time < timeout:
        resp = requests.get(url, headers=headers)
        resp.raise_for_status()
        result = resp.json()

        if result.get("code") != 0:
            raise Exception(f"查询批次失败 [code={result.get('code')}]: {result.get('msg')}")

        extract_results = result["data"].get("extract_result", [])
        if not extract_results:
            print(f"  等待文件处理...", file=sys.stderr)
            time.sleep(interval)
            continue

        # 只上传了一个文件，取第一个结果
        file_result = extract_results[0]
        state = file_result.get("state", "unknown")
        progress = file_result.get("extract_progress", {})

        if state == "running" and progress:
            extracted = progress.get("extracted_pages", "?")
            total = progress.get("total_pages", "?")
            print(f"  解析中: {extracted}/{total} 页", file=sys.stderr)
        else:
            print(f"  任务状态: {state}", file=sys.stderr)

        if state == "done":
            return file_result
        elif state == "failed":
            raise Exception(f"任务失败: {file_result.get('err_msg', '未知错误')}")

        time.sleep(interval)

    raise Exception(f"任务超时 ({timeout}s)")


# ─── 下载结果 ───


def download_result(result_data: dict, output_dir: Path) -> Path:
    """下载转换结果（ZIP 包，解压后包含 Markdown + 图片）"""
    output_dir.mkdir(parents=True, exist_ok=True)

    full_zip_url = result_data.get("full_zip_url")

    if not full_zip_url:
        raise Exception("未找到结果下载链接 (full_zip_url)")

    # 下载 ZIP
    print(f"  下载结果...", file=sys.stderr)
    zip_path = output_dir / "result.zip"
    resp = requests.get(full_zip_url, stream=True)
    resp.raise_for_status()

    total_size = int(resp.headers.get("content-length", 0))
    downloaded = 0
    with open(zip_path, "wb") as f:
        for chunk in resp.iter_content(chunk_size=8192):
            f.write(chunk)
            downloaded += len(chunk)
            if total_size > 0:
                pct = downloaded * 100 // total_size
                print(f"\r  下载: {pct}%", end="", file=sys.stderr)
    print(file=sys.stderr)

    # 解压
    import zipfile

    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(output_dir)
    zip_path.unlink()

    # 查找 Markdown 文件
    md_files = list(output_dir.rglob("*.md"))
    if md_files:
        print(f"  Markdown: {md_files[0]}", file=sys.stderr)

    print(f"  结果已保存到: {output_dir}", file=sys.stderr)
    return output_dir


# ─── 主流程 ───


def convert(
    input_path: str,
    output_dir: str = None,
    is_html: bool = False,
    timeout: int = 600,
    **kwargs,
) -> Path:
    """主转换函数

    自动判断输入类型：
    - URL → 直接调用单文件解析 API
    - 本地文件 → 走 batch 上传流程
    """
    # 确定输出目录
    if output_dir:
        out_path = Path(output_dir)
    elif is_url(input_path):
        out_path = Path("./mineru_output")
    else:
        out_path = Path(input_path).parent / f"{Path(input_path).stem}_mineru"

    if is_url(input_path):
        # ─── URL 模式：直接解析 ───
        print(f"[URL 模式] 提交解析: {input_path}", file=sys.stderr)
        task_id = create_task_from_url(input_path, is_html, **kwargs)
        print(f"  任务 ID: {task_id}", file=sys.stderr)

        print("  等待解析完成...", file=sys.stderr)
        result = poll_task(task_id, timeout=timeout)

    else:
        # ─── 本地文件模式：batch 上传 ───
        if not Path(input_path).exists():
            raise FileNotFoundError(f"文件不存在: {input_path}")

        print(f"[本地文件模式] 上传并解析: {input_path}", file=sys.stderr)
        batch_id = upload_and_parse_local(input_path, is_html, **kwargs)

        print("  等待解析完成...", file=sys.stderr)
        result = poll_batch(batch_id, timeout=timeout)

    # 下载结果
    return download_result(result, out_path)


def main():
    parser = argparse.ArgumentParser(
        description="MinerU 文档转换 (PDF/DOCX/PPT/图片/HTML → Markdown)"
    )
    parser.add_argument("input", help="输入文件路径或 URL")
    parser.add_argument("-o", "--output", help="输出目录")
    parser.add_argument("--html", action="store_true", help="HTML 模式")
    parser.add_argument("--timeout", type=int, default=600, help="超时时间(秒)")
    parser.add_argument("--model", choices=["vlm", "pipeline"], default="vlm",
                        help="模型版本 (默认: vlm)")

    args = parser.parse_args()

    try:
        result_path = convert(args.input, args.output, args.html, args.timeout)
        print(f"\n转换完成: {result_path}")
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
