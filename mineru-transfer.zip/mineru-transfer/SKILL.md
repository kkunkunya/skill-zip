---
name: mineru-transfer
description: "MinerU 文档转换工具（基于 VLM 的高质量 OCR）。支持 PDF、DOCX、PPT、图片、HTML → Markdown。当用户需要：(1) 提取 PDF/文档内容为 Markdown；(2) 转换 Word/PPT 为可编辑文本；(3) OCR 识别图片中的文字；(4) 保存网页为 Markdown 时使用此技能。触发词：mineru、pdf转markdown、文档提取、ocr识别。"
---

# MinerU 文档转换

基于 MinerU API (VLM 模型) 的高质量文档转换，支持版面分析和 OCR。

## 支持格式

| 输入格式 | 说明 |
|----------|------|
| PDF | 扫描件/电子版均可 |
| DOCX/DOC | Word 文档 |
| PPTX/PPT | PowerPoint 演示文稿 |
| 图片 | PNG/JPG/JPEG/GIF/BMP/TIFF/WEBP |
| HTML | 网页文件或 URL |

**输出格式**: Markdown + 图片资源

## 快速使用

```bash
# 本地文件
python scripts/mineru_convert.py document.pdf
python scripts/mineru_convert.py presentation.pptx
python scripts/mineru_convert.py image.png

# URL 文件
python scripts/mineru_convert.py https://example.com/doc.pdf

# HTML 模式
python scripts/mineru_convert.py page.html --html
python scripts/mineru_convert.py https://example.com --html

# 指定输出目录
python scripts/mineru_convert.py document.pdf -o ./output
```

## 参数说明

| 参数 | 说明 |
|------|------|
| `input` | 输入文件路径或 URL |
| `-o, --output` | 输出目录（默认：`{文件名}_mineru/`）|
| `--html` | HTML 模式（用于网页转换）|
| `--timeout` | 超时时间，默认 600 秒 |

## 输出结构

```
output_dir/
├── output.md          # Markdown 内容
└── images/            # 提取的图片
    ├── page_1_img_1.png
    └── ...
```

## API 配置

脚本内置 API Token，也可通过环境变量覆盖：

```bash
export MINERU_API_TOKEN="your_token"
```

## 依赖

```bash
pip install requests
```
