# UI/UX Pro Max 经验积累

> 本文档由技能执行过程中动态更新，记录有效模式和失败教训。
> 更新原则：精炼而非堆砌，同类经验只保留最有效的 3-5 条，过时经验直接替换。

## 有效模式

- **配色安全组合**：深色背景 + 高对比度文字（slate-900 on white, white on slate-900）永远不会出错；渐变色限制在 2-3 色，避免彩虹效果
- **响应式断点**：优先 mobile-first，关键断点 sm:640px / md:768px / lg:1024px / xl:1280px；卡片网格用 `grid-cols-1 md:grid-cols-2 lg:grid-cols-3`
- **字体搭配法则**：标题用 serif/display + 正文用 sans-serif 是最安全的组合；中文项目用 Inter + Noto Sans SC 兼容性最好
- **玻璃态使用场景**：深色背景上效果好（bg-white/10 backdrop-blur-xl），浅色背景上需要提高不透明度（bg-white/80）否则内容不可读
- **动画克制原则**：transition-all duration-200 覆盖 90% 场景；hover 只改颜色/阴影/透明度，避免 scale 导致布局抖动

## 失败教训

（初始为空，使用过程中积累）

## 待验证假设

（初始为空，使用过程中积累）

---
*最近更新：2026-02-17*
