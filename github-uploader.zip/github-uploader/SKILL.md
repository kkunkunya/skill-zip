---
name: github-uploader
description: Uploads current project to GitHub with one command. Automatically initializes git repository, creates GitHub remote repository, and pushes code. Activates when users request "upload to GitHub", "publish to GitHub", "create GitHub repository", or "push project".
context: fork
---

# GitHub Uploader

一键将项目上传到 GitHub。

## 使用方式

运行脚本：

```bash
bash "<skill-path>/scripts/upload.sh" --path "." --visibility "private"
```

### 参数

| 参数 | 必需 | 默认值 | 说明 |
|------|------|--------|------|
| `-p, --path` | 否 | `.` | 项目路径 |
| `-n, --name` | 否 | 目录名 | GitHub 仓库名 |
| `-v, --visibility` | 否 | `private` | `public` 或 `private` |
| `-d, --description` | 否 | 空 | 仓库描述 |

### 示例

```bash
# 上传当前目录为私有仓库
bash "scripts/upload.sh"

# 上传为公开仓库，指定名称和描述
bash "scripts/upload.sh" -n "my-project" -v "public" -d "我的项目"

# 上传指定目录
bash "scripts/upload.sh" -p "/Users/kunkun/Projects/myapp" -v "public"
```

## 脚本流程

1. 检查 gh CLI 是否可用
2. 初始化 git 仓库（如不存在）
3. 创建 .gitignore（如不存在）
4. 提交所有更改
5. 创建 GitHub 仓库并推送

## 前提条件

- 已安装 gh CLI (`brew install gh`)
- 已认证 gh (`gh auth login`)
