#!/bin/bash
# Input: 项目路径, 仓库名称, 可见性(public/private), 描述
# Output: 创建 GitHub 仓库并推送代码
# Pos: github-uploader 技能核心脚本

set -e

# 默认值
PATH_ARG="."
REPO_NAME=""
VISIBILITY="private"
DESCRIPTION=""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        -p|--path)
            PATH_ARG="$2"
            shift 2
            ;;
        -n|--name)
            REPO_NAME="$2"
            shift 2
            ;;
        -v|--visibility)
            VISIBILITY="$2"
            shift 2
            ;;
        -d|--description)
            DESCRIPTION="$2"
            shift 2
            ;;
        *)
            echo -e "${RED}未知参数: $1${NC}"
            exit 1
            ;;
    esac
done

# 验证 visibility
if [[ "$VISIBILITY" != "public" && "$VISIBILITY" != "private" ]]; then
    echo -e "${RED}错误: visibility 必须是 'public' 或 'private'${NC}"
    exit 1
fi

# 切换到项目目录
PROJECT_PATH=$(cd "$PATH_ARG" && pwd)
cd "$PROJECT_PATH"
PROJECT_NAME=$(basename "$PROJECT_PATH")

# 如果未指定仓库名，使用目录名
if [[ -z "$REPO_NAME" ]]; then
    REPO_NAME="$PROJECT_NAME"
fi

echo -e "\n${CYAN}[1/5] 检查 gh CLI...${NC}"
if ! gh --version &>/dev/null; then
    echo -e "${RED}错误: gh CLI 未安装或未配置${NC}"
    exit 1
fi
echo -e "${GREEN}✓ gh CLI 已就绪${NC}"

echo -e "\n${CYAN}[2/5] 检查 Git 仓库...${NC}"
if [[ ! -d ".git" ]]; then
    echo -e "${YELLOW}初始化 Git 仓库...${NC}"
    git init
    echo -e "${GREEN}✓ Git 仓库已初始化${NC}"
else
    echo -e "${GREEN}✓ Git 仓库已存在${NC}"
fi

echo -e "\n${CYAN}[3/5] 检查 .gitignore...${NC}"
if [[ ! -f ".gitignore" ]]; then
    echo -e "${YELLOW}创建基础 .gitignore...${NC}"
    cat > .gitignore << 'EOF'
# 常见忽略项
.env
.env.local
*.log
node_modules/
__pycache__/
*.pyc
.venv/
venv/
dist/
build/
.idea/
.vscode/
*.suo
*.user
.DS_Store
EOF
    echo -e "${GREEN}✓ .gitignore 已创建${NC}"
else
    echo -e "${GREEN}✓ .gitignore 已存在${NC}"
fi

echo -e "\n${CYAN}[4/5] 提交代码...${NC}"
git add -A
if [[ -n $(git status --porcelain) ]]; then
    git commit -m "Initial commit"
    echo -e "${GREEN}✓ 代码已提交${NC}"
else
    if git log --oneline -1 &>/dev/null; then
        echo -e "${GREEN}✓ 无新变更，跳过提交${NC}"
    else
        echo -e "${YELLOW}警告: 没有文件可提交${NC}"
    fi
fi

echo -e "\n${CYAN}[5/5] 创建 GitHub 仓库并推送...${NC}"

# 检查远程仓库是否已存在
if REMOTE_URL=$(git remote get-url origin 2>/dev/null); then
    echo -e "${YELLOW}远程仓库已配置: $REMOTE_URL${NC}"
    echo -e "${YELLOW}推送到现有仓库...${NC}"
    CURRENT_BRANCH=$(git branch --show-current)
    git push -u origin "$CURRENT_BRANCH"
else
    # 创建新仓库
    echo -e "${YELLOW}创建仓库: $REPO_NAME ($VISIBILITY)...${NC}"
    GH_ARGS=("repo" "create" "$REPO_NAME" "--source=." "--push" "--$VISIBILITY")
    if [[ -n "$DESCRIPTION" ]]; then
        GH_ARGS+=("--description=$DESCRIPTION")
    fi
    gh "${GH_ARGS[@]}"
fi

echo -e "\n${GREEN}========================================${NC}"
echo -e "${GREEN}✓ 完成! 仓库已上传到 GitHub${NC}"
echo -e "${GREEN}========================================${NC}\n"

# 显示仓库 URL
if REPO_URL=$(gh repo view --json url -q ".url" 2>/dev/null); then
    echo -e "${CYAN}仓库地址: $REPO_URL${NC}"
fi
