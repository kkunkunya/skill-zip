---
name: autodl-deployer
description: "AutoDL GPU云平台项目部署与迁移工具。当用户需要：(1) 将本地PyTorch/深度学习项目迁移到AutoDL；(2) 生成AutoDL一键部署脚本；(3) 打包项目适配AutoDL环境；(4) 配置国内源加速和省钱策略时使用此技能。触发词：autodl、GPU租用、云GPU、深度学习部署、训练环境迁移、autodl部署。"
---

# AutoDL Deployer

将本地深度学习项目快速部署到 AutoDL GPU 云平台的一键工具。

## 推荐环境

| 项目 | 版本 |
|------|------|
| PyTorch | **2.8.0** |
| Python | **3.12** |
| CUDA | **12.8** |

## 核心功能

1. **智能项目分析** - 自动检测项目依赖和GPU需求
2. **一键部署脚本** - 生成 `autodl_setup.sh` 自动配置环境
3. **智能运行脚本** - `autodl_run.sh` 支持 uv/pip 自动检测
4. **国内源加速** - 配置 pip/conda/HuggingFace 镜像
5. **省钱策略集成** - 无卡模式、自动关机等最佳实践
6. **项目打包** - 生成 AutoDL 适配的 ZIP 包

## AutoDL 目录结构

| 路径 | 用途 | 大小 | 特点 |
|------|------|------|------|
| `/root/autodl-tmp/` | 数据盘 | 50GB+ | 存放代码和数据，关机保留，**不含在镜像中** |
| `/root/autodl-fs/` | 文件存储 | 20GB免费 | **跨实例共享**，网络盘 |
| `/` (系统盘) | 环境依赖 | 30GB | pip包安装位置，含在镜像中 |

## 工作流程

### 1. 分析项目

```bash
# 运行项目分析脚本
python scripts/analyze_project.py /path/to/your/project
```

输出示例：
```
📊 项目分析报告
├── 框架: PyTorch 2.8.0
├── Python: 3.12
├── CUDA: 需要 12.8+
├── 依赖数: 45 个
├── 数据集大小: 2.3GB
├── 预计显存需求: 8GB+
└── 推荐GPU: RTX 4090 / A100
```

### 2. 生成部署包

```bash
# 生成 AutoDL 部署包
python scripts/pack_for_autodl.py /path/to/your/project -o ./autodl_package
```

生成内容：
```
autodl_package/
├── project.zip           # 项目代码压缩包
├── autodl_setup.sh       # 一键部署脚本（支持 uv）
├── requirements.txt      # 依赖清单
└── README_AUTODL.md      # AutoDL 使用指南
```

### 3. 在 AutoDL 上部署

```bash
# 1. 上传文件到 AutoDL 实例 /root/autodl-tmp/

# 2. 运行部署脚本
chmod +x autodl_setup.sh && ./autodl_setup.sh

# 3. 开始训练（两种方式）
python train.py
# 或使用智能运行脚本
./autodl_run.sh train.py

# 4. 训练完自动关机
./autodl_run.sh train.py true
```

## 省钱策略

### 无卡模式（配置环境时使用）

价格：**￥0.1/小时**（正常GPU约 ￥2-5/小时）

```bash
# 在 AutoDL 控制台选择「无卡模式」开机
# 适用于：
# - 上传数据
# - 配置环境
# - 调试代码
```

### 自动关机

```python
# 在训练脚本末尾添加
import os
if __name__ == "__main__":
    # ... 训练代码 ...
    os.system("/usr/bin/shutdown")  # 训练完自动关机
```

或命令行方式：
```bash
python train.py && /usr/bin/shutdown
```

### 升降配置

- 调试时：使用 1 卡
- 训练时：升级到多卡
- 操作：关机 → 更多 → 升降配置

## 国内源配置

### pip 源（清华）

```bash
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

### conda 源

```bash
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main
conda config --set show_channel_urls yes
```

### HuggingFace 镜像

```bash
export HF_ENDPOINT=https://hf-mirror.com
```

### 学术加速（AutoDL 内置）

```bash
source /etc/network_turbo      # 开启
unset http_proxy && unset https_proxy  # 关闭
```

## 常见问题

### GPU 不可用

```bash
# 检查 CUDA
nvidia-smi
python -c "import torch; print(torch.cuda.is_available())"
```

### 磁盘空间不足

```bash
# 清理 pip 缓存
pip cache purge

# 清理 conda 缓存
conda clean -a

# 查看磁盘使用
source /root/.bashrc  # 显示各目录使用情况
```

### 端口访问

AutoDL 默认开放端口：**6006**（TensorBoard）

自定义端口需配置 SSH 隧道：
```bash
ssh -L 8080:localhost:8080 root@<host> -p <port>
```

## 脚本说明

| 脚本 | 功能 |
|------|------|
| `scripts/analyze_project.py` | 分析项目依赖和GPU需求 |
| `scripts/pack_for_autodl.py` | 打包项目为AutoDL格式 |
| `scripts/autodl_setup.sh` | **一键环境配置**（uv/pip 智能检测） |
| `scripts/autodl_run.sh` | **智能运行脚本**（支持自动关机） |

### autodl_setup.sh 功能

- 锁定清华 PyPI 镜像
- 配置 HuggingFace 镜像
- **智能检测 uv**：有 uv 用 `uv pip install`，无则用 `pip install`
- 验证 GPU 环境

### autodl_run.sh 用法

```bash
./autodl_run.sh                    # 运行 train.py
./autodl_run.sh train.py           # 运行指定脚本
./autodl_run.sh train.py true      # 运行后自动关机
./autodl_run.sh src/main.py 1      # 运行自定义脚本后关机
```

## 参考资料

- [AutoDL 官方文档](https://www.autodl.com/docs/quick_start/)
- [AutoDL 省钱绝招](https://www.autodl.com/docs/save_money/)
- `references/autodl_best_practices.md` - 最佳实践详解
