---
name: autodl-deployer
description: "AutoDL GPU云平台项目部署与迁移工具。默认交换路径：/root/autodl-fs/（上传下载都走这里，无data/子目录）。当用户需要：(1) 将本地PyTorch/深度学习项目迁移到AutoDL；(2) 生成AutoDL一键部署脚本；(3) 打包项目适配AutoDL环境；(4) 配置国内源加速和省钱策略时使用此技能。触发词：autodl、GPU租用、云GPU、深度学习部署、训练环境迁移、autodl部署。"
---

# AutoDL Deployer

将本地深度学习项目快速部署到 AutoDL GPU 云平台的一键工具。

## 默认交换路径（铁律）

> **所有上传/下载操作统一走 `/root/autodl-fs/`，这是 AutoDL 的跨实例共享文件存储。**

- 上传文件 → `scp ... root@host:/root/autodl-fs/`
- 下载结果 → `scp -P PORT root@host:/root/autodl-fs/results.tar.gz ./`
- 项目代码 → `/root/autodl-fs/<项目名>/`
- **禁止假设 `/root/autodl-fs/data/` 存在** — 文件直接在 `/root/autodl-fs/` 根下

## 推荐环境

| 项目 | 版本 |
|------|------|
| PyTorch | **2.8.0** |
| Python | **3.12** |
| CUDA | **12.8** |

## 核心功能

1. **一键部署脚本** - 生成 `autodl_setup.sh` 自动配置环境（复用系统 PyTorch，不建 venv）
2. **智能运行脚本** - `autodl_run.sh` 自动 export PYTHONPATH + 运行训练流程
3. **增量更新脚本** - `autodl_update.sh` 自动查找包并解压更新
4. **国内源加速** - 配置 pip/conda/HuggingFace 镜像
5. **省钱策略集成** - 无卡模式、自动关机等最佳实践
6. **项目打包** - 生成 AutoDL 适配的 tar.gz 包

## AutoDL 目录结构

| 路径 | 用途 | 大小 | 特点 |
|------|------|------|------|
| `/root/autodl-tmp/` | 数据盘 | 50GB+ | 本地SSD，存放代码和数据，关机保留，**不含在镜像中** |
| `/root/autodl-fs/` | 文件存储 | 20GB免费 | **跨实例共享**，网络盘，上传文件**直接在此目录下** |
| `/` (系统盘) | 环境依赖 | 30GB | pip包安装位置，含在镜像中 |

> **⚠️ 路径踩坑**：上传到文件存储的文件**直接在 `/root/autodl-fs/` 下**，不存在 `data/` 子目录。脚本中不要硬编码路径，应用代码自动查找。

## 部署前思考清单

部署前，逐一思考以下问题（结合经验文档中的历史教训）：

1. **环境兼容性**：目标实例的 GPU 架构是什么？预装的 PyTorch 版本支持吗？需要创建 venv 吗？
2. **依赖管理**：项目依赖有哪些？哪些需要从国内源安装？哪些已经预装了？
3. **路径配置**：项目代码放哪里？PYTHONPATH 设置了吗？文件存储路径对吗？
4. **运行时验证**：CUDA 真的能用吗（不只是 is_available）？API 有跨版本兼容问题吗？
5. **可观测性**：训练有终端实时输出吗？日志写到哪里？
6. **成本控制**：用无卡模式配环境了吗？训练完自动关机了吗？

以下是历史踩坑记录，供参考（但不要被限制，新环境可能有新问题）：

> 以下 6 个问题均在 RTX 5090 (PyTorch 2.8 + CUDA 12.8 + Python 3.12) 实例上实际遇到并修复

### 坑1: 不建 venv，复用系统 PyTorch

**问题**：创建 `.venv` 后从 PyPI 安装的 PyTorch 不支持新架构 GPU（如 RTX 5090 sm_120），报 `CUDA error: no kernel image is available`。

**规则**：
- ❌ 不创建 `.venv` 或 `conda env`
- ❌ 不重新安装 PyTorch（`pip install torch` 从 cu121 源装的版本只支持 sm_50~sm_90）
- ✅ 直接复用 AutoDL 镜像预装的 PyTorch（已匹配 GPU 架构）
- ✅ 只用 `pip install` 补装缺失的小包（gymnasium, seaborn 等）

### 坑2: PYTHONPATH 双保险

**问题**：`python src/train.py` 时 Python 把 `src/` 加入 sys.path，而非项目根目录，导致 `from src.xxx` 失败。

**规则**：
- ❌ 不用 `pip install -e .`（非标准环境可能失败）
- ✅ `autodl_setup.sh` 写入 `~/.bashrc` 永久生效
- ✅ `autodl_run.sh` 每次运行时 `export PYTHONPATH="$PROJECT_DIR:${PYTHONPATH:-}"`
- 双保险：即使忘了 `source ~/.bashrc`，run 脚本也能正常工作

### 坑3: CUDA 兼容性运行时检测

**问题**：`torch.cuda.is_available()` 返回 True，但实际执行 CUDA 计算时崩溃（架构不兼容）。

**规则**：训练代码中必须加入运行时检测：
```python
def _cuda_usable() -> bool:
    if not torch.cuda.is_available():
        return False
    try:
        torch.zeros(1, device="cuda")
        return True
    except RuntimeError:
        return False
```
不兼容时自动回退 CPU，而非直接崩溃。

### 坑4: PyTorch 跨版本 API 兼容

**问题**：PyTorch 2.8 将 `CudaDeviceProperties.total_mem` 重命名为 `total_memory`，直接访问报 AttributeError。

**规则**：用 `getattr` 兜底：
```python
props = torch.cuda.get_device_properties(0)
mem_gb = getattr(props, 'total_memory', getattr(props, 'total_mem', 0)) / 1024**3
```

### 坑5: 文件存储路径不硬编码

**问题**：假设 `/root/autodl-fs/data/` 存在，实际文件直接在 `/root/autodl-fs/` 下。

**规则**：脚本中用自动查找逻辑：
```bash
for candidate in "/root/autodl-fs" "/root/autodl-tmp" "."; do
    if [ -f "$candidate/autodl_package.tar.gz" ]; then
        PACKAGE_PATH="$candidate/autodl_package.tar.gz"
        break
    fi
done
```

### 坑6: 服务器训练必须有实时终端输出

**问题**：训练代码只写文件日志，终端空白，无法判断进度和问题。

**规则**：
- ✅ 每 N 个 episode 用 `print(..., flush=True)` 输出一行
- ✅ 包含：进度、奖励、移动均值、速度、ETA、是否刷新最优
- ✅ 训练开始时输出启动横幅（算法、设备、GPU型号、显存、参数）
- ✅ 文件日志可以简化，但终端输出必须详尽
- 推荐格式：
```
[11:40:05] EP   10/3000 | R= -201.4 | avg20= -220.5 | cost= 1102.3 | viol=0.025 | speed=14.2 ep/s | ETA=3.5min
```

## 部署脚本说明

### autodl_setup.sh（一键环境配置）

功能：
1. 自动定位项目根目录，写 PYTHONPATH 到 `~/.bashrc`
2. 配置 pip 清华源
3. 智能检测依赖：逐个 `python -c "import xxx"` 检测，只装缺失的（跳过 torch）
4. 验证环境：Python版本、PyTorch、CUDA可用性（try tensor）、GPU型号+显存、项目模块可导入

### autodl_run.sh（训练运行脚本）

功能：
1. 自动 `export PYTHONPATH`（不依赖 bashrc）
2. 顺序运行训练流程（可自定义）
3. 完成后打包结果为 `results.tar.gz`

用法：
```bash
bash scripts/autodl_run.sh                    # 运行全部训练
bash scripts/autodl_run.sh && /usr/bin/shutdown  # 训练完自动关机
```

### autodl_update.sh（增量更新）

功能：
1. 自动从多个候选路径查找 `autodl_package.tar.gz`
2. 自动查找项目目录
3. 解压覆盖 + 重新 export PYTHONPATH

## 工作流程

### Phase 0：读取经验（自动）

读取 `references/deploy-experience.md`，了解历史积累的有效模式和失败教训，指导本次部署。

### 本地打包

```bash
# 排除不需要的文件
tar -czf autodl_package.tar.gz \
    --exclude='.venv' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='.DS_Store' \
    --exclude='papers' \
    --exclude='log' \
    --exclude='results' \
    -C /path/to/project .
```

### AutoDL 部署（完整流程）

```bash
# 1. 上传 autodl_package.tar.gz 到 AutoDL 文件存储
#    文件会出现在 /root/autodl-fs/（不是 /root/autodl-fs/data/）

# 2. 解压到项目目录
cd /root/autodl-fs
mkdir -p 项目名
tar -xzf autodl_package.tar.gz -C 项目名
cd 项目名

# 3. 一键配置环境（复用系统 PyTorch，只补缺失包）
bash scripts/autodl_setup.sh
source ~/.bashrc

# 4. 运行训练（自动关机版）
bash scripts/autodl_run.sh && /usr/bin/shutdown

# 5. 下载结果到本地
```

### 增量更新

```bash
# 本地重新打包后上传到 autodl-fs
# 然后在 AutoDL 上：
bash scripts/autodl_update.sh
```

## 生成脚本模板

生成 `autodl_setup.sh` 时，遵循以下模板：

```bash
#!/usr/bin/env bash
set -euo pipefail

# 1. 定位项目 + PYTHONPATH
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REAL_PROJECT_DIR="$(cd "$PROJECT_DIR" && pwd -P)"
if ! grep -q "PYTHONPATH.*项目标识" ~/.bashrc 2>/dev/null; then
    echo "export PYTHONPATH=\"${REAL_PROJECT_DIR}:\${PYTHONPATH:-}\"" >> ~/.bashrc
fi
export PYTHONPATH="${REAL_PROJECT_DIR}:${PYTHONPATH:-}"

# 2. 配置清华源
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple 2>/dev/null || true

# 3. 智能检测依赖（跳过 torch）
REQUIRED_PACKAGES=("gymnasium:gymnasium" "numpy:numpy" ...)
for entry in "${REQUIRED_PACKAGES[@]}"; do
    IMPORT_NAME="${entry%%:*}"
    PIP_NAME="${entry##*:}"
    python -c "import $IMPORT_NAME" 2>/dev/null || MISSING+=("$PIP_NAME")
done
[ ${#MISSING[@]} -gt 0 ] && pip install "${MISSING[@]}"

# 4. 验证（含 CUDA 运行时检测 + getattr 兼容）
python -c "
import torch
# ... 版本信息 ...
try:
    torch.zeros(1, device='cuda')
    print('CUDA 计算: 正常')
except RuntimeError:
    print('[WARN] CUDA 计算不可用，将回退到 CPU')

props = torch.cuda.get_device_properties(0)
mem_gb = getattr(props, 'total_memory', getattr(props, 'total_mem', 0)) / 1024**3
"
```

## 省钱策略

### 无卡模式（配置环境时使用）

价格：**￥0.1/小时**（正常GPU约 ￥2-5/小时）

```bash
# 在 AutoDL 控制台选择「无卡模式」开机
# 适用于：上传数据、配置环境、调试代码
```

### 自动关机

```bash
# 命令行方式（推荐）
bash scripts/autodl_run.sh && /usr/bin/shutdown

# 代码方式
import os
os.system("/usr/bin/shutdown")
```

> **注意**：自动关机后标准输出不可见，确保关键信息已写入日志文件。

### 升降配置

- 调试时：使用 1 卡
- 训练时：升级到多卡
- 操作：关机 → 更多 → 升降配置

## 国内源配置

```bash
# pip 清华源
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# HuggingFace 镜像
export HF_ENDPOINT=https://hf-mirror.com

# 学术加速（AutoDL 内置）
source /etc/network_turbo      # 开启
unset http_proxy && unset https_proxy  # 关闭
```

## 常见问题

### GPU 不可用

```bash
nvidia-smi
python -c "import torch; print(torch.cuda.is_available())"
# 如果 is_available() 为 True 但计算报错，说明架构不兼容
# → 检查是否在 venv 里装了旧版 PyTorch
```

### ModuleNotFoundError: No module named 'src'

```bash
# 原因：PYTHONPATH 未设置
export PYTHONPATH="/root/autodl-fs/项目名:${PYTHONPATH:-}"
# 或重新运行 setup
bash scripts/autodl_setup.sh && source ~/.bashrc
```

### CUDA error: no kernel image is available

```bash
# 原因：PyTorch 版本不支持当前 GPU 架构
# 解决：删除 .venv，复用系统预装 PyTorch
deactivate 2>/dev/null; rm -rf .venv
python -c "import torch; torch.zeros(1, device='cuda')"  # 验证
```

## 参考资料

- [AutoDL 官方文档](https://www.autodl.com/docs/quick_start/)
- [AutoDL 省钱绝招](https://www.autodl.com/docs/save_money/)
- `references/autodl_best_practices.md` - 最佳实践详解

## Phase N+1：更新经验（自动）

回顾本次部署过程，更新 `references/deploy-experience.md`：
- 新发现的有效模式 → 更新"有效模式"（替换弱的，保留强的）
- 遇到的失败 → 更新"失败教训"（同类只保留最典型的）
- 未验证的想法 → 记入"待验证假设"
- 更新原则：精炼而非堆砌，文档不超过 150 行
