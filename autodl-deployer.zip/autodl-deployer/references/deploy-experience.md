# AutoDL Deployer 经验积累

> 本文档由技能执行过程中动态更新，记录有效模式和失败教训。
> 更新原则：精炼而非堆砌，同类经验只保留最有效的 3-5 条，过时经验直接替换。

## 有效模式

- 复用系统 PyTorch：AutoDL 镜像预装的 PyTorch 已匹配 GPU 架构，直接用 `pip install` 补装小包即可
- PYTHONPATH 双保险：`~/.bashrc` 永久写入 + `autodl_run.sh` 每次运行时 export，避免遗漏
- CUDA 运行时检测：`torch.zeros(1, device="cuda")` 比 `torch.cuda.is_available()` 更可靠
- 文件路径自动查找：用 for 循环遍历候选路径（`/root/autodl-fs`、`/root/autodl-tmp`、`.`），不硬编码
- 无卡模式配环境：0.1 元/小时 vs GPU 模式 2-5 元/小时，环境配置阶段必用无卡模式

## 失败教训

- venv 导致 GPU 不兼容：在 `.venv` 中从 PyPI 安装的 PyTorch 只支持 sm_50~sm_90，RTX 5090 (sm_120) 直接崩溃
- 硬编码路径 `/root/autodl-fs/data/`：实际文件直接在 `/root/autodl-fs/` 下，不存在 `data/` 子目录
- 无终端输出：只写文件日志导致无法判断训练进度，必须 `print(..., flush=True)` 实时输出
- PyTorch 2.8 API 变更：`total_mem` 改名为 `total_memory`，需用 `getattr` 兜底兼容

## 待验证假设

（初始为空，使用过程中积累）

---
*最近更新：2026-02-17*
