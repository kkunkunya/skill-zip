# AutoDL 最佳实践详解

## 推荐环境版本

| 项目 | 推荐版本 |
|------|----------|
| PyTorch | **2.8.0** |
| Python | **3.12** |
| CUDA | **12.8** |

## 目录结构详解

### 系统盘 (/)
- **大小**: 30GB
- **性能**: 本地SSD，快速
- **用途**:
  - 系统依赖
  - Python 包 (pip install)
  - Conda 环境
  - 小型代码文件
- **迁移**: 会随实例迁移
- **镜像**: 会保存到镜像中

### 数据盘 (/root/autodl-tmp/)
- **大小**: 50GB起，可扩容
- **性能**: 本地SSD，快速
- **用途**:
  - 训练代码
  - 数据集
  - 模型权重
  - 训练日志
- **迁移**: 需使用"迁移实例（同地区）"功能
- **镜像**: **不会**保存到镜像

### 文件存储 (/root/autodl-fs/)
- **大小**: 免费20GB，超出计费
- **性能**: 网络盘，一般
- **⚠️ 实际路径**: 上传的文件**直接在 `/root/autodl-fs/` 下**，不存在 `data/` 子目录
- **用途**:
  - 跨实例共享数据
  - 多机多卡训练的共享存储
  - 重要文件备份
- **特点**: 同地区所有实例可访问

> **踩坑记录**：之前文档中写的 `/root/autodl-fs/data/` 路径**不存在**。实际验证发现上传的文件和文件夹直接在 `/root/autodl-fs/` 目录下。脚本中不要硬编码此路径，应使用自动查找逻辑。

### 公共数据 (/root/autodl-pub/)
- **性能**: 网络盘，慢
- **用途**: 平台公共模型和数据集
- **特点**: 只读

## 省钱策略

### 1. 无卡模式

**价格**: ￥0.1/小时（GPU实例约 ￥2-5/小时）

**适用场景**:
- 上传/下载数据
- 配置环境
- 调试代码
- 安装依赖

**使用方法**:
1. 关机
2. 点击「更多」→「无卡模式开机」

**注意事项**:
- 同一主账号只能有一个无卡模式实例
- 无卡模式会释放GPU，正常开机时GPU可能已被占用

### 2. 自动关机

**场景**: 不确定训练时长，希望完成后自动关机

**命令行方式**:
```bash
# 无论成功与否都关机
python train.py; /usr/bin/shutdown

# 成功后才关机（推荐）
bash scripts/autodl_run.sh && /usr/bin/shutdown
```

**注意**: 请保存好程序日志，自动关机后标准输出中的日志不可见

### 3. 升降配置

**场景**: 调试用1卡，训练用多卡

**操作**:
1. 关机
2. 点击「更多」→「升降配置」
3. 选择新的GPU数量
4. 开机

**资源分配规则**:
- CPU: 8核/GPU
- 内存: 32GB/GPU
- 例如2卡 = 16核CPU + 64GB内存

### 4. 保存镜像

**用途**: 环境配置好后保存，下次直接使用

**操作**:
1. 关机
2. 点击「更多」→「保存镜像」
3. 命名并保存

**注意**:
- 只保存系统盘（/），不包含数据盘
- 镜像大小会影响启动速度

## 数据传输

### 小文件 (<1GB)
- JupyterLab 上传按钮
- 简单但速度慢

### 中等文件 (1-10GB)
- SCP/SFTP
- FileZilla
- VSCode Remote

### 大文件 (>10GB)
- **公网网盘**（强烈推荐）
- 操作：控制台 → 网盘 → 上传 → 实例中访问

### 数据集下载
```bash
# 开启学术加速
source /etc/network_turbo

# 下载数据
wget https://...

# 关闭学术加速
unset http_proxy && unset https_proxy
```

## 国内源配置

### pip
```bash
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

### conda
```bash
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main
conda config --set show_channel_urls yes
```

### HuggingFace
```bash
export HF_ENDPOINT=https://hf-mirror.com
echo 'export HF_ENDPOINT=https://hf-mirror.com' >> ~/.bashrc
```

### 学术资源加速（AutoDL内置）
```bash
source /etc/network_turbo  # 开启
unset http_proxy && unset https_proxy  # 关闭
```

## 远程开发

### VSCode Remote (推荐)
1. 安装 Remote-SSH 扩展
2. 配置 SSH Host
3. 连接到实例

### PyCharm Professional
1. 设置 SSH Interpreter
2. 配置 Deployment (SFTP)
3. 启用自动同步

### JupyterLab
- 直接浏览器访问
- 适合数据探索和快速实验

## 常见问题

### GPU 不可用
```bash
# 检查 CUDA
nvidia-smi

# 检查 PyTorch
python -c "import torch; print(torch.cuda.is_available())"

# 检查 CUDA 是否真正可用（不仅是 available）
python -c "import torch; torch.zeros(1, device='cuda'); print('OK')"
```

### 磁盘空间不足
```bash
# 查看磁盘使用
source /root/.bashrc

# 清理 pip 缓存
pip cache purge

# 清理 conda 缓存
conda clean -a

# 查找大文件
du -sh /* | sort -rh | head -20
```

### 端口访问
- 默认开放: 6006 (TensorBoard)
- 自定义端口: 使用 SSH 隧道

```bash
# 本地终端执行
ssh -L 8080:localhost:8080 root@<host> -p <port>
```

### 进程后台运行
```bash
# 使用 tmux（推荐）
tmux new -s train
bash scripts/autodl_run.sh
# Ctrl+B+D 分离
# tmux attach -t train 恢复

# 使用 nohup
nohup bash scripts/autodl_run.sh > train.log 2>&1 &
```

## 推荐工作流

1. **创建实例**: 选择预装 PyTorch 的镜像（匹配 GPU 架构）
2. **无卡模式开机**: 配置环境（省钱）
3. **上传代码**: 到 `/root/autodl-fs/`（跨实例共享）或 `/root/autodl-tmp/`（本地高速）
4. **一键配置**: `bash scripts/autodl_setup.sh && source ~/.bashrc`（复用系统 PyTorch，只补缺失包）
5. **正常开机**: 切换到GPU模式
6. **运行训练**: `bash scripts/autodl_run.sh && /usr/bin/shutdown`（自动关机）
7. **保存镜像**: 环境配置好后保存备用

### 关键原则（防踩坑 Checklist）

- [ ] **不建 venv** — 复用 AutoDL 镜像预装的 PyTorch + CUDA
- [ ] **不装 PyTorch** — 镜像已匹配 GPU 架构，自己装必出兼容问题
- [ ] **PYTHONPATH** — setup 写 bashrc + run 每次 export，双保险
- [ ] **CUDA 检测** — 代码中 `_cuda_usable()` 试运行 tensor，不兼容回退 CPU
- [ ] **PyTorch API 兼容** — 用 `getattr` 兜底属性名变更（如 total_mem → total_memory）
- [ ] **实时输出** — 服务器训练必须 `print(..., flush=True)`，不能只写文件
- [ ] **不硬编码路径** — 自动查找项目目录和包路径（autodl-fs 下无 data/ 子目录）

## 实战踩坑总览

| # | 问题 | 根因 | 修复 |
|---|------|------|------|
| 1 | `ModuleNotFoundError: No module named 'src'` | Python 不识别 src 包 | `export PYTHONPATH=项目根` |
| 2 | `CUDA error: no kernel image` | venv 的 PyTorch 不支持新 GPU | 去掉 venv，复用系统 PyTorch |
| 3 | venv 导致 PyTorch 版本冲突 | setup 从 cu121 源装旧版 | 删除 venv 逻辑 |
| 4 | `autodl-fs/data/` 不存在 | 硬编码了错误路径 | 自动查找，不硬编码 |
| 5 | `total_mem` AttributeError | PyTorch 2.8 重命名属性 | `getattr` 双层兜底 |
| 6 | 训练无终端输出 | 只写文件日志 | 加 `print(flush=True)` 实时输出 |
