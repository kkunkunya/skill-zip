# AutoDL 最佳实践详解

## 推荐环境版本

| 项目 | 推荐版本 |
|------|----------|
| PyTorch | **2.8.0** |
| Python | **3.12** |
| CUDA | **12.8** |

## 目录结构详解

### 系统盘 (/)
- **大小**: 30GB
- **性能**: 本地SSD，快速
- **用途**:
  - 系统依赖
  - Python 包 (pip install)
  - Conda 环境
  - 小型代码文件
- **迁移**: 会随实例迁移
- **镜像**: 会保存到镜像中

### 数据盘 (/root/autodl-tmp/)
- **大小**: 50GB起，可扩容
- **性能**: 本地SSD，快速
- **用途**:
  - 训练代码
  - 数据集
  - 模型权重
  - 训练日志
- **迁移**: 需使用"迁移实例（同地区）"功能
- **镜像**: **不会**保存到镜像

### 文件存储 (/root/autodl-fs/)
- **大小**: 免费20GB，超出计费
- **性能**: 网络盘，一般
- **用途**:
  - 跨实例共享数据
  - 多机多卡训练的共享存储
  - 重要文件备份
- **特点**: 同地区所有实例可访问

### 公共数据 (/root/autodl-pub/)
- **性能**: 网络盘，慢
- **用途**: 平台公共模型和数据集
- **特点**: 只读

## 省钱策略

### 1. 无卡模式

**价格**: ￥0.1/小时（GPU实例约 ￥2-5/小时）

**适用场景**:
- 上传/下载数据
- 配置环境
- 调试代码
- 安装依赖

**使用方法**:
1. 关机
2. 点击「更多」→「无卡模式开机」

**注意事项**:
- 同一主账号只能有一个无卡模式实例
- 无卡模式会释放GPU，正常开机时GPU可能已被占用

### 2. 自动关机

**场景**: 不确定训练时长，希望完成后自动关机

**命令行方式**:
```bash
# 无论成功与否都关机
python train.py; /usr/bin/shutdown

# 成功后才关机
python train.py && /usr/bin/shutdown
```

**代码方式**:
```python
import os

if __name__ == "__main__":
    # 训练代码...
    train()

    # 训练完成后关机
    os.system("/usr/bin/shutdown")
```

**注意**: 请保存好程序日志，自动关机后标准输出中的日志不可见

### 3. 升降配置

**场景**: 调试用1卡，训练用多卡

**操作**:
1. 关机
2. 点击「更多」→「升降配置」
3. 选择新的GPU数量
4. 开机

**资源分配规则**:
- CPU: 8核/GPU
- 内存: 32GB/GPU
- 例如2卡 = 16核CPU + 64GB内存

### 4. 保存镜像

**用途**: 环境配置好后保存，下次直接使用

**操作**:
1. 关机
2. 点击「更多」→「保存镜像」
3. 命名并保存

**注意**:
- 只保存系统盘（/），不包含数据盘
- 镜像大小会影响启动速度

## 数据传输

### 小文件 (<1GB)
- JupyterLab 上传按钮
- 简单但速度慢

### 中等文件 (1-10GB)
- SCP/SFTP
- FileZilla
- VSCode Remote

### 大文件 (>10GB)
- **公网网盘**（强烈推荐）
- 操作：控制台 → 网盘 → 上传 → 实例中访问

### 数据集下载
```bash
# 开启学术加速
source /etc/network_turbo

# 下载数据
wget https://...

# 关闭学术加速
unset http_proxy && unset https_proxy
```

## 国内源配置

### pip
```bash
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple
```

### conda
```bash
conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main
conda config --set show_channel_urls yes
```

### HuggingFace
```bash
export HF_ENDPOINT=https://hf-mirror.com
echo 'export HF_ENDPOINT=https://hf-mirror.com' >> ~/.bashrc
```

### 学术资源加速（AutoDL内置）
```bash
source /etc/network_turbo  # 开启
unset http_proxy && unset https_proxy  # 关闭
```

## 远程开发

### VSCode Remote (推荐)
1. 安装 Remote-SSH 扩展
2. 配置 SSH Host
3. 连接到实例

### PyCharm Professional
1. 设置 SSH Interpreter
2. 配置 Deployment (SFTP)
3. 启用自动同步

### JupyterLab
- 直接浏览器访问
- 适合数据探索和快速实验

## 常见问题

### GPU 不可用
```bash
# 检查 CUDA
nvidia-smi

# 检查 PyTorch
python -c "import torch; print(torch.cuda.is_available())"

# 检查 TensorFlow
python -c "import tensorflow as tf; print(tf.config.list_physical_devices('GPU'))"
```

### 磁盘空间不足
```bash
# 查看磁盘使用
source /root/.bashrc

# 清理 pip 缓存
pip cache purge

# 清理 conda 缓存
conda clean -a

# 查找大文件
du -sh /* | sort -rh | head -20
```

### 端口访问
- 默认开放: 6006 (TensorBoard)
- 自定义端口: 使用 SSH 隧道

```bash
# 本地终端执行
ssh -L 8080:localhost:8080 root@<host> -p <port>
```

### 进程后台运行
```bash
# 使用 nohup
nohup python train.py > train.log 2>&1 &

# 使用 screen
screen -S train
python train.py
# Ctrl+A+D 分离
# screen -r train 恢复

# 使用 tmux
tmux new -s train
python train.py
# Ctrl+B+D 分离
# tmux attach -t train 恢复
```

## 推荐工作流

1. **创建实例**: 选择合适的镜像和GPU
2. **无卡模式开机**: 配置环境（省钱）
3. **上传代码**: 使用公网网盘或 SCP
4. **一键配置**: `./autodl_setup.sh`（自动检测 uv/pip）
5. **正常开机**: 切换到GPU模式
6. **智能训练**: `./autodl_run.sh train.py true`（自动关机）
7. **保存镜像**: 环境配置好后保存备用

## uv 包管理器支持

如果项目使用 uv 作为包管理器，`autodl_setup.sh` 会自动检测并使用：

```bash
# 自动检测逻辑
if command -v uv &> /dev/null; then
    uv pip install -r requirements.txt
else
    pip install -r requirements.txt
fi
```

### uv 优势

- **更快**: 比 pip 快 10-100 倍
- **更可靠**: 更好的依赖解析
- **兼容**: 与 pip 命令兼容

### 在 AutoDL 安装 uv

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
source ~/.bashrc
```
