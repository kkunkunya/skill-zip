#!/bin/bash
# ============================================
# AutoDL 智能运行脚本
# 自动判断 uv/pip 环境，支持自动关机
# ============================================
#
# 用法:
#   ./autodl_run.sh [脚本] [自动关机]
#
# 参数:
#   脚本       - Python 脚本路径 (默认: train.py)
#   自动关机   - true/1 启用自动关机 (默认: false)
#
# 示例:
#   ./autodl_run.sh                    # 运行 train.py
#   ./autodl_run.sh train.py           # 运行 train.py
#   ./autodl_run.sh train.py true      # 运行后自动关机
#   ./autodl_run.sh src/main.py 1      # 运行自定义脚本后关机

set -e

SCRIPT=${1:-train.py}
AUTO_SHUTDOWN=${2:-false}

echo "🚀 AutoDL 智能运行"
echo "   脚本: $SCRIPT"
echo "   自动关机: $AUTO_SHUTDOWN"
echo ""

# 检查脚本是否存在
if [ ! -f "$SCRIPT" ]; then
    echo "❌ 错误: 脚本不存在: $SCRIPT"
    exit 1
fi

# 智能运行
if command -v uv &> /dev/null; then
    echo "📦 检测到 uv，使用 uv run"
    uv run python "$SCRIPT"
else
    echo "📦 使用 python"
    python "$SCRIPT"
fi

# 运行结果
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo "✅ 脚本执行完成"
else
    echo ""
    echo "❌ 脚本执行失败 (退出码: $EXIT_CODE)"
fi

# 自动关机
if [ "$AUTO_SHUTDOWN" = "true" ] || [ "$AUTO_SHUTDOWN" = "1" ]; then
    echo ""
    echo "⏰ 10秒后自动关机..."
    echo "   按 Ctrl+C 取消"
    sleep 10
    echo "🔌 正在关机..."
    /usr/bin/shutdown
fi
