#!/usr/bin/env python3
"""
AutoDL 项目分析工具
分析本地深度学习项目，检测依赖和GPU需求
"""

import os
import sys
import json
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def find_requirements_file(project_path: Path) -> Optional[Path]:
    """查找 requirements.txt 或 pyproject.toml"""
    candidates = [
        project_path / "requirements.txt",
        project_path / "requirements-dev.txt",
        project_path / "pyproject.toml",
        project_path / "setup.py",
    ]
    for f in candidates:
        if f.exists():
            return f
    return None


def parse_requirements(req_file: Path) -> List[str]:
    """解析依赖文件"""
    deps = []
    if req_file.suffix == ".txt":
        with open(req_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and not line.startswith("-"):
                    # 提取包名（去除版本号）
                    pkg = re.split(r"[<>=!~\[]", line)[0].strip()
                    if pkg:
                        deps.append(pkg)
    elif req_file.name == "pyproject.toml":
        content = req_file.read_text(encoding="utf-8")
        # 简单解析 dependencies
        match = re.search(r'dependencies\s*=\s*\[(.*?)\]', content, re.DOTALL)
        if match:
            deps_str = match.group(1)
            for item in re.findall(r'"([^"]+)"', deps_str):
                pkg = re.split(r"[<>=!~\[]", item)[0].strip()
                if pkg:
                    deps.append(pkg)
    return deps


def detect_framework(deps: List[str]) -> Tuple[str, str]:
    """检测深度学习框架和版本"""
    framework_map = {
        "torch": "PyTorch",
        "pytorch": "PyTorch",
        "tensorflow": "TensorFlow",
        "keras": "Keras",
        "jax": "JAX",
        "paddlepaddle": "PaddlePaddle",
        "mindspore": "MindSpore",
    }

    for dep in deps:
        dep_lower = dep.lower()
        for key, name in framework_map.items():
            if key in dep_lower:
                return name, "latest"
    return "Unknown", "N/A"


def detect_cuda_requirement(deps: List[str], project_path: Path) -> str:
    """检测CUDA需求"""
    # 检查是否有 GPU 相关代码
    gpu_patterns = [
        r"\.cuda\(\)",
        r"\.to\(['\"]cuda['\"]\)",
        r"torch\.device\(['\"]cuda",
        r"tf\.device\(['\"]GPU",
        r"with tf\.device",
    ]

    for py_file in project_path.rglob("*.py"):
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            for pattern in gpu_patterns:
                if re.search(pattern, content):
                    return "11.8+ (推荐)"
        except:
            continue

    # 检查依赖中是否有 CUDA 相关
    cuda_deps = ["cupy", "pycuda", "numba"]
    for dep in deps:
        if any(cd in dep.lower() for cd in cuda_deps):
            return "11.8+ (推荐)"

    return "可选"


def estimate_gpu_memory(project_path: Path) -> str:
    """估算GPU显存需求"""
    # 检查模型配置文件
    config_patterns = [
        "**/config.json",
        "**/model_config.json",
        "**/*.yaml",
        "**/*.yml",
    ]

    large_model_keywords = [
        "bert-large", "gpt2-large", "gpt2-xl", "llama", "vicuna",
        "bloom", "falcon", "mistral", "qwen", "chatglm",
    ]

    for pattern in config_patterns:
        for config_file in project_path.glob(pattern):
            try:
                content = config_file.read_text(encoding="utf-8", errors="ignore").lower()
                for keyword in large_model_keywords:
                    if keyword in content:
                        return "24GB+ (大模型)"
            except:
                continue

    # 检查训练脚本中的 batch_size
    for py_file in project_path.rglob("*.py"):
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
            batch_match = re.search(r"batch_size\s*=\s*(\d+)", content)
            if batch_match:
                batch_size = int(batch_match.group(1))
                if batch_size >= 64:
                    return "16GB+"
                elif batch_size >= 32:
                    return "12GB+"
                else:
                    return "8GB+"
        except:
            continue

    return "8GB+ (默认)"


def calculate_project_size(project_path: Path) -> Tuple[float, int]:
    """计算项目大小和文件数"""
    total_size = 0
    file_count = 0

    exclude_dirs = {".git", "__pycache__", ".venv", "venv", "node_modules", ".idea"}
    exclude_exts = {".pyc", ".pyo", ".so", ".o", ".a"}

    for root, dirs, files in os.walk(project_path):
        # 排除目录
        dirs[:] = [d for d in dirs if d not in exclude_dirs]

        for f in files:
            if Path(f).suffix not in exclude_exts:
                file_path = Path(root) / f
                try:
                    total_size += file_path.stat().st_size
                    file_count += 1
                except:
                    continue

    return total_size / (1024 * 1024), file_count  # MB


def recommend_gpu(memory_req: str) -> str:
    """推荐GPU型号"""
    if "24GB" in memory_req:
        return "RTX 4090 / A100 40GB"
    elif "16GB" in memory_req:
        return "RTX 4090 / RTX 3090"
    elif "12GB" in memory_req:
        return "RTX 4080 / RTX 3090"
    else:
        return "RTX 3090 / RTX 4070"


def analyze_project(project_path: str) -> Dict:
    """分析项目并返回报告"""
    path = Path(project_path).resolve()

    if not path.exists():
        return {"error": f"项目路径不存在: {project_path}"}

    # 查找依赖文件
    req_file = find_requirements_file(path)
    deps = parse_requirements(req_file) if req_file else []

    # 检测框架
    framework, version = detect_framework(deps)

    # 检测CUDA需求
    cuda_req = detect_cuda_requirement(deps, path)

    # 估算GPU显存
    memory_req = estimate_gpu_memory(path)

    # 计算项目大小
    size_mb, file_count = calculate_project_size(path)

    # 推荐GPU
    gpu_recommend = recommend_gpu(memory_req)

    report = {
        "project_name": path.name,
        "project_path": str(path),
        "framework": framework,
        "python_version": "3.10 (推荐)",
        "cuda_requirement": cuda_req,
        "dependencies_count": len(deps),
        "dependencies_file": str(req_file) if req_file else "未找到",
        "project_size_mb": round(size_mb, 2),
        "file_count": file_count,
        "gpu_memory_estimate": memory_req,
        "gpu_recommendation": gpu_recommend,
    }

    return report


def print_report(report: Dict):
    """打印分析报告"""
    if "error" in report:
        print(f"❌ 错误: {report['error']}")
        return

    print("\n📊 项目分析报告")
    print("=" * 50)
    print(f"├── 项目名称: {report['project_name']}")
    print(f"├── 框架: {report['framework']}")
    print(f"├── Python: {report['python_version']}")
    print(f"├── CUDA: {report['cuda_requirement']}")
    print(f"├── 依赖数: {report['dependencies_count']} 个")
    print(f"├── 依赖文件: {report['dependencies_file']}")
    print(f"├── 项目大小: {report['project_size_mb']} MB ({report['file_count']} 文件)")
    print(f"├── 预计显存需求: {report['gpu_memory_estimate']}")
    print(f"└── 推荐GPU: {report['gpu_recommendation']}")
    print("=" * 50)

    # AutoDL 建议
    print("\n💡 AutoDL 部署建议:")
    print(f"   1. 选择镜像: PyTorch 2.x + CUDA 11.8")
    print(f"   2. 推荐机型: {report['gpu_recommendation']}")
    print(f"   3. 数据盘: 建议扩容到 {max(100, int(report['project_size_mb'] * 3))} GB")
    print(f"   4. 使用无卡模式上传数据和配置环境（￥0.1/小时）")


def main():
    if len(sys.argv) < 2:
        print("用法: python analyze_project.py <项目路径>")
        print("示例: python analyze_project.py /path/to/my-project")
        sys.exit(1)

    project_path = sys.argv[1]
    report = analyze_project(project_path)

    # 打印报告
    print_report(report)

    # 保存JSON报告
    output_file = Path(project_path) / "autodl_analysis.json"
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n📄 详细报告已保存: {output_file}")


if __name__ == "__main__":
    main()
