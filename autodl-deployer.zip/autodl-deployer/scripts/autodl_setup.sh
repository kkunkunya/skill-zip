#!/bin/bash
# ============================================
# AutoDL 一键环境配置脚本
# PyTorch 2.8.0 + Python 3.12 + CUDA 12.8
# ============================================

set -e

echo "🚀 AutoDL 环境配置开始..."
echo ""

# 1. 锁定清华 PyPI 镜像
echo "📦 配置 pip 清华镜像..."
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 2. 配置 HuggingFace 镜像
echo "🤗 配置 HuggingFace 镜像..."
export HF_ENDPOINT=https://hf-mirror.com
if ! grep -q "HF_ENDPOINT" ~/.bashrc 2>/dev/null; then
    echo 'export HF_ENDPOINT=https://hf-mirror.com' >> ~/.bashrc
fi

# 3. 智能安装依赖 (uv 优先，无则 pip)
echo ""
echo "📥 安装项目依赖..."
if [ -f "requirements.txt" ]; then
    if command -v uv &> /dev/null; then
        echo "   检测到 uv，使用 uv pip install"
        uv pip install -r requirements.txt
    else
        echo "   未检测到 uv，使用 pip install"
        pip install -r requirements.txt
    fi
elif [ -f "pyproject.toml" ]; then
    if command -v uv &> /dev/null; then
        echo "   检测到 uv，使用 uv pip install"
        uv pip install -e .
    else
        echo "   未检测到 uv，使用 pip install"
        pip install -e .
    fi
else
    echo "   ⚠️ 未找到 requirements.txt 或 pyproject.toml"
fi

# 4. 验证 GPU 环境
echo ""
echo "🔍 验证 GPU 环境..."
python -c "
import torch
print(f'PyTorch 版本: {torch.__version__}')
print(f'CUDA 可用: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'CUDA 版本: {torch.version.cuda}')
    print(f'GPU 设备: {torch.cuda.get_device_name(0)}')
    print(f'GPU 数量: {torch.cuda.device_count()}')
" || echo "⚠️ PyTorch 未安装或 GPU 不可用"

echo ""
echo "✅ 环境配置完成！"
echo ""
echo "💡 下一步:"
echo "   1. 运行训练: python train.py"
echo "   2. 或使用智能运行脚本: ./autodl_run.sh train.py"
echo ""
echo "💰 省钱提示:"
echo "   - 自动关机: ./autodl_run.sh train.py true"
echo "   - 或命令行: python train.py && /usr/bin/shutdown"
