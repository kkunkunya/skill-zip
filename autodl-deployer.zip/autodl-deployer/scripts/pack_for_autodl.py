#!/usr/bin/env python3
"""
AutoDL 项目打包工具
将本地项目打包为 AutoDL 适配格式，生成一键部署脚本
"""

import os
import sys
import json
import shutil
import zipfile
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Optional


# 默认排除的目录和文件
DEFAULT_EXCLUDES = [
    ".git",
    ".gitignore",
    "__pycache__",
    "*.pyc",
    "*.pyo",
    ".venv",
    "venv",
    "env",
    ".env",
    "node_modules",
    ".idea",
    ".vscode",
    "*.egg-info",
    "dist",
    "build",
    ".pytest_cache",
    ".mypy_cache",
    "*.log",
    ".DS_Store",
    "Thumbs.db",
    # 大文件
    "*.zip",
    "*.tar.gz",
    "*.rar",
    "*.7z",
    # 数据文件（建议单独上传）
    "*.h5",
    "*.hdf5",
    "*.pkl",
    "*.pickle",
    "*.pt",
    "*.pth",
    "*.ckpt",
    "*.safetensors",
]


def should_exclude(path: Path, excludes: List[str]) -> bool:
    """检查路径是否应该排除"""
    name = path.name
    for pattern in excludes:
        if pattern.startswith("*"):
            if name.endswith(pattern[1:]):
                return True
        elif name == pattern:
            return True
    return False


def create_zip(source_dir: Path, output_file: Path, excludes: List[str]) -> int:
    """创建ZIP压缩包，返回文件数"""
    file_count = 0
    with zipfile.ZipFile(output_file, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(source_dir):
            # 过滤目录
            dirs[:] = [d for d in dirs if not should_exclude(Path(d), excludes)]

            for file in files:
                file_path = Path(root) / file
                if not should_exclude(file_path, excludes):
                    arcname = file_path.relative_to(source_dir)
                    try:
                        zf.write(file_path, arcname)
                        file_count += 1
                    except Exception as e:
                        print(f"  ⚠️ 跳过文件: {file_path} ({e})")
    return file_count


def generate_setup_script(project_name: str, has_requirements: bool) -> str:
    """生成 AutoDL 一键部署脚本（支持 uv 智能检测）"""
    script = f'''#!/bin/bash
# ============================================
# AutoDL 一键部署脚本
# 项目: {project_name}
# 生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
# 推荐环境: PyTorch 2.8.0 + Python 3.12 + CUDA 12.8
# ============================================

set -e  # 遇到错误立即退出

echo "🚀 开始部署 {project_name}..."

# 1. 配置国内源
echo "📦 配置 pip 清华镜像..."
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 2. 配置 HuggingFace 镜像
echo "🤗 配置 HuggingFace 镜像..."
export HF_ENDPOINT=https://hf-mirror.com
if ! grep -q "HF_ENDPOINT" ~/.bashrc 2>/dev/null; then
    echo 'export HF_ENDPOINT=https://hf-mirror.com' >> ~/.bashrc
fi

# 3. 解压项目（如果是压缩包）
if [ -f "project.zip" ]; then
    echo "📂 解压项目文件..."
    unzip -o project.zip -d ./{project_name}
    cd {project_name}
fi

# 4. 智能安装依赖（uv 优先）
'''
    if has_requirements:
        script += '''echo "📥 安装项目依赖..."
if [ -f "requirements.txt" ]; then
    if command -v uv &> /dev/null; then
        echo "   检测到 uv，使用 uv pip install"
        uv pip install -r requirements.txt
    else
        echo "   使用 pip install"
        pip install -r requirements.txt
    fi
elif [ -f "pyproject.toml" ]; then
    if command -v uv &> /dev/null; then
        echo "   检测到 uv，使用 uv pip install"
        uv pip install -e .
    else
        echo "   使用 pip install"
        pip install -e .
    fi
fi
'''
    else:
        script += '''echo "⚠️ 未找到 requirements.txt，请手动安装依赖"
'''

    script += '''
# 5. 验证环境
echo "🔍 验证 GPU 环境..."
python -c "
import torch
print(f'PyTorch 版本: {torch.__version__}')
print(f'CUDA 可用: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'CUDA 版本: {torch.version.cuda}')
    print(f'GPU 设备: {torch.cuda.get_device_name(0)}')
" || echo "⚠️ PyTorch 未安装或 GPU 不可用"

echo ""
echo "✅ 部署完成！"
echo ""
echo "💡 下一步:"
echo "   1. cd {project_name}"
echo "   2. python train.py  # 或您的训练脚本"
echo "   3. ./autodl_run.sh train.py true  # 智能运行+自动关机"
echo ""
echo "💰 省钱提示:"
echo "   - 使用智能运行脚本自动关机: ./autodl_run.sh train.py true"
echo "   - 或命令行方式: python train.py && /usr/bin/shutdown"
'''
    return script


def generate_readme(project_name: str, analysis: dict) -> str:
    """生成 AutoDL 使用说明"""
    readme = f'''# {project_name} - AutoDL 部署指南

## 快速开始

### 1. 上传文件
将以下文件上传到 AutoDL 实例的 `/root/autodl-tmp/` 目录：
- `project.zip` - 项目代码
- `setup_autodl.sh` - 部署脚本

### 2. 运行部署脚本
```bash
cd /root/autodl-tmp
chmod +x setup_autodl.sh
./setup_autodl.sh
```

### 3. 开始训练
```bash
cd {project_name}
python train.py  # 替换为您的训练脚本
```

## 项目信息

| 项目 | 值 |
|------|-----|
| 框架 | {analysis.get('framework', 'PyTorch 2.8.0')} |
| Python | {analysis.get('python_version', '3.12')} |
| CUDA | {analysis.get('cuda_requirement', '12.8+')} |
| 推荐GPU | {analysis.get('gpu_recommendation', 'RTX 4090 / A100')} |

## 省钱技巧

### 1. 无卡模式配置环境
- 在 AutoDL 控制台选择「无卡模式」开机
- 价格：￥0.1/小时
- 适用：上传数据、配置环境、调试代码

### 2. 训练完自动关机
```bash
# 命令行方式
python train.py && /usr/bin/shutdown

# 或在代码中添加
import os
os.system("/usr/bin/shutdown")
```

### 3. 灵活升降配置
- 调试时用 1 卡
- 训练时升级到多卡

## 常见问题

### GPU 不可用
```bash
nvidia-smi
python -c "import torch; print(torch.cuda.is_available())"
```

### 磁盘空间不足
```bash
pip cache purge
conda clean -a
```

### 查看磁盘使用
```bash
source /root/.bashrc
```

## 目录说明

| 路径 | 用途 |
|------|------|
| `/root/autodl-tmp/` | 数据盘（存放代码和数据） |
| `/root/autodl-fs/` | 文件存储（跨实例共享） |

---
生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
'''
    return readme


def pack_project(
    project_path: str,
    output_dir: str,
    excludes: Optional[List[str]] = None,
) -> dict:
    """打包项目为 AutoDL 格式"""

    source = Path(project_path).resolve()
    output = Path(output_dir).resolve()

    if not source.exists():
        return {"error": f"项目路径不存在: {project_path}"}

    # 创建输出目录
    output.mkdir(parents=True, exist_ok=True)

    project_name = source.name
    excludes = excludes or DEFAULT_EXCLUDES

    print(f"\n📦 打包项目: {project_name}")
    print(f"   源目录: {source}")
    print(f"   输出目录: {output}")

    # 检查 requirements.txt
    has_requirements = (source / "requirements.txt").exists() or (source / "pyproject.toml").exists()

    # 尝试加载分析报告
    analysis_file = source / "autodl_analysis.json"
    analysis = {}
    if analysis_file.exists():
        with open(analysis_file, "r", encoding="utf-8") as f:
            analysis = json.load(f)

    # 1. 创建 ZIP
    print("\n📁 创建项目压缩包...")
    zip_file = output / "project.zip"
    file_count = create_zip(source, zip_file, excludes)
    zip_size = zip_file.stat().st_size / (1024 * 1024)
    print(f"   ✅ project.zip ({file_count} 文件, {zip_size:.2f} MB)")

    # 2. 生成部署脚本
    print("\n📝 生成部署脚本...")
    setup_script = generate_setup_script(project_name, has_requirements)
    setup_file = output / "setup_autodl.sh"
    setup_file.write_text(setup_script, encoding="utf-8")
    print(f"   ✅ setup_autodl.sh")

    # 3. 复制 requirements.txt
    if (source / "requirements.txt").exists():
        shutil.copy(source / "requirements.txt", output / "requirements.txt")
        print(f"   ✅ requirements.txt")

    # 4. 生成 README
    print("\n📄 生成使用说明...")
    readme = generate_readme(project_name, analysis)
    readme_file = output / "README_AUTODL.md"
    readme_file.write_text(readme, encoding="utf-8")
    print(f"   ✅ README_AUTODL.md")

    print("\n" + "=" * 50)
    print("✅ 打包完成！")
    print("=" * 50)
    print(f"\n输出文件:")
    for f in output.iterdir():
        size = f.stat().st_size / 1024
        print(f"   📄 {f.name} ({size:.1f} KB)")

    print(f"\n💡 下一步:")
    print(f"   1. 将 {output} 目录中的文件上传到 AutoDL")
    print(f"   2. 在 AutoDL 终端运行: ./setup_autodl.sh")

    return {
        "success": True,
        "project_name": project_name,
        "output_dir": str(output),
        "files": [f.name for f in output.iterdir()],
        "zip_size_mb": round(zip_size, 2),
        "file_count": file_count,
    }


def main():
    parser = argparse.ArgumentParser(
        description="将项目打包为 AutoDL 适配格式",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python pack_for_autodl.py /path/to/my-project
  python pack_for_autodl.py /path/to/my-project -o ./autodl_package
  python pack_for_autodl.py /path/to/my-project --exclude "data" "*.csv"
        """
    )
    parser.add_argument("project_path", help="项目路径")
    parser.add_argument("-o", "--output", default="./autodl_package", help="输出目录 (默认: ./autodl_package)")
    parser.add_argument("--exclude", nargs="*", help="额外排除的文件/目录模式")

    args = parser.parse_args()

    excludes = DEFAULT_EXCLUDES.copy()
    if args.exclude:
        excludes.extend(args.exclude)

    result = pack_project(args.project_path, args.output, excludes)

    if "error" in result:
        print(f"\n❌ 错误: {result['error']}")
        sys.exit(1)


if __name__ == "__main__":
    main()
